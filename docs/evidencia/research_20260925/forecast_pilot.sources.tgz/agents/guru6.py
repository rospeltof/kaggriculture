# Copyright (c) 2026 Guru Prasaath S. All rights reserved.
# Author: Guru Prasaath S
# Date: September 23, 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Kaggriculture route-replay chassis (pure Python, stdlib only).

A *route* is a pre-computed tape of 719 Kaggle-format actions
``{"farmer": [op, ...], "hands": [[op, ...], ...], "market": [[order, item, qty], ...]}``.
The chassis replays the tape chosen by a caller-supplied ``router`` and wraps it
in small reactive layers (each independently switchable via ``settings``):

    hand_align            pad/truncate hands to the real hand count      (fieldbook_logic)
    weed_repair           DIG a weed that blocks PLANT/BUILD, replay      (tetsutani + task spec)
    sell_lead             sell next step's lots one step early            (fieldbook _lead_sale)
    front_run             sell before the opponent's scheduled SELL       (hook; opponent_plan)
    budget_guard          fund each 72-step block's purchases             (six_day_budget_guard.hpp)
    room_guard            keep shed <= 99 at hour 23                      (tetsutani)
    clamp_sells           trim SELL orders to the projected shed          (tetsutani)
    dead_stock            sell stock the route will never sell            (tetsutani)
    terminal_liquidation  step >= 718: sell the whole projected shed      (fieldbook _terminal_sale)

Engine facts (verified against kaggle_environments 1.32.7, env_1_32_7.py):
  observation["farms"][p] = {"money", "tiles"[y][x], "farmer"[x,y], "hands"[[x,y]..],
                             "unlocked_quadrants", "hires_today"}
  tiles: None (empty) | "LOCKED" | {"kind": WEED|COOP|PASTURE|PLANT, "crop"/"animal", ...}
  observation["private"] = {"shed": {item: n}, "seeds": {crop: n}, "inventories": [{}...]}
  observation["market"] = {"inventory": {...}, "prices": {...}}
  observation["town"] = {"unlocked_shops": [...]}
  Agents act on steps 0..718 (interpreter marks DONE once step >= episodeSteps-2).
"""
from __future__ import annotations

import copy

PRODUCTS = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER")
SEED_PRICE = {"WHEAT": 10, "CARROT": 20, "TOMATO": 50, "STRAWBERRY": 100, "MELON": 80}
ANIMAL_COST = {"GOOSE": 300, "COW": 400, "SHEEP": 500}
ANIMAL_STRUCTURE = {"GOOSE": "COOP", "COW": "PASTURE", "SHEEP": "PASTURE"}
LAND_PRICES = (1000, 2000, 4000)
MOVES = {"NORTH": (0, -1), "SOUTH": (0, 1), "EAST": (1, 0), "WEST": (-1, 0)}
FRONT_RUN_ITEMS = ("MILK", "WOOL", "STRAWBERRY", "MELON")
LAST_ACT_STEP = 718
PASS_ACTION = {"farmer": ["PASS"], "hands": [], "market": []}

DEFAULT_SETTINGS = {
    "hand_align": True,
    "weed_repair": True,
    "sell_lead": True,
    "front_run": True,
    "budget_guard": True,
    "room_guard": True,
    "clamp_sells": True,
    "dead_stock": True,
    "terminal_liquidation": True,
    "block_turns": 72,
    "shed_capacity": 100,
    "board_size": 10,
    "max_orders": 10,
    "turns_per_day": 24,
    "min_sell_price": 2,
}


def _get(value, key, default=None):
    """Field access that works for dicts and Kaggle Struct/attribute objects."""
    if isinstance(value, dict):
        return value.get(key, default)
    getter = getattr(value, "get", None)
    if callable(getter):
        return getter(key, default)
    return getattr(value, key, default)


def _int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _fib(n):
    a, b = 1, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def _step_of(observation):
    raw = _get(observation, "step")
    if raw is not None:
        return _int(raw)
    return _int(_get(observation, "day", 0)) * 24 + _int(_get(observation, "hour", 0))


def _shed_adjacent(pos, board):
    if not isinstance(pos, (list, tuple)) or len(pos) < 2:
        return False
    half = board // 2
    return pos[0] in (half - 1, half) and pos[1] in (half - 1, half)


def _tile_at(tiles, pos):
    try:
        x, y = int(pos[0]), int(pos[1])
        return tiles[y][x]
    except (TypeError, ValueError, IndexError):
        return "LOCKED"


def _is_noop(act, tile, inv, seeds, pos, board):
    """True when the engine will certainly ignore ``act`` (mirrors _apply_unit_action)."""
    if not act:
        return True
    op = act[0]
    x, y = pos[0], pos[1]
    if op in MOVES:
        dx, dy = MOVES[op]
        return not (0 <= x + dx < board and 0 <= y + dy < board)
    if op == "PASS":
        return True
    adjacent = _shed_adjacent(pos, board)
    if op == "DROP":
        return (not adjacent) or (not inv)
    if op == "PICKUP":
        return not adjacent
    if op == "PLACE":
        item = act[1] if len(act) > 1 else None
        if item in ANIMAL_STRUCTURE and isinstance(tile, dict) \
                and _get(tile, "kind") == ANIMAL_STRUCTURE[item] and _get(tile, "animal") is None:
            return _int(_get(inv, item, 0)) <= 0
        return (not adjacent) or _int(_get(inv, item, 0)) <= 0
    if tile == "LOCKED":
        return True
    is_dict = isinstance(tile, dict)
    kind = _get(tile, "kind") if is_dict else None
    animal = is_dict and _get(tile, "animal") is not None
    if op == "PLANT":
        return tile is not None or _int(_get(seeds, act[1] if len(act) > 1 else None, 0)) <= 0
    if op == "WATER":
        return kind != "PLANT" or bool(_get(tile, "watered_today"))
    if op == "HARVEST":
        return (not is_dict) or _int(_get(tile, "yield_units", 0)) <= 0
    if op == "FERTILIZE":
        return kind != "PLANT" or _int(_get(inv, "FERTILIZER", 0)) <= 0
    if op == "DIG":
        return tile is None or animal
    if op in ("BUILD_COOP", "BUILD_PASTURE"):
        return tile is not None
    if op == "FEED":
        return (not animal) or bool(_get(tile, "fed_today")) or _int(_get(inv, "WHEAT", 0)) <= 0
    if op == "COLLECT_FERTILIZER":
        return (not animal) or (not _get(tile, "fertilizer_available"))
    if op == "CARE":
        return (not animal) or bool(_get(tile, "cared_today"))
    return True


class _View:
    """Cheap per-step snapshot of everything the layers read from the observation."""

    def __init__(self, observation, player, cfg):
        farms = list(_get(observation, "farms", []) or [])
        self.farm = farms[player] if player < len(farms) else {}
        self.rival = farms[1 - player] if len(farms) >= 2 and 1 - player < len(farms) else {}
        private = _get(observation, "private", {}) or {}
        self.shed = {k: max(0, _int(v)) for k, v in dict(_get(private, "shed", {}) or {}).items()}
        self.seeds = dict(_get(private, "seeds", {}) or {})
        self.invs = [dict(i or {}) for i in (_get(private, "inventories", []) or [])]
        market = _get(observation, "market", {}) or {}
        self.prices = {k: _int(v) for k, v in dict(_get(market, "prices", {}) or {}).items()}
        self.money = float(_get(self.farm, "money", 0.0) or 0.0)
        self.tiles = _get(self.farm, "tiles", []) or []
        self.board = len(self.tiles) or cfg["board_size"]
        self.positions = [_get(self.farm, "farmer", None)] + [list(p) for p in (_get(self.farm, "hands", []) or [])]
        self.hires_today = _int(_get(self.farm, "hires_today", 0))
        self.quadrants = len(list(_get(self.farm, "unlocked_quadrants", []) or []))

    def inv(self, idx):
        return self.invs[idx] if idx < len(self.invs) else {}

    def in_hands(self, item):
        return sum(max(0, _int(_get(inv, item, 0))) for inv in self.invs)


class Chassis:
    """Replays ``routes[router(...)]`` with reactive safety/market layers.

    routes         : {route_id: list of >= 719 Kaggle action dicts}
    router         : callable(observation, step, state_dict) -> route_id, called every
                     step; ``state_dict`` is per-player and persists across the game.
    settings       : overrides for DEFAULT_SETTINGS (layer switches + tunables)
    opponent_plan  : optional list of the opponent's expected actions (front_run hook)
    """

    def __init__(self, routes, router=None, settings=None, opponent_plan=None):
        self.routes = {rid: list(tape) for rid, tape in routes.items()}
        self.router = router or (lambda observation, step, state: next(iter(self.routes)))
        self.cfg = dict(DEFAULT_SETTINGS)
        self.cfg.update(settings or {})
        self.opponent_plan = opponent_plan
        self.players = {}
        self.diagnostics = {"layer_fallbacks": 0, "entry_fallbacks": 0}
        self._future_sells = {}   # route id -> {item: [remaining planned SELL qty from step t]}

    def _state(self, player, step):
        st = self.players.get(player)
        if st is None or step == 0 or step <= st["last_step"]:
            st = {"last_step": -1, "route": None, "router_state": {},
                  "pending": {}, "sell_state": {"due_step": -1, "suppress": {}}}
            self.players[player] = st
        st["last_step"] = step
        return st

    def _route_action(self, route, step):
        tape = self.routes[route]
        if 0 <= step < len(tape) and isinstance(tape[step], dict):
            return copy.deepcopy(tape[step])
        return copy.deepcopy(PASS_ACTION)

    def future_sells(self, route, item, step):
        """Planned SELL quantity of ``item`` in route steps >= ``step`` (suffix sums)."""
        table = self._future_sells.get(route)
        if table is None:
            tape = self.routes[route]
            n = len(tape)
            table = {p: [0] * (n + 1) for p in PRODUCTS}
            for t in range(n - 1, -1, -1):
                for p in PRODUCTS:
                    table[p][t] = table[p][t + 1]
                for o in (tape[t].get("market") or []) if isinstance(tape[t], dict) else []:
                    if o and o[0] == "SELL" and len(o) >= 3 and o[1] in table:
                        table[o[1]][t] += max(0, _int(o[2]))
            self._future_sells[route] = table
        col = table.get(item)
        return col[step] if col and 0 <= step < len(col) else 0

    def act(self, observation, configuration=None):
        if len(_get(observation, "farms", []) or []) < 2:
            raise ValueError("incomplete observation")  # factory falls back to tape
        step = _step_of(observation)
        player = _int(_get(observation, "player", 0))
        st = self._state(player, step)
        cfg = self.cfg
        view = _View(observation, player, cfg)

        route = self.router(observation, step, st["router_state"])
        if route not in self.routes:
            route = st["route"] if st["route"] in self.routes else next(iter(self.routes))
        st["route"] = route
        action = self._route_action(route, step)
        raw = copy.deepcopy(action)
        try:
            if cfg["hand_align"]:
                self._hand_align(action, view)
            if cfg["weed_repair"]:
                self._weed_repair(action, view, st, route, step)
            if cfg["sell_lead"] or cfg["front_run"]:
                self._apply_suppression(action, st["sell_state"], step)
            projected = self._projected_shed(action, view)
            lead_available = dict(projected)
            next_sup = {"due_step": -1, "suppress": {}, "r36_debts": st["sell_state"].get("r36_debts", {})}
            if cfg["sell_lead"]:
                self._sell_lead(action, view, lead_available, route, step, next_sup)
            if cfg["front_run"] and self.opponent_plan:
                self._front_run(action, view, lead_available, route, step, next_sup)
            st["sell_state"] = next_sup
            if cfg["budget_guard"]:
                self._budget_guard(action, view, route, step)
            if cfg["room_guard"]:
                self._room_guard(action, view, route, step)
            if cfg["clamp_sells"]:
                self._clamp_sells(action, projected)
            if cfg["dead_stock"]:
                self._dead_stock(action, view, projected, route, step)
            if cfg["terminal_liquidation"]:
                self._terminal_liquidation(action, projected, step)
            action["market"] = action["market"][: cfg["max_orders"]]
            return action
        except Exception:
            self.diagnostics["layer_fallbacks"] += 1
            return raw

    def _hand_align(self, action, view):
        """Pad with PASS / truncate the tape's hand list to the real number of hands
        (fieldbook_logic.act). Extra hands would be ignored by the engine anyway;
        missing ones just idle, so alignment only tidies the action."""
        expected = max(0, len(view.positions) - 1)
        hands = list(action.get("hands") or [])
        hands.extend([["PASS"] for _ in range(max(0, expected - len(hands)))])
        action["hands"] = hands[:expected]

    def _weed_repair(self, action, view, st, route, step):
        """If a PLANT/BUILD_* target tile is a WEED, DIG now and queue the intended
        action for that unit; the queue replays on a later step when the unit still
        stands there and its tape action would be a no-op (the displaced no-op is
        queued behind it, so PLANT -> WATER chains survive). A PLANT is only replayed
        when the unit's next tape action is not a move, so the mandatory same-day
        WATER can follow; otherwise the seed is kept. A no-op turn spent on a weed
        is also converted to DIG (tetsutani weed_dig)."""
        units = [action.get("farmer") or ["PASS"]] + list(action.get("hands") or [])
        pending = st["pending"]
        tape = self.routes[route]
        nxt = tape[step + 1] if step + 1 < len(tape) and isinstance(tape[step + 1], dict) else {}
        next_units = [nxt.get("farmer") or ["PASS"]] + list(nxt.get("hands") or [])
        for i in range(min(len(units), len(view.positions))):
            pos = view.positions[i]
            if not isinstance(pos, (list, tuple)):
                continue
            pos = (int(pos[0]), int(pos[1]))
            tile = _tile_at(view.tiles, pos)
            act = list(units[i])
            queue = pending.get(i)
            if queue and queue[0][0] != pos:
                pending.pop(i, None)
                queue = None
            is_weed = isinstance(tile, dict) and _get(tile, "kind") == "WEED"
            noop = _is_noop(act, tile, view.inv(i), view.seeds, pos, view.board)
            next_op = next_units[i][0] if i < len(next_units) and next_units[i] else "PASS"
            if act and act[0] in ("PLANT", "BUILD_COOP", "BUILD_PASTURE") and is_weed:
                pending.setdefault(i, []).append((pos, act))
                act = ["DIG"]
            elif queue and noop:
                _, replay = queue[0]
                if replay[0] == "PLANT" and next_op in MOVES:
                    pending.pop(i, None)          # WATER could never follow: keep the seed
                else:
                    queue.pop(0)
                    if act and act[0] != "PASS" and act[0] not in MOVES:
                        queue.append((pos, act))
                    act = replay
                    if not queue:
                        pending.pop(i, None)
            elif is_weed and noop:
                act = ["DIG"]
            units[i] = act
        action["farmer"] = units[0]
        action["hands"] = units[1:]

    def _projected_shed(self, action, view):
        """Shed contents after this step's unit actions but before the market runs:
        PICKUP removes, DROP/PLACE(non-animal) near the shed adds up to capacity
        (fieldbook _projected_shed / tetsutani projected shed)."""
        cap = self.cfg["shed_capacity"]
        proj = {p: view.shed.get(p, 0) for p in PRODUCTS}
        for k, v in view.shed.items():
            proj.setdefault(k, v)
        total = sum(proj.values())
        units = [action.get("farmer") or ["PASS"]] + list(action.get("hands") or [])
        for i in range(min(len(units), len(view.positions))):
            if not _shed_adjacent(view.positions[i], view.board):
                continue
            act = units[i]
            op = act[0] if act else "PASS"
            inv = view.inv(i)
            if op == "PICKUP" and len(act) >= 2 and act[1] in proj:
                qty = min(proj[act[1]], max(0, _int(act[2]) if len(act) >= 3 else 1))
                proj[act[1]] -= qty
                total -= qty
            elif op == "DROP":
                for item, held in inv.items():
                    take = min(max(0, _int(held)), max(0, cap - total))
                    if take > 0:
                        proj[item] = proj.get(item, 0) + take
                        total += take
            elif op == "PLACE" and len(act) >= 2 and act[1] not in ANIMAL_STRUCTURE:
                item = act[1]
                take = min(max(0, _int(act[2]) if len(act) >= 3 else 1),
                           max(0, _int(_get(inv, item, 0))), max(0, cap - total))
                if take > 0:
                    proj[item] = proj.get(item, 0) + take
                    total += take
        return proj

    @staticmethod
    def _apply_suppression(action, sell_state, step):
        """Remove from this step's SELLs the quantities already sold a step early."""
        if sell_state.get("due_step") != step:
            return
        remaining = dict(sell_state.get("suppress", {}))
        kept = []
        for order in action.get("market") or []:
            order = list(order)
            if order and order[0] == "SELL" and len(order) >= 3 and remaining.get(order[1], 0) > 0:
                removed = min(max(0, _int(order[2])), remaining[order[1]])
                order[2] = _int(order[2]) - removed
                remaining[order[1]] -= removed
            kept.append(order)
        action["market"] = kept

    @staticmethod
    def _add_sell(action, item, qty, max_orders, merge=True):
        market = action.setdefault("market", [])
        if merge:
            for order in market:
                if order and order[0] == "SELL" and order[1] == item:
                    order[2] = _int(order[2]) + qty
                    return True
        if len(market) >= max_orders:
            return False
        market.append(["SELL", item, qty])
        return True

    def _sell_lead(self, action, view, projected, route, step, next_sup):
        """fieldbook _lead_sale: when step % 4 != 0 (no town consumption between the
        two steps) sell the lots the tape plans to SELL next step now, for products
        other than WHEAT/FERTILIZER we already hold, and suppress them next step.
        Skipped at the last step, at shop-unlock boundaries and if a SELL for that
        product is already queued this step."""
        cfg = self.cfg
        nxt = step + 1
        unlock_period = 3 * cfg["turns_per_day"]
        if nxt > LAST_ACT_STEP or nxt % unlock_period == 0 or step % 4 == 0:
            return
        tape = self.routes[route]
        future = tape[nxt] if nxt < len(tape) and isinstance(tape[nxt], dict) else {}
        planned = {}
        for o in future.get("market") or []:
            if o and o[0] == "SELL" and len(o) >= 3 and o[1] in PRODUCTS:
                planned[o[1]] = planned.get(o[1], 0) + max(0, _int(o[2]))
        already = {o[1] for o in action.get("market") or [] if o and o[0] == "SELL" and len(o) > 1}
        for item in PRODUCTS:
            if item in ("WHEAT", "FERTILIZER") or planned.get(item, 0) <= 0 or item in already:
                continue
            qty = min(projected.get(item, 0), planned[item])
            if qty <= 0 or view.prices.get(item, 0) < cfg["min_sell_price"]:
                continue
            if not self._add_sell(action, item, qty, cfg["max_orders"], merge=False):
                break
            projected[item] -= qty
            next_sup["suppress"][item] = next_sup["suppress"].get(item, 0) + qty
        if next_sup["suppress"]:
            next_sup["due_step"] = nxt

    def _front_run(self, action, view, projected, route, step, next_sup):
        """Hook: if ``opponent_plan`` (their expected tape) schedules a SELL of
        MILK/WOOL/STRAWBERRY/MELON next step, sell what we hold of it now (before
        their supply depresses the price) and suppress our own SELL of that quantity
        next step. Bounded by our own remaining planned sales so it never dumps."""
        cfg = self.cfg
        nxt = step + 1
        plan = self.opponent_plan
        if nxt > LAST_ACT_STEP or nxt >= len(plan) or not isinstance(plan[nxt], dict):
            return
        already = {o[1] for o in action.get("market") or [] if o and o[0] == "SELL" and len(o) > 1}
        for o in plan[nxt].get("market") or []:
            if not (o and o[0] == "SELL" and len(o) >= 3 and o[1] in FRONT_RUN_ITEMS):
                continue
            item = o[1]
            if item in already or view.prices.get(item, 0) < cfg["min_sell_price"]:
                continue
            own_next = sum(max(0, _int(x[2])) for x in self.routes[route][nxt].get("market", [])
                           if len(x) >= 3 and x[0] == "SELL" and x[1] == item)
            qty = min(projected.get(item, 0), max(0, _int(o[2])), own_next)
            if qty <= 0:
                continue
            if not self._add_sell(action, item, qty, cfg["max_orders"], merge=False):
                break
            projected[item] -= qty
            already.add(item)
            next_sup["suppress"][item] = next_sup["suppress"].get(item, 0) + qty
        if next_sup["suppress"]:
            next_sup["due_step"] = nxt

    def _block_requirements(self, view, route, start, end):
        """Planned purchase cost and item reserves for tape steps [start, end)
        (six_day_budget_guard.hpp calculate_six_day_requirements)."""
        tape = self.routes[route]
        budget = 0.0
        seed_bal, item_bal = {}, {}
        seed_need, item_need = {}, {}
        hires_by_day = {}
        quadrants = view.quadrants
        for t in range(start, min(end, len(tape))):
            a = tape[t] if isinstance(tape[t], dict) else {}
            for u in [a.get("farmer") or ["PASS"]] + list(a.get("hands") or []):
                if not u:
                    continue
                op = u[0]
                arg = u[1] if len(u) > 1 else None
                qty = max(1, _int(u[2]) if len(u) > 2 else 1)
                if op == "PLANT" and arg in SEED_PRICE:
                    seed_bal[arg] = seed_bal.get(arg, 0) - 1
                    seed_need[arg] = max(seed_need.get(arg, 0), -seed_bal[arg])
                elif op == "FEED":
                    item_bal["WHEAT"] = item_bal.get("WHEAT", 0) - 1
                    item_need["WHEAT"] = max(item_need.get("WHEAT", 0), -item_bal["WHEAT"])
                elif op == "FERTILIZE":
                    item_bal["FERTILIZER"] = item_bal.get("FERTILIZER", 0) - 1
                    item_need["FERTILIZER"] = max(item_need.get("FERTILIZER", 0), -item_bal["FERTILIZER"])
                elif op == "PLACE" and arg is not None:
                    item_bal[arg] = item_bal.get(arg, 0) - qty
                    item_need[arg] = max(item_need.get(arg, 0), -item_bal[arg])
            for o in a.get("market") or []:
                if not o:
                    continue
                op = o[0]
                item = o[1] if len(o) > 1 else None
                qty = max(1, _int(o[2]) if len(o) > 2 else 1)
                if op == "HIRE":
                    day = (t - start) // self.cfg["turns_per_day"]
                    hires_by_day[day] = hires_by_day.get(day, 0) + 1
                elif op == "BUY_LAND":
                    extra = quadrants - 1
                    if 0 <= extra < len(LAND_PRICES):
                        budget += LAND_PRICES[extra]
                        quadrants += 1
                elif op == "BUY_SEED" and item in SEED_PRICE:
                    budget += SEED_PRICE[item] * qty
                    seed_bal[item] = seed_bal.get(item, 0) + qty
                elif op == "BUY_PRODUCT" and item in ("WHEAT", "FERTILIZER"):
                    budget += view.prices.get(item, 0) * qty
                    item_bal[item] = item_bal.get(item, 0) + qty
                elif op == "BUY_ANIMAL" and item in ANIMAL_COST:
                    budget += ANIMAL_COST[item] * qty
                    item_bal[item] = item_bal.get(item, 0) + qty
        for day, n in hires_by_day.items():
            first = view.hires_today if day == 0 else 0
            for k in range(n):
                budget += _fib(first + k)
        return budget, item_need

    def _budget_guard(self, action, view, route, step):
        """At every block boundary (step % 72 == 0) make sure cash + the value of
        stock the block already plans to sell covers the block's purchases (hires,
        land, seeds, animals, products). A shortfall is covered by extra SELLs of
        unprotected shed stock, highest price first; SELLs are moved in front of
        the buys so the money is there when they execute."""
        cfg = self.cfg
        block = cfg["block_turns"]
        if block <= 0 or step % block != 0:
            return
        budget, item_need = self._block_requirements(view, route, step, step + block)
        market = action.setdefault("market", [])
        existing = {}
        for o in market:
            if o and o[0] == "SELL" and len(o) >= 3:
                existing[o[1]] = existing.get(o[1], 0) + max(0, _int(o[2]))
        cash = view.money
        for item in PRODUCTS:
            planned = max(existing.get(item, 0), self.future_sells(route, item, step)
                          - self.future_sells(route, item, step + block))
            cash += min(view.shed.get(item, 0), planned) * view.prices.get(item, 0)
        shortfall = budget - cash
        if shortfall <= 0:
            return
        candidates = []
        for item in PRODUCTS:
            price = view.prices.get(item, 0)
            if price < cfg["min_sell_price"]:
                continue
            protected = max(0, item_need.get(item, 0) - view.in_hands(item))
            avail = view.shed.get(item, 0) - protected - existing.get(item, 0)
            if avail > 0:
                candidates.append((-price, item, avail, price))
        candidates.sort()
        added = False
        for _, item, avail, price in candidates:
            if shortfall <= 0:
                break
            qty = min(avail, -(-int(shortfall) // price))
            if self._add_sell(action, item, qty, cfg["max_orders"]):
                shortfall -= qty * price
                added = True
        if added:
            sells = [o for o in market if o and o[0] == "SELL"]
            others = [o for o in market if not (o and o[0] == "SELL")]
            action["market"] = sells + others

    def _room_guard(self, action, view, route, step):
        """tetsutani room_guard: at hour 23 the end-of-day drop pushes every unit's
        inventory into the shed and overflow is destroyed. Estimate the shed after
        this step (stock + carried + harvest/collect - feed/fertilize/place + buys -
        sells) and, if it exceeds capacity-1, add SELLs preferring products with no
        future planned sale, then highest price."""
        cfg = self.cfg
        if step % cfg["turns_per_day"] != cfg["turns_per_day"] - 1:
            return
        cap = cfg["shed_capacity"]
        units = [action.get("farmer") or ["PASS"]] + list(action.get("hands") or [])
        carried = sum(max(0, _int(n)) for inv in view.invs for n in inv.values())
        produced = consumed = 0
        for i in range(min(len(units), len(view.positions))):
            tile = _tile_at(view.tiles, view.positions[i])
            a = units[i]
            if not a:
                continue
            op = a[0]
            if op == "HARVEST" and isinstance(tile, dict):
                produced += max(0, _int(_get(tile, "yield_units", 0)))
            elif op == "COLLECT_FERTILIZER" and isinstance(tile, dict) and _get(tile, "fertilizer_available"):
                produced += 1
            elif op in ("FEED", "FERTILIZE"):
                consumed += 1
            elif op == "PLACE" and len(a) > 1 and a[1] in ANIMAL_STRUCTURE:
                consumed += 1
        market = action.setdefault("market", [])
        planned_sells, planned_buys = {}, 0
        for o in market:
            if not o:
                continue
            if o[0] == "SELL" and len(o) >= 3:
                planned_sells[o[1]] = planned_sells.get(o[1], 0) + max(0, _int(o[2]))
            elif o[0] in ("BUY_PRODUCT", "BUY_ANIMAL") and len(o) >= 3:
                planned_buys += max(0, _int(o[2]))
        shed_total = sum(view.shed.values())
        fillable = sum(min(view.shed.get(it, 0), n) for it, n in planned_sells.items())
        needed = shed_total + carried + produced - consumed + planned_buys - fillable - (cap - 1)
        if needed <= 0:
            return
        priority = sorted(PRODUCTS, key=lambda it: (self.future_sells(route, it, step + 1) > 0,
                                                   -view.prices.get(it, 0), it))
        for item in priority:
            avail = max(0, view.shed.get(item, 0) - planned_sells.get(item, 0))
            qty = min(needed, avail)
            if qty <= 0 or view.prices.get(item, 0) < 1:
                continue
            if not self._add_sell(action, item, qty, cfg["max_orders"]):
                continue
            planned_sells[item] = planned_sells.get(item, 0) + qty
            needed -= qty
            if needed <= 0:
                break

    @staticmethod
    def _clamp_sells(action, projected):
        """Clamp against a sequential stock upper bound, retaining market slots.

        Earlier BUY_PRODUCT orders can fund a wheat wash's sell leg. Their full
        quantity is an upper bound; the engine enforces actual cash/capacity.
        Removing empty orders would change the later lockstep market races.
        """
        avail = dict(projected)
        kept = []
        for o in action.get("market") or []:
            if o and o[0] == "SELL" and len(o) >= 3:
                have = avail.get(o[1], 0)
                n = min(_int(o[2]), have)
                n = max(0, n)
                avail[o[1]] = have - n
                kept.append(["SELL", o[1], n])
            else:
                kept.append(o)
                if o and o[0] in ("BUY_PRODUCT", "BUY_ANIMAL") and len(o) >= 3:
                    avail[o[1]] = avail.get(o[1], 0) + max(0, _int(o[2]))
        action["market"] = kept

    def _dead_stock(self, action, view, projected, route, step):
        """tetsutani dead_stock: stock beyond everything the rest of the route still
        plans to SELL is dead; sell it now when price > 1 (on day 29 everything not
        already in this step's orders is dead). Highest value lots first."""
        planned = {}
        for o in action.get("market") or []:
            if o and o[0] == "SELL" and len(o) >= 3:
                planned[o[1]] = planned.get(o[1], 0) + _int(o[2])
        day = step // self.cfg["turns_per_day"]
        extra = []
        for item in PRODUCTS:
            have = projected.get(item, 0) - planned.get(item, 0)
            if have <= 0:
                continue
            surplus = have if day >= 29 else have - self.future_sells(route, item, step + 1)
            if surplus > 0 and view.prices.get(item, 0) > 1:
                extra.append(["SELL", item, surplus])
        extra.sort(key=lambda o: -view.prices.get(o[1], 0) * o[2])
        action["market"] = (action.get("market") or []) + extra

    def _terminal_liquidation(self, action, projected, step):
        """fieldbook _terminal_sale: on the final acting step (>= 718) replace the
        market orders with a SELL of the whole projected shed."""
        if step < LAST_ACT_STEP:
            return
        action["market"] = [["SELL", item, qty] for item, qty in projected.items()
                            if qty > 0 and item in PRODUCTS][: self.cfg["max_orders"]]


def make_agent(routes, router=None, opponent_plan=None, **settings):
    """Build a Kaggle ``agent(observation, configuration)`` closure that never raises:
    a failure inside a layer falls back to the raw tape action, and a failure even
    before that falls back to PASS (with hands padded when possible)."""
    chassis = Chassis(routes, router, settings, opponent_plan)

    def agent(observation, configuration=None):
        try:
            return chassis.act(observation, configuration)
        except Exception:
            chassis.diagnostics["entry_fallbacks"] += 1
            try:
                step = _step_of(observation)
                player = _int(_get(observation, "player", 0))
                tape = chassis.routes.get(chassis.players.get(player, {}).get("route"),
                                          next(iter(chassis.routes.values())))
                if 0 <= step < len(tape):
                    return copy.deepcopy(tape[step])
            except Exception:
                pass
            try:
                farms = _get(observation, "farms", []) or []
                hands = _get(farms[_int(_get(observation, "player", 0))], "hands", []) or []
                return {"farmer": ["PASS"], "hands": [["PASS"] for _ in hands], "market": []}
            except Exception:
                return copy.deepcopy(PASS_ACTION)

    agent.chassis = chassis
    return agent


import base64
import json
import zlib
_R108_DATA=json.loads(zlib.decompress(base64.b85decode('c-ri}-EL&p(j53My5<F0e<Xd^M=BpR+!6(;<$}j(9DMM2FoS_Tz-QkXes^~_Syg-QjEsoPwX0hP<10~YlC}2Q>nAfZGU9*y@Gt-AzyCk~-+%pYKm42j_&<L5zy9T4|I2^=*Uw-6@Y}mT{`le3-4Flwzx>z#^UJ?|{_?;4%fJ4=|M|av{`x=u@V7tz!#{re{pF`WfBg8v-4CaqkMBPJ_hI|#F8QbJ{g;3G<M`pj?0cX7=iT%(e|`D=<Inkr&VQYJ+WyPG{QUm+;}7l^U;fOyU*G@o?#l=K_;UK;ZWF%!$Ir*(Z(sglG3q~F{+y5c^W?q%@!$RV+uNV|@`v7L^ZJO>ujW5Jedfg{U4HO&D6@~8{5kenfBW<OhoAoO`A0tf`Q_1_4||=|*@rFuihRHi?|wWQ&lleR;#cwKoQ{8d{QAX@@5Cd${iHi<mp{Cm_qZ4SI39oc{O`XUKfL@3mdJ9x_y|5f^RFK-e=YgW;_av*JuHWGo>;Jyz^9#uc6#^m`1|s!uhT@P{oj5W$?OxZzkL16=gGF#s`ZGk>tXh}mp7Wv_4Q}wGgN-*akW_!8-M6^{yJ}X_J_>*zy4d?PqWWGpTps~-~Pbl^Ug;knE3PQG95u!P~PW;`HrtUPV@5f)iiGl)6Cv?obJU>uQBi7J+pa#{ps=tFGGdfO#DWFESYb;(b!cO9}r9|xIk_=q2z_W4M2TtVM4Ee+nG>sB@IpJ@}o+BnEbiL7p+)mKFL{xspA}Q{ejo0Z<ysk;kOz$_H|fq|7QG^c>i90_wApYKl1Y7!|}(D|M<7Z-#@<p@c#c;9&wky1b?s+@Par#`J3m+VDW9Z@7|J@$&Y^C?`fK}Tq(zQ%Qt+zN|%AElc8l%U^ct_Nt2HTkL;W^=iL~Si}V~d9x(r$Fq6G=<@#rCGfc35hsJw3X<paX%A>uW4kKrEvhN1gIr*%2`6_GNE<^8T<(n?P;r4auUygS>1>l6UP$D$)dZO@yekJjyVtFY$=d;*KU1RL?<Q<7{6ZZGy;vy5g$kK+V7Xb=#eD-X<-Jhk|1X0!4XszW+vfshk9F4H(VCBOjbQBEt{0D!2_xr!^rT=7>FRP%Ft60;08TLTdXTOIDn&RYsGNc?_-XKPt-2r**k-u+nQ|vHKe+i~lPCbX@`O(%`CiDyjaGRV~_6GrI{I)2J_e3Tjj#GvZWP5z01ilcOY|ELuj73;Y!TPEOoTt%<xRFEktN@l*KdX4It@SwwRf!i&_C@bCfFq-F^Ts)k1HR71?2_qSlImTAWL819=&oCoc|TR&Q+!5z&z8Z>c<oIKJ@~PfMNIQ5VD+x+S7fSt$88Ak7t;xDh;`!<^la9WDTIuCf$B@p``Zv?YXw4E|D)K!0VASq77>jHmMCxPJimy?m)Hxu(-Yjl-x!yVYeWz%3cLQ@l<pz_zWr{_lMCv0<kK40K8V_k59)+*8MUJv*6oMFI%jpUg2-Bs6ODsz9A>qmtIO`SPz(u?#W~Jv9lhvkQFU4uCdp&g9_R%A-V(<s#UKC#X~b3K%jGiXAQa(I)ye^Fj6||3LnlB%*ElUOxs?l&d|cirEkSjU2>=F=RRSL5Zr$}Wdy}XrNtcpy$j3dHtPntF8mRpd;1Yb0f%7=EO7{2Mf!9&^!c!2KGXA-N*(aa#)9)|8RU;FS0_^*676(Gd%F5l3m)pjUz??r0Ue6-<+o<yE^%FmdIC6u@Dhq;fvjPZCm-C;4kCdD}E1`x%)w|0t$0-_*Q!|c`b-R&CM)1gR(04hC;!Ly<{#s_N382@9=F2JB{*(LrkB`5<JN@nW`|tk&tZkGWsLvaFFaS`98eD-{6%o(L(|h539P#Bg$uZ;l+3QtTuc1GW@u%;&5~jFM<bIS@as@Ab6`UpKwN4j7FLGh%b`!MBR;Yi*y)Dea0yo4b8?3bCdB!Mjt-7}8Ml1D~S;3FfL4qO$cD<+U-z17z4&nOVVdX^9jTa-lT$2V-xwOSDe>g>o?qDo{&V|}eobHS?9=dBXyyM=C5dwJh_;2btui@*<%jf?bj5z!ZNWc989>AoV2nPhq{GJRdPkb)Tnx7AkpHxHV^|y<e$93wHM^Pcq<qss4gAQ}Nn?0RTcTn>Ifdk=#uvg-QFd%k}3~(^Yn5KiSRFIBu*1fo{AVGpk<=iK;Pv^nCE@1!8ti+Nt_@>{A^H}H_4r2hvlSA}iZNq8z#GRkA#DRj_VaaAU0+raTDL)u&JX)!c4Vt>I1P-3=Ky~<`ce*(5%w*us;&ZT^kjIcVxy4`g@tjSYSkkB(jjlo92Z=G=^@7%(yrr$nx)kdyc~gv$L$=~1maL_0v~`xIoIa6f2@pPi^4}#mArOP4v)?xEn@pQS<-4Pm$8YuS@TSXC!~*?bvvQ8ut5s!5+1+EJHZl#=#3^tA&~pm*EK=Wm>R{3#HjU{Ni=A}&-@my~)sf6w36YMN@#F+K@>|x<=QMbS!_{j$ZHPeBZ?FW8#;x&9N!YrZfyLl5Pl#Eb)!wD<P++EG)t@+`#7YF0#TD<J{I-d6CfJB<POcTPMdEVJvQnxY8jkgj!2Kb1A=n#6@1>7_gOpfsQ_thb=ShZ=^d3bYO0|>JC0>pHojIaA>h-)vonUEybph($l*CwgXudpe7s-3E1A?U&Xhhd7=+^@u+A$;=LE5vavhUtzBVsGM4hV)nRsb%ft~p1$f-MzZ5qw(kJ&WC^fpt{BWb-{FJ;3lV@GX857ZPJ2uID9C;pWM;O3YVKPNb}rQ3#D!t*;GcQ{X_P(v34R5-ouZb53UYE4#eFKVJ4oj><MU6CB;0ju}j7oUzg<E>REq=xfRG?LPhG{fB?|R<P0}m7K=@`ez<CX;JEc66TADXswVF>wvMu2hign7@8&<*I!0zgI0}%lIc_=t>EQYF}ps}a<6s(adZ{O?ZX-442zSc&{~+lYKmYtEC@iAI^MS5A`|mTR#{vMl5!k;giHjA(_pG%)~!?DQc0>#h4(3S@hQMDA#_FQSP86!Pkm2mx4(hSo(vhtQ_|2d>UJFxAXKSYTEc{#X^OjHTENb^j(CndPOXUo`u$bl&7?g62)tTr$;XZa{8lml@AA*DZ(ubV0EpvFQsW&}>dn@LjvFa|k?l9*ABTmKKu;P`kJ2r+n@>$XC@zkrcOn~;KLRPk41=`7XIt!2^cCV>40nm&x^&m$d4lSUrfsHuBkXMjJ)AlDGs#w}w6nPJjInGOZ*^Iv^h7a7Lt4941%!_=(~ifA<_ZZ#1=w7xQZ1#J+e)X}Knuu|j%F$tk-uVm=8Oj9n>eh!#8Hb4c-tH+(OjYRM4zW>VgZ!{0A#0gCh?A|Rwm1GMn8Bm*b+==$wjrQ%Z(LZ0YzTa+dauCm6*b_zR5r#IJw%?c}Z*y9|THHOyw24f{M)f3l&T+2CO{8@N!hQMOlz(0Fk3%B2q($vAw)<!K~o(p56HsvTl8qc<e}de8kDoO(K3;TC*pitW}A+76`MjpUJI_6A?kp)XfWiW>u4+MYMUwXHctr^s;y^w>XQ1WZd9&8D+&#zHTjxlxFiWPh2a|#&>H!T%C1FzF-@O-}b_&@9!@!e;j2oZCiMXqIN4yX!i~Icqs1&{0+a&6M?hG2mKhY&K&^3qEZ6a>%0#rF5#9})_=h757`1qI!ODisH(n@{VYDvfi8s_AL*Y=svt)~HeE(=Mn2oofS`m|v-yGnaE??#aa6b!B?1}3%jnHz?SP2snEx>O1-!9#{9N8=W<=M&oHTcZ0n-UWzd-*8Pz^U}?q{pI9k-?hhyDJO?}a)YG}xm2$-Q%)CwuJKA2t<g1xjkss43~0^}R3Wr?-^%)*a!Iv0j4~`A{|oJ@T8*Pa~go#$<9T>beGzoO`eBkUzdGC2(X6AE``l^Jm=bdlQJ^8W)S9^L3gNl>rA&X1LtsH(9)*Z<f7PLE*?-^$-#f7pQK0Z*Dx&t$fm*e$Jan4;G_%b0rFbv;2AhUWU9_aMaogASmhySo-lg)aN#xKfdbob6!t9R(gg#nxIXNdOg0*+zQNhkZZ(ZUeZ?@#byKUmdz12Q@C5rL3YvU;l3KxnYj33h4<jN&{F-b@Nb|N`mQW&VOiEXU(}izC2$l@coD88*w40xAQf7X5Q4|541M5>%L2W@N0Qx8Q5B&iXi%jI-(jNaRWYv)Csl@pu?9Uo_`t=hHNv)eD}`)_$_XPSW*BWTBCLSxy(Uk{g%Z%(f;P5PX(sCA6lcMX<<h%-a^+PoGoG_iBX*hv@fE|zJ6rn)V$^&$L>v|DCj1OYzK&7ZZG|F#kufVQAMm7n9a&SZv6A|20w7OA89Nk8Fb}O#!F8;60O00|3Qt{_g`A5N%<W!IMg-{_x${2OnCc_!226(}8L%XrJA}oPPZGJ8XLg^$vZ=~DVNo}}Iap(xI_2el>WhnU+Lga&NFl4=)xik%xISQ!8q5P=U5x;-q#{<`KF64^VV=mF9pB??iuB7`-Pkpmd|jH%o$BtCREX|e>bJ|Eq^S@-u2W~nj^$;KmS~wl%74w@K}mkjY@my21eIRSpTRhn$5a#8dZ0cFmD4~Q*$l`k7@KnRB={?^j2`O=(_RrjG&2YNAng<^RgIVuI90^0czJ;>8{<Pv=%A_=m1&4<1;rQ!RVM!@*-etvUoLG0m3+YKNuW|iOac_QDbPlL&`lo}Tl^=VpbFPBNH=KPR^+~%*73Wr7nKZNi6wY*)62!g4g+in;zrm+-+8WeLeD5#=rW4FoomrLyNnCa%*(pw*ThgtDwVi~ll(kcFWgiE1_?I{l2cWxQsM!Keen<hBWpQSgGsR$T}FW{c4Do*-ax_AlLAxv<7<rF_Rmy_Chd7ytxpUz;TetcRC1!F0tl|%_!)7Gxqo|YPuNS2m4nQDq#=tg+dcdpkr(9~()*ysBt6vGxL0E%beIbLoDrpXht+aOt??1-&H28-&=9OoOJVd_I&9kCSRFK|0FjM<S1ypNHaRNOK;M9o57(kbN(dG$2U#7t8Mm?~1;o@7$E@Te5mi9I!vu3-tM1wMVF_sj>?nPp`!d`Vd}hmQTxuG{$}!)&kQw5NYq&rqlT16N33r0k9B2i<Bz*>LH`M3YH7O=qqOXiP-H}Q1)^$m&WvEL0d>7DqLFTz!9-~*-rpnIt8tiUoPioqnIhR<_R0-r{b=orNcM<}FZ&L2Dix-RIWhKR9-<K)-njSSJ?1I&tkkdd5N@I#1&9q#+!ejAGYp{>e##q-UFHZ285osk`^!2X*K&5A;wCtVsdRpG`h2T98fWac>h~d`u8`Uf2Dh9`H+C{n%WfA!EuwNJ^mXB$|d8NT)g8Rnmv4V?{JwMeeAp#-i{FzoXw(`DID)cADiHZf|O0q*Vc2DR+iXagKY&30oTd_FFgI2IaLk=PH02#D0rbv{V0T3H$;Zdg6rq9w<+0Saze5)46S6JxtAy2Vw>s7G!5rAPpY+ge&uIP0v?jX~>*!<XRD`WS)!w)J@)fW%6?(R_Bd2d6ll8~~%l2yyNL<vo}Yh@Jla%4C{D&GLbYyctDE#g$HYkR74hUFr^Loc)C?FG}&a%5-N9?E7q(<KPVV2O#30mzWy`f{-q#RAj!%hn$H(Ng9`VM@{Z<C1@T%Z6dIagH6a#aE%(v9ngeBbT+M^`VU8?E3aI>&5ic#73V!0wV9z^|`k7U!tMgU6Q+rgm<Tkt;fIr{VneN&O}{80L&<aNnCH~0rJdt7iuQY!K%8a4w$RY&3l=Ho}X8vw1i)%#-S@v#Oa(&Y1nDvR<21M3n_zYO3USP6vQwp=EhO>g5q-FEF1`dY;)qMcA+eqsO+^bS0~TZn(_s&+{4R_1twSPJ`v(E+^-;=$XXmTy_j{vQAFIxWvS)?Ud36W5Jxc2cNE3NkMJ4aM>l+kOL;yQz(I1Xhr!Q)*Mdq-Q{8+Gfc!+@LtcbU7A<KxLk3{+B{8ID@}!kH_VZJa<I(0DUV-kgNeR*>PiQ;4X7Y*{l@_?AZ&P#1A;nJjNj&a-eUzWx{~hcfOWdasm(b135`U?r)@vrTC1~c;<GP89qeqy8u3jFWKLp_Zv3JoWuW(*f8F+xvli+K&z;=4@s`|bxzz~Ryhk{duf+sT^^pAe`E7LK+F5rWcHAf9LYoZ3QZq7x~1}Mb7`#MU<MO&lHxu2=zoN1LuxuxuiV_7epf@`kfpa7-&(dr@g@DtGp*5I;n*;Gy#u*-mj0TxI<peO*YnSx~wQR=HU126>zCISqG9rBf`V!p6K@H>HR>qNyav7H@JgD!RxK9WX)5{$xH${Q&%Rl+)%*a+<CRqv1{8*L9ZR)7O@FDMNHlF)@8FhW)D5xp*P=dyLSLWFvf{p~m=wTjM;(m^w3<+Vt>cI~4EEHjcqzt$=qc5R1Rag<QdI(D&K)XOK~^G-Yhr5q9!5#9Nl^)yUZ5Br_D*2kelAp--iKq@XN#-Re2F}FDOqBs^)SfYQydIFH5O$&N&Pjx6YRI+>?E$V|#-cZ|@dvxBxr#yV}ithP<iKD6Tc*y;B1@&|}2=fAFP58W_iQ?COY}W;1P^|!+wJsmyj2yDVnb<L(%iF$S8aZHrc~ph3k)nIY0UpO{{EXF_7z%71Wwvos_{CIHV}L?zY6vt7-O!Mb=)ZzcS-bop@HKWeU1eXn864TTjSP@z6{kb;V%myvml_TF`y>bN431SZ;2Fn$F7+i|NsWs&m^ymny<~0~tvr_SKXAo$s?2@?tp^3g%+hJY%*rR)esqlnewh2R=1c2B&#|zYf?}iBARY@4Q!#)+zhd%mkE6V8&0&rC!7OvLJHW}Ps;tQvrYY8hX%YqLc_*o`mJ~i1*>OkFZ>G`444k_QU5SBZJQcIiMYIk(b4d+g-HJm=-Z$BmJ-q{FDo?R0x=hGXy2hZ>2m#-eSr!s25thbx+hc+y<FrRMRvjv|Oi>fz3f;7|yi{zc2;mVtDup_zD1D5Om4UK<_Z>`tgWv?we<=lpx$JL>!x;sr<$Vqj0z=aegG{WHOGF!HgWB}{UE&N!^DAP(CKX<lQXarDOs+@#M@fP?|H>7m55rsbixh|&-xb1$n+Rm-^8!O=25xpO_!f0$$>TLv9;J&|-teqknU%|=|9Ocb!rm8+F9>lH0}0`)?x>gy4ORRlE!uiWg02s_kG}R4m{-xSaH~Qz&1XzWH-}cisVcl&m;zBnAt}-lTdaXn%`HFKVYN>l*A*?yIPIhG!l_rru%4rA*=FWgBBg`e6{3XJq$ty(I76rk5&fwwm?qIq#<ixvI)EGGk;eI0O)d-Fl5$FuHhTu(H{>kEKIAg+KGclc@z#}jz$0U;pOvvLk#Typx6A^K-D$MW2w2x`*=TAAuscFH2mv+th%^*4(L;i^xu~gbF$G{~nfZ2?kW?yy7rG4svw*;vf%KgiV&usTACkx1gwm|x7A&0XASoy7Q;h`TSero2IudcXk1V52MNX<FN1F3&pvQv^o7{)@Q*L6M<`2B)!cIKDdoCU+J=ZE1rZTv8Lo$|<((t;&?g7a`<Obgrjgg)U22%oJ47|=j@~Vsc$r4%t^S{#)AiQBIhHZx2ho$cXg#=rfd2IFx=onK2L`r<<g*mFHrB0$aw|1L9^)?<6!&Y&yS@&aE&2ZNcYk?N`63nA)+5gcR2y2a&>KN%WHN`U+PekT+;2NuydYejlU=!&ND@4i!F$RrWPP-QC(aS=PR`f(#+&q;;vFkD(g5@PF_n_OuoRMzIwk4kJA08r61U8WtNO6~K_w2l@xJQ!UB9X74nt(^c^@nV%rc!VLP$t+zfi#^V>vI^zF=3o-pQDh85IWxJYp8J#rkgmVmz$bQ3bTk}w9&afL9KY?S$BYI3!!5}6Nni?NM2g5LJ5QQc~Wdc1Nl3{7?L&n4XHWg01}YS<~eY5rg9O6r$V!d<Yz@X24v(1(RYKl&NM-pMWU(M(S~C~0_J4*4>!;5sl^^lCl9<cgt;kFDb0=hP1RU3AREe?QJzxdKuRE`TH<$VzLT6YO~H3feG@|&6*7d4rfsVBLyNx+mnOv~hBaHs9tG^oqm(y=F>a!YCCV?HG0M_+-bk3W)q-O*laS6O6Sryf)=96MSw8b1=kqJvM3Xw%DzUs^-$*SoN?1RQ@v5vUc{QDf=`pMRmjDMrg(f-LiOZDOOr<uqV8ft(546lXdnOaK?pdmUl7#?kqU+e3u-0@&+^3fek^e7r*gsWzTeAg3^w|A0E8D6D9l>h-&nPTXs=;XL^RI5+z-G}2l>&?Os<#tHcEJ@iK&LRTHo{5J88er3!VO>o=8<Ux>3~WXXCfrM^8<?A)!SfG`5mI~*6nJ_`w!LmMs}b#`-Uh4F9R7BEruWGlCC5{PgO+kyo20tZmDxJ@Ld__(4xn6^8>TprGP@Og}{6fN8lLDtT!XNi)_AK{|oo+;PMX!U7;o7@i^qA8qX_w%g~dum&e33L9}+~IvRqzTpE?K0U>R%;(Ro<k!k=;MU<o2G4Ca=wEA0@<>)r0!wF{w215$<?x)cl1qE3Bx(eA=sQMTfKrJ74*ZO+7680;Jfb+25y3tt?-YVp4j;O;K=->>TUBJ`_I$rWR_yaIla`ceH^t9IUuk$RZCrE``w4#Rt+q)P84r2T04!`K&sguW7@ZS`jM=*}d&wLORkixKYAkEnZ1sP^Wf8+~^<Zzu!Nm8nF2e-;Oe=2$p89OvC@}9^qLr#dKD-obw-=xBC4dd=2sgUKW$~B_t<Dk8NbEYhR`mfKWuT)nT#5Hmuo<?F<O*kHJuVhq|r)sW1hT?ahTIxKj><M_|s@e$CKt8d2L9}MgfQ4uf`wEyKU6CvX5`3%VK*-ceN+PsXS&>DIdTYi@)q}+%SZpQx-=t*3E<C^l@(C?(o<Aks1l!}*?FkX>Ck3>DUJ*1rBV1VW7i>$9ZDCBQIFi|2Vv5h8f2dtcJ(4xUAxfRXBv1q7)pCuW&g;NkBICu5dMlnn#3e4$hT*i$WjJ^FH9{D(od)%+*#H)_nOH|&Gvr+L{7|F~R%)f^IGkZSR!F?!B4-MoOfPRW^rN&hd}$kA;x<FZat9Dk8G2}?f*%~l6O(!%b$vl_gQVT87F_^cHx-H=Q_DyPgR0mWV?c(a`%e{$xu<4hX{mRjA&6ke+eI2!X*G2@joUttLU22dhTU$bd~9i5(}<MPo#kAgljrP=8El4#p)n|MlGB69r#Dk}Db<B~ZFA2-&y7W}JFq1M*KZ)LF}8rY$I`qrE5ht}*3U!NktX!kG=w{X9HppE=TG}@?#ZGAM_rxHU6O3`)&3PFc;Zi{Fb5ry91Q~#%CWF4ED{xv0`-kcERox02Bnc-ZFJ|96w|pwhl&9VImDItAfzG$LM1>5rNo-1R>jGkCtDCtnj(|_ocS6UsCP2u3_Rb01a+#ZZ#c5vHo4!Jaq+xuuP<(igF?2r%FjPl;6Sa;RzCjGFo;v{!q1Pb#ZP7SPIW6N`gTlbgjE~PEdx$9`?TMG87J4W$?Hr+o(2Kbg{+BH1KYZCoJd|GU5>n-yh~C>#%MR|l}quKyM8`I%B(SyGi@{NRlTWLPL@l(<u;luJ+0-$IrG164?){~JW3P9prTHvjAZyFR3Z9NJ#ylRkPMZbgho<W=*!K|#$^U<9ye46ofaS&bHH(;liHY~CF6WXod1irnEB4>8FyhW1z^Dlzn#gkF%;5sNt>kE+5JUuvxJW*(nU=*RxIQW^l^SSw<cZ?7K@M^*(UJTm9LVp6PUZJQF`lBE*zh7-qZuMIK!0qDl8ko)5Skxo0+g4<V+ysl#>L6sBGH4OqTSn(l(9XhSXgG(U<|YwAvq;N_;j@UtXhT55ptV2^5dtz93&~PtV-z>h;y%x6?&cxTiH8;+C*#z6kg)^Qm6`-?B6kzi{PMf>^pIRHyKoOi~jC;^d1On8T76)*W?nTYUOe5EIaJ^5NPCXF3u<+R`_gmRul8%FKP1Yo|s$KwIZ9qq7MNn<u!1EL>X_xN?zNqs4Ygq#1JhOrQVi?=R>8Jnzo8ACQy)Zl9)>EzFkn8%akm(y=+k?#Y#_5Cm48Bs$(w)DmXCHj-Wgyud6flS!@_1LvqQq4BN<;5$^kN>V-6UkTPjWwDl2D<19(s2}EO%{OvKMSro88-dEUxJBu;!>bDTiZFYM?gQBOOi3uTPV8)W6$v2lqy%Dt1+e@U!4ESw`(_22$_iiU7fLN)^6!iZ$fiifEom&9Jf{;DFc87v?k{*vcn`?ooK1lkE&v2_f9Gy1n-0gt@Z*Bq1xEkl0BZK=wJkxP0r;~J8^wY^RAxOqBF%!2(S<>GO(qurO|p*aM5hH)Q~=UyAbW*mw|Bb<UF7q#l-IgS31YJzw3;i>&@zbT&glLGES-u*=6Ts{Y6WS@R82O>TL4vnSOr*>F8f$-YK}P+u_vL8PddNdRwf)d#gIN}84@qSfaiXto=SEA^Imb21}+7J9wmv)#2bh(Wz;_bm#VnK>I;R=brB>CDfV>zbMZfr3lKE_Et|WqwJ-}rUYVo;>_S!?p3)_6-UUwcA<L++?MnQ)xa82Yl{WRAR9K^JGBnX<I~_b-<EbiHq-M>~9FzTH9PcoqEBpFb=d4N0d<^H~)?M))z>B;ztH)2IFWM2rozlCgqexJ4BWWXu&!@s{`Al1&WNM>ElYzKG(&41{5Fzp7ZqBf=&)>fedUVbr1cAnAds&&mlR{8RFwGKC*)b{)xqylFj}7?T<t-NuPQjQZCkJUc9UX&rIAb<GWJ1Q2B{R3`hP6$BYo+yAuK{NC3H*v6AX!kCGFzU-kaS=SpOT~k80YfJsSg;4T+%cwuaT1!Z(J)GwJ`?(DB&u3+>(*J-SkW8sAF{M^M&jl&<`G*>l7hu#$v{eXoPCj)~!bVfCS$Gp&fC$Hu^%IM=20Yb+^?HaPqK*O(;-4mevC^&Shm}+pOIOt_spBP*q#pC8kz#i<l%ehmPe=GM32%5rHNM<w2-SMp|S{CGS{}&Q@?VYSfpBZRIH}d$Q85JPTUL&_iJcst1$>S|!OfBBV{Hte~Yv@fZLZyNg@}COlW-68%Re{qOXIFze=%b$k%%;{>NbL6SR}ys^zs(bd0G*Pqu6(&T-iUJr7{Io)6E_rXEaX%<@*)+j2r+$EN@n#1L?V%F_!@_lYV5)YF|nd^HXL8`XOWV+4~Tab-S((R}DZqSg*#bx%cn_s4FLVL}h=~H!ht)CND%051f;me)g#sqYYtcy9aUaR*hZ$a^Dn-U=rGKk+v63vj@uc}%f6GU48r{W*O=oITnua$g3Q2;ZchcjR3ith63pY(<FUF!oRf?8s(GfuQH_jarkUGo_0^>2zrEKggHDL-dz2BPYJ*WH7FJ`|5!tdAAlpt*McDtx<AH)7mirTxjTwX5}?*myy8M0$964nUntjA)6lEi?(IJ(4@kv{s-O(5}P!SG_BZb88AE2QK1A%$7<WOpNv8&Qv_$v_z5fYANTA8zF(VI|9H-tpx!`0h*0@X=$i34(7s%9#o-m-gARh9N!~jAxR4s+Ro?uojp9!#-L0`==CRe*ippcXr7Ele-J%^4xvyyb|^i%yX84@ke;8XQ*$|t@9*yi8m7H|Fs<QIuNZ$BcX)sEZ?b1x=DUZACC_(p<RK;FG>bnJOp)2?{tAa|?kTa2)Iw9-<Y8<omI_YsQDFx(<M_oXte=+HUNI-XFcFIYCV0fe4n2X#{(t-P{fD3a@#D+eHRZWGONqsJ5t4cGO0xz|;A$n1P$$-RH(K3^Uf3XL%Q68)-mYZ|IGV{{Cng;LveV+<`b1vd2u*LHLO6v8uw1s!tb3MBG)b=sm|1((Ua79tJY1kjw2hN8m5nfY29iCsRtJhXV|ID|q!}ZaOBTtZT%|kkWMm!SzNm@&usWyo{2f$)qKk47xLv@m7`O4#Cnfw#>uV|AV=H9CC-DMP=I%``&kXEYDYND0U;Q~4S;25vd)Q>jENK(qvL)?D;cJeOI%%g4$%RRyNqzVrfM)Z`4ZmSFpE{wh^aORqsi<nb_*C~f3f;mtT3-Mem>~*ZpAMzQ;0mPf=YyN3-xk1~>*A~YT8ck^CfHEmDV6wOCZw^-ZcFQJ(}lUqbX?;XvtLZ+puGR)@X^zf`SARFsLFYrhjK+WL$iMT;_}1rPYrHD0w7)2R7)@Tjf!))IWTmx+8vLD7}60{xkSZVikULgq)w;NsMRrre5jU_C4ap@vI=jC#SCt2ampG1Y8*FSAz~~7K{}qF#?{<k(iO}625^tcp$V`AN8u-ujo8c#UC*KwepC2SRib(My0*}0VG6z|7Qm!G)L&@&&05Rpj;jWhY+yk!VTXo1ssg{dP-Ut~(=y|B)qM{iDaDsoz&F-`W7xpL&AF=u{bJ1#ry*G;(nZxr&?K=0ySD|~IEHnzZFE_Xz~_!prGgwJ)yI1<l!M;};PcmT=7I3roOgM7aJsPe;nnPQj5abCqWOT$1#KUWxxk`DwUL<46Pb@Mzr6eS5`K8P_Me|-5$^HB%daF=5cTIbBunHVrTmyyE|CNpo8M)&IiC3&GrXL*e}XAyD);|;e(&###OZjf%UgI^ojDJP;0I*NjjF>x+mwT3Ac|}PoU=Z`3xw(acQZXNNxuFv>X&EN8Tb<^P|bkA`4^0r>CFFkICFY$AUDlo=fS+Zw4C($cgN;DTlMH+NvX5+oCg0jmJ0A62lkDQ<{yRb0OPFNmFP2@Y**}#uC6y~F%28xW@YKpWP!Tsw~Nf3#pl)#fI|7ayNUp+blKmY#i-2dz?uihfgv-dCTzW4+@2&oL&S|fTT7Wrr_n^)gn9*y@?PfW{z3A|Og$`SCV9_t?s;`&`kuc0%ZGQr{&Xp#y!-Y2FYmryGcTvf&*0jMV=sDs*<b!%f>MyXA@d#qPovL}SB~lDzy0ygoM;&D_V{b4F21SpQ1cK1%J4DjUb)=}jOHAmzrCc~Qf&III5CUwG;Z=RG(Z4GJ(0_f&Pf0%s`8Xi;E`+<9_O{lq?%Odb)ko}JfT>JDEhngIU6$P&H0qWVd0wBqZX|ybOGoa5Er~JXZ0UHACJFzUPPAc1=Y}~{=DYl5;;c0OOSRil$sW-;2_maT*cAEibWb~iM{%k`tan+s>vrLe}orfSWIG4#p2_t29V1#f8B2dzaCp}wVGAqxdUNMfQM2ky5g9(_Gv^dM<eO*I>~Z{cnpWG!%d_JX8Qr1^{ILcYlU0LFciB*DHDjP-Xw8_(If7eNP-QNdxw;CAc8%D<M&)Namhu(7W0+1<c`l^x8uIX^vMzY>x*NmNOp$OdTm~K37l&}<crrie{UljGbWjFsibQu-yhv&rTozxK}qfV;b)<7dPwpcvzG!_%S-D(F2WP4E__{?3C2UG<%8BMNx9#~@*#QzjThusP4GLcgU&b5Gqg0Z9l^b=?xtO}K4JOhQIBEocBt9k5ogNct;EZ)8!Iak8qbvRv53=Iv2~Lox(A66NIVzR6IGRI=VT;il4nsg3+s4Wvf7wOr%Uq;Cq9*9gzs%zFp{OQy)}1|mR_@fb+v(xWPy9L(zJt(p{wcmP8hqrfRHA@T(i6r#HNaAV5$rGCRv;^nmxHH(!4{)9jddEsiK1a7?sJs*}B#sIu)-eVS~sn_LxSkj6mL>xwsSo>mUmSMYmDom=v9%EKE%|dUN5s<O~I6#4#&@%x+QAiZI#BjOhk|L3PF)*Hlb+PSz_`<$alvfa8n(B{4tL<Gj&5q}CWXjcU{8r*2rEG?eJK_FT#QyB>L>0qt&(;rc_|jWi=aY|=W*w-c>{SuwHflPYyyS5vJBOInwJhs!Z_Aa=$kKRQ+~fvVZ%P>68-Dub}S-fjOR6YJ;}JZ1L!4Urfo1V!hAr;sJ(b+WFg3UnwO!#WU=*)e#c#QVKt8djSapSaqA+zrjPVkv-;RC1%9oKG}iJw8eA_HmO0Z?Ulop2#j!pggx8h$k$Ln6+1yWszlw>x$Esu*S$2z5s*2CumDIU4;H<m~;T7aKwTlBaN!8t)~Fb*SWut7LoXx%RY^_#WtWSe`Vv`ZADqUz8}0b*eba*N}yNX&T^LF(tmWIZmhV@SSax(&E}}m$Z#6RhpD^rrhk0jm^C=cy|L`ChF*<a@-J6NZ4hzE7fc9=^AJ~{1=of%khVfh^<j|8?0&`QyQkyIp{x59i1%Ib`mV|pkF*QuA+w7srEc0j0mIn^5$A%%JYnT3C0fRM1vcTfTV`j3rc`j8Ayz}^lt|bWFSMn&?2~{>-nz68VDd4!;r#O%6XWvtAWaH<DpjLGzkt4X{R9LxS`B({e{Qq$Tx-J+xbz_U4T2^rM9p{*LO^*K;eu0gFn_`1YG<9F#={;~cvgqyC3(`^&r4>5aT>ym4o<^>YbWh3LJuAr578!(-7AY(E_*m~BbLn3gzs@;O^Mo*M57AiFN+hGy(!8$P1^~PlrV9$YDQaeQLxeS*v#HV?G{`{FeGGq(2E>}>M1!(J(^*|w=ws8B=N?V4Z3~u1%+8d_T@&qlUvUN5{Q^*yN0+FV4P3W8qDq}e@z6m*-pljo!L`2S^1^nIFOU7wIn9=`EdI^wMyu-Knm6T>JD&lbbCVU+YB@j^Pt$lEY?7TR2$K&tVIcDSG+$-2c#$sh*v?NCo32v|KyMYplME{LGQ^5bj(eqbWNxb;9Nw7+EuB#^ZWUrIJ>fWOVk<`zo&Q+<f^CsVnbb}h0<m6SlmgAd2+Dr;jh1{X8y>|$w9`onhC+)QM*{JS8lj^Y&CUO))jzbYa2u^QE8o|Bdf|LBDi(Mh?$A#Co|;rP*>b#)a96<Q`#jyzrM;DIcx9XiuGVzks{~%eXcTYFvydUJgC8vU#0V3Q8^9=QXy|(eZ6o_>df=O9n8)v)=^;Rsdf)Q37Ap{fIL#b_?PzyT91RwLZ~C*083y@YWwCIF6D%qMCr8RuelYrwWQIU)BtUX+XCsUVOK(|eXZvK1CT$qjM(ioEO_9pZ7^bXH>q7sTn>zqOoXrylxi8NxsaC}CwTD|rG;Th#*aH(ihW%zb+1SV)IL7_LE77gL8o1%BTJD=p~pMtIk*G0(Pvu}8qLPzw__-ol%5jvr;fVGVaDs9+FGEyw58L>H6WNPI8}p485gTinNdtZI})m`F11l|*Ikt?)Aw9xtt4$D)D)1S5ji)y*ONpWAcPxu+Fia5AKa99<Uw#^&h53MtPw#nc4J{Tu{^PiiYm<$b`>%Rni|}v!KN)tbHGa&v-kkQ?sd)RIoxJfvN5%lCcMQ9S3w3i^v(5kn{?04Nbw6a=nUm?TS_zD_Cq&IEQaf*J|fzI7A)<_K&2YLO`|Ey!3eNKsz>$qkBM{?n8j9@UYkj8nNhQ1&}(&c-2%iWsL8}w;AYI-Z@=#7vPU?6PW&(oVGNmi&PXady4>0N7wW2#5@+O5*eT39f#Mg244oxYS;RV8?oQ`iGE=YkhAlqAwHPRcqQsdgq`5sH5IJ~eMl6<Jy#@@HL7=!9DL+KCag0XJCftG00vONY28H>IY#09+42nk22L_Im(kp5ea)gF{2TLWg`4|9?rMmWX-c!~D4HVuc$h-0KMh9TQ1fh>uHhq^m*PQ>B2BgVUO$G#VtwN^_O`6I09ZgKIoc-}w4UIC>%~k?B6b$bL0U05Gpq>`FoxLLNfz|Q7L=?MFAjK$8+$(;3O}3J1aHROy5lh6=H9N3EmDN#MbVU!zUys67o!6Vu9$b<7LNwmN{Ls33m1HuCUenCWw+U+|vT8*Zz<-#A<@NILmseS&AdR7sl0nU3<048!*rJS-0u-zxZ9k2zL&8v^y-!yyanuVpR|y?p!bHqufc7%w*k4U(MBQdSI|pRoYjYgHhjEqJ>gXLDz^$o&wdLM@hgy2jS>Y@RPObNxupUc2IyFCEK?e!CIC=KFuYI#SF<Guu^jrdOC^nYOmOphP)=DGR_<*1QV8#&rxfp$w#x%X>#kdqvM_&IaP~TTWnVjF#=P1M^ti)29TNZtSTOEh*#0kZXuC&x{mo$*gu|?7+Rx9xfqEjLUPU-I_hj39_-LQK&%Q}V&Zi_c?be9IyG;kOuB{n$49LS+7@gNsWo`K{K7C1GX&!67^JwIEWg-p0n<%pb7e9<<WJ_upQ_E$II;}P`u*+GxRvg&AB8LpW%hz9a@;BL(IhvDkKxVC5Vw+}m0Okv;TAJO#pWNZK)c(w8<8c#=ZS~n!g!KtC8&{?s(PU7ed7fui`sSw6v`ts?jSpl8p{k<g2Agc5o6DB3PGVS<!N}fR3oY)536m`CBhYn}VX|)?cwxCQ6cJeLezguZRh=@bU!C0Q|4k_%~91B^`9wP%q7)B$N8ckVEjvp)pbY;+Y-v&+|Dw=xN8ntMnArulWwDtOja;3Ri7R`%yj-NM3Q5mysu>bdz$&p%Oq3RsvD(yW);`qnMN=zhAOzO^EnO));Q%D<Cu`#B;Ab``66`xznrjo>~X^?ib6JUBt#u$m9bfx>gV=71cC3tk?m&8p2n444onKo^K<2q0HF)}&{HDUT^6}bvhCY-`dsq$vKBzrXrmS#IR-ld@fDKutBeMD;gex~KxULjerBnzmZbA?&aI=3QgUVgX`%LdOg-6L>oEQe0YJ+X&4QtMA-EMB`5?f9q=5u}45A)74Fo~Lxv6XcO3@3f|N*Tf=?=2syy)AX_`XTI|S$l=q98$)bQ1n4N|nu_quqO@~=f1mNi=l?WQskx7LY20X>6d#pErysBpFcR(l>L_a6Y+A$?C!o~1u%NhFQ52Yphq&0)4JU=Qm5|P1q(i0jRkN-;w`u1aJiAYi!RLU@vmx%XM!(fJnF6T%J3&vL%fh?g`+b}JCkz0iD3EV2n`459<WZkO5|uEi97`yl_7>ME>Ake0dLl$5-u~ym{QFD%_Q#iB-hF)03*s*5F3-RF^%X3C^0hWM|K=r+rAu>6t%x!SFGWZ7;x0dE`iJEYI?Df>92?)*_seCo!JiYjN`4U7M2F3Km^X-qnZg6v%&y6Z&!>xFDZ$&WpaLZE8Je_I$oG~V*Tl%FDx-58v%$ciuP@h6r`giK>6SDUa7`@BNq$4qw2n*xDysOcM{|%xpo5MMA`vgZ6G~R-iHMF6d5v$gu^Q`Et*8z~%_U<pCh<vm=!q`J`65C|sny^#st`l(4ZHKoZ<DKZc~~kk%tO%`j{zUm#Yjd)XQ<#DWBo#ijI@ig5dN_y1XgL9=UR3W#1_7a{_2NkHzSYJqqK?z)9TyCslJgN!izezIb0pSbpOk{ZuB-`6@R8|%%9I_c_gic@fvOdQR%Ial7Uya3|NILyWKqPuv}<rO{FK+QO*uaw1*8$9gydewg~`d?8<iqXgy4a2DWv~5Gg+4-4OAUXD8Lurxiq39Zxg5(lRG^cIRyj?1y)1DqN>&-Tn#(m6UuABdwM$%ECZbvqModojNE~#+d-$w^Vhiy_>L6k*QLJ5wYeRKdtFKMg(s>)n#xr8S)lZcV=YLFb-O+rad;=jGa_q#4t5bv)QLZV=4?Rr(-b&M>jn+o7+kqe}d@WkZ!2AwUGh~r@a)({D~4yw?hTc+5E;Cx}+<~KU@@vkWmB`p*xgV$H!_9?4S;gLc_QyPFT_@aKz%B?NI;miDF%-!MoiAxn748HRUQex@8xE$dp?wcaX$h>VtIem9&;dwFnFCdElm3On1Q1A^i50#;@Q*D$C@1kq>I$po3T~X$XBK)dou}ka0@OD}~?wKCO?4XUoKPlQ9yK?;k2>50MpjTSW67r8TJ4xeplYNOg25DvMpWdy;|1scpj53$C2e5V?4ax5F9|NWc?rYThn=k!?Zc`MP;G1@75`v~nk&^MHTUk-}P2;OdPjbaR4BL|%mq)S&{v<bPoWX4^WFSlm1uhf~y+s%B6nAAGPoK89EsoKL-4D#luLh<V>z(iv~Jm1mbisS1~a3<b!7&>n<l7ZHh0@xr8+A(kY##3f)&!N=!_$GSqjst&<bDzMgrCEF{xEbU||nN@(W@_?~a%aa>Hc^|N3Ki@K@4C3<Ok<0(^snyZ0GJbAqLlu<ydntjW<OGU=I@|z~{9}tZ8Sqj(LWR6tEP^Y!D&KJVsBeH~IXAV3aJVj_;g(z%lK7}j$P8*^&f=_m2J)=3UBH}4|EYTvX*ncya^=u$Q=5;uI-OK2`Ke**QODGsrgk<#iem&aYI*yBdUh^ePHPU4f^bi;8IEZ%JA?#l!5GY=$?OCx->haNYs-?k2MXxbJ1o9FYCzMWH#b0p&Q=Bsp7&gzavM3*cQ3i6B9EdehJhM|&_>y*tF7cIY4JzcJ?CLq5%y8Tnf^ONhKw)l3ojGDd@>+ULw35Tn{`|8Me8(J5`I)jU_>cnAeLer+_Y}GIFAu<j6s-ln>bjyUGclkNPcY_i&AzYH6|<ce-OMkWrw04P)CF%+SgIJEd#>wu>Qu4k6d-mB;vJCo=7O92ss0Qjkm*4@yXSO4rki$K@r*t#v0F63V7sjR;EBm(O|28Oq?y04^WCV1_a7X4M}LbS#6pWK39NF(Y6t(Bo+nnY&rdm*ir9@QK%6?Oc_IzDcmQub-DRi;x7su3CF<H;TqV0Vr|-07Jj-}DqnQAX~W~_;w8=Eo|nelqPMiBX`#?AUgYX>E5M%AfGp&|gSyZ#a4Q4St(uXPhjdsaxM8Qtwd3;le6Lx4i=MfeY(n8{8}uUu3*C^h@GCu>-)=L|zET=xMr)P{tP5(bbaKa5s*25l$bRAt>;U@RK6daD&Pgy>53=;7%QWh2+3GcqTD<bC*KJrOjJ1O1FVV;ZtK9BWrw)YO{z;{nNqXD3qyg&*m0MLdxIKq_bPKe#^a&3U*=?zrkGHRDJeEA=Mn6-zC2;^Y_6Pp3xd{|A%LDh{M{x?Ah!SndA>Ai;$V0?B))Os|B$@zQzhMYk%LhQr`h50nnf&rl4X(82xa64+BLJlQ<x*--1Jv`SPn;K>bYj%ihxGI(f}L*3jPMn3zWQ}Wj8(A?>Tk+*C`FF&K0$;*yTXh|fuLJMHkzSI7Ef@@go8@|(CtuwLY8aHkcGG#R&ugzK?@m+Qgw4Ny<I`IMhP`f@eiEXQmmWX9^X#ci6tQ5lH!b<P9Kd#%so6nAZ6-y;8oReIi$GT8H9S->>46tnGLK~RXT9Jo&P#ozVY25^Q<LbhUGhBIS8(BXmO}Sog8cq>CGMUsg8yNbLA?~p$n`7$bTzPC|i^RQ&>)#2+WhmCue)-TR`C`>RJ(o5(JN<*hKRfb9N1WB7xmme&GdIYJcYlvL6u?W|9X~#PE&wr9q>|8q=*M|0F76CexDLBXJ3OYprA?P!_o|Cr-6xmOJ-pGx|4k?_6|ZLXef>DVBoPCM6&me@vlOhhc1LT69l3KXcV7%G5|f9ZxeU9$u7)6BT2!rbV7Sy1>(Or8qAG7N!@|@*30}6ZqOGxLEY2q9rMU5f=INJW7BvYQmo05{j2)0GiK%*W7jf5<xfxzAZ=tE|eB2o=MXI-VKUXdk;a^4JBWfUP{(j*69~$YV?V;(^uY}yYD?0YT$1#!DU`23oIsXmd!1RoY{Mp6=b@CY+!{PLzH8|iSN3os!S#D_#^LL7L3iKv%f6J`>j{K5lU3|le?HFl}?>dT6p_2$tKQLOUw&h40sxzI!{wK%r@6FLx;fRI7K!d+az>PU(CX;FVr?JT`%cnsMGg}DqSEE*=yT_LB-hv7xuyoGH@s-@BZXahBRTa`c$}aFe`w;hzC84C#bNv<La>w5udf|A##VC;yG>$S19JD{JJt3hcUlSh9in|R9M8!X@#MVsW6ApqWzs<BE^NRwfP?CLuKDNSY5n}^{m&=!>#B@lPCj$H%wuiBSxO)dhkptJ!6g$ZA$I<RM5*((h#h!HTBi0b5G=jGYG5CS#n$qI&lf<$=9Y)N%LDz<B7W*s<=_5Q(TVybnHdz;fCfm^(uen%@ryCuPH9Un#7BW)uOEI^eIuLUXg4vMPXmE+T=7a&e(aOY@DZq_{lQhlRDcm|B17LNCfB4s4sf@rl{L`LBE(~xG=A+KZhjH#0}#46~K5s69ul18^~P553cW+mVZG-aQq=f4U7m5zAR3YLAwa(0CAabX$aMOV-!2GUEM%Hl`ck>PVBwe&R4!^ZWvLU4*9Tnb(}vc;ux(~kfGlAi<7zwpy@M;XXBGSfJs7}B}#wC<Y)w)b?3Q37)~E)hW;&U5GSwe{^W?>NJmY?VtrJXW!xAoQm@bNT4j^bO9UJVqU@UL=B*r}7_)?qSaHQvf*Xf4yHB=C*Y+YWd&x6`<B-f7&AEeu)?Zx>s6d4lIz^_DVma)&X%pRHWwH~g+VGU$HwdhB*B#bCr%V|dPqzugU8do=XF2G(osT}x>1gmVP3h@nJiFc#Sl+f>pEdr9Qe33oVMv<EMInx<CeWdpYT%o8GdVBhpbc>}?6`~SsUT1^wUq#PRk<>{1%9%gYmNzWNki1a!dT=}Z7M>QG*)1+KNz0@v8*Dh#uTY2#KoT4Ry@6?i4{{&Q*)QMh!8ZSzA9V+Cm+A^(_KMd@@Se99=@};)%r3E`g9r6MnY4Q2+QZvq{$0@OnA*i+Ryd*yY9(KKbz5~Rik!JHmX?WF(IW=H>ORjgL${#6PO?WDrPXqS-PFk$-c#@Ri+m_bm#>xz65EAa{%jMlbsTj<5PalXZ$l=xE@3~?6itO8C@q-)w<N#mp*{!|AcQ^St?;ii&sir;T8FNmTf%WZ6j&eJpS>q#PTX`-KOk6!k>dw92F6C)I1sKxK`Bn0IcioqP~o|I_9VyFXv&c+rgKiTM#T<VlX?EdM|(BkbaYR#IY;tEA*A2Bs<XYy8O<*fsIYa-4jk)OaUj{a0^;`-ZPS9Mg*mgGQW0rswq9oskv^k@Gm@htdr;d>mhUzy9O0V*C5vKQ)p7%iP$2md(^plhEYdl{Xd@8N_PTEBm$v^848j+iPgdNN#w}alR5%dBQTsk>LxC}vwQ&~&)=$8`77kZ>*y854PRRRSr^D;flca`Kyl63;ucLNzUOcrO{J2H3T({xKH+YRE%v6(`XWhusQC7nSXRCvs11!wgDl$P@*_&@B@n#(X$tj>GlTk;%nEIDgCPbNP)d>Ym6(zM^b4Yk5N2ciJiEkhY(S#90}gMS9;S*!glXO+YP0Sm<%nSEme=ZQ;20AWc1Feq%arZ;0xE}&0e+{S@+h7YuS%Wx>`l9p;U&Kg`E|Fx8Z=5-iJGQ?)(t#w<h#F*iR;(zR`fy{CTG3q4usWv4qL~>GGLRve2$z`??C`cB1E1hO^-K)hR|X^Y7aKz>dbolbVuYAnz>xgdkTF9wr$tk%_Hmdj^S`_g!6-ny_D3<4~}&CU9E|@Mwe#{Nhuyl)Snxyq~v+Fm3Ac&onA-vw?E&1_~{=%zP!1_#&-+#qCD0TUGgiwGS(W`Ft6cM?b1_Evh6};B%7-Wlb9AG0Vh04!U)abwvNB#0fYF{*KuWyn2Uci==DWd`t?;lC2<VR9b38td1^oKZ06ns{9_uFaoJIn6`_`--iDMz=Y~)XCkCY|uC;DhL_D&RCJFx6H9Korh%X7wE^2e2i^X%tkmVYxO6dw4*4(57-Iq4dSPm*oZ|zF0ntjLcUjp%*;M%Ef8q!#}q=<BVAp~ARHCzNgOtMbx#LYaF1gF{qRBA7kn^&ieTY`EiUnv+B`+F5ha7saU@43RgC75@Z3C1LOTvBn(X$&}A&npdYSw1kRjH4x5@_lg-VjS`o?!FCC``C~Ho43_`Qsz<jeNBG}QUE7p6c??T{c7^SWPuMq5ggU46QJo!cllxXr+gB9?MYatl(dFx+s9qPo$1BPJmuEtabvY7gDNj<tl5oL-S(=xfewwI`xaqzAstr}E)=1L7^tEO$vOjdLgq|s_=!~bRLErL6-X<9B5wk5QyLBRSD=2iaF}3lvoh)LGkC1zA?-%u<<|~=)1ye>J_j$1qlp6#-8ygE4%YZ8WNXhL*bs}{wAn(0a7yPRX~AM4CaXG<h2Z%Onz%m2b3}AaW|_mQk85>^FwZ9X*o*T4Ps!znoYN#WK~Ry%TRa}iRq3}H`1#j|3k8n1iGnq$^Bj8PWg?ZQ93u$Z{F&3Rhg4qKBayf@M&upwMf%i->QlddXV;qt1*=@1Gfqm}V$njKQ-|n0JUqmS*y{&Ujep<`vf|t2#}W0-NMcq~CC-;3%zn9<<?<fzMJmAX3!4pGu9q)xjBu%#<%>->`_1y*+0!Hh4MZ}SefQ(bFYi9SEWf)Te@x%~@x#ln%Wr-?hZjTeo9{qd30R|)VzeX%Y|~QXIoWm->UfzTtDYbx>BGHtkxB>NoW~ZcXO|V2QsT<IOiC%cEOf?xKDj-Y1iCwiK|LW0^Q&CFk#^Dv!qoQLb<jB`X0!qq`!tZ%9ScIx&traFQK3A(>KJVETZUFab^rOcpn9lmrl-m=RMHjw=rB~n0%Wc$Yw-J@OH4@qRlympElC7=Njbmqnt$DJ+de#L#2fe>M^h5k;JN6L7Kf8hMvTSjqUsqf@WRLdx^He(LYulfI4ne&RL}SByzF(bxFj@G@-;`AMsqRgWSxiL`FOk3Wpc=wyV+IH$ryyl14N1I5_U$Z<CR;+qA;0XskQ|zI}IG|!e@A7@v{IVV!NJVhbVIRe2cWAQ`#GlAI>197)OOO(_x`|nxa94GqQ)QyJuhOWkwIS$*LFp?7nUT=jW!esKy2ktE}TEJvB&5ixF+|(sUYxZ<~ABW8kvVIFSH4ss1HuiBa2zB+90FUBU8Lvc$Fh@-ok&MN>JTBxzu=JR^=Idg!WM9S0rkg|OohfNzWS1T)5EW4dmGu^pUw$Jmi}P%!V~lDYwfT;}V5yB~;3JUDoL8A-p9o?q-lxJo(v2BD1CZhxfE+T{AyIy9*pYAz?BxhxytqgULxQ}W^>Em_QU{ElzR1U7?%g=drrn`I=KN2*h|;g?fI!Cwy~S}cbby&$&dXZ!`ISVlZnn!YQmN4-9v*;Q#I?A3tSlAq_{TzrWwo``j(33h!`v?o3R?-sEf$yAJ#-v4^|k;Bns;X?Xp%T;1Yu3`AZr%DaS*zvpc7@+cnW-<^xSSN+wI?gxCEs&&LDc!Jfy+Wk|MK~o919~FPA+N1`>mbVY(D|@&tGr0Ty$Wi2+0J1+6e(f7)!{co8fhpc)!nqv2MIKYoE1~k%SEWM#2e8Rg>m675(G9Cv12Cfn-0=)ifEg|`7V#(3iIq;V)G6;E5Gpi3ra<{t-5U#%4EEPMiW{%<L26rE9-V>Ty?8U&(^Q(k~@IEdDhU;ErvZ8ie3!T0f}(V`u49jM^Xai;N*H0;!W&Vc{JnOUs0M#ssyV#?9q`fj95zf?PVlT`7s0z4Wmp~(dNn2P9&via$%~s!{s3Hg)e(l!BATQoK}xF&(fWVCE{aDPS$3qt;(dJ9{1o%R#jTo+*YylJ0vv7%=UC&lZl91vLMpI={CAV$(u`-f=$fGR}KbE^rwz4uL1p_7$?aD%g%feChBFpk3iMkV2Dx73{*<PB;}=K__r5uFaDAF&0f!hnQB;uJQHO$ft;r7rfOP@G6y_FK^QUN@TSfrs3*<Gx%|In8Wg{1UPvVMq1v0a_?A;JrgP2e3s0tay)6O4MC0Pxf~T+csZS;Lm%_ZZ6Bz9#bzV$(5MI?W9l^w9HV3JmWEGLonk@s=q=!TRYzfrn*$II$>jg6N5gOaX7zj%BpLuD)wR`FX!Xg|;U!h1IZ)~85j}$+VF;|1V;>(@0pr51xhBYUba%~@w1Kk*v;%h(?3h>t9TcKK;Jbn;`Ul{w2lhX@ML%3W@OcNmWgrZjz$0|g6O~;Mcb18#5G<Ier<elKFz~q4BUlH0H4!!(J55{amUzxjNcx+Ni3M4eo4VUIYIn@Ug(KuQj=fZ6_IB|$cO0ceLRzg*3vs^{!7&U^8nt=x6`9<R$s*6yI|I3F1o!+iJxoL(>e?jw6i<ALRbt#>D05C@R{6@{1#a(cq;OF8(BFg@m*->Q&B7sQOhjGejz|aNOG$t6y7ArEzN5=vlu50-k9*gIREv00Nt;iyXha6DZV)HnNV&e8yH=F@hP6FXbZwrLH-OBr95oa>VkABvu&3tLrHxZsx8KJqg3zS%$i|tpY8svE)RpWMvc{^5^AP0rRRIMgwk1cx?mYSW8PR9V8lU9oZp_@f8HSa0gP?3xk$0X7NhqrBk8^E32)lIHgTm-_tvB5>EP475Voq#P)W<p-SQ@C3eQ;U%ES_`u|Zw@?4zf*#_H-bwv#<Z5n_%$FMELtFO7OM6kwb;F6%c%+RGD<kH8aKGbr@ZKH^kaXvDA*fF^{~wcO@v{3rZx-%Ld^;=&SB3{Uo@;2u2e{7Q|}@(si0&omARgh%Q}iLbeY7-rs5}+pvH@al&FIaf1f~9w`lC&yoQE_=rHOuR`teR{czY#Lo2fd=fx*bYty{0C_tHcA0=zPX)*|06IU@DytJC&ml+icHb^jVgBk~9GR0|dRKNOMyI%+#-Y2CBYGLH=rcL5+3H1{lA4GKDC#Bi14|~>7yia@`m>jz>ve1tc^n#0Ii(HEI_FfQZmCz@@&h$TnO+?;$S2d0(3T^QX?8>+MlT+{qj?&$R)XK?eP-6m~QMt9;6!?%FrI}cFqC`Oyu5qBK6yjqd0;6K0wSI2mWPzfuMINW-yh{w>War39oR7F4lKg_pKs#sC<dbRp=)=ZgDfmKhtcI&)i8t{Onnp6SbL!o%?|*ssbw~evJpMK*;bf{xrH-_3<Q(nylbKOm=`0M}hEDK9ae`S4Yd94v#-DEho2@BFS~XQP7S!<9IV+4^UON&6Z1BU));(|bz>x9hgRorDn#)7(1twOQ1`H@kg1XL3(jMa|zk2SXzAVC1W_;3If{b;qDil-^qc)x<tAsH*a>uA{4;rT{a~@Ra-oH>H^VsQ$9C+!`UUELCG6`U9c&@W!9CF_8FevVv4L6_RI<s7z?@Y>v<R3%`OW%HlmO`eXk)jZt!;v9{G#~{f(l|>^r4vs<q_Fl_IdpWZAXsc`Y#ju#ff;mr|Gk|;Ib+fKrC^GjdAydi;=u6Yl*G}YSFj%$A63#Nst+fpsZ9TyN}d`C+cr&HU!7wP$)ty$GC|_$FVH^%bGGH-g0tM$KeySXH?+q@<?{M51u?WbjJPd`^jv0#J?z1$t6G#FaJc{N&-WjG`p4&O@$pZhS0kQlIbp`7v^Nhg9!AB{M>K!B0#9jCnM#&s@r2_&F#Y(hvPgVPU?2|acK!t#m#7O4>`Ula%&RU>5+4$Dz~tQm#<S`A+_T$>8IVrMAzwUdAaNr3UZ`y&x8h>*>akAryd#_<u+|X&V$vuX#IUky;_Zy)+xfOePUU{WU9y8KXe7azAnFK*%4Li|_6g`L;rz+((Ul-Ek{tu@C@L+g%|Vs|i#oOQMVF~t&hoA%aK+BYXCXfwL5UnVr2bPORvH!CXU2Ib#*d<y)**BK@i7cMYUu#Hlj-=9(yf#ukxjJm;|gdu)w1ma5<YH1SBKFKP&1ODmU{%ZarQF<CWh9SDHcsDLvm&s%S^^Fs_)06NkW9Ak22b_bA-|W!aafm+rlyr6(j|{2a2@8NG(^n^_DI5n6TU!9OuK5*gvyID|BI`{no2&qNCYpSQp$gmX%#K0`UwHg=9n@PA~0%pcV;<9+>>baU`ILAQVEAO^I2%7r~PL)|8$M`nE&}m4>CRsZuU`((#Ic;<R+psEk**P!yo9{bSdZI%2mIltLv0`3r0~y>C?VzW=t8*EyFnv&m%~2+Qru)|Ilg9*DmhJD4)P)zm*>Y2gHggxSibLIq4mq;J5q)#^yRU{>kZ<St)Qv(oLiI8zmk2Z3UO1#L&ceV5U(e28QXZj4S4ss$V)Kg_=+fl5IjjW{q8F_n2U%z(pRyz?awfg~wh|5&5ykA|TiU~~9jM8yA?J&UO^;;F1dQ3z@JHr@HWil-|#){aXBbcCEy--glV;K*Bzs)f;mxfG8?Kf)9kjC}gH!>c3&?{(T0nk{pqbXiqV4>n`Q&t}SK#Vg9zD9vWr92}#D@_ufzTY2S<bAPn*6c^nxg~bqUJ~mUc<mqgNqQD5_3gik*eW^4+++)uu8s9x#V(V@3yWv@Ewq#GKXuuTr;@Z-*^*#+(S$m4rz22G-(9?a(qOaMxM|>$oJ32AdQ3Z}0^mUNu04;c+0!MGQhLt$opPV_)Ln=xO_s>;sah_l-)H6(uwS|IO#&}sQm-AUH`M`O1?DyTz9Zd>XS%RTJk*nemI*ONpMd?sRT8rN>NE5QI;V2gu#iWQ*VTT>TO7W^fZ8?<Hd#;>80tPFNrK3tfzlsm!&On5i9DTk)xxWrU^2MC_<e{7bJvVM8vTi?x1C%=%%a_Yv>oy#y6$;r`Q4&<56xGt8w)|j=nxe|BYMVkqFRu-XiY$+wy2IsPH-_1_EL%b9n|GDppkZFoOwq%epU(NE)JZgYx*Pmg4H7s6QSy<R(}A4{gg6{fQW_cr+#>XdwMNiU4xoJ6MRP!bh-i&cJDXqSGCuGApGcpT-(Jot50v_#xyZ|)F7a)p$^a}x%qSy1knnb~Qs|CJJNqgroZ*Rxpl|2<WNdBv1gD&`rlbmkWBGS@LN~o+K`TwvGe`lHPNVGXkE3<TCWRO=m;@_#?Zp(OP-R3bNa;o^&K(_X1l<B4yBG_O&3rziJcHuFM=4&UxhsMqLeU^p{d*}1<w+;g%9vvAy3B@1b~!QQ#xL4xq0<MCPxwrm?Jatp^{VZrFZAlD7HSCn7jHfLc2pe8mq1U9+G7J26c-9KPNJ+v+VWj(&n=A<y3LoCEZq8Uvp0~zH#uOKc=JX_%3tvSbQpv5`Yam~(e1y`XeBZ=x&W7c5hnH89oXNE%u50fcbgi>he#(smL`z;$&W9mkshDsuxc7^oPJ%eqcO1`-)#%Y)tq<1ms#z)NhVJ#%LS)nE(3!jP<H|ywIp6?CThgz(UK|i(*v5KN)|tp84ZDFmNauTK<qm@en+^n+0#PZW3p8(aewPlSn1`O4Y?|t0cP1T{MrtdBv=<Dn9!_Ytk@BBOg0>UhX7w3O5kIF2+AZ39aKSU8?gxko1C~T`AD5N2LosD=LnqQ#?C`;>Zo&m2@?=Wx6YJ&i@dOv{t<n(kxyg~ccYK&DvZMtzb1@%W*F@h&Cx!4&B-ee`<FszryR(1%V3iY6aL_VoyS<2OI00Iq7;5ybR>B7vZ-)8oHmtFd0M>mA5*faLr2@_!;}q?dDf-OhSGLtB{?AdJTHtb`L+etDp3g&?!X1N0N?7ie;3kxKxGy5A5ogps4B-17c`1fA{Zvm3BEf#c}fLRCRM=JOh8YPx3z3PX`zjIX3jDaU)9Izmn>@2GqriJ9smqtTO#Rfj<nzjnN?K7wKIZZdDPEIKvNUs`CdkfY_i;eT8v02J@gLggwh<#rW4onc#e72*AZSWE=abq&GvjkjrP+X)?%k5Zs@5YUte7>hM4kBY6D9Zx={UM+S^T9YeBY*mK!?@Pjg6FYD?2s&|cvb9_7cgzvs^dtQ>+@KBQ7sm`akKI~IUixqa(vqWB7|fCRgyd`p8{{|(hzdA|SG5o`S}qNv1~z>!3~jqoWulc?^g7qfQdP&q<6ric1h78w1udY$W(+xx1VYbpwUGg;2>C$hQ7H2yjwo7~mJtf7ocX&PmPZ>OY5=Hz<_X%^?^d+KPWG4aqcAJ@yI<s83McvEdm)^1~K4BuWdldeWrC)KZtfm(1uL^DpMOAhUcXto%ZJ)+2MbVS-L%hDHR|4+A{&~m$?B07B+UJr+31d(#MPg-m%ks9|kaw(zIN!MU0Eh@P!49un_DSVSversKx)4!y`SN!jIEa-+&ML-rW+6X7q?xU^}ML5_ph65x}I51{r&+7b^e^$#)f(?!7kn8qwW^;!s9Kza-jU9a!8mep2$L;u*H52w2*EU+o4Zw^PX4U3C4oH9E5#3Ob2+tT+;KoK9!C?UUa6@$*KPLE1^b6o-02+zL79=z9FmAd?ADT5`AfI?e;AbW9A^SyQrx@d6Iv=g0M{m_bQS5|Ot7y2w#0@%HW}A}FU@Y(Ex*iFvo1550A3V}0|2DjSa~oJvPW{pALYK~-d9~h7d(j3ZF!lAviS4BVmPq;6CuzX|I)IAA(lXvZ?RtIA$-<#yto_As5gdooUA(+}*^YvUTO>58mmT+`;FkF1Ro1k?i~s4N6A_cR+ZwBub`OJZy>6}_UtWGIvH^;xc#IY9TQW(rAOzLYw(IzN><3E6X+*tuYshOLOhL}ZVN_X6@qNNvI;Ib1I%tRbN8WJOXHjPTvq`x|bWyRV7-~f!j;B6*ja5A8$dCP&HO8i|wZ;}A6<73^^A}0vcBt$k>KtRTq@g1dddE(GR_{%M$B3IpuEEFyrFHI>I*2p$xP52^i*w~V(o$oi@9rF1_){KmuHo0fQ_}U2t$)uf!!&gp6(z~LV#&QzwNU7tXEv)EnDCIj)3`J(H^tlWM^wF?8Q0TNE!rVg-Mu3CDoR!ArlhJ4nov`JD{(c&o#0t!*``6J&|Y^{y-T&r;s}`nFD=o*YWdj8>G}zpBW8UytH|~-4HMBmWBZ<^?JTaaXlqHq;zo`lINqtrdq{eg`_~#c{sGK@qA8yh76GEw7Ep{%Bl8S#_e8!$NMtL3X-a{JEFHk^X|~s=z)80&(_-)x20J$DA^+LKci;nIt^(tHaPX!=V*x%XGq(95><MI$Vl{q4Qb&oP3MXQYT5Jofg}g#d;Dl}4yT$VpVcJ*tX_qgo*2WrvCMtw5|FEr1N9*eN%0K`S^d+IKwCX&=Qd3fFoC{rFPi9ix)y8)g5RUEecTG*CO}`64Wm<%+&2k$02)!21Fs1Zj4Uxep{l9=gWu)N>iG9=VRie>8iKR}`KYES+l7d4n>ozfb;!7)z375rPeHjL>SDRU{p^;9lSCgsys)XkjaJ$)GXEo+loM<&#236z79ybkTQs7NzDc0+Rh7c1{C#Tk}<kiKNw_TGvb&Wo!j{i~KfMwW3)fW+3+WA=M)#Rpj00kHopVI(K<Ug#Oa&Es}rpfrUP7g|&=Zy!A;0p92qQX!bz6ex##t)Q+2FVMWgLU<auLN`BaD~HI7d%zw>ZG#ZMu80vOx3j;Ex1&Iql=}I2%`5o8B2iHby)c+Z6dB<DwK)Bd6R$|@1^amUlcP*{MK7-hqOlfzOAI|$Ks6nfz}F{>4K`Q43m5-)OaTNUB(5CBF|Q-r4YvAtWMSkNDN0-ii>pD_1MN_!J*5;!(}4Do9>I5TFU;@I!h61r;xowsKojzWSnhZosM$*)eh+>Rr6>BDI6Jfqt0ycUDqsNx$*-$(v_B_8H?ZlF1f~C*VX5>YJ=$Xu)2fFO+3~-YLn)>#kPO!bnoLx^2mBJPaFehN=3nz+)wsE&4`%?acV+E6MI{r<iH9YV6Q>IcKLXAZ!#Vx$}N%u5H3#<(s!U0fu@IB|Lrg9YoQ=7!El3`y+>Sh^Sa_bS(!|PBCY}*wy`9V)U_zki&TgG3T^V{ntaIi0+jGj?R`_KS$wHVNSPn@tqhGUHn>>R(jOY-?H8g*99Wg+CJRvZr>bgyrT{Wdv-FlHdZAVpZ@46t@<=K`7?&nS3sUvx^3Guk6={T~n)ZC}+-}8Iny5QTdIf;<bd5YWKP{QlB(yWmD>VQk<V&_)3OOZ-c|oIjSc+<|aC6)qgPylARsAPZc5wqK@_7sVvIF@tH62s#Pps%?X6}U)p4I=T)ZOyr*17oZ=D9co4EBW%VZlL#WJ*IIZbQ@agMKhi#ST9HRz#t~$Ew2d^33Zap6<RAI8;v&XhQB?e5Y{VLjWYoRcIRNPMj(gdFxs<;1>e~sWE%BP4$5`P5avEbJrBRtw#{1N&FE=R0|dY2qjR^hVC9r^OmUp&MfR@Yb&oYvE6_kfTWmGyc|Uv0w0j<A}m<2><>7z@ABYA9YTYG#@AH6v<b8as)4b{_d?6;q<~G8yI_Y^CDT-EnQ1^$k}ADOn^|XJX;0>Hx)#*>hHYP{L(XB|HrKOK6P+RBZcYG}4A`c9igvP&$b@ktOGZO2wttr@6U9`GXadkCIN#;m&&Me5foX&hML@%<1HN~aQ`b^lxGS;fSmDNL>PuUkNk)>84RBtYc-54YGNNc|tk9aC-W_Azfw8g~tz38=k5N@ep|=M;$~v}Z7M@Y3iB}vlFc`9Jfgx|gn){o>AS80M+iiKiM41bQo7}Yb{VCJOo6#0>yEXse(FoJWp$QBxgInS%8h2n4{spj~$gdZQ+Cp_Vmg-V`K0XUMC|exuj;55)8&k;2=%jMaD=vHyuBWLmBX^OwYb`GN<cn#p;>ujrw7W?hu2d;l`-M}2u0^>m-?>6(L>UolyMSbH1c-82Oqr|>hX_Qc7p%x>nf6u0aB?&4l<#_8aF(~;&RWC_l<=`G&{ciJUJ}FJD*jqq$8E8?R3U^<<gc?^EW@F1(bdlw7UcY82OwR+Nvc-0D@|}5cllCAdFF+(0_IH!uyw4IJMs8*3%%N@!8~n*7Gji?{oA+eL+9<n5&;dCsk$;h6}E>u-NICIj)w?D;)3e(=(rc-seJ@0R*n5l+hwbvO1C9JLUt*o&l76x8+x{5$I5f@9;c`@g{k;gQh?vntp5s8?EflF6O6ST+bBYp36XhE^y||W5@0Ofc0sfVBSKqD6O4N_GA6ao_YB2Q{IPj_%Xq-!^pt=N%<R+Z=x;Q_Q8mnJVBf_=e58X=yYEWH8KyFKJ!FkZj}TTCpijRRAv%pF)-X+msJTIA^fK2$uuQ>OsMDR6ywy5xRfV>nN<aiOL|mr&6FSCxg*4QgOQoX*2MwNcaxc=A<Ya?wnG+Q7pp$_ant)^TSOzIdVJ@5-e0Hc+UZKUSkTIn?%IvKqv9PB1IwSmWt!1XhMGnw4&*@W+5M^|m*o0qW(DXI+m^R7Dv02NN(j|!bu=!N;Ha7bQflNTNt*QseFB8G(GaqP$5A$Mp7c|G)!e{rSc%nE2#o|GG1CviL@FWoKbC367ISG!t&{AW;Yx}-0bQu-t$f5u{(xNnw1pc`tBv%!KC^9eDqNwW0y(JCze-)sj(?Eits}#y$C$b_<YzogC<#SHN<vlokPg(8cIcw;JQi5P2m$?VM653#xVVbI~ukmE!3C+oF_4J_N6T>fn6kt_G#)PG5BTh#<d>-nlJ}FD;e{?a}4zoP$#?K<vMAnj4n}amD*BCEKnDvu&B#(Vw235*u#n}YPEYz#06k~~B&j}|PjfYeZdpntz?J4VxR=6A58k@pO=LXVLiWxi!hYt%}!{O71IUi8VOb!cm8sJa$Vx?#$$`GFvm{?UETvXoq8sO=5ZlJKHh&{!v46zUtRxU{b@MZXE^urpy3;EcrZm~+&zVkqLAq8B1=c%vy#o!}0d}I+<&kk!U==FYprmNUWIqczk=CBK$1V52wm3d3oaL@4z%=`xl@22zoZUx>d*$1(O2mx2}8EdpLon=47dgE3aPz2oQfSPD-Q-UJtk*-#7q@euZKnEGIdBvM46m|1EShE5VA5ZaEJYeY;tx~GO>mzO-uKPWxWz=EDaDsp@W>hRJR!f<jCP4Fexsb>EODU1krUEed!lQ`#HI#%JGt0$E#KshOhxnrF?MWI!Rv0UIYl}>})wTtg47Ain<qcb%aO!Adbuwki3ZyW6IvRVwu#?!Nk*F@^!M-fee52MN#HsMQla!rfM`mUEzT>E2&ma>|yrbfW-99W*47J5^S7hvgvBm;!+%nobeweO@Foq{QP;^d)8y0GTy0lXhi+K7}=<5g1w{i9vRdz7F8~jJwd}>G)Kqo)UCW${vOxbUVMQm=4MKBv!m{A`pU_|~G+N}T)kcgU=bEINFq|}fx4~cLit@#r78$JVtk+K$9`8=$wT`_j20}PX=G;xn^w;mYl>$8^%U3u<q8|~2xTW~35^H9Y5Io%MgLtIsX_<$+kuzGdZ)pwOb$}wvsu-IU}(Q3Lc$Oo`;eF-*{QdwwEX6uG_@-5Gl8mdAzBQMIziXC7h`mQan!a<foU21$SC>6<?a#YMsOF6i5nk7e^7?8#qwEzw0IqR?#r%Z-!A@V|A-9{R!VO6P9v!wb$uM;YM6t_4cow^+8g07_1#grYO>gvtmowd#z06}}}SLn0p!<z^M`q+2I^-h&PE%tfbe;I%KuIupOcHA7z<B}P@^Cqs^J2Fk?3)Dwa@2?QjJiAcS3C%|1*1LQV1pzJYow|!k4OvA)cXwm#3UG#fxb(izQT;r(et7z{Ce)$3`fsGi$k_(GsXiwj+zRA)90GWXBz30ZlExjS)K&D-ddf1)1ZtdsN!%ZWFN3dmSOHfm3J9eR<*GwtWzZtj;y8)J`OoPTO{;32RhoQZ7Ay8!e91Oq`o>bHp|DIxJAUn5SJ_Wl^1ulGz2)N5HO*FFT7f<t>l(HU+|RW+n4$+b_EKxs6_zxnAZJh>ujQ9c$MN<t+6-Z>-K5xvpY!a1;;IIQKWgAuLLC?GQo8g#dkaHgppf0r9yHd=gbK!fw;|}`6m1WrsjyC4=xh1LO&QTiXFLGP%U?AEAy&U;l0=HO3UONAb+ui#<#AY`k@k?m<o8gxaX>#Voq(?orc+y2Ac0rls=}~z)1F_+aP$&32456pD7KvAdgecs%A3zg^!h2eeQS@ZEqk*d<*E#(7`_y5GyYuZdVn^jUYkc7W0>vJE$vsDfe(iW)I2<l5ltqz8p2^bD(@+eVD*w>o0;@)m~AK+sNkZ##r;ZihZ@LPr&{z1<|40v7l2EVXHCQvx_LoJ9nU7k{VU)}`-bFf1G=Vl5|jsrOd-+f^DP^Q4s0H=5^biBWyjtWxGtoTYE61wYmJl!&to}gqcPL1gd{}W(-(AP)kfB5)u5MKft2DK8!j5{MF6_OgYj-aA{c)yUY<<KmeQaZg^qew9*y#eThU$V(DH~T+FJld!SRFY<yzw5a2|R{hD1HZWgB@z-WG(nh(96bQLrO{v?wrM{McfqzSbg>UjE_LPhuug07D4&_O&FhKgp;s1>r8+k`RKM7vEf{VSw}CC?Q^R#ZksUtcA}%;_&VC8m759(@pi@*l`{MQ+<hD8Bj5?`tuE=D%4JxPnn3!VpQ4bP4JE9tg-=<-0S3eG;llLoV;G@$FjEC@YY0kP09!5>)YKPN(~Vp*N&)|TdU@<xv%+meyLKUq5LRbV@?36MZ0<-EA19?h#np6Pp`WMaA6VATEC8{o8^|oSOJDi#t2e}W*VG!387f_wv5Y1#O2L^n#<}o{NG7%39;<K0uzYdIxfS^>_*jd{FW$Ia_2y$G4u5HqofTF3V2-v!hT8S#)?6mYe^Db?B?DiXDnBz;!#nxdHBXirpoGL?N!a_a!mL_G`Mt(?`2hyC#XoM)9Z<^Xv+7R;B9%nY72Z)7rjyfuKzSk=rr-6m^6)~epv%Mb+d<Qk|n~oN%`c)ACp4u`>do3xc3hmr=)u=*kJc*>^3KQ<;kyUC%t&OfZznAaLNhY%B^(9^i*L5$lIP8oR<64oxBvjaMAHwlCL^ZoR@$D#pXGq7@POsu2y^IJ=x%`GUY(<QzN?C59W4n^;9thOi+O(6TU(%0u(5P(!CHapSy27<G)i*Y~=1EB`W9;l0|dmXC&B1_nJJ=v`Pu1$8zd(%^1r!<&4a0S#!vmv`Mu0Xlo6an^ZJiv1Hd(r)=*~x`uL~4Q$_R^?-$TBjH55BFx%^7^aglE$bIKhulpbj<aW)dzLN?(>_h~E1Y-plD<+tt;P8Q*XrB1LM5DSMur#mK{VW7oi*NINfpal0L;VUu3Cd^pw^=u!<gtNU2aX8hg6}XYdV^nzLu~N&p4sgIxoAJ&PyQDm$zzF(7(62RpEHDZ&3>G`nX5jKo`pQLytmPvP>t86n0Am=`MrUGOJH($akcq-Zv1wNy1D8QB)}Qd6s^EL5J!2WPJMpl|-w|$gSm<{1C{Y8MB0#?0Eu7qZYPq8WBT1rnVqy3pxZizj`NvIl)|azCe0{(C5eJn&9UTsjp-DO1N&o(Jxei$;g03kzu3{0<=rwhnCkETKWa*T>EJXEyZ-90k(Nnc5{taaWbJI%3ENpe6|sssb%CP(<xE3>WrR_=f4>fu@--Fn2b_ex<)57SjV_jF7zo-uI|<$W~9m2I`d`$Fs088qAmJJGo)e(i=MoWDUi{#0_o+E4Egp)bthOCGUMoo7qmj`pz8YK7_HoJzN*AyvY@uc)ttlCa@U~eqpYrz7i7$`%gv`gZORsfq*=7MdjTQZ>r$@Ex4mVck2lw7^IL39!@H8p`8F$_@7F;FSX+@-^<zG~CSY(rnf=jH&P~^DTvnM#b50?C^`%PaXr*|o)m-kGA-gJUYseyVWfN0%O=x1&6juEavo>S~Ia6VQ;%MFeSU-RBBT7-q9LI&!tDx5~7p`V+rRBp#Ln=l<Dl7IE=*#KMdS=w9O+6;_f`k~0h(=!N%PFx?(-R1zIlslC&CHjdD_A{Rui$oGgrSpM=e3|<T-s|a7rI-b7z2Atj5*&CRq;ip)zv&g318!U^A@YZ>~RXi+X@Db7L>XZBXk<2aC9QS-J0#HG%boGZ;@Ipk4lHQnWa#l696^Ms)W6}xy={MPnSu-R#C=y$uj-|IhSWC)B-7(O?>)DtUSRvqpYCPqH&%N``4@GfLlqz58)yMk+Js1wsfi4q$_tz=Kb<-?|yy%%e$}J;pgM=H$)XVrtQ6Udr@5*+rx0dBkR!%$`W`(ZUbTE@?^wt%X~(f>qxSjF?;dEhAh&r3t!XN&v(USAtoEZa;cf0G5)em<>-p`Tr}QWch=RSWh=(Ec<uDnpN_=vhkYxi5sOt}1bKQYJ*8lx07xlVj6|qIGo%9(*P}dRS+0HgdzZtVWFmStks>-fE#va!5-0^hM_-(sm3#!Rg;wiU+Sv%q4Q9x3Ip!8|i*0nNiG5uGO+gQkXcm}F{KQ;D6Qyy1t7j4AQcHM-R#*aL^Uv)}qgxGS@V91la&76Hut|9g2oAZfGGdNYpj4Ng;8;s=zDbrWuo6KQY|eO$H>|Tvr|m9rl31>zZMDY>BNg+K`(>~Dn}7QK<u^H2hi=?=^4=EG{DYV0erxfno$E%;WvA^xd^%(+!-U`kOX6h*F|Lii9Zu`Skt~t7>Y}`3FhL+*;pSaUG^D5k0{0tZ9$g02Ps(Ku>9C)1pvgu~Gf2zUm-aR$szviR87|Lt=GfC1GZcc|623by-;2$!^eYLjb%J*nN@5Lu#1w@kBddDbsbG#)5_LJ&7T=@R%DJmF*yGMTCAk7+_xcj~1c_la2%10u!Iw1Oq5SR=5n`2bg2?-#1AGqZNG!*##=w|%9Ril~1-*Bu#wQMas5Z`1#VVQgVzD18#eK$N$Zn*)*9%akJ>^uW<m^{=Dc;~kyKhAUQZd2M=>wAK_PE*ki4O}{ZliXTRh!{mM&<tH_~GT(Wz7vd0Us;#!+^iZg2wBRprNt%Uck;~qh*($jE>@5hSykp(9+|ekLQG|7%ju0!}_-6TmSawX2Mtj>=-!J(6CR8!O!RD<Y?mAd+z%1hW_~?cV0lyWX#|<(Jz2Q+-nlW@3MU;UY_c2f4=|l(?32(A|L-;#?2B#$v85FeW@4iVQ_8Ih{iL8X8qtrh;q)F`0^4n|HIU7jsgNi)gnch6w%O|{FnxTrKMF~;F2uJGDrHT<g@2>mg`=o4v6u`<0IHYu?y-<Y21{$4lOZZtqh*Lblfc1*=qT8p)yKZ*5W^*g15vQeI~x^qe@!#Q@7-$`m9{JFk>!Qvv>ziOk88hNiJ4PXoXi!UpLi{FK_v@Sua|%o}?-w`)@>Qq!c>SFLN6IZMv15LZHF&4u0Thc7#P(jCzKUx=0xwG%y?HC)UbH4aau6ZV)Z)n5G`3t<HwR_$sN!O$X18!?JWmOJ*H*Sjd)$Q>-Cn`K0DgI}GSQqGDBzF;L*i9CeUF!KZbqoffhfLrqETBj^Kv-OI#F*AhG0FNSo`N<2Dli^L#<NoF1cfPqC|l|RiFoQa9}ksTBL<GsQ0`pTGcdF<BTI0z09K|K}KBlrN_Fknj)DlXtHrKKlyJG${@5_}axWvWhi%&C>kE+Xf(2m)IisKv4~oeTBbSa)hkeJ<uZ9rr@2*tjA^3bn-n;(u<oiuESuKUN_|jW=(Bw!WOi)3F|o=|}uX`7>4ZD!`<S#<$=+w?EaUCV)R)@NHn%FC}(8+}Bu9Of%Mv24)1Khx;_(&a${me)swA_^Dg@eyH4}q$(CurgpQUInYq&puJLzEV$;7m+wYMDzk7pjt`V}6qc91yj5B};!VZ0avCHy*1;O?)Fsvp*Kh>H9f;g0gBWKGTd5HgVjzAY)$(bW0~AM<c-qa2q#TI;^mq%jV^JE*1h(e@scH`OE^a!!E5?;e%Z{bokV|_ci{s?@)VijRu-CdQY#$>mRzswE4n60-NUUNfYuZLtdU>i2m^Zq?x9WGCcHXUf!?Mo56Kms!WrEUcWxFFvwUda_zq%2VL{nE4F2hV%E3eW?jG0zR;%OacuKUXJaE!^JvdH}weMXcb!V+wnhMaXP;mA;C@lfuF%3AaoCQ$ovnTQgBLrSw@^}+SB-$3N>bm|1nN%#u+McH-=sj?K7*Z@*yC%Dy32@V24<<OJg85s69-+L^qEhwI_vW5!LJ<Y(bYDi3ovduz^x~?Fjkr+6#Unw{y#>s=Iu65TH6DAwXk{)Xc>VOaekU3Q?s}mnS^y9-Ez>|(pzH<ZJv8;I@lp-KEP<J;BuPJKEC6fa8oi^M?VbzA}A9<;GZ|BA6l*%sYM){o7LMm|<l9hRlD-g43U1k(s*O~{=7nfEDS2JmoY(P@<t&ha=qz6h|_D2d5;%(W6P-%WQgx+sDgJl&vnl^Cyp`YP1hGFCZ@%FvgDRku_S^@+f(@<oQF3k|UeQIKGy%z!Q!UB^NU|WfD1i)}47v@D#EnQ6l;M0#7ABZhh;9~Bib%2h$DSYYFp?nTMY1}YL=_DL=S)OiCYOQ3*Hlrem#5TCMf*T2jG?B5hv(?u(f7J{NGjmH%aonYNdn%72by`6{)zW|iyY5)2kWrU;cUuv<C$ke|QcP(zW1W>sodt47u{-61KHMAy0<h{>Rf)1wfuX`W4C!|CV4TPu9F~$v<s2+r=wu#hm9xsY?#g2MYt5hG$)YH_%m^7Q2FTSm_5HS$W+)nFTsh>DC|gNoHJumC=dM<&COSB|^KfIbcV+(`%Xp!nsn|OJ`ig1+f4sGz+CPaR$+-N;UtO;wdBQtWW%Qp*aG)Y<LE8`hN^RPl`EP2pJY=-0ht%nokT|z1lOwpPilfH5MmvP0WmnnGK1k}MFcc$WiQ5<lvy-+(bQK)spdmu`o@PmDjmJR{S0#Dv8AC1JVyoYnLB=IUNkRSug}1zlYOk&Hb5yj}&8A~Wf^gZ5YgmvJ>kEo*&3L4q=}RHK1s?_&(IPiDX~QecZF~9K221iFTFZHpSCs{<VY3>JYn(>2fXF-Rxw<L^>FfihK+C3(j(r<hfc{MtlU>R;2&%dAZR(B7OPkrs81X&E2n)roBspcw!3()E5fm4^1pj*O@YLfnC-e~jM5lI;==kp~h_>^%H#XKHKo&=*_W;XH$c3zHT9$!Qp=SYXZXy;ggt1N8lqEUcUm)N(23Q&jMttKh2@_3{-g8!6IVWPbKQqu$`3A(4jpoH%;76&P5mcDFQ`ZqrTkFR{R>8NTB~IVlW?xWpd%C%WZQS!1p<=>r13iTcU^o??denu}IU;=si+(Zejji<s701a#96og`mr>)vHbBT^<+c&5Ka>V<N=AST58rKF6HMl;0<IR8`;v5`<h#xyxq|mD^DSS)frLf{@sz%tbzoe6^y8=7Jc*(T8=1-|liKJoFi_mct);?4jV>%19RBqF?*%c{cB@Wj)j=&kHMCmx==U?{PL2w(qF`*#+KP`M#;#86&7`$_nh#%sd1z{O!*o{_fd5sfM`TLaRGqKS@r721af??HYnSej2#P%zc3_J(#~#-apTD1D<6e}@Ovgr3_;|v$uMV8~Q8?~OY1CV9*k|6<%%mI>gfn+yYct?L)yMLeA~uMLHyyUz_Z_yN2M#hA6a0mB+DdSE18hT(V!jDkuF*!%ITr}QKDxehm8j0;Aba3$!D`Vlz&q2hWPsw^Yc8IHFHK@J=esoc>x|ZG)AMR1Uh%WP`0>6EVqqTRa^wZrmZ^MN#~_PvUs!|$Wg`7_cSL)qxAM?tARd}tnUGFZ0)aQzAv!_WwgQnqlU6851eh*%@&M{wFoB7@tLRcdXf$@3F)ngNZS4(}5o*j`G`pkWaaYug&-mO51AqPw7&wgiQR}SJsJzi`2dSf}F9*e2?zpZoMrRAgMRryUz-hodM^P}?^kZs;ocImM9>-MkXYw>Id7SIv0P=~V0nZ@*eKMWQpf)}WMUwF44MtAu>KsKy@K~YI*-jZq0ft=bd~`Y_y9{C-azpL+@RrBhzY|^3#39Zu)$AMAFD6*7p~YsrcA6Ll+ueIdhREs^6MZktUY?HdQ%mcWz2JhnYZU~|@iEd%D_{*$CK%Ro?QU7dx5?lQ3T@vR-)Wci`03~g0xb~xCK7H2%9TbuT0l<%W2uxVn`9qu9tp!>eP2M$1x*BYej7$_8`({`DDrmPNzz8KSr}kGK0J>rd<S-q!C0R)yhV1%bn5b*YR<Z-dRD?5AN-OjKMrQ*6R@d1_NLIZ1m+rCksR0%E2;tV`pLz~W~Sl>s3jfiOi{@1#8QZf3R~BuR)X^x<z38;sW(>Y^<kAWPg$j_ft_vE$m$^H4%34m{n@L?h09kxUn6Qgi!O2v`ZghX{QivcqsOcPJJ6w=C94C8B~b@wF5KalJsiFHw|n~W(_pMl+LO5ENCDq}=!e_1wB(VpPIXNlV?m7PJ#Y_Bzj<XWj`?n|h?FucSdW8b5Buq?u&m~SJkDKLXl^m!RB+sYvGP`7uP~8Nmpc}~M-vyqVLd<2jGiY$*tKCe?`69hGRSh<!)R)I`#uK}K2o0tt~x@?KZZ-_>$E-v+~r~DfzSx-YSlj5l(?+L)cs7F>^<;!^&~JXH*APG#4f8=CpPr}@OuILD!9s;mlseaF@#ghPqY+lJ~~E#W9gr`4J{ht<cn!m;G4T3bu~n;@MSW(OCUd};2N09@H}}dL1o#ha;Nh3lh<TLb*4PSZGQ?|FVk#m{kjXix##Srh#O@4a+<kLr`|-sZ1+LNfg(GUC6AO7&<m`S#9B1CcGgBorry_eu<BK2bB#>29E;Pb)a^!gx-e}UaBNf<cJj=7aH#AUk69smRiVMD(?<p#fK^?I{w)=urKID9vG$I(;&~AW?anf(Z~QAFfmpJw`ln&CF-i8wZCeochI?Mp%F$Re3<JjbnnhFO82ttK?(tKLj1o^cp%O{1P<H-NEWOe`L;1tB6|kv9<UUo+q|HyeI9yeLWDR=IqxEJY3Z2D#)2~I;N3Y^_J>ywd2qt8<Z(S#X;TaDKUV?kaq|iB^=7xe((E-~cpcrzSr4R;6N8{x+s54pV&s8DBkyusmFuBy3<*YdlX;9I6s$3)}13t)46i=C}d{SzS>FQARv>-6SaC$J!ge+KbO#uT`MFVCLE*Yy*{7!DBO~pF^<$MQKa`N2keZigihZh(Y05GL8DQLq1Cog+z!HoIdE~xRZ7#hlDYEhzm-!Do>#RcGa54vv!0<&zT8dXRzlgLY%Sv~Edzp8@4kBEi+Wzx$I8<ctCgap)XtcjJiLm-PjVIH(OCB#xb?OsTzfn+Ll4^63&m6vK#uIol3h=ztHO`r|Q93@ZZ+ty@(3T=W}OPtFSk1+fn_yvHU#cfi{7^F@iHcLSTgCa{I7?SB82iw}}qPc=izf<mly>h4}i!jgpb5U&$QJbwW9v(ww`b$JdUOUa|xuod94yKAo0k74er=<ZNg96u3)Z%g}R0a$@0jGiv3A&x?RTM#oPS2V~2Q<@m6QwpjXFN{?VXC32QrGayDtx%ZFU0odS|>%(a_vsL)&)yAmKhk<@!b}|hIjm+$lGgzQeh>K$bZo)=7;~R3T0B&n1$EA(-vlhHk=8^ej#{7Ml7sE#dvCsKSuiOhZu{zts7^JGolxCoK0M;t<pg2?Jc@cUaDaY)f$R~pg0Igc)-Z+bE~hqJwhzt#sXA1dv&ha#;nWD0#86JM-x;KCa|jzoLgizZ!$g|Qr#|8{WOUXEV!dEZuIIw0R6pSb}oO4B~-46(xcN%D%O*h?*PE6rNpOT0Jb(@9!=Yjbic3FHM&?2&qe}DOK6pnC|<>q;-!e%4|}V!0c&lEI=Led!adr$oM<My=!yZgI0~$m6(dpBic4IOTAj@(w|c@E0yR2dh>}feB_#_=8ISsO!76&@{91MH8gF`%&$RjEcVjU_n5-}wf0P)#`@=rO_8AFReg9GtD|D#_VV+IGWb3d3Z*iM;zcC@5w=;Y*RAq`+ZAQ8|<#inja1o7FbCQa2BzT?q3j-&9^4N@!SaBkHuGI>X(a3n%Ya#X2%8U%=PPw7Px<b`)GXqs&ZfQ2lu~g<@q~+vIaR}S5W~Eb7!i?SG%ml&VOvAdK$ui6uz>%|b+|mbOXH=YQwQ6eAJIfQ2^PCAv(a^1=)~ZOo5+~Po+et<AuC(8@>bg+|OFKH7au0shJ)>=<(k+Zfu;daqs8|SsG#Rc(^8{gt2WR-!-iB#~G^FsKJHQPq=bPHWk^feZPwXsmxMFw8y&>}$ONCb4qLjPRZFM=4qp4%W$-eH&<++;~CT+j5VNzW8yza&Osqzxo8d;h7NaCvELAXN_%d0aUF8^3?C*-;ooUg%dUyI(B`^8yqPH8ypcT)LWYn$$XLF<fvheIq+f6ZJJ5juGL)_tD<VKza~lE<kfDt-T{VCkB7u(7^3W>iurb!>E648ja>jiwdzYG;wx#&MqMP1Prc($lORkbv0u(a%Dl;?NlpE8&R)-2|SzV@ZSX&D^>WSyE~<BWW^&vqrrP@Y@Be4n*69qdrq3EL}zsCn*{Com2r@WO)O35uRMm(c}$`lM?rN*Hs#0DPb2T7l*>#0(uVUqkeq^ojn|C;B8e=hi<m>EEnRFuzvX)B_C=7Je`h91~$mNN=bt9WUS)?!G$GFMq)cTxddu=A+~7r6rp7RvoV8}vW^q%?8zKsu;)*OWlva$CcP5Z$SJ;8LhAYX0Rlht6@9v46G{;n+qEg)VdP0Ky+#-N+PMrS$~~CrY1wfd1^bC$+3tniRj(k5I#~u&SS$rYT!$TFrAj9+`hS>~*3*B;*wK{yC6@Wo5&O=&^4zzVNbH%NY9Log6EjxMjR$6D&xov7X6U6BpLNg6lZyihX*~%%H>?%G+Ya$xf%nJi0FAb%6SQ1Oo0{B)F+#d47@bpkgJ-(oX1~kJYn3`W3mx2dDrI?=iU)N_2As1nRoo`cY^|10U5Q%5&B!wvv(p~G+;p?L(*8zuCEq8B$=+~*iR#arMl%N09dX%n4vTwPpN6etz1;CM15~71x*rD`2v}Y^!kfjePE)l<d?Ds|5}o9gnyY=mhVyG0ksM+aOmO$nl~E`Yc%(~uoe;4DRlcQiRZp_eRcN@Ey4}2&7@Q|bfFX9ElP@0h`Nm*?%hJ%<D+@m$sO394g>uU4u%MrsiK=rB5?CJ<pIX=M%T|1oDk4_#(4IsU1FNm5{#}O2%lGA<2f~(#z!E8*T66)n;S(&r!R9UP&t?T~;JIShC;99tWv{GU?0n$gu}m5eR%o~AoNMt~mhdmsjI-##pyom_z_xT7HYp*@_+u_mc<<C%pnDx_0(6>c$gi1}NY6&r2|@>uP$+{NEAB6~piRHOGiRI!>`l#Ze$+SmO|pvKgBG{IEhEH_h*mP1l2FOy+xZozI8%*m!fRo3ttS=~hJ>t{5Z0OtGd`E$TDigr><wiiWkBMfwsK-YcZ8qV>Fzv64x*pa*H`w%{UaMqLZn$Y5RC-f(~!LMI>zhjoNM5QuaO+_06Q~V9bh53!X^oQjkqLA^qY~SLG8CGPzgGQCs7jLwkm+B5Sl3%<m<W!IYp3tB!XjXwV9&bf&_Zr_k~K0ICJ1qfBRM_(Xn02Dq)t_8Egc~*var>_moVT=ethmL+VyCs;%`LHC^H~IQ)P+`zLwa=K=iwa(1}|-+#E3I(Kf~y03U4#r(}{HE%x&wPIt<<D>*rswmZ3>EC9h<|t?RK&6GDJ5oNY0Kc>m)4wT5$D@`^rtH0yWZ8HaG@NVF4%=R6l~ZwI&SMJ*SCC*T<0L}q7#@LL%h-}lYC0jGydAb(sj>5uaizNRhtyXsoo(J$c=XEzU@|g<s3+M7LkZZ0ktec~!D+Twso(-Wp}df}=jsYHwL(7=UE6>wWU9>c%&Sf&)<RoUnKZ4n$ub2jewv+MZcGW*bnZ5>uZj(z(bohP2`)T}MpYs*$)F}jHkS@@mRK*bIVu86rAl?<?Q;n1cO^T6oO!O!lamy?UHRUYWzzs|Ob_Y81?2a6K4e9O$K?Bt|5uK%%H08eP&VN?;X$89BATb*H!TaXZzf@JPJo}2?{9C;LG*iwOhtM#mjnVr-6Y!Qi?a@AT6tnNCM|HlAG61JV1jh1FJ^t5R?C`a-6Av5<vmg#E!C&zB1<kAjTPJK118M`HGM_jT}%0}ghXk8#!ro>*+%qwIXmd4ewSR>KOPJu#c20eMqFGcaDFf>iiQOkhelqED5AnI&q}D-_fn#n+VxORc4HN#1QwE>Tyk)pM_cwpSB)EHFF7T2acK~S<#QWoxTxlt)5FHR=xtS^x2Nx^$>QTi9pS4nUj2o}){C#GX^H~*nbI!gsn3I5OQ^1IrWMP)w#VEQ;?Ub<YOhtmB$_XWt!bS8x(gmtv4iXPkAMIB8$<3KxSz9~-+q7j>CYcOs^%l`@;qknJZO@j6yula$$7Bws#p(@PK~9``K3AAXwfBi6yp9u@e2~gU)t4SBVLWH#haL!6%2g+mOJJK4?OxQ<OF^Y2!lhGc6jltLEqim{`3oaC;IA)G~?*Y>ru-btqtDfh%Pv5?9RxD_<a^|F@MoJ2v-LQBS-(&BYq<+E-FabGed-`-~SfA?;FCXUHs^>=^I_u%-1nh0EsWeduDzeZwe&jzC&cr)Y)|CDGzQtJHMn=d0Z4vGb;#iM4GzL+mu1oDyPT0kF`Dau9dwzWcVt;g$;;9k(?leK>Xz5fL&DE50s*@#olOu)JTzsZKt1r-Cxx9dh&De{piNAM|Ya*@d!-eJYtI>rAf~2XoB>RR(|XdMknDk1ew@&sqjSn_#lP;+XgZ5g(N}DB1t#2Gw{{3W#7M@u~-2^Ti(1o{Y}_DYRb%fo$uXPXmZ!D1m%=jMzBq1E1j#gBNp~7m)%MDha%ESMOm7{sJ^$1(=1nOjVARpiNpHvYoy-mgOHXcY44-%+G!Rp3|aO2<g#+=+1!r7rlC4&B~*YjUci+*YMrn6J2doR?wFtT*K_sDaq`LGgHFmKhXf(>-;-ma98UBli1s<KczvB;{^#AV?|*ss<=6lI^76-V@>BRmcqj<F)HVtT*JDS;>mc=Ef6t%dzF<Z3_K|nOBQ5$aq0B9RG0mIlZ-2i3@Y6qjd<ov-aXc4qrPts2{QZxA{yz6sSlsbymbZpi(%WCY&LSnWT)q{@IDOJm%?CsqPB+C}7`*W+m+(Q+{Wq?B-je87Q#W*ACN6!{<hE&U$!cMmth|g+F9+3+FQ<7l_xgnQ6)sinXsVe8Eq4-KH{sBNhnWn!K&-4I>etu6Tx=t<8lUCzUjF#`c>HaWaGMthQNk7@=U`|o)rxlMd_%9H*vHzFB3zjMP>Fg4juY26_;OiLU&P*MK!WtTb_`16VzsXM2AL7f)r}qOZzJ`x-lt4k&k>%#gAm_g7Lx8{XFDq^<MFWM1Po}TbF#}s%-bIdXFUQQ;x&3-l3Hr}0T+)nW1OUohPUh|dnC@a@9v5Qyd5e*aancN`OR$JI(!7yo=uBHL_9kqNC+sO0wb3*FsZ`k(Bxe7EzZ%`)p915#q4I91%OKE?Dx0&jj9~GfOb4=irRbU-#&hL`E@~YjD0L6sCuCfQ2-E;*)jveaF}j=A<+jJJXX@H7!~qn(w-$y9&vkjdpVDMD0DRxz%gZj%>`>wl)#^C?3vFe>*R;rKK<FRaK;)TjV=C4=K|aGNVFBeGxuF##;V1+j<;1ZNiINJ^221Y&vL%aY8Jb;YvO2@SBYV5q#o@7^#Jq)uekgGZ4jy$V3|%yM3aO9iNem-K)b?~sgLu=o9pPF%2X=Epy#A2+Oc1rMlfP^zraoaw%=%4VkK!&V#^USit&12Z-Dd5+F+H^re2r_@OU>`p%IJ#krF_#q25IX@NLUc7LJphoR{;z<J||4vqc!GR2q$41y0X77n1sI`}&JeZ<Us?_a(m=shzeFuBn_REZ4>(^B65qc4dnfvHtR<`*BNUC-f|VpQ!F>H6twAgOU^h1Zjox!2p}Ul~O8c2+L)bFhv2ii68J+cGsda@7skQZmX`+<qMJgEN)R^uNe;bm}3xbU!3ENnENGf&Gtfo`KBB)HW5ah5D5CY6(O&=KuWUK`66BB6_f-URuDQLpl;EeU4NN21eF$vD23N*RSAI?^0S7~-t?fKBeDkzeWh`rFCbucvC-;!0F>d?0*W!2IDMjzS(Q7Z5u(G$jVZKGdbF*e2ooiVxnX$*sk~3;l&TP3LU5tcf$kl@amDSXjTup$&}fQP+g5!X8|QX96z6h&HMi%P3j)-2pPs8%{=<liIbeKK5$TdE`{LeZLK(YSUla}5QTsg7$y}D)+zph}r<ipeqX~*z6SgT0v=`mCw>(Es@qlG|LM|0~3?B>vol9xLk^rf|5so1P#U?0_kY~!&N@&tf#QHqAo?(*oFH~&1Qu~ffzViN4t9!(>G(G6c3ZY{r^ZsB*)tRwPGGM}?0imaKqID3x&T|nDYsJ%mKNvhgz*{Cnv?O8!=%WI$nC_YC#Lc@@`bH|eWW)|E6*G@HwhCRMO%`r&>>=-<+X~QCqwAaDn2Wa3W4*Vs5O!uFW>9^?{2TjNitI9i8K<UkQyncUVy7*INZ6=g3n=Mw`y&yDV>y=D`GP^{!Vtb5f-zX_=5j^Ddl%&reiF6(T#F7EuEmrf%9$aBRrz@Ll_XjNYRTC_Y)!o$cOl;9K^-mzpoN_3r45zq@W%n|URI-zEbTfC%AzQ;Ecki~0yUT<G=m#pe`>14CS_N<qf8S&6bix`GT0S$2Uj<_xk|u5%uSd7n8FSKL2{XbLb;(5J(CK^sqQUG;e-(@o5<%6J%c_x3|9T}ThvV!uZB&L=?@x<Bb*8%{ajeexX84Y*!27R;+2spV41wpNLFd}$iKCi`ZP+YPd=+5&C9<^s-n;!e_uJ|8TbD?ko`<{j8v)BiD3cD&oAOby#l|Q_yG0Yz}^~Ld6y?KOv+x`k)WU^USfn8iO#K6z+Xv}2JsipYmrb7z^8lcsJ7sLa@eqj4<?j1shaQ{C)2CCK)QZwCnyeDM2M_1-6vOcslgS5feUMKj;7G}(_D3Y2MgyAh{smAA4tG@SR)Ei^5CdRbGj7-(Y%UDGZf^Dba^lC)aG#_0lh2`LvExBI3D3SCFhTUg;{N6i7Yv{=U@@|tqzY9LHa>KA=$(fM?Sec5gFG}$I3!Ko^5`iOB2+$S)YB1s{>DB{-o92S*l(_Z(6(9n-{fu&Ed2ef)>`%LqEyhc9u0QFiyQp{N2R>8c48>#KP6OyDB{Vl=kKsJh@g{OeaDW$PDlv{$fTdt!_S1w&u=LU<EM=XH$+aa72t{LiXsDr$+ie=L`RWwn!!z=|y+<>JF#^MC&MHJ9oMy0Q@9%CTz{d^&LZ_WbwCYjT8QCpw0&F1CX?OKG4+LR>fB^-d4>7SzN&AQ>4TypXzZ9Ha@_v@#|s&H<HEKXA{S(r^g~>=NK{lA*b)-4X6h3X>~twPQc^EaKFRUHy%s<K+zA_R?JMZIUH}5o>!w{yGyZD8grUJa%6ZQ_+3EC!L$W($4e|~yV<MI=jy3AntJEYB`bMq^hoNH<S*2>P30W$9eB~BmHJ(D{&_OFUNR3lTJ~e|;N9p*Pm%(d_#(i<wTfAdtVtVuWc<8{yMeMr?FCEtFLfNUEzn~uXy!GEB^yayY;QK(QGjauC5h6yHYTf<GI|p7sqoHX<+M8(9`-AwCi4Pqx#YanDh<}J?2-$w*nc;DnkPejZoKmwAymg)n+WnpjR-m;i_l?Xvo*1ISv@w2KiWwq?=YS(cfT=5iPu${zB#qGqR-2<#^|$(J_U6Gt7o)3DvGSO?WYn7h;HDx0M9=q<1`Q7h^SWw0wj`K#EVqDuK25(uPhsNwgZdqI_H<3A;KqwPy_9s>a?_H)VYFvwP?)4jfSUMUxTUICocM;Nig@-j5ff;caS$RBp33)k;g!F0f&=v1_vaOQA-|<E@Ep(N)e>ZzPS|Oqoxp$=@^_vN|bC$9m@+n>lio`?wV#Puc~Q%-T>$S;&no+8A41l;<!9BgEmo8($G%YP;CvxqfE4COiWb4mbEq=x<Y*5RdiNvGq+^LrDY~1MZt;!ih0ns5R4F(RVX78b-hV>YfmQIk;#SU&w3~sGD2e*NskwvwKD94OXyI9G-4$ll_M66JvB0Tye$b>Riq0+S$Nrqju1Vu%stIxq__#N&rEPFrFlEClWVa1H+G{e$#{^ON4~IR4Bp22G!mDpELF3w2<KV_R~~)VVR~>a)k2^&=rguPh*TRwM)<S6XCYXYtX{e4pGzf7s&`a4n&NTIj@5SRngHEL1Ek}*ki`>T`p1lA=59ZpW@JVlRMUnR7AJw_Zdy;d_^}JETuyOQ`$baQ9j15sEFxu^TZBDH@*``B%Ee7f^;AbhDW~I~b3X#u;ce&L9ds8bMAkZ*q_n>>N4&5Y?wShtVmD*>&(!+?OGtu<y@#tes}dKO%V8iW5qvo;f0Z4{E<Px>IK31jdZ=rz=bx+r^2y6^_P>f$5cuJsDghsyykqdK6;22ri0TT5QYGVN+i~Io$K^aAh~mkc2N@>Ua4eJXcdHA>LXR=Dr=^0~{8vq`m&Nx<wZI`ROH0|bsBHp3OkE4Vvc2ZQGBab4#!1RAk!D$pEZ_T*NuAj7T=XzSdoO=M0uK`QIJ0|o!N2TFo&ii&1I68(+1x^veUG^;q0!ylIizw`<IFiwk0c_;wQu*#!lkpRRW2pdjGI>#0AJm-FE#?bHe!*d`DCH?ISD>|BOkmG{jj>53OLegB5#CEBlRIul}WN;n4HvTFuz{}^WFK5Sm;DqaUPh9e#9Y^K}#KF8Njymwu;zgNUf(kNFq-t4JZ~V9wW`;;l9>xASw?^43YNe+2G}!v_B@7X5^i)Bzgfy8OioCs90s+QDQpHq1mw!w<I6D*ldB0$oqY0E~>=_T;=e5r%fUyCwH!c$e4aY{X)S#B}=6qB8&tdt0xlGAipINEb8PSkVlx15yrc){MLtxCUYujSLBTMU?A^X(oXTO3mXZdjm)p4wA*T(4GA44^co0F<Q&u5)ui4wj%Mv)6(B3S38*|QrPl<B+gNNASe7ZA!*HR8o=fMUXM|xlJvl1H*dQ=x4SCoEk!q3>Kq^QEPk`{6CaMB-ylGmM*S|HL#X(UNI0xd42=pYZD4U_ufa8pn&23C==eK5^-Rf4oCPQ}~c0`HSzCCU#;lOEKC%>n`L%q-$K~Ns3thCIkxcm|)`O4g(N`e3bh4tNtwkR~rO_XX&h$)4$;;-5bT<^FMwi8L{f`DS~tb^a3MR@YlPQ}3Vy=g7AyU|GpV1S3of^rg0r|g9lOLnzNfuO?CRvMbKipTMH?H!RcD8@z#4p6;%Rhc?3w_}bbbc$tnq~vC&C{=w=sQ8IzR@94y3)@wvn;9H<W?&x7<<joG>5ZeVxWM@T4vI5f4m$`%*(u2=c~0dEoLUpe+2<5*qE66g%TxU;UBQrao>EUAuh_9PEOGyeQha0~U9)!I4iU5%av@w1+cWdW%9V;Eq2q^_U(XhKX$9=-YJ1GCx9ymPM1Reex@OF7J?{n&Cy4$NhZW#MK9k7v((UR!)y4R@G%wseyQdL35U<aHw<MSyyukP%jy-7oV(I-vlAcQ~INxC+W(hy~RA#kgz32{9l!u^}4vV>j{LUff7RDI3EyQT|G(PzNe93;2igny}{@wixI+m4xhSo8!DEd^E&?$%3NTUaMVHLAo5SW7VgJkcQ&(AwUYqdPJLWRt%<MCB$>W|&?YU>nSPh&NK5K!d6K$QZ675S$!&D515l1hbd&B%muy@X0f+!IK52p(St$0?jy0Wx=Xk0Hv|dmNrL5djAcZvu{|2DLG+Tn-0|B<G<$apY!=s&OO4aaT==&E%BUm(3~dxn6g@hzrbWHK(BQ#y_o|Zk|3d;dN6TIde6=Qw>V;@$Zx5`^)zg`J&ndVKvRtn)qvDNKPf$>Q2sxJzu&_PE?#6DWhd9fyxNCl>(Pz;#(4R&CuC!UhEy^fkOSw%2uK6QmO=)j?};Fl$r0Tq?*;g@b=H;-Noeo0K&mMxI1%9X&C&DvoWNGWapV<f7cZYVR0Fy)e=P3*lv%dy0=~97*g6yhn5JcGw6dhgOz%fN$@+pt{!iX57&Q*dNtpbE^I~m{KC>~dIMeik-v@AGwDA{rPdPup%RmS_8!w$s7rc!NDDG~NXx%it6;>#<+0FC9C0cj>VMRp7+!nI<0`&I6e`YHO%n(j94eLj`{}vZ#^%Vp)(woa(g0OEd)7OYxtanDe2VoaE{4gI^CEU;khA?%@av9fMadzBMv0Otwk@onxDkBiG29~@vxzh_8(lHtYE@RkU{R&<?wY%nTd9}hKTm+S0W>`g<UF;;7^l0^Hah{}h0<OD7e7d4oL^mhGdnv?Y1=o!<4m^YsS#J)SG>dFIYePZ8(x-7xfo#VM!-doqf%o?NoU0B+Y)JfG~78nvYd!bw3&O=p+b^w4yKkCb4Dk`L~!I;V!rWj3i_Zv(~Vuk;fX<SNw7kUEA^h~1TBx8;$FiB#g@l5xbd!HJ(;J3*<`;<GhW{#hd~aWpE>;t6(7*)quqnjP=zbNi*cr##mSTSUURF(Hzmxm1!Q&cXCaH#$Z+nNr2H8eC`-fbRmvV~JOM?}^_{(jx<dVZ4_bs-8}VG<Yw^eK9Y1+=i8*v<x)O5H2_qzl5wa~)<n?s%+uVpueEYZ1G?=psO(5b#d`zaW>_i*)kn6=1sC*LYCBe4S<ScB)byq44rgLGZ+pb7OZ_5;<z)Lmz%WC;QV+@~2>uDxL1ZJFocO$O=ja-DPj9Nll%<>k*+H9M*EZEwo+*<rZvav#f4`RYEr<ZLpK))gwp0$2wquTVB0yk-o41#**Ek#M<8W4^xn=HY0EKF^y(~XG#b3>peL}Ingu&%}|11-C}Qk-b>sqp@2Qc3h$sqkT`JL$2i%Ew!j3Tm#ha_!WVoJKvBkD$a0+1=SDMW)H>rY4qmqTQk?<-4jp>($&VyVC^D8*M}!9&}cJO`@?!#G+)K{9BD$!DESWMzJ4ocgqbMk=`{C2T~+!dEg|nHjDzq^SB(AY|(ES%*C*X3u=dSg30Kw=z+$UUDB1|cwkgnMS3oCzCzZpY1TW<8#;Em;C2OF!Fbw~XnI-FrG&MRBxwv78~ycnrpt3g#qaxS4GPm>tJAN@$Cqq|$(}cjn?hAI6<pd|iFE$@V(+zxVJzDS%{}eUu(araB}LL(6I^dI=i%V!F*_rtsgA?!i+5bSm+S^?>Ss}JD|s?x?`*{=+fL|+S@HB}G)kQ%L3zDT^2~D1i`wca!sj`;MobKn#SgrI;s&C)ok=K`gds*ktGLbShPtO6IK!Ii&1QruT4D`{=-lT^BCrv}@+c*S;T_{)Bb7j-^|w^4ugQl=BV=0NgBK9A$*U8Xbiw2)tl52Xc^z1Vv`v)0cXfGBw9^GbO2Q}-pIklrnK(M$B5U^_mo(a%V8+w7l``ktV;w;<7{g1Jw@uMkBcUOKgei_U?e^8TEzv+&S&8lnE)V5YowjM1+v2g{UQ19dItcx_v?Iu8=NxJ!atm2i)T*NHinFnIp9<$xK~s?^^?-duO<0N%Rkr5tjWu@xxT??*Cj(kK$RQ2vnU(?!B`fDM39FQsM`*Ey!s)Ied|@hcTl?L8DR{S7a!<Z(VnZ1!?`|L|-`;Tfy*%Na_rh#>V%inZYLBd7v5tOTEHF7HqnUgojN`XMJUxyXMIPdgsU^ONb&g0;NX#$qMYPpCD%#~TVtO|C+%dE6QMcKJN8|w2i?_D#^L@7$37k2iA{md}#5Ml5uZ_cfWRyarvA_^(ycUYN85neq3s9)jq?=?dk`Gj6JeK*cM@=}4+$QM~kAYKcBo)tX9Xt89!1%GAdfH@^>JpDyiimTI@h=IQyhiW21nIW$6e$DG2lh{6(nSxogR=(}pUAJ9SA&0z0ox^!Uq*(HH_-!}1bMB3x9=9^bINmEDn%4NyD=tA_g#K<l6qTVnop*Ac;;?EC{Hx|mF75?$4|Rj8z!hGkzP8aSfuHyml)YW%xo*J0|+r{2bK&Th^Iqo@A>>W4iS|(9Ge{a+*c_Yyf9fwNAUJX=aS_Jy-2+GEk!p1Xi8JpDIE-BJ*HZMXv_2|T%x(-+Pi^=ivXiz!%)hxtEUA>kMzj&GfWFL6VnAzB}{S+r=0U?W~aj-4Dl3NG8}j7gIT-MTZ0(x(GWW+fLLB*`nHr7<m%eah>+(nUK1-=@WyN<wMwfhy7h>HChQ<}6amf<6{9Gi4JpvxPT9|6t?N^;+&pvr&FLO?qo!>L%i8;ht{>P$`oS93&`wW7#q`AxHN~%6-JB+fGYe}&i}tXlak=+hHGjEHQ@aGG5i|h`sz)tDF+V-i>3bvUBX|xYB2bQ|iI!|CJ-YF5H#QI$cme;<e5|uISuyyr1Qjno1S-eS<htN!9pYOa^b|{6C-=o*uY&?FIP0(QusWj`qyW~iFg%NTmXUbTpx}S8_cpzeEIGE|e|hUzgwgzSSzRS`7f@BV(bWYl9xi(I)&mS?R`chFhpq@kxY0<OMJO|r*MaU^O36cVcbbv3L-L%+9tt-N1#I9vc(CI*a?XgQN!R<;GR<<6U9M`NTL`JF7tA`bBgDCZdDiMKa%>q#De5Z2?M)Y9u_XJrU^a|7@W~_aR!pg}-702lbzOqBYs)Ck;Pc&GnTw3+JT=&QP*uYTyn@cT+oZIOvDojdrGq=~ZDWl7h+_|im4kg*dY)0QMVH6nAU#*-R-%Sup9hN?+{4kvMi<WPYEd?Y>$L)28?T1fquJUYTb|c$7vmW1%d!=a%Xr&BUu93*hgF1YYLJFEZ=q1}yW}IIGkbI)n2MS+{$~B&q8E&ip!u)Af7@tmdYAu=u@j$SK&x|5R{~EisVxKTeO(Ht?oQE8Kc=v<rI~uw96bH+heaqNtO{}SMNz6!giw(|40KB>N}aWyp6V#MO{_C3Ope|t6Is-UojgRE6ujAq>U8nswz)D=CiwJAJUWrqwkK^e$1Fe?3PdM&#@o^ZY3YWlkOo)}qnoobdQ_j+jA3j0l1f|E#$v;$-Eo}2!0JMEGxM=6->zt3yxWMsTSHT%V=RtleX*EXk6AiZ{<W_&m0xJY+C9nvZOBiECdWKtTVFH~6Gswg>nLQh4!#A+6Z*?afdhP>URm31ROaY4!9kZPwWIOP?47RD{kCmsOQq-ug>a+W(~%ugJ!q8ME>KdSK<7@Bqrji8jjI*Aqf-8c;J@)-ziDvIWy^nD;P!{uM1|h!cZD0ACXwo6I48IJ{?sKptmw3qdlu;6?XoGa?iWyH=0snGVG2lxqo=bM>|x;2<n;8~UOt!20~n@Obg7&it+8{90Izv7yS1Eq(yw^9H`HdYo}!0%sMZMHk%+aTH)eRWt33KPQZ&MXO!U?Bwk>6udYAycL`FkynqW9(T`1qO@Sc*=%qBZ&Z)bYWS8ZLh7G+!HI~Vp*N2fH_3$<2WZUOcr`cW-VR6lh(v~wy17Np;-*{DggwU4#u+%Wv%pe7-C)5s)ux5yARD7LBv2(xX=Y~TtJIMvjI%x5rET`gTypY5PVIv#}&=juN5W<V<L|5JqOg5NZ7j63>_4#GXRpU>_Ro=9MHo0b&-%d0Uz1G@-PmbQ2by(9GUP|dr{vZxVXQj~edB0DiKJ5@{5-eH}pU6-|1AH*6PF<7@1ys|}A30e~vx7%`R5zyIa)u#@t@3_NsZ}n6%K55d}?h`>3!soz<!jS_eXaN0F?AN*-m7|{}7xNa=(rf7r83Rw%M<H55=%wVdl5sc`cMq*G(*lj)bb+MYZX}zPsQf@1b9y?r@l`mgt{$JOf^gl$yvUUHQr#j^4z<AOwslBWpIf=ET$j5htQbzTKUJP$!=C2&oe8N}E<$-s<?&R^pc4&t_mnM6Y+-xxCHQbH!5wV22n`}L2)Aot?&lYbRTY#5ux1xl_6axDdF!ENt>%C8`Z)4<x97_fh~p9hN0I2>Q6w<u)#N&ABqCOBKgyeVizr^(pF(J(b$PrMyawvDQfvMIbkYpXgTiLzG^_=o#6qW`Xta9bRAn9b^h7;F6k>zbU03P}dfZ>rS3rm<3N2cVSn+bL(uJc=_U$Mw1H>{l-<sC|=Zw{q)x`3mJi^`?TN^8{;X;kokFVLI=zZvLqqd}{RZlF;GM!r}S{ft_>yobR^Ip|^wbkb=#aWXcQO!)O$Q{F+?wsw?V3KmDc<G`ynrFF;!c1*8QKoXO9NW&$gQ-$wzTwfWV2_=|gTME4ll6EDDdFMHDb#>%z;The4D0jCW($Jj>EW4x_OBXfm#dkwK2cYoD5qH4Z)mck2x{dQ%Hj31Bvk1<Z9URjf1~M(HaN`HfG*;Kp7p-{?YDni3gfnjV=WWj7&W>R-(qX3_gS!A-`&CVXfhtB$hMm2Y|0a#C7gV6lY$PTa++%#P>DuYLt|Z;=Gmh&#t9=jfUBHq0t=_Qbmy;HI0l=5BF1OTtptJ5@(|m2C@U$XvhS5+iHk!_?zYYPB0E*bRdHn$Ty5nOt8E`)+OI2~XS^+As}uuk7jrkaCygHeP3hB$#nP>MP&`J>sofIp7Tc~iqIdg80@<w7&q1}Of(U_CnCOZ^Ge#7R$ZHoU)9|Xye&t#_P}LI@Uqw{d$HwBQ-P+&KALL4!2Tt+x_>J|x=@BvSpRI)b@dV#S2fNB4VaKt4VeFzw&?{E^v*t=W!YA?<L079i=HEsfx+VpEll+?E(9|gotvt7xk_M*swYsL82@D-m<#Wqac{w6pL~%>-Lp#N&A}o#CBK6kLS5fiq6QlTHqTSEXrFgHOUOnfg2KyMW+{}7r95%|*iRMbn=@`3*yOHlO1-79^!x*Lx=#yNDw+MU>h4%&)w+0QZ8q+{m^e!Ed*N{<55WTHi?I5*MV6%hTXVVJ`JLD$mFS`P04X4#QfA`(1K@%vlC!a6YE?8A2y!#}RO87n2**N-bvP#LsYS*hN1*<!^XNukML8Z?(2*A2DH4XSV%u23t$f$%XwWE^ixHVCbnsu69p)G(y5oQ>(jZghne0Xx{WnGBS+v&M%oyfKG#p><7+89eiYihu2JegJ2NUbf}zIS6STRM|oBJ0!_YqK&@O2;eeQ%`@}7q2m9Z%gxdWWq|}qu#OAOV^@QiaW%Pd-We$y3s2H^G!T(xyoA+5XjUI(e8qoT*AGw^0X8&etcq^VUu2!)}#~d@YRHZovE8B3U>aUdgV(SUg^SFW2~vS*5I9nuPXokLdxU1&Un(b$$NV~UP>jo?0N3fP1aSCrw3G$UsFZ+8>$7T2UuucPL1_DsjjZSj+E)Ip;!8X@|WLR<T4~_`F*t&zm<UEo?AXDmKf6E+w!2ZnI@FVe19MzzPqx0GEaGr3-JxVz9ihQApMs5^)_BxOYNH~rZsjD{Yt87^o?Z4eg$!{@2gDpee|bl<c2lHsfuLN>#7}nPfa6TzvxxveomeAN3SLe@yfjYef<32fX}|#vKyi{`VJ)WPB-%M9r)H;+4dgE5WfL&`Ez;8zXOAJD_?h&!8@g=Q+VG{b%%$Wn!%IrPc7Wd@%eqIg3~vm3by(2e?<!6Z^;w<YRtHyQ^mJr#oa&bFF=a>{M_oh@a0Cx2fiO!ZjBK1*CEl3v&{O>TGMR#nJl^wu~YwaCf&X=!Ve(Pee5Xly_j@6c&2N-8?VQd+p<5h(#`gr8E`FCt{QvU3$ovaD=!KYUK+j$&+H4Z$|}?cW}^FM3|3W>=*AiNu^Ye8T7!zia79476?Cs57Ngr=8;Q~;Ifq?EaJvWlG-<8rG?)6cnkAcMMLnzsfO}=i&V~it@~4`UXq1ZvL8cN4jbV5Dec!*=_0gJ1wYSCX*YL{LJ&Q$WVtWb3<wpdKe=5K7v#QG`fp6T0I4NQiudjbHi>XjqB*{)v`oI*Ya*%jYvg=l<wOv<g1L=}^i*9FF@Ibmdhj*<tFCnp$OOtOx^}qGx%p7L_iPYTA%8$I{pT)*q_d^CR_lt6HKW7%=Rj9Y~lc~3Z(#DoZuSK-=V4IG&mX$QrB=Fbi0G0HlHbOYtXJiWSTVBt(*h7E%$6x>cC*0bfe|z7Z=)=^7N?9YIaPYto$X;LPb7S5twH6kfY8Rn3c39j*6ql{dGPS>ldP}Rt=JH;w-Wun7_+==Y$l?mMzcR%z+yG@xOWdAEZiYsu5a!_WV5hpw?Nn^IfBwhY+kdLcxMoK}jK02r8-L8KIh;t1YDZ~>zAV3RcSh~)M!eL&{p+uP`^*3E-~8`?6*G3_EnQbp`LWB=*>OC0cc1+RUB#~z_oMuEy_Gvu4lmY8m-n?;0*&l-=d4}M{<D847I>h6Tf6IxKfW)ihlW}j*imDv|0{<0zB1P+U!j?O^o&J5;~hOlAW<$lB?i?-4<3<s3*^%GF1C6SbEveo=Xsh3`5`HHEKs~hT6xTAOP9jv-Qo$4-KDBeBw=9NSyL~=>3-fk$WIcD${#;rfB%=to_{#~siyH85uYSkM%*-e8zM)!Zd#AK2|w-D%;i@d95&-;J%njzi<<;FQE05$!Jth7l1M1NO|$Pq%lT}l-g?;S%)yJpgO&?9Q=?|BSHmP-va4*p70)BrQJA7UY;)?^yffY)TdwRUPdBMyPCv*6Rp-E}Q?`$7-+c5{HMp3d&B{XkUF2<!Zov%Hba2Yhr`2PtCpvGI-oR)g8_L+BPCBdHvD=OAK@LhOG0s!((0gj=bel+x^6bt$w0FzO=CqD<QLbvQWZu{wfAONxe77>as=sw>qS@F1<!dr_!ZWD%tq>mXjR{q6Ypu%#;bjw0sJCFKtZEHAA;vBjD+t+r?6H2}DslU%QGX!X-I!8HK1CawwL6B4HE)X~HIO*d?`>?~#s0i~EJGlpe>Z548k%#f&6y%eY+H9d6~@5HMgLYem2qV&D}PMMFg}@cE=W#E^8WGqhOh<hlJff#&Dhp>;>tNXNs`S8={r-C55{`c4<|&965w;zO3wnfr#mf`g|`O;2RwS`daLkzX!8FN{`;7qqeXON^flWpI=gyKPhqvtaabyk;<dJfo10@Yi+jvACjS<AX4B(DWny|X#cLe#<qv~TeC~&#jkaRV7%FTYQiHe5*f;L>W>S>)q_SrF))xU$mea8EKBJB6(J@wI7dCNXUExSq7t9SdHppR@JiU(MDCfYsPCir1wH@qS9hW(u&utvdHN?20zmv!bfFb#WxLjy`sXzQ$ni-!>0!X#-y=dImnsy`O5kKmsSZ!DaHKZn><8(un+!u9Sm+&ij^0UV!Vw^g#+Zt9BmiO`cr@sQ_i@UnbTDhqHMWemT6Zg{}Khz;{!=?0;-iUsF=+OfJY+>Nx2@)iOr4MwkIiWtea^)B~KA<C7Wv#8YGkCKT7GsKAxK1^;&O}{PF=01hkdKx{gcyOT`k2>|hWicm-@pC+PyhW}@oi&c{{8K5zx|{5?gtsWg5|7h$?UN%)8kv+IIWnANcrIv)$+`?qaU+jt(K=T4>grpwK(ya3+S69FUC`@e)6uCPL1k}nP7zoLz|9bYm^b)8Afc+6hiT|{KDuxyJ>#1`Gs5B8{Q3iyl5B;_5g%Y;zGCXCbbBKsG&N|)7KqgNrPAuQ87iuP-Dl`*H=)bNO*$$u7>;uR2jNE4&rnPL0v0Vd%?q}t>Nl8?4*0T`zN>bTkOu6-XeXu$y+Pa77%O^@IIqNUkQE|;X%W!Z)|9&sr|z&b(B4H4W*c<oLfT?OkFS)-i%V|TNSo+7JCydU?9X>-8NwyRgwG)RY5GE)$B&DG`}}B*}R)P<62)+cftOvifKJ;5PpVibAc&)x{tm^>6N=4HOx(G@wfCaS=DRu`S<?1v661+>&qhguL{>UmtI;beU-XinYXEZ%VFM>r*#{|7r%NQs|YhW%sTHqq^yfS0O&3;J0FP`c^nD%7&Gv>k*~DLsVPZ{A(Nq=j!h2k=Q`sO=L&UPL^?cU25N3#Fz&c~<DJk<Sz56I`~AJ{9_S-FsNk3Ktkj^YrUMZkn$f}jTVYfPP5oAD8HJ2?d8rNC?7lD-Rh)6B78l(%sLBj+v9+~Zd5QpAk8Vv3?yovz+kfplh?|(Ci{<c`u%p8oR(gsO-uE`rzWcH<O`E!>)?En$XDHSgPi-g>mh)_D6S`&MPBv!QT}>;sXN~sOhljR2*Yj?`(%K2n8nS30Idie;!4&$b95kAdcW-^hi`-pPmyU>7>0Y$cL_HvQC#R6ccYrRyV#W0zDa_t(Q1V;I`Fl{c$Ap&4YL(epZOa&jyFVj6&mkXP_Jyg(Yb(EYX)=Q+#4Er1b7hEKm8g10Q;UYhdnsO49F=OAPczEcB8+XBuG}~lKff|`6PxmD>0(!yGOR75(ocqG=A&n)sGhe`x{ggFHq><D@`Eji%HTT)C;IE`MB33gO!d2m?b^LupHiGvdQyUAjK8@7Qf*a&v+-+t&Le!V52}Y+DDbIsPSBduym|>AskHJ_b!@^KO0)|qF}JbZyX`fi4`9QPfwkHkj4T!KGEP`~D%j_vZ6(7)_(y@BTE8`l?4cVfO++8+T>~vDT|3suw)4_k=4hM9m)j3W;qB9+gQ@L^r~-XV++{UYmYlJku5G73pJJ2fLEfwox?L^do#%jMHN^|3JYKv3NB-Tj)$9XeE)M2ldXAuU98!-h(I6nPJ~lJZ+};>}jXvfQd%_`rAerP+o<L8uT_Os+ti8aCN!RBEMym&<Yd+Fs6>@->&)2KLm}-YW+Z>}QTW_OmZl*l+E0q~NHZEg>KRMFE9{X+{PZ~HBT`3GZXROw>n@^6FRTVzD+ch3jS6oY-9(^2hQCUfPo1q%%uY4(skk*6Y$eaU}mnW9Ql9$;9rwPV79WKE{ud)QolZe%IZ8RZ<fXZj;ZnPr|){?TINZSMZokEUCu_Jii(D-ZD?EBkM!|qFUqp^~nP0mstmg0KGO^a#|<KGC%D7(M5oXP`EAEvtJ>upyB^3tc^7O+s0R_WEojH}Xt5z~ZdLiF89hhA4@#bD=<deesc;SYiw`8DC<KEfIO++42r`|8`NRoKaln@@YbkS2<Hpt9UUP(7=RrQKPWG2Rm{MYwK3^UL9A8D|_Q&eMb5tP-O1R`#MrQg7vNJ^XorURDD-xO*?9*7#YI`D&ovXdF#;T3OUx;-V*$Y1{HU&QejpTxEbpIU6a_!Wiy(Mq>+g<11E2WIPxe4T3J7Q4{li0Bvz5wM=ZM6Lo1LNpDXtV=BYplcdeBq!r?teQ%5Vw3xmc=go|PmB4^Q%jAr6z_Lbt;sa+^S6p)!(x+r>;5k)zVV|A2^KxZgU%nql2sd)XY*8qV<xwruMb@d#o=9weAh*w=+)J?$W;N&ZhjE(9RH^^O8CQZfHelD>bI+Kel2mP&T=>lGkoh~yPe~e;Z#DF5b*@&co6bET8_j77g|oGwTN)S?in=joocbO!lSIWt4r4&HGq5q9UH)hZ33O5MG*s4tfK@s_w0i;*Y|7fvdr+eKvX#%o1}@8T@DhCiF){2)L+!qZVC$AEeA17#c`7?_j!>@6UYHLPj@j02>o$tc*7mUgYhkSXp_=XoNGhJ3Zv|eQ$6#v#e}P{gV$ukrC}l_6SlOKsYJqw&%=JY!YWU`JC*OR~1zFa>5O|x=MAx*PNq1*|<vt>rsFBf^(<IUL{uby8Gx3EwQCAEwdSF5-FkD~;jo#J@lbcMF{r2_0V&HE%X%H>7RF%BEhu9tD0yga(qO@UoOWN6@H#F;FZJJ<q-cfQWc*Gc15x%AH72gDHLR0QOP|x;JNFw-n6xain5|s(FT2U^BNVx0BTmI%r)S{lVm62kNh0Zajg>o-AvTt|L+n_)T1V{d^u-iC%geQJ@b9!Xn+ge($4aUJkSd_ruDfgNS)tu|<XUJNb5_=PvQK|{%vTKICZz{WeUfR41tBcs1!8N;Cg69w43wzP7Q@z=iT&lmbj=<t2Doss6fq~EJ5z@#sgKhhf?^Mr6?{5*&N<-yqmjc}C){#pvAD$R;m_MBFto>yHOFG92;#Px=nS)mgLyt->TD#bb=x&+9TFp&@nXyCgGeTi(pL#`7-4mK)eoY-F{Tuz%%jsLnCe%5Q-6-@PX`Xd?!Gbz!<+n-^3<ulM+CpQRa4E;<867?wgNn`unzVy+<T=bky&}qPtHIRaohM4cl#Y3KpF!e$^14CxAISHw@UqYT^pC&({ZDxMfB)^bf4<#Bm>`_>UT3f^C2O|7QOA8g)i*3e=l<?)hx9v}6RkG1OK#9Y+*-@-^qa0)A@Ve~{J7CdVi69Ov}|4P@ZbLR*T4PcfByWNt*Bx%9aPIJ%De1)H5UVau1)RCRZ~Q6LFay;(}@dFSq<@Rz^u0Fb!xl)YA4(0<etZgmI1V{REEF+TIU)#mk(NNocN+gGnhkLge{B?#ps>98)eqd&8b<!7qlo|Z)?*~b8~uA={D59+%^-^!f{snTI;o}bhS0nf+_yg0ZL-+OF``a(R<YblqsZPWn~Uh_t^dEN4YQw%vA((({-CFkfe$7+<a8uh(lxFeR)$AO^)K$%~z#;!2Bg;I&Jn+TW^O3BMbzE6!os9;`Ytq82bZO%y3gVTQTk;92k*ZQO*wK829ZH)RmgrTg@$132&vxS|OFgpOS}sKD+sJZn3m@W@8E1Pu<rRUp}njB6r7z_welLCumZ>H+5Uqw_vX-R_*L#FIk0ZIx^nxjR`3XsG+6o45M4Nb|Rhvp+#iD%Fu7O@jS2}cXlgJ$@fah*{?)~_hP6usX~l>e^-grz@VIPcaOVQs&<Fboo9<twB8g0y6EcF#`fJ4->O4|W}cPAr}DJBci2mAT0WO@9{P0LC9rC5G)s`6cv~Trv0ig2vhoGm9Ws|EyH<XovC?bLaPm_Xg(|I5ALv(lEeq<qH)ZMEG>srPebLx!5>`<u0*eor<%iHPuhga#N~=ktnRdiSgj+!4k5y|5xr86Flqd1LyjCd<jtf+Gpgk8`MC)t4K-C=Dm$YxQUfHQPf6Y;Q^=9dt4VC(p<MmU%bsTsPtGCs%Wc3M7oh%tWGbLd@4RiG92^1d<0>>ULtrgokbs#KYwminWg0y!3Tw7<dqTlvb??ZVva4a7;(<o}arjWP#1frt}Xdpf{qSdfWibwwu*ZJM~^`_L}=J;ABFf}Q=sN_>a2X9;Y)FI^7QL~%%_KB~k-j%IT%30qOiB&3^DzF*o?WO7VhJWvFDX-oLRltlo)rNAKZmXy$hdzr`BRnPPiSjv}E4hhmJ5DfR&am`SXEbzd*~6n{EV!n7Wh@D{p7!0RnO%l^4828Si2Plq?HV_kH`3Eq9<*5w8m8Q=dY{b>)X<`0?IHCYzy15aKht%``@hVYAI&EkT7~NMHu`(Fmj`RwaW{JduW#1!sC}r_=s2-dWA+_nLFzMmCa?&$pQp_?i!bIqT8H<2R=?Wgdt`{+2%pb)Mm<xm*Eg;tpgT;=XuqGD$mwnfKmW__T-$H9;R!RmEsqiIVX-<)m6XTi<mk-YBckPcxN0JQHd$cpue@MsAG#VM(cncQ+fk+T<C+5%b)=Gs)vRFOpAzeVH<5ayjbgZ=rn!1|S*{MkXKxt&=FGc$AJ3Se_bMH2?3qEF^Eu*s<$jMB4TCg7eGODTA9qukLrn$LkzzX?t1yl?bs-o8CQ3uW{lI;I`l&{x?({>K%Q{B!(Lp(A{@ila`{I6deoh?#_lK+6vcafSuEnLIjWE{7_V3@v^r)U<jeNLq5Z+ui4f&TD@tdLdct>%7b4MRMskfW#Y|+N}>k(6a>3P_i(s~FJjC^$WO}C%ybH}+s{dQh%%WzbAvi78>4Ok0_$wbG^O0uAvUWbl%^m{{uu-orVwxfrp`oqzp(wQ99o@~2Gi}cwz4|m9kz8kWI&hUUblkMdfPZx!Dl*Jm^c&?a$MyogkoA*w2b@B)@r4$eMQ~ULjvP(MYeCD1jVQNdh4XSMIj;+~i^EXsbFgxLP?_OU?Q8BwhnMHZaZVvq(3Ej`GLdNj|bzIBWCaj&hhZx8`TDZcwva9Mia41SglE049klks}+QVS?Z}zq%n8b2rmeIn@5jZB75h3s-En?BNqg=ent)WWgO!e7aI31Fx=EL{7axD-}F13)ws}?`Fx#Sj85JoYay$SY3l4=EEj~~~xw+o+UgS5f3W{Ck*e^*37s=K4n+ec+@YWd#7o3e+r#UWoYsa)JD(&Zzcsik*^mR5ioNU7QsW+LGA(_MCo(`}XJEtjOoiFy0pqeo_wpVJ}<)%#523Wq96th%$Ow0c;{wUw4#m!ig%?y-7Js+3$ec4?*lR$z%WmD)L4JLyo6GSMO$h)VmaaX}~2?eN~#7HR7nG8Im%15HhZ1l1G8gz4|-gUmK0x6fdx9PAg<vE44GStHrn_D-$Q(#B8AcpfNkTB2sv7dV*X9TmTv{gai|NnVe2R>y;TtWnoSus5qB!B_jq+}1-EPL$#gYjIyiaFpKKbybGd6%{c$ni?o<!tF{{p-gv#D*WS>@clus{v(W~F<%TtDI=r$V@9WZ`+9Db-|k}JO364<`g?1fb9=^?^;#R;Nv-M>?=AYLYq*5Qv2#mtMit!cO$m(l)(E?LEwhYIB-Frg188=)f6Y@wjq<dvdhL7BDLRX&yumaIS+TA_uL0z@FU)eyfqhp_RcqQ4ZAgLDr5x#j?5qcRJ0#u~WgVm%WFKRjxRNpkrWz|MA?ok;`Nk}(xl7!KN(-*Z`;qO4AWnIhRYsI*ZaAo{Mvcv7mZXi!gi=;HG#b@Mm$IY%;%NZr*Y?a}KVy2=NbRlas5NY30u8szCT0Mq@2OTqiNYe~%$I_;8ldC-LA;_Bet82n_d_N4n01(PTtS(RjlF2Iw_T$Ik9%w7_qd;q57icj@o@Y5mzJ+h-N?ps{NPQ}ntkUK9)I;3=xZgg8W-)O4flHMoXuBR;tcj{H;KP$NK{8V8hO)f@jeLUsqdXf1Eq>3+GhcqJD9p<Y{x5+tIb@s)T^v5c96<eP6(O~i{GGT<|biMDZiy?`n|2PSc^2y$zCJ3bdeHg1|xzG^wPhm*rP?Tq-SjY>DtCV+t^FoQ@b}x7fTl&!<yWj#m8e*AVb;A0eN5-KXN)<j8pQv-BwzoR(y&CVw*mtEtuv&<H1R(W+*JEj8OCFu~4oG3U<<h_0SzPYde_)8AfTaQJ~e+IW^`geMhJdq&E!AnQzqXk<c5#LN#s!9J3~)?*CX5MXyCa)lxQS5CN$6GBl-UHX*&+|5V(A*-~f<3$!gHWtu<Mz~Nv8F)5N-VZP7JD7&+k7Fdin)hPm9j<vQE-6tJ>Zy-N%rr!<7E;N4Nisd$tx%r(a-gZ!)TFK}Ff<(?5ayosBjNj$S*5hlnCaZc@KgkRqS%Te=4WN{Jsekv%JVIpZu}Zx#d=(Z|qSz`N6q$vH_4u?7Q+yJOyC9RmQH#>LNzR+ub%S=3^%{`3L46Q8Hak+cb?|7a&%a*gsY(dCspg<$;5y`g_t(NoSoaU}z(J~P;Z_`!Q@CreQ-iB>*{PZ;Lsmb7Ij!0<#1oN)>792`-@HW@(Bha4>>~Pi%_E$aVJa`8eb}@BF)V(_viq_zO9{<OKGJ#NlDcU4%DdasrsD>&PVV~QpzWaD1IXBSVKKb5b_rNCfbN0bQ~atXdfrHE*A8g!C^F^4JCELv_Ip~*43+*M?eMnLa*ONuZv|?N_v$afQ3|IpujA)-giz8AqxYcpqo!_-Sf{eRqKp%33#6fNnmX)p27g+M_m3Z)JGXGT_#?L$IsZG7k2c2lga8(m$BFX`Rp<F#GN(S2z?u1(+=Xp)vfJ<B@`O!;MA3=cD8-Wk)C4<<OZDpz{MxyN?CAyLrkt~m1*v^y=BLJMr=iY>1vZ4c@0V&4Cr~94x@qhx4#O25XiH9;X4C4;Mdo-+um$FB_m1l9raQn}AJ-ipXf9F{7+a9F)<4uby``++X0h*~SJm7M0%kI1baC6ip@JB8QYG4d%i=3&8wNAE5}V>p-vEIHPgor~O|;teWKC%)ZEmTk%R4@47(FP`U0W;Or!C2AbEd%QZLh`R8}6&29z=|;ZR<6A5V+l`=eDR==ZQc`_WpIA+HW>CN$Kq+69DW5U#u-s6&rDAY#u+`m>p9-f3e3FWxmOVxBHawJNqcohn0E|#~0As8;vdI-#vL_LPHc$ak&NK)Ejl-6-`6D_<LGIfl1R5KV}ZUw+u&Ev*St&aA+jHUCq=zK6$Oj5An&B_uJiJXZPh8Z}|PKeWWmU-?=G=Hk<3+JGva){nB6$)s(Wq%DAabK?GVxlug&UEZkbDHi}=g<(eHwYOAqwyA3m43dO;L9k^Dd#UN!3JchY6{NC+;@q)+p=I=d(rByw}J8Xgq-uUr{6PkLwXHlxOp@KHVv>|c<y*RBk&y!Kn3N1zxctD@{Q5=O@a1?9gOrr|28&a%~#@T_WF^eeuXiL?`njNd33tQV}Jilr6#9S{@`h~--ShXCui%91^`c8Ebm<9@_GWzw-cr@S}Rxa!`n^kv8^Zh#gv0g;>-nR4PK?cXxZE(FSEoUq@!{w@m=CXYz_zZ>fdfpPYLi{wZEcswtcst*=X@wxg@-wQu){u?WL*u>vAOWz}&e9fwZZr~$wicrX;g4)ug}@kps74i2U6giheW;vSt&*(yGv$#Uh*NsttrwchW27l$Wfel3&0-wNJUGvwL$$jTL+D)35#5{*Y2=~y2FW_OpzRpb(iUloYCS}#{oYWUZ<qr&9iVnv4f7H!PB7RYXSGLI5Y3xTe%?Q;bMXV0|J8R-(E3dvfHK_@coku^#-7qOhw%-Ud~;I&{ZW<KW_k6%Sk>dO%N_UE@a23vE@tSAo#YD6rk=>F33IS3=0^VR4su#5?J#R(0BU*wlTn(8>=7}yxuc28h?MqcQzEXF3Yxm8px@sdqMi48uZBY!ZVlo$vO`V1909t8U2Zic2@D`Z)mfyrkYlm!*KR$|?CUg%c20R|r3rl%Iqmbk#5)ZS@ZJoz*?bljwU)yM(>q1gkr3AQ_x@k|%2N47WtgM)S!~=VG$Cb6eHmZ4qwSI7y>&FR#_8Up<6!+|DZ8WT8Q4HeUrEhqL2?^c`Y&QEvz1tzbJ3{I!jhr^NzC5jc4!(zEgIXJ>QNHYXJF{&X|qBW>TO<cPlsg!_z(TpZ<@op?Dvlg+|~}8vejGst_G~n1|51TPqgc<b8~5?l5ygs=W^S7B_ou+_19P*cv04@HTu-_5WyC#hjCQJUV-!=u%;fsT{RC`Ini6g#>%=gn;4(=P(~J@xBT7vkRBNqO@=UJyS<QUH;I!|2U6*%l@gM^m9Bd*%#$4P0zu_hr;ud$1;w=5x8e`g-pBNuufCX{I!*CWsnHS!`w?wRWYpPgAv6_G3$jqFuvd4NQp<pW1E3gDzODjBJ-tf~r*ulbb<1G|wcW&O614&HccY!D5$GBlrNN5ol-Z5#6J6HjR37Gss5stIo}hu+TS4sfP1?+CxUV5s^X3LnK1{Cjj01nmIWs;ZI<z&$+55(^nS0+>d!hkbx#P}Cb5;a}YDtx;trx-VqOR<%l7GO1xl4}{Pn6xFW#?lQoeVd5RD2>LGU?ZL+UY&kn4@~usE?WZciYLV%p3d28qJK{Y5ate9&*N-MnUO`OEw9ocdZT{IE{pThG>*CD{z3@J!7Z+<p+Y8T5HiLS~&6KLQTTshMSBG+*-#x_2!l9%B9xA1NW456~w%)Ev`J6O<V9xXwuym8ef~`W6cAwYlnwnZ+EoSN@>e{rLAyf1KFCGb*pzNn_LwS9A6*Bk+8R5WtaJ{_OA@Dl+WJOB+!y<<gW4K4p(kMRgK7&<sf#QFm4xF`u!WgV(v{Vj=^s%OGOXWTEofc$sK2PV9z5u3{fx*R>ztDdTHMGjLlEQ$E?Pp_XuqC?xKa&xAGi#Z0c$S+o?jTMPvu&GbJ0I+Tj(iq$)H0twpCcN))SotBHuDNu8?!KvAe@&7<6#AxT_4Cbo=1#zmycDF6-nxoeS&w*T~GBz^i&JybKDZ4VChR|KLm2RZZvwuyk>Zkl_4d+e~O@eUerl9C#hXF&C$PDK{GH>B{tPV#AyF+T)ySsXqpp?tWtGBU*5*)`?TU%fSt1v<xw+B=Q{S;~<;27X!;>(1dNzFE!52@}OKl|xPXR`rDGJkdjld>PQaL%LTNv2qq|_4}>N7MHyF;u;77O^C$p+lnrDFY?=`4O_tC%@W2imB0eb2G)DBL8u^(V7Dwq->*I87(Y3CKUXRm#?q*c4@NR7%OOVQ0<F(0-l<{ajUJwNYyYZ?2dr!a3r!y0bb?Nmw-wI-OqHI`wx9~&_wf@p<+kkbk3aq6uYdm&KK|$5-c`8p4l^k}_3yv^_RqJ_7P_8fw~y5Hij^_y`xCa$=@f@N6?*RvgMHp)tfBtj{`J?t{pEl7_x<<3K1{XyPJ?b7H8EHz+^ApF=T+@<n!TaNFoVwa1ZNG0+Aq{+zC`+}Db&kyYEnE3)4&A>*&f(2xuFfN?1TB|f4sf@rxByC?M%D4@zfhGqlrZ(rW(xa*L{2VruS=ndvi^Z-R@m?pDRWX8h=Q?1AHTNfBV~S|B%S2c2pHtshtsbqzA<Z%wM85q=v%n$FHMWAMRK+_ZaHLC?iUlm0dSb*9=xjxqeqo$-kS-{E5_P`soO+&#*n-pMU#!0Hu6rw#9Ub)!#iyR63?OqFbxst|R$wU*w`Nm7iH{I+4Sm_#RR3eUESr`mgrvd%BO8en+|4(3EToRtM@vb!yFvKfSrNu;fV$x36m~Xq(rFub)Y(uLWQ5|5V67o6XiQom<QB+uEATR@IVc>q9Z-Tt~Kwg?L*j4N#UUp13Tw)RF1xV$&X~em32Cw#Mz(H|SAL{_GycB7C&e9CyFw^PSnGVCLF13XcsqL7Z&UEML_g<T0}uqOp!1b&(6kU7_i9f}5^aEVe{(clYb#K4xQE<(GOKb?vdQPqELhY@3sxCE#HKvBoY8ls2NWD#a9nZUb|+rQ0qZtKi*D#7H%(8>oy3#{BEvuZH(r@Bx*ha&S&HEGcS<qc#{UPyp2CRs#Is0jH+5_qO=Cwh`&tYExQ;dcB`D24Alcd<A)G0A}$<!&=Ggdijn#p?lNUsS3z#q^C_Y^%3z*lZW`3B(z_m0~7qIX%)Zdv;N+~R%|J>nZ)?b444nIE?CRKVur5gU?Cs!Eb*GI=+x8q?A~UXeJfyuNr$F+1P#0h!Z0<A_F7(XaHZT*N14Bz*0VgoS>!pkc1juXZ6*Wv@vRr$*iP+EN{7gU%nsEJvhZ*O69=(mS?wkiNBdGG7TFnRv~lX%3MzN#Cw8MXzgW!KrBJiODm%4d>qU7w(p9W1>w4So!%PKc)Uw1?t~XVaw=xREQ=l%U9S%PWj+L{MI$cnjyK%nMdz>8F{c1ciaC&Y0Ksyz+^qfcg{K`D1DiWv<Ks-;y)JjdlM0qioBG%8`v7=m3#?U6Tk)kJPxmeBEHlbWl5$6%+%7%t(1A{ToOS`7`PEBB~E2@z<%v+H$4c%fZ*&#hdvaIqu#)fnr*-{?;V61^xvr)qvZl}YsP#48%YRGN-+HCAGsV)F(sa7rxQe3P}BScO$#+zaYyQp3*GUa4zwL{wdh$f|Kx71ag#l+&RS8_cg6)LB7FUippG$!>aC%;Xg#^C02zvaqH*?af<cX54AYfLpx*=E?w(nNeW=FQp%QVk|Hjf_D*p+pHYzL0#aOl2&J952u`+;7=S?e$6YPC)94k{$)N*_8ef`Y4D|TKG=w?<?EVs<0_Er)Iz3<0QQib+P-1*wPMMXCG<Wl(uks`NtIB;v7yI&q?L7-|=AFflpJL@`dI?nhqppYv{)vHK1kMdv#N+N)5{1BVLYmgP%o`mk4!Fi3aFud3$qOM|WSNp?n@2ZHpfwl+?RE!S4+&wvIz9xvqh>xB()3AhNi@io!!1o)sTxFqlN%jcLW$n=NBcydP0#j|}zNHju7a=$7I)tYcftP;2*E4Yz`-q+usd_0aKo1|9Fi0GC-@u2G08?$0{mKLRb-?cuguyoqr|K3bQbw~maqI9?hoExg9_Ve%_2_G!bGQ`ZibMYZF3WYKE1N}Z0ehAdjNQQcd%DJ)HBsO;zV8oP7l<W(n*&y9NU@wxx-?4DN&^>qaH`I7dgqf*7a#Mw3WtClLKlF)dq8G6ocaL!ooA<i4tTzj&iN7YL4rKUJ%V|?;vvi7kwSk(itMx#x=nQKM1Dv2H(2|ZU-F9v<?>P|)?Fubl6PEEo?O`OG6WW#H1**E@t#^?ckHmWzonq)@9(N2}19hWm1dnVP*(KfpV{$9tw-rvHqnTk(S_l=u{+b2d1Vc%cY)}kNNi8uRn9D?dy#@n3PmYdT&wrbh8S&BAD=$o<nvFYaDjKOB5j&9W~AM8hJZ%uQKXTjQ;->lNxxbjevVQLV>)r76)mZtpKf;!5B#=EEg{>UtKEd*Co`;1bCZGt$UW$JtOHW=7EZCxEL>M&Mq+Vg3+K!XC0^&-uKn<sSlEHoyl+GsgNcWJzL==EBKu(<_fGBal-$5B%ZSGcFQ=w-mAU33(co)D|?p|$hQfKT<_-(rRJHLdA&)o8cq18`6b3$~63*8`fBi^OV5r1o~y3Qg@Z_!gFG6*MeD&<2>?KNSQ4<zRYR0%es_X0y;maS)#>s7Ca3(oAp{CY|(-{P%1C-SmmI&NX#xN3E?XZcJ<5wrjq|=Bhn(nUtNQ<6;FS?#$NJ**cYehZ4)Zo02^@`IqVgm(FDOR~jOO--uEP4o0BfAKTlW?!n=KIAv*5)H4wX7Y!;$*GhcolZLo3_40e`KwgEO(CzKBp$`KF{|IL~+%;5VWNl#2f|}GbKY4>A+Ng&11|suzU(w!JriS5OBwLZTz`i<~9izh?R!@xXY1HgKM)&jtkj*HrD2G*}$F8E!@n{R4vP@c}Ejzd@DxFKYr9JYJ7&mn1sqNgofvDU#4^51O6-jp8TaoE;cPr=%E6|)8sYp64yatVxes)xH0j(9ZV;g+FSo@q?=~Rj%oa*+C%y52CMK;YrShef=h*@WSyCvORS|Cp2=-JSPW#GUXR2z8DS~I0_)^SF*Evxmm{+3L(#mO$-)2IwgDc`bS@B5UzQ_(UCmzC*QgNTZL5N>$idJ)gAhr8KVgp#8ZCN{i?GPP4rSl*2lZXR$W3*0%Q)fx!vRo;6A(F<m`cjoTOn3|Y)G?}Q_9eR`W*8Sd$h1EbF2Xi+yek(b@*(6~Rv{;>ik?u*gPG0M=*xt?3H8NN0)Tniqx=p=RZY#GgT>;Fh=ggs@o%HtM0zEYz&zD;Dss+v_&Wl)PS81VkuwygMcxOtZRq5l^PmMi(uD{co3aqL{la69>*m64CjD)kqP}D5hc!SN}_$|WqW3F6#XgHb%Q32wOf!kMzVPd74AkSO$?gy)VurKX!5RU+gV;#!sQw6~(r~*~)d&)SAnvxnc9C~^Zg^xH8K=~cIP?JH~s>nayLN@jDA}cjadr7{B)p9M6JdBm9NpKV0rhA{U7*V~-?&R2~UE{uHO^so&g<qvo;jPbCI-<6b@MCm*L~q9oL|P0`@|P!&LMaRh<?W~s7wOfH@TUe=*chEVh<b#Uy<SaWLroUO_uOSS_Z4Mrywx1R4WkiXIRa^|M1Ao69)_$`x304X>W;F|@#5D9DgX|yVM=wnsjI=@&<@B1bJze>X4Vu-M`H@H+C)_C67}Wk>YFvP=+E?RV!?PNkn;pDXA2#BRT!(Sz8K$m0!(RD_<}3sa$E5pR;vf_k)l&eM`F1mU9i~L?)E9rXDS#2ilE*YLU=Yz{ZOa_sN}}_7+mwQPP3L7=yj>%n{_UuI2czF4PT0bMJoL;l9}rC%nd{>_FT9!-EA?r6+69~V*32Zo^<1YNt@F|F=8bg`>FmmaJJf9@a9!ZP4vl=S}uFF;)<ze>yPq7-N6(-FtCUk7mFQ5`;J6jE@+SOhi77SrlA@Su%6YZm7LnVvN_)v>q`yvx|`D3g_><~lgi?%f~{`WoGOnIVOdb~QrEY*GZcnsO!UYT#YD|wqN()Y-uxxQ>mlCL0VsF;OVgw;<`=cqQ!c*91|Ie9^n2zPO{Jnm%EUw0!<-!!q8i%v*Rau4X7_ut`&k~l0QNHNOsnUzeC6l@K3yug&ckZ$%|r^>7ZVA6WT>=W2PkXK_LDX8;VN;`LdxFiszm`!wHU!lBr#Wftu{~+>20sD?ie5K=r0JLI9f^}AqrnhdBZ76MR*_s4dXt*tn~24l~wC~eUDMa^n#pDTf1Tzr_{Jxvat$w@7-Vjs+Mw;3+{4NLnY3vcSu~EO%$N3TwN!Iv9v&(^%_46g;u87N^0uMmC(M?Y3z5(H|V;zGuj((&z=MvYCIP`iiGwQz^PvPP`*F*_e_|KkX{>BshVD=>S-D$tbIS;%%gE$UH(@uLIy=P{C3b3IyN+m2u3D7gAY{8pg-Zwf-*ghO*`$YxpI2>M4>B9n056vYU)T0k#{!cu-cfm7Ef(3u$-0D$3m+@7be?YD9uyO*ZMs>b<`kRV~`%O0YLDww%W9p=Jbp&lwaN=sun+EzXkH@pge*RO_$1`dS8Iu6+I=6-gJXUnj}y5DbOHdEJycuuDHb%6|}WWf4EKv7krKzV_c@rqYB>6F`?3eXEgwrg*$u6S?P1@gE^}&s8Ob!H1z!_S2m?G<?*5PZ{~Tt1CM*cSHZ(k4SO%C6C&TaLQ^(_cng%bmgGIBCg6vD6tGA2XzGwYs2P(3-#PXxFp9u~d$Pi(7^mZVfNU_Tjiu$8=11S#)s-tF#D)}>txg)|c&`D4!7_1FExLcsw6d7XgMxp^=^_PhFFqS<Psh&-HRGuD%2X|=p5BVlXfyr$bkXfAQjoxC23&X;CE8PWzGC($1e9Ys@d+J}{!Ct4C_4?i#KhD0m|IlR@TRjnwAxbiaUJVf0t96vq0_DrPc@UClyyIlH596+W%?6nVmaR7IKr@II*LdqP|>9F@qS!7?VIaLdm7K?P^Z=M&iP5}(wyvbT6OClsl%^CkWe#)Dhy#e9<6g#v88o#+QTOe$bHpZ?Poi+tF=;HEuYWJH%tN<{h4x{DfH$>T(rIXNI@QP`?I#odnmSTU-LQ#*h)w5poK*T@pj+Ou>UKQm1IA$hopX5_U2nc4cCJO(i`6W@zxP)JiSok_fre3{~kHPy}w16R@FD$)biVUmivnDpIhEuO{_@|OHMsxcRG1q<GN}8xN=oVnq(60cehTLkb^m#($sdZ5i9N@?DKoQHM*7J#9b*>#fmmvjYrjt#bj%?YfaA;&kprXUoiDD0iB}f^jM;)Exr;_u-kmX4E4@PU-eNm0U{*_ehUz_+v9(Jq8EjPnqUT#W=AbKnnwWZ$vocuh&h_uBig^}pz$ag8Opw$DtOYME+1htw#gUm;=;cFBanGL&pcfkzwUYL{>_`s8h;!;+A8_lHx^plU)#|AYY{YP(aPx$bV(ZD)y?MdlfAf>VvQ_cj(4NpZB-ulD(Z?21h&00vE|VB^}+xBx8MHxrudckz{36=&R*kMoR{h1p#SubzyAGCqCD{1yWUx7&GWatwHCRskF9Jv=%4u_HJD-lE+crc5(<?2`saVVz5Qo&C?#-oEXFAR{`R-u{!tZ8y#Cac*wu2z5NM&4KmP4sfBoBE{^!rXeR%h{a8VidKHgtR|L~cgG%^$257H;vXZl+px|;3!c-uqqvGc$GwXc@iGuvTUz(0Ua(PuO>oA<XW_pl|T@E#dRs_i({WcxE&QKbuZ(7bz8FL4b)<+xP_tvi>oEtSs$jh;B?>f<O_f#N+%2Ya`*E#DGQ{Vc<w>rE<q@H=`=Z|hw>>{oltTj%lwr&&A0KIA@iHm$d+le8D^dlhUj<+*BXz^zlP`vu)IrdB?((xz6bv2@8%`Wv`~nBwIlVMwTE?Us&H8yt2IZISV-7?@JEs61`?8hdqy%12Yh7%KX1E<0JtHDJ83khV>~=3#LMK{;kGr2C~vel35gM*n0-|70XO&5A{J_Eh^+TSSG(!LCLn*ObdeFn0e=%#nlYLbR~@HgRng`-<fzVa4WZysl-)u>+56=$p?*-h2^}?>^rI<Ti0*1_^Z|JjPWIs}>TkXyoqrsvsI&Iu6RH<i~FY>JZldD<5k29a~4&Tnf7<_u{q5Tdn0IZ7Vr2Y#N`Gt&704i6j32gzrAWY+$4^I7AI)f91wLKu)!Axj&(p5+M6Osv&?jby4LLd!>y4XNzB*Qo2RTm|2(hDA#joD0dNQ6TBa<;L|Ff#gWotyRI3Z$0*<|gF`0PZIyS^H)Cmq((*<5Yg8-g7kx)2b*QCh(N__*bgImmgf8x9Z^Y9Y+E*)&tz?as1ed}dQCEKn1{B{YngR4oN8=`_<V5%Hvxyd4Vc#{#5j5#`V_2XTP&LQvvGltzl%u0&3sTn)7oizhOJuyBQ#EUgG#}9)075@K-K&+5N`8<YwD6j4{!FN_3m$B577xOOmbdH&32j}Emo6do)Q?<K^a3fL8`3=kyPD@u$59;BsMkR$eCH7h+7_>_N}(Ma6$xmmwF{(KZ9|&!uGjoI1ysbWjy01*y?WHm{t5O`;!K5&%wn&P$wV6FH5<0eR&#9`z6I~ag&q|f7K_Epv8sznJ=FMsc~=qQ>w0qgGVJTo^*uJ)uB?F2s6(yXR=%LR3s#8q-kiyY2aadfBL{;)Zz-m)4x~!9#g>et9Aq5fto&D}_j1`Vtj<yesnTj1;UnjJPz1|FD|%=}U%h2qi&nFj4-ZW|;`5`Uol4K_$HZ!!U$)HEs|13TfwXXUl&^wQs_azukb#txE?bcUusYFAMd4OOL+3PB`frE#JE&LK#%&NeJl91%-BV873s}v`roOd7EbLY?Jr`MmsXLX!5+?N$FjGdR&relye@h`MqP=QbUWq&%DyZc5A-_k6Ijl35g(kNvF;?y}F8rrNaZ{7o)MSjPX~$s?7xlc5dfYFI5WwS>g37vKTm(@Y(FqCOJzYhx{a{lS*=sx9C~m$^wvf)xOg|!A6W@83uF3@+NpZ?D{q(5Jrd=T|-JJ^wxRR|6GJVR?MA?+ujR%B);<s!QbD8X~N?k-LhL#PyO48O=f^JHz-dc5`Vin(}1kDyUeNfF;+4@Fv!wrkHofMTBU051bz0edmxZf0yX#{?YS<n60W=V5YJ-uG0LPK@ZqUs&dJ-E+Wv=WE{`Sn$I%T?xxA5hh01|++}(q7ckB6MyKbxltA-53`ykHqhubxlXu-YI5NX4r^VL-&AEpth^DPUY;Q5wH-c3$x8R1oc*LQe5M^gR`Zg933j+Hq^>1R6&;BT)Dy?NS|Vg0hZgp7Bv*~J?71-T|u{H+{tY*v){i@U{sQ0h3n1A&M259>@>lw|J^SVwN$DC=~|DL()VCX!^a<!dOC#doK9<=iZtD5D`*Qa?@Dy`<cMQUMZxp8FYVA?ZV2T}e(vKI?<-y8ZmmATH|J4jS*88Ktx72Ss}wmZ5+qaka@QPQd-e#0Qd@g_k&K3cXtNE+ATM;+iFf2zJdr(ERaS`JW8~UP!vV|!5)ExWr)*MdDs@u$($E2bq9MK+e4*t*v#nFbF=eRxNPnswB=UrFku6qF5lJzVxO)FBcfnF)bg7*x?as7Mp6u)RM1<w@J_BnJc~_n4WWxhipVxh^+K$Qkk|ay(`LjlLR*+Gpp(>;4o|E(%Sb1Kp0}oaK$ndUh9O$+6so<6>b6c}uU%#W(+CSbR@)l~(Pl@arb4;f2oj<KvW+OciQ<dw^K)!ohR2}a70G?u1TI-Ury+@cx_7IS5I#uA)fDUOZGAa&cjy3F<-dy2u@bixbt!oQIs9x2C&A1IRCdq6Fps_NTP!{Ay*}3PKR_57#H4v*W(GUamxZ&;nxB0*M_m(^}aPX{W6y|v&Sfeew$8HoI8gqwBiM%NnsP)W*7|2x6tVx<xj5{{Bn=0W_Q~EUov`P|;7P;H~0yhC^FCv9Yp&FIe&D{0vpEbAA<8mhbN_IT}RYNbZUmhBt*SOl4g145sqSdjXi!$t^z+yjWgJQTrF=169Or62%kXKBrCh!<@%P@}(e;Y$vcZGKg3yih{;l7)>5;U@+!fCcdeoG%F#7P-aaCf|;l@DGox}p^}lfcue=I_xrr?w!qpsr;=i;9;-$!eUAA1{n~Pi29h4b|z^Wp%wRO)9%wT$igF4k`{wPD|M@J{n<+V|w<nu~chDCQt>teV$UFbM>1I-=mJf7C|?07Dt)0(>o~p=krgNa)ZVox}LXN?Z(X|a|?TM)B|)d=)J8&!1`IR(i&xD)T2$gJ}xFQ^hE7)g#vW+v@+BV98uakrO<678QLg9bnd`kR&~%VFng@bMg-dHn>^F)_j3#O+tLrL!y=BDu6@?-+vK-@^0MGB|EsSOvpS?f+$N!F(f{=!1QWnf%bD`Pcia?9OSbB4YH{zhJ}f*GX&H@Ms)uZ;tSA_)TXl$9qob;fK1A8P0<#Y-SlZ-+s21zJitH<G9>pt)mo`Z$mFbs6D0GxAnTDgYMRR=X?QNK`Y^TwChOCj_z>&Er8MqnL)o<RZ^t)#T(>&d&u<iv+FXl+U+q4n!BTYItMbxsT^4<{pf9(O_a?tt)_^7z;5Y^A}dpEs~m$vPeT9|v@oH%r+8O>^mIeyerd4D&n5WUn3Muo{y5m7UpuJrvBp)71t8r8mvuL|`H-11~~QTs?seqn`ro5>~X3=vC}neyYLt&bm6&8e`6!})yKr^mdiL!wZ@ITWg;7`biBBz^BQ2Ee1C;q<KON|Z9O?R}@^&g>bBxgZ*C2RPGD+xVEiwJuj$$>Xh&)_$7P@KNpE;slHw0Si#$#@@=eYWueGsPu#?>vO&`PI&u`^{Jd&HeZzE47+a)?G;d}r_4_Ozj{!t*Exr(m4X%D7A4`p=%9T>R6J{aIDmS}qhxv4p0i)sb*`4UN(|LTS7MB-y%kdG>5;N#>zvZB!_xN_)+*?va4LJY-BevOikd&ht6kMh((U?DP7og6-ruO=JW#Emy6fVK`v$$Mqd2%m_lsquPPw4+ixMD-FL%FB(p^E+R?>0%tSY-kB@fc3RF!US8=$Xlg%alOy!oOEbd%A%hx@SHhQU~tuLhjn6N}cGZk@nPKC151uQ_gSY?x|aymyKSmKpXcn74LleB~A;%kE&{*U%g4>3#3K5p65Z^SArMPOG&eLa-a+a@0FNv@4>Zt+uk95~InKSv?!n&gr$j^p7ApHbhBP>au!T*BEMVt}9osOLK3ywc0p=dGK@VkY-)`Jw*HC3aV10M^F}wUdT4xg7Vg*b^6o?rfT%Vtq!1U*l8*y)M3<SNXL;qa@Kxiup_nyavapT`TK5ThXTs%8<A|l#=1O^#8l3U-vQRSJwZ72s(mfLv9bE0_W7G~^KQ!3=45nvKk6vb;D6IqTnLeag@B`zdyF)JCad259zk4UD(~v+>cE+bXAHcfvE`W!J_g0}JM9I^ysL&Xjcu?%tCpeFix=k~GGneo+Y`BQL$A}L7IO1)<&NtVUhTK;A!!yrsit3{vT%8a^e13vChwEU7V27{?L?*IhHa3}NjW98bd&0tXwwX`dVYv-EH-gK+Nr0J_?2fMt>EX*J+F^;Bq(>JR)R~=BStOLwpfbO=%qT`vUn^>CaXRi<}C{M?)DxO%(;g6o^{S1-F`|FdJ7?wma36+)CuhUSl5xwt*LcFnf>+ViPL$ejvZ1t>z5U-;F;JRg$m*nQK9wfn(|_}eMC?~qSM*Z(^qE^NWF*lu0gX<Io9_g_3o{=P!Gm`uE6-6Y+YJUw&7%~PP0h)MA`4VWbtc6q`pvsPEDS(rW1Qo$FEf2_m^TSJ~+(!ILxLff5IP(x5aHE`iaaIdMR=4nH^Oz*k=!qs_Dv;r$?>BQb#TR$B$&1?pNzF(J-_S5N}L0$8NP{=uf$oW9si2qO)p0pRzhk1!hy##a3dj`_k$62Y5t&Bnw?={BF@o%3iQ|IVv~(h#K{+^#Rk`au18)s2>V(*p|}<Te&LG32iAF+H#&s!%%gyz~u?l%9k%g4yUx5U%%7SAYv*PdZ*F?GB5`+Jpdxktm0)39_xp)H;uJC22L@m`*0nlNBU#Q&1+2{k5GF26yCs3p5l-H`_7zu|67^=7`_YNoqgbGB)NMrcDTqO(kru-)$YGI2nI+^elE*blek~LS$H1F_={0}nQ`zZFkJ<rL}U`rcr!nc<0>FZa&mc#8gY!D$;?zFr@pB6k7q8b2Eq@5qQ=<%#b^84-F_S!1I-n`BB9M|k-b=r*)PQP@<^5BHMw5;C-A=;&r1wf{pn;ck5P7fA<s(#D^P^%<u#Z`!u=Je=Wp*9Wjgq!M)zN4B)=KKA1!)@-C^oGjl%c#_`T{Rd~k^d2H{_BQv1m*QZG2J-9*Urx})09Y(4$jQEl^N@_oj%AKDo&JF6X;j{QDk+QvitLPOa-9;`N%Z8q$gXCKQS*lkYj&+%%b<X*eWYs{1H)?@oP`3nwXM;S_T+k|gDCr_3}`ZEWBhgX^L>}WhXJ%8f!Ri^fOX0U3Q^3NQE>+R5cooTpexFB=3zBUeLNQA3G#m>RT&W#m}!NmYyXzHrR5|xnnz2`nAtF+XvO8+CpxC{*A{>G~)=y%k^*!;n4k|!7Q8HHsF%<iU*=9{TOEOy<^#-}O+|39Zh_!Bw4TU6hY0d)j7+RviB4p2XT?xtUm`nuMU`O>u4hS5rz>yI^;UX#K)&b0SQb{#l|>3;h~%0}V!^>U25LD_;1i1&*S^<YMn9>uDE1Q6O1k!Gd3*jg6;QP5|cpjLBi^Q!=I;YgZ8W_V#<L5s@L;}rbHe0Np?6p1xf|GRbQIoZVgWhgFp(x3kE*T4S>cm3zz-fz5J4IPd9h%zAIFVwfvwKrk+L~%v$&wH*Z$OMtcOUv`+hON=Yz0)ut9mRgyG12%N7FSDP4LLJAwU>Aw0L>DDGP4}${!y0d7(@?@U*JZ<;?O@^yS%Xj$0EVf+Ak`d_Dd}<D+deg(X3iS{mrySV2D8BJampVMngf%2w)f%zU|vn*Yh&G{1~xu96I}LiuLDomaGj3>r*pkKkoY;QYcMtxTHBa%i%qinnZhLh?4C=ajRNZ5+fGfp78t&vA@*7Q~5@IVEFK-%xbqQpDn&uY4RcQnx~;U-qb>N8=zIsIpuFP0v@k|PPw;r-I#B+a<#HnS~X5-g_oXR4|mH{au6k3$>ES!z8cexC5llk)V3nb&AZOXS6*Y@KWx~urlokczf*fsL%}p$HV89^@8qlW9_pIS9R&MHG-oXo{O%Xugvp>f9e?{WmPhywYPH^Tz|pG7Wv6@9W1O~`+muTRmol8cQ-8t@KoKWO(D;dJ4bA6QryppjxHL_jTIEykv9#Vft937);0*H%Ff4?_-DHsygytrPvOnegZO9u!qXez&l1jLbP7dAjK|YULvNl6ntle>bC8mi6zmX#x8#SiBF|dN4NxT_L!K1XBwR6_`0yG>^NKiQotqN<$w{77Yp4PBu<bh3I*8~A~ia1^x<jm6s=Q-xKq|R3&cDwP7FU&^{c%v6#L}+rKoh%7~j=1uvD(CVW_Y*=VqR(2k&Dz~r%d0mrRyZ9_3YbyHE$q_xtF-{e8nn)h-zi(HFWDW%8$4Y2W9{wsdl>Zi5uJ|D>T5J(TM*-T75<EBg(<=ca{g9)8ES?#Tkm7Ay2|_7uwTA^^xnQb=ZzBjE)xNla=T0bTXLP+)Rf+NLod%C^1y6*rkC#n4s@V5Fo~RBp4y`HF-?#CYji^o0iR=<^=EP{#7w(BWWt}=FddBrK}*GkofROenUtjjsdv@JCJ*YhY%b?-K<&^%u%pc4E@x%hxO;l$7ig)ESGQjEU|Qz-m!o7Oy+@6|;~59Y+DY<7rx(iNX>gvQ<1Cq?XUv}}`ToE>0j)2l0dE!EXpJ5QUx)L<K)QD^FF*qFq6*lpe6*1o<IiR@3HDhkb;A6;rLzC`gN4uULgX^mn}P!fqIW3pI%lllps&za+wb}JZ=qN1QAh-A@)OmpE0QIK7|h8x)C*}{dyB2VNc1E4kRn<{DMVBqAGvG@Ny^HyW~z1#_Q8z!GhyHl{NMlA|NH;^AHL83?|+^7Q|D7U(J7yX(|DRr^JzJ)r^Me(r$l@#Ii-Q$&M8f&G@sIPO6!TvC*sf0iSmht6OAXDPBfor;f(B*&!?PDnSW(I<>8daQ=U$FKIP?<*VAx54e2z{X~;MK9Zth|8m7}QpN8c$tf%pO8q;Z{)0j^q-`RK?CyuSBaXF1EZ<f=PP7|G`e42*S#5X>jruj52r)fRS=hK`{Go9vqnupUoo@Rco`7|%5dF4a(X-TJrPD?&5!)X~$%XC`!v6s`bp4RheO{bMkYd)>RX&q1NbXw=r%5Md)h2P7WU(A``%$Z-!ncvNsU(T7|&Y54&ncvTuuao!3*WnG~72+M@CE_jOHR3(;i%k3`6X8Ykb^J0Dzs<z2Gx7UO{6Z7I(ZsJb@jFfYQd5RS_&R>CiC=8uH=Fp?CVsbxUvA>JoA~u6ey3@G>G(Q+vx#4A;&+?)<tBc+iC=Hx_nY_yCw{|egpK(+e#wd7a^lyV_&q0n(TU%5;#ZycT_=9oX~JUQ>-c>qe&LDVc;Z){_?;(y>51QZ;@6(|y{8$ghOgsSpZMJ;e));te&W}k`28m~Kw=9dHbGjjy!bk{LSi!{wnJh=B(_9iQzW)UVq+w>Mq05Bu@HGBvOS3HL2M6Vdl1`$*dE08AhrjwJt$$t@^x$vVtWwVgV-L#_8_(gu{{V28!KCuHeZLujn$3ijrENMjup=KAhrjwJt$)j@O5ktVtWwVgV-L#_8_(gu|0_GL2M5iuvz#zwg<62i0wga4`O=|+k@C1#P%Sz2aVWOd>z|^*dE08AhrjwJ&5f=Y!7045Zi+$Y(Kt^?Lll0VtWwVgV-L#_8_(gu|0_GK{NI#U&r<!wg<62i0wga4`O=|+k@C1#P*;C8=9|Udl1`$*dE08AhrjwJ&5f=Y!704(2AXpt<QU(?UC6YneCC;9+~Zt*&dngk=Y)Z?U56F1YgJY$ZU_y_Q-6H%=XA^kIeSSY>&+L$OLD?*Ree^+at3*GTS4wJu=%P!{xx|!0CwB;p^ac;CSG9;CkSD*dCefk=Y)Z?U4t#C%%sDk=Y)Z?UC6YneCC;9+~Zt*&dngkw^G3zK-pY*&dngk=Y)Z?UC6YneCC;9+~ZtCpbL5j_r}z9+~Zt*&dngk=Y)Z?UC6YneCBhct*aC?UC6YneCC;9+~Zt*&dngk=Y)Z?U5I_P`-}sk=Y)Z?UC6YneCC;9+~Zt*&dngkyrRyI9v9%Y>$EMF|a)bw#UHs7}y>I+hbsR3~Y}f!7KB1Y>$EMF|a)bw#UHs7}y>I+hbsR3~Y~q;J*1fg6rn%*d7DhV_<s>Y>$EMF|a)bw#Sg+;rTkY$H4X&*d7DhV_<s>2nL7-2nP}a_&NjvL;{2Y!~z5Zw#UHs7}y>I+hbsR3?l*tU&r<s*d7DhV_<s>Y>$EMF|a)bw#UHs7$!s(zK-oNussI0$H4X&*d7DhV_<s>Y>$EMG0X@-d>z|kV0#Q~kAdwmussI0$H4X&*d7DhV^|QY_&T=7!1fr}9s}EBV0#Q~kAdwmussI0$FL%(A*yj$V|$EjkCE*$vOPw&$H?{=*&ZX?V`O`b3E_{gV|$EjkCE*$vOPw&$H?{=*&ZX?V`O`bggD99u{}n%$H?{=*&ZX?V`O`bY>$!cF|s|zjDX75u{}n%$H?{=*&ZX?V`O`bY>$!cF|s|z0g;!lV|$EjkCE*$vOPvbXM|_OX9Q?OXbI7L9fCBXG{Q97V`O`bY>$!cF|s{Iw#PUjmh*LNkCE*$vOPw&$H?{=*&ZX?V`O`bY>#n9(C6#e9wXahWP6NkkCE*$vOPw&$H?{=*&gG9?0~OhdyH(4k?k?EJw~?2$o3f79wXahWP6M&(g@@coJg=eCbq}K_L$fn6We2AdrWMPiS045J*I?&gRf(IOl*&d?J==ECbq}K_L$fn6We2AdrXAPgs)?JOl*&d?J==ECbq}K_L$fn6We2AdrTQA3}46gnAjc@+hbyTOl*&d?J==ECbq}K_Lv6bI(!}5V`6(uY>$cUF|j=+w#UTwnAjc@+hZD$6!CRzkBRLuu{|c_O-P)OIU#jI?u6t?vM0U{`4bW-w#UTwnAjc@+hbyTOl*&d?J><rv-mo;$HexS*d7zxV`6(uY>$cUF|j=+w#T#}ALHxT9uwPRVtY(%kBRLuu{|cX$HexS*dEi0#0{Anr*3SIne8#NJ!ZDY%=Vbs9y8lxW_!$Rk2xX5<LlTSGuvZkd(24T|5y5j651K7t2d*aQ<2in{IDxt)cW+Kc19x0zkZfvwoGbg`FcxgXZhZi)XqqFD@pB)MEE1Aoe6(qzDsIn!rxmZsh#n=*hq86JIa#O&bgk{&iFeMuI1m0zm@Sj_(kJyu{me9;XL4F^S$G5u_<S^<&3|@)|}a#Guv}!gU<L{Bdo&L@!y*HZ_WI-X8v0<{uWzy#@}Mw&TQOyg8BG5-f%P9cZPvsVVD>;hLK@qm|5)1*TK?k>X~glv$1Ek_RQv<+1@i7e1^prEC{}iZ9cQnXSVtbv-5_VVRzneGaG(p%g-xT4weqD9k%_#wqMxx3)_BS+b?YUg>ApE?H9KFlCZ}3I=217wqMxx3)_BS+b>vYZ2N`R)xx%42#b-gV>>Tw--YeCu>BUc-@-Oq*k%jcYe51%;%ls2zLxE^uw53m$-*{S*d`0xWMP{uY?Fm;vJ6<_d>z|lVVf*$lZ9=vuuT@W$-*{S*d`0xWErs+__}f0?jMPCAgNuDY&Ryg3!Z~*y|Aqpw)MicUf9;lgw4o*pKZOctrxcS!nR)6)(hKuVOuY3>xFH-%s7Ygb!_Ve+Zy{C8yh<tTN`^Dn;Yj<Ik56|{2U8E$HLFC@N+Eu91B0kg6CjcFZ>+K3O4{hz>a{QW98>q`8ig8j+LKd<>y%WIaYp-m2JHyI1IjyZN0LsSGM)awqDuRE8BX78-WjDTdxGq!q>5_SGM)awqDuRE8BWyTd!>Em2JJUt=EiGHDAYeUfIqo+j(U>uWaX)?Yy#`SGM!Yc3uY@zxg`0^U8K!+0N?#_r=$-omaN=%64Aa&g-}(wJQ?BCnvS*i2vum&1+&E;WznjvyE4_@ya${*~aSxkbtja8?S8Rm2JGTjaRnu$~Iov#w*)+WgD+E94}wTHeT7rE8BQo()Rn=&MVt_Wjn8I=auceF7VR$8D9%W4o?nr0`LUz2>=vu=J4j?&c&a@p^HZsmo7eCoVs{*aqHsO#j(S)pOb_Dd;-q>4DWu1dq2a!pAjn02$pAr%QJwBGo1XHBx>Lj@abnb^E15m8Ls{ee|<&<x&@atobqxM!f!{y>Lk5<k^BdL9q#@NzkWslIRh3s0~a|XhMa+noB@rTfsLF8iF5b_;E^-%kuw02GZ2z9Ad)jMk~2V(Gf<K<V3PAFp%I@zP&p&2oDo*eh%0BHC1=1TXW%7g048T3Cg(|_DLw(v<P6m04A|rh+~f@4<P7BG4Cv$x?Bopa<UC6N#wUQEoB^PmfuNiLp`3xCoB^VofufuNqnv@GoEM4N_ynMoGq991z?3u4lr!LzGw_r%0F^Tkl`|lf^D1Fp;yi*mj3z08<OGrwNLC<ef#d~}7;KrrmKxv_k{n2OAnAeR2ZDMD>?ODt){i6!k|ju*AbEnIUjlzgsvrQEAYhU$2nHq~m?R96F-XcFIfEn(0)+_{CV7LPVFHH<9wxbiBo6|K2_`0>n4n?;iwQ0!z?dLo0*whaCV7M;5|T+sDj~UqAY=lO2}UL$nV@6>lL<~HK$#$A0+k6?CSaMMWdfH8UM7H<AZ7xY31%jsnV@C@n+a|vz?mRt0-XtVCg7Q%X9AxIekK5#AZP-i35F&hnxJR`qX~`%AT0q&OMudlo+sdGm;5{dSW7_G5}>sNY%Kv?OF-8W;I#yNEs-SHus<NS1dJ^KWJ^HV5@5CjoGp<6pOPd};*^~Z4En&J4-ERipnog|o$!M9AaueT&*HCS8vtu=z@Zb2bOE9h$?n0AKA`ACf>pO;(Fw)|7@c783mTnB{tEUYjGsu{oQ+5)EDu1^32OwHbizW3fYJ%8sRflzSb8n6biz9QN?bZ&6C~_{Ju;oJEpDOdM1n)(u?38l$C(A4P9(52UMBn)iGkqBNGv4yG%o+<Aa%m-e=KEBa2~fgdm>4hW!)l-N}Pd{hgTUT(f}^LfvXez%qYtn0P+oBo#1&AT#p7>C-|cThXl|%!7C+_b&og!$8-U%6Fk%fxlV9Z3BD@9StWR@J$jwsz7qV`1;0*kWVZlzf>%o<y9QYG2Zo(UKx_HYASiYsfv-0hJJAP@ooM^daz(NeTwsC^OeFtAR3h1Ah)X2kwp=j@qMhIp6MSMK0lE>W1?@(p#s%<?2@W#BL#Di4fmps>f@lsmiCSHPpG-Mj{wCaI5`T%RT@r_hx?Muy4nTK;*GzDmlcWtKc?13+eWKkdZ|I+VHK~Aif_DYto#0}h33(^@>s!n_p@{e_&^u+xlmPFq@<rYfYZNA1fbW#$JxPiMn6iR>^A8u!r1OzU|7w}^uLgW4q(09?z7z7OghVPKlS)~<2HsQ_w}Dd!(y4@eDj}gtl2M_&pCqM1fj=RqN|IEe#-C8+zhL1B)&51CB2eBBG&~{G^78A1RP2&qC*))aNm)WxM)GInl}vIa{s404n>_n~#Sd8gfW;43{D8#|Sp2nM@gpY>=H$bXlOH+xAFCN93BHJ)*CYTVx?U3y#sr8l0b@)6852;(1eh@aXG{PZlOT=ge@%cI6R^gV<(I;V18z)NHZz<!5XY2dHzUhCnpBQ#{K&?SZ2ZW^k8J$N#*b{g%*Mwf8$Yt~=V#*y<?f?5{7AdCv^!xs@5sBqHt$a8Gx?E;cS2LkqnUR?SImz}y;J`B+&jy!f2G`ekZ1kna_>Q2Szqowh|!;yd!vOb4Z+-7`n&?U_aMLJKKCBvm)_^z!}&{d??LYV$i1JCdrwF1edOMMG$j1zG^ZTt_<@2SDENVbA1L^Nf*&aOk%{jz@%hNak4*dzmWdBCeu)<&GnnPfWkT|ikbPKFmkFuKe(W+KSHWQ2k$WGx_mO)ax%ZKKAG!CDdmp*Cl6x;l?tSFmf4JNml{8pkkP;wlF-Vb5@@^8c7`n2aq(O>()eIcp%<>uhT6yuX+90GTM-qM{;YSjFB;iLAek9>X5`HA%Y7)L4N%*fvIhf@?$P2SD55j~3&f*hLo=D*LN+9@3!tgc7$Aqd-xC*!Q9iI@oLTUdJ!a`vz#GZo=MS>7Tf)Yg%nlETkB=CGC5Pc;ueI-zRC2)NukbNbveI?L+CGdSE5Pl^vekD+TC2)QvkbWhwekIU;CGdVF5Pu~wf2BcM{@`ap{*}P~l|cWM!2gv%0G7Z2mOufPzyX#(0+t3zzNO`F5#mLB0)7@$U<q7c31naiY+wm=U<rI+34~w?j9>|rU<sUH38Y|2f+Msm5~5=og*R%Jf8r#A)i6pc$}C?kAH$spnF%p7A!sIvnozY!qwFy(5X8+SjA4kJ386C~b|xVWljsS3iv)p-B&=bOxJb~rNJ1M1m5T)4ums|;B+OyscGkitumr#zmOvhsggp#;7YTwF3G`tJ{9y?MVhIdlNhri1dy$}fk%U8R6xK?itrXr$A+8kW%8j}bpOE96oaf{~ha~_Jj06>o1R}8nCb0x6u_Rn#kitmN!bl(!OTs1wIgA84u{6rt#S(xdMuH|r8s+U`2?(VabTN`}ia{A838@&gF%nqClF*7l9wP~_7z8pB6fzQs#gZ_KK_nwVB_ly5BS9x)kz2+xfLca^Tt*UlF$iWP@QW?Nyosd%-HZg`44e}Zh{kYGNRZG-!ZrpGjRX~q1R0G49gPGbjRYl)1SyR)iKoRHfSN{voJNA4MuMP5f}%!(q(*|KMuMnDf~rP>tVR;LF$ilUC~G9)8-un+g1AP4x<&%wSQ5rD2y7%MY$Ql*Bv6heaE>LAjwP^;C7~UI&_<GQ3aO2Rc$yGU6C!FtNKJ^T2|+a>swRZhgt(dzSQ8>^LTF8soa%+dR9H-f##DGrg~)VcGQ}t4jS875)&L|p(j>1GYhaRhiZy^pn-FRfVr@dOO^CJ$;Wi=OCIsAsh?@{{6Jl;c&`pTCNy08vITB<!lEhsIb0i78kmg8;yh+G^5qlGYZ$k7<2)_yOHz5EgMBs!FoFoQArXxY8BSEMmAqXc#;e;@p5Qh^2ags<p<Cr$dzwjv>)+YI4xt>fCq$-kVONg+9s7Q!>gy=?yKm@>-B<Kqumn4`A0G9;BB>{3tg1HFbBFGA0l>}TR0a!^uRuZ6<1Z*V%TuDGz65y2td?m?<4-l3Fh$R7INdQ?AP?iLkB>`ti09q1|mISCJ0c%MBTN2Qg1h^#uZ%F`L(k#zDT@Efnjy200z(N4_l4f}a!fPwUw!&;H)V9KHE9ABtyDdH;{I*yKz+n=Am;@vy0g6e$Vv>L{7zaw22TB+SN|*>r7zs+42}&3WN|*{t7z;|63rZLaN|+2v7!6984N4deN{cK6JTGR15{85l8WWRrCSpz~Noyh|g%WxblQ3rioJotEo$z9T(IkL02`EhhOp_K#y5I(Y)FePP30O@6Sd)O(B)~NZcufLelYrPHKsE`OO#*0>fZA+l8Q?Z)k)zinKgDOU7#2ByUC%PWauUFt1T-fB&Pl*?5&)e9L?;2#Nx*c{B6p8v0azyi*GT|&5|Ev=$VqIKukf)^Xom4ItPKD>3Fu7%9FxT10+2~SWD+2m1WYCYlu3&`0+t1EnY73w2#vVBPOJ?8G)WxqBF}-fvCNmV44|3>tR^kOfGiZq!htL#$ijjwgyQlhg$!BPkT*JHd<?4u;7wZOiLgq5-=sxY#qZBDi;#@VTf@o$u9E=lq(x3_cx%9S5&)hAgeL*wNx*m#K%NAY=Qzs*&ob%I@H{FCFIG`Vz-SXd+60s~0j5pBX%m3j1f(_rs!hOZ6TsR8v^K4>Ht|vc*d`#h36O09W}5)oCZM(nux$cvn*iJ<Ah!w7Z31?i0Ny5`w+ZlV0)CqS;HEXt1@p`*X92lCy!=%f_V1Zz0Q9C+`uDNRf%hf=zG;<1!u4>nif5DKg4~~+8RY&D82|+*V8IDsZ~_{f00*aayc|w|;3h!02^ebvh?{`ord8f4B7<a1KynkH+@ln6lp>B&#8HYkN)bmX;wVLY&-6VV>HCqszgqeZr;EUx5Sf!;afr=HNGqhafDoM!qZ5L3LX=Lc6emPC3GR25{8}m$*V+OicUq-ZA^J)1#)#f&m2~?UmpxMSBSk+_^dm(-QuHH5KT`D9NYM|4(qFG#Xcc4^UImdTt%B@|?5E_fBK#@JpCbJ!+MklYiu$L>e{TApA^-{nP>}!?4NwsQ6%|mC0Tmrk5dsw@P)LCyDiNX*Au3(ccS3X`L?=RYB19)bbRtA2I?I~EszP)kL?=RYB19)bbRtA2LUbZTCqiT*L>xlIAw(2HL?J{JLPQ}%6hcHHL=-|qAw(2HL?J{JI?Js=)d&%V5K#ybg%D8)5rq&@2oZ%4Q3w%*B%*xc@t;iag2#{YR>twEc>Jze$j0MGc`tI>lJ~N~?m8Y%=L#NA=k0qRcswCc5&|Wi<)_d`MWCef_ES7GG*S^L34xLjC<%d*5GV<Ok`O2ffszm?34xLjC<%d*5GV<Ok`O2ffszm?34xL%P>%8oq~WJ*7NYak1SG!z|HNqlVU!R?31O5FMhRh*5Jm}Mln_P<VU)1J2|Jvy#R+?yWRol1LWG@9Y3l}(i!pYMosdKncT>g1uM%Bc5yll|T#?3=Ic*u#mPu{wfFypEL`WB(zz%>%ptQ9FeKZVF+M0tt8iojtg3{I|Bwwvt!w|u1P`We>QQH24Uy4lv|3Ppd1P?-RA(XbRA^eR&hRWqD+8Tx^ZT&;I7<(pd-@`B1zK36cJ%fl$h{%M9Oo+$?4P*ieK!5=VH~;|%ARqw*D1bI8WGo~g0t7{5f+R9+n#i*Zx64oGn}#8RN-{wvnV^$QB9x4XOOQ(@(Mv|qC8#D-l26PsBab_nKN^Mz`pJ~!V^}_rP$tn(M(`ylDU(PkUmJ!9s>%deWrD6UCHXB_aFA9eXe$%Ml?m#~l;pQy!9ie|ps-9Lu`KH3cMU@X$z_~PNOYG)cv+N}MWcKc4dt`^6q7^JjU@9#SaYIQKFdfE7M=()Z;H&Td=J-Q^$AOW=#~R`At4J8@$zfS5D9Sr{5O3JFUeQ97x`;4z9jQY^4Da732RQYn}tO{Xas~uK=hkMz?q~$X_V{mG3in&TZTx~=Sb3jxizdqQK1tVI?<sMAv#fd7O7{Eq7$)aQF|7-XA!McT82nOphX2*WS~U{T7;lQp-v>~L<?HPphXQ@<e)_lS_Gj*5n3dnMST@5LnO-3+k3`36oF`x-j%zSArcwZMXV+LEMh1uOOcNj{b&)876oaMkQNPT5s?-ZX_1i@9cdAg7I=iDl|_t#btr18%QjYq&tfr(ys7wU(N$f<GV8dt43TI}3xXobs@Ikw0-8dAQwVqp0Z<_zDg;P{fT<8b6#}Y4LJACQheTi%=ng?;l|*G#JTatJ2`a0UH@*oOdBZP&Gla@2L1C4kuu4!@B~e$swhR$;Rtfs5lx18Fix66>goK|&s~RW`Wl<3qK8uae0v{74agh=iEph3ITI4!>7OPHxI>0srw2pw*5zsmUT1P<Z2xuJvts_C}fZ>opc0h3`%R|d~M1CJ!Aiz5k@DAV(34*uCi^b9dj7M4Gu)N(-rv1)a%Md|m@i@?gTZWFFp<i$SLPlcmiVhovt+f811O|}ibxD$?=#a*G(P2w8q=g#!%xTLnr0p2l0OC7Zd{2@}NN1|_%p!6jNTC<?B$<PB97@|KyzNQyg+-bn;j7?>;7Wd4&(Ie6CGS#sfi6?Y7Aug%^BpOWgmUqp@LP+k6)OSyLn>CHGlDbRBD^A^FoG}~A^hNtMy!NiL|+77#9p|61TX|%WPOOZh_wi{aQQf4Aj?BEMKDDyMJPoig_lPhMHodCg@;EBMF<TP7$iP678no%5&aPS5cUxD5cCl95b_Z55bzN15bhA|5bO})5a1Bs5Z(~o;QZmQ;iBPLvv?!E4*m!Z2_6Y92|kJKfiQ*uhWLf>h3JLgh1iAAg~)}Ng=mFfg)oIEg&>9SgusNjgs_Bwgm{EV1f^dH{X*v#62DORg}^WLeIbqpZ8RK+aUO;+8g$Vhi-xl>j>0$zLlO;&Xb?n$9vTk8I0NGd3@tQBq2c@sAvEZqK?V&fXpo|S;s6No!BG#2c`(0&njK{5U=9ZZI9R(u+KmDO$hMzdV8CEL=JGL?kJ&7YW??c5gISo%!dMojvM`i|nJkQCVIm6yS%bs|z77Eb5dt9sF#<t??SVNgjA3C43qx3#!NLd@Ca^Goh50LtUt#(R!&jKS!srzyuP}IpxhsraVd@G)SD3lN$Q358FmQ!=D~wxV+6u!~n6<*F6(+4PXoWc|j9H-)iXkh^SYgBp6IK|oLJbt-RhX{Aa24vGD1TzI3WHUsePXN%Q&p%TV5TZsLcrt{2B*9N0w55KOJQ0H_y=aCfPP?73fKqcq=0;2N(w_#n2`eNfe9%LNMSw-<58H7!f+I3qc9qU$tVm)VJ-?|QJ9LtP!wjOFcO7{s8K>UUx(n0=#B8r_P{6<CZRA0g*hmUL179CLr|E3!Uz;5pfCW1`6rA&Vfu-%p=9_8o(XUUVS5qw*C?4OehGfWM#0<@#-0ef4pUDUdcw>TMxJEiNn9BABZ=TPb|hg-680oz$%_%q;Lb4YBy&!Z@x!T2l5ZmElRC2G`?GwDuTJtW{AOf<Y$h3Pl01J)@!@5&+%o(uHa1~rQ<h{}ZX3=PyBk2oB<VUo0Op#eEfqleBcI@Vkz@cd4sH-LO&DpyL=*4{%ri}rm9OU`JC0|^M@!BhCOf7q$89;BuCh~PBo$v^E6NC@og-705xLJKnX;f?_gONDGRia3WT{a|YK$ZnIV=Eepwqyh(Qt!8#wl%;36u>^0+C5o0;sM4(I)}Mq#z-H?n$69fnc$E@j)aCGzeyk%=9eZN4|>RfQ*3#L2Bgt$Xf-i*(Jt9`pArhb`$vo3B~3!lVhRetYybS&568)khrJ`GP0Q>Lq>W-$ZsS^Mv`+)l7*{ikmtrezvRinOY}gZOvsuDX%iuD(sE@Ij-w&hvt>e>rKQV++$)+d(;!K+pD+_Lxl6`ONa?(knUM1ll0HJ#M@aj!7z)4oBX6cb)&c&=N9Ih!wjzdW?o3DwYsoVWaz9An7rAt~%by8JBq58uWYC0k@-~Gg<d%fw@{&XovP>G}8IWhn_CT_ElSn_>sYA$INmAEJDov8pD!FvRe%anDypqrjkmSzrq>@16sgMPKWYi=?1hS=&6qB$K$gYyyShkkz4`j%}%$kr&(;)UiGL6(~ko_bn^_E@}a%<X>YuVelX|bAYFJwo9m<`zx@@yJpgNfy^!;otel5HBqcGzXew+RV14Prj*H00cbq?-mY;3^(OTnK!~ZTAjsIe3|SlO*QwUcz^vHt>*qaF>9S)Hvl=!873Z(e?`w2XSn_q~RpFJ@%dS2;n4un~5h9JK^n0^8b;Hlbiwu`L6s2e@$)%{tS0RayuV6IpMxYP6py9NxlWoDWO%8>sfvv|H1Ep6UT9Z<VLXz<<Kz6cf|SPci`+W%NL{M=!APG+&tm#2?q(nNrG^cAlyD}_YViZJpfiC4itnF1&!k6#m$SK7e_CTu;C#11QH+EbQFg#9v?0rCk(<7gK)+m95M)}3>xM2!R>Dkf`z?32^K648-&vaZI1$cWP28QC0L-SpOVy1<-~#d=_KzEixlS$!oh>&<N?A3!qJ0p_8=TS2&WIi@q<9PKp<Qo5H1i17YJkvv^~%&(M!S?&>grL96*lzJ)FPiBY!{g_djy}{v+Y+Ne%`#Df=Xcghv2vJmOa&+Tf)jAU9^J4$c|^XAOa~MzVE*cEDS6&DX(SL%?_lAP<4Rh9)^=;C+L?Msjwvq}&4BB<(5Sv#BQSB#~v3Y+b$>C2gn4$lFQ!S_Che<VUz0`MHt06Cfo*<I4r^Cc%~_adGk^{Mqey;n!!m0`Em^kKgx!dlS$m0^D>#zG;%>fHeIE`zA2zNCJ;Qh6J7v%`O={A*>PN+Lps3x=9X?5O>Mp39*h4>~2wTLgc&T@PrUZh=GJ4cunFF4JC<}Gwviejy(1zi6=zKS{6@}tV(&jZC!4eJRyo+QhAzWnIdogK*b4sJ|yiqh^*Iaev;>(<$_W2d79)cU=1VI5`rxu+Fk&1n&fpX8$?dhwlm2~k^ETh40!YhPELr%gm5ewJ^FYqP&t7Bh!C4^Q+fg!&?ToQ1Z)B+&>k-*MDSa{oF>^OfVbu5*H6rx5Zy1JIU&qTE{|A$fz1g)pAhvWkw@q!#C`&)5P?*PKq^EC{)Ff+dHlTP<@iAAhtLTb1kLiDEr%yG8xb0fZeer+OA*Zi7r>oLo6#)L06Z#~iAdUvX1Q3>2W(2rei4Sh2$Nrg(J#X67h(8|F!@Co@giw6!hjcH!i&&mMABx2AumFkk)*=XD~ee!!mt-%+KVvmMVR*@415tLz6c{<G|MMoc}#r~#=Z!1UxdLg!sHi8s}W|u2*Y1APamK=+KmY9Mg(#q0yz<ZoQP&gp5?~G6^kzxXDr@WJ}drM9P;Lo@iFnqSk7oSBD5P3+KousjlfVuvn&gEW-t`dEDHl$8w^D>%gVs!215~np@_gxL|`Z)Fcc9OiU<rvB<)6EC?b#(5y*)MV_<|%BSNPUNv9FWiAXw)FiHi-EB%7fafG3;3knaXdI903QxMZ)gmE$WNO6&v8zT&kT|juk1Q}t3j4(q+7$Q6J_;4OS9C`ea#~*q8_i9VQkSt+JmX<Ad{kqPSFyekq;w!x=b^?!4U#ml<in+&=cLCj(?J6U8CrlgnG^%W<`yyVD+Im%-eEqgvMNihXh84o7^uA-|9&Nu%)CFwEX!Tv5jyY=&Z8x&?edkIoM_&YKmmA1iioOK<R|r$zfZJ)wA9y>VUs%cym;%3TVj+x#(;{hu*c!WWk>7&-xX7=;j>Kp<N&oO7zX!V#<Kcw)a9ZS7jncS<Phf9u1LCqf@m4X<O&I8wL>*JzT62q@r{A`>NR}>W`y#30B}o^s9lgkx9v70HWQ>b{WtR&r(<ME}L^>_vUzGG5bLzBgUPmV9@!G`sT+?%muG1op=$f8mjGdPGE<MLcJ7K2%(*Ck#=h7~{NP;UC6R#z1OR`+CnDo_2s(a1Om(7tax7qn3+hx6E=a`4DX6J&p@3M1gyxwK!i=@wZI%&q1?0k_#T3oGU)8cF;rI!0%#l5auc0O)jT#|Fl-xCJ#Nm{cpf=}!DlAKF_Hb(IY9iD^^PeO+$t>Tpt?^c0T5b@CAN$Bt-ba>J#`SW)1a!t<RQsGSrZJ&g;PeR)#q3x5<_DN{_B(#0fD%Zixt0aI@&X7<5TVp<rFrP-4-zN<46Xw&7Bt4v@k4KXJD<<i*ZjAX)?<FT;VT8+)QO^gv$q7@UBvYdBr>opK0;f!c?s9bcU~N2_WsYW<qgm!?mN}Ybj%JyoS>|Y#`9tUL(~-abYWX{XT+U433EU_IZWQ{UMUfnyHf9t9WEU3m50IU}RY$^R{zWsPw6UZc89Z&2ElvuLOykJmj~xEU;g1~t$l;G1{>b5v9R63z;pZcVKQQ<v41Uw7d=3V0waCyWXLR82NA7;)?nmx^<nBlAe&p^)?tbL%*W7(Ma`z*5Kl*2m{Qbz^kNo|}-+$Ho{pf%{I^d5E_+K)EUyls_kD%ZxW2%rd{819F1i>MK;82f<E5`WYA>km!Kd$mkzK{(JzlgDYcttox_(Y8C!z0dOXub}nW?N%eAHEQy`tXDp)W@9uq1O7n)mjMxR<9`6N~;`mrNeAnxY!Gm`~a^)?i~pXbVvz8qy!~Wf)pu1i<BTnN>C#u$dMBCNC|?Z1VvI><=l&y4na~9MbdzZD~W8WA>&F=lA~4n*2J!2Sh1{_R%|QAU7xGxN~?r(Su60doszD!ZmaBUin?Yf-QiDUsNLZ;=CiCuS&p(EWkJe{6n=jY{6q0BL-8&{@h(H@E<@=qL&+#Z=`KU*E<?#EpJnnI=Se8tWhmX{O^5YSnb#~&xT(3`%Dm<ean}!-*L*MYD#`m->AViIt>sT4(BtoYvCeD8lZei1-fr_w=QZQ5GqeITv;y;XS4co`R~dJeaaS34m2p=Yca?Eh8F!U&R~dJeaaS34m2p=Yca?EhdAqASo!5+;%(%(C-6Y7Iwwr{)!dX@v=GM2H#N;|O_A)f~GBoxwH1;yIn=&-^GBoxwH1;wy_A)f~vWU^%>%3-2?qx_hWk~L2NbY4w?qx{sWk~Mjv#fgvG2ou_Sr)zAGiKW%xtF1~m!YheA*z=ls+S?<lp(5@MVt0s=QTrPFGFK5Lt`&PV=qHvFGFK5BTLFilQQz8j6^9TQ_4t{G9Dr05wbi&5)F-wq5z)|tVX~Z(9;~5d@z$whb+>s*$e-bx=7Lm|CPc>MHBopsb+E#ELU`Pgkk2MZ6=HE<_+CU77fl1zL}ha+K>btCYN$1!=^b2o67cS`5v4YpkY`xC)q9nD`x?m@d<1j*f%HnE!aFTafXdEjGR$%$*^*UnKSI1VdxA?XHnjq=o6LCFnosPbJ{5KOfs4*Ohg_VjY}%&ve97qWvsu91(>k{GnQb+8q8RP8LKd38D^}*4Va%U$UIgg$vc*3oCKwxY~>`Z+ABJb<$DLuV=ZSa=8V-W06ms;#+uGp)H%ufLCn0>P{JD5xM>pBN1>vG-H@>zGWJ8phPblRU}t1(jf}k^1U1+o89PKMYOqZ*_K7GAqrRi!^r&Ttq!M;g##YMMOBtI<kb3MWkzTnX_1IrI2_XLo)hCkmhG3mURY|_sQPpHRe^S+C+P-toDVec5Z<GEkTNSbOlJ;k8+<o4kv6C~la>icHB)=<(b(4VhnWQfRp`?b|U-)XSn7vd#NbUkjIov?nN?;e%KEo|!_yrU%5{c@PT#uWO6(&n;TVwcbvdUzcNfAh@K(f%J4kR~<#Xu4rrCx;14u_H9F|xP})a<et6;-<|FCTTgOmfGAtYmxwn;nIRjOty+z31(=VNF!<GKvkE<eo=a{KCtGPhfYUj+X%gWK{ApI$kn-Mn;267N>z)UPdu5lWZESKDdnxzmefMGCW6y>&WmOS)2!IdKum$!+m7<j|>Nr;XyK7NQMu|a3UFMYZ+c7!;NJ4k<F%9zVId)?j*yXWH^)zkCFiwWVn<JpOWEJvUnA7D*_q_Y9O$I;06L52y!6Mfe5jQ5}OcRiC>Y5pEwq&`AN}F1ldH9P0D`aS;V!7ZxQDr-bLJt_!p`EiGvXjvlRfv#fXpDYJm8JNVG{6P|AQ(2b4k}>@KB1sRfFg5kDi2M#_QWX~fltuMuY>B|)hPin|eiBMwJAjtIAja+^rE2_KfY9Pv3)85B+|A;l7>Beg-{#S*V0DsEC86dgAaaudHJjz>I?xE}F6!jC1+M+DtO(M=@Xq)aH@M@X`SB}-_s#Q%u0n@GEf0}>A;Tv>VR#E~E1V=%lpBGGx1Gp?K}#TB8bp5cqKI3pAeGYaa*u^@abIP{?YILCsFAT8;k^qI(3Tep9%&1ZuQWG^Gi|Fpxw;{&o;8fjn~X{$j5kggg80O^LgJswC0Oofgz51WE@{csTJ&dHL*SK4#(u-(<F_UGh{n;W-D(pDm0;Zq1#KvMG{1d9k)(iS7JS6X1C)kWG`q+MleMUfViER>A+1op19m`HocAgwF%1oX8Ms<hpvoP0VcDnpGr(hVbBFoPID5_{Pfh_;e5OIHgzS+Zn?=wQjniZl8-G8#HEIyy31I`Sa)K(rmiAc(d|HgBa>g|ITC(<5&m!LOO*Tlh5y!RP?V=m5#+_sD4Y$mssa==#WmoJ-^^f)I?3kBp9wjE;|tj*pCvk3w#Bkk%diD&ek_MkD;DMNTvLO?O>9gUGMq^6g(_uvli%1HI|u$s!K=aWcrF5?Uz-WRVZOsRv}y5^d05&1g!=XiCXwO37#{&*&x30Jbxb?F?u;1KZ93w=>Y~40t;O-_8KIGZ5~K{*;Ucl?;eG1LKw#GN!GaCj;#k^8@nE!m5t4SqAc*rRN-#vyA?gj0TpB4wj6L?u?G^JPJ`M*5N3JM%+I-xidPs^C&?R^qMd<y12#8=;Y350ueK#n>(Ws<RaFZ(bX-sL}&Mf&oZOKyCk&C((`>Gw9IJ!-d-KlPj6IPGn&COn!)oZ=UnMVlXoE}T{&`GPXgn%z;V-}9xR8CMJ~oKkQ2!DB!CX_j1KWElBx27&~X2u<(fr6^`kLAi;}9m8*CKOQ~hYn&*&h}=pfG`ttzq&&{q|EKx7pg8%;GC-Q;<ccPe))FBSV^lolUcA#Yah7>cW#{IPt0xC*@HQSKg%G9MDJS(I3BG+wjFvd(htdfNUr1X|@!ON$R*D}Q*UPm$M*R`gqy*NnFGi^^+8d%7gXXmH8WqAoc*`qc5WjJ}<WUiFM#^^9Ki3<Z;m%xi{vNrnPRhEmA({~*KN{sT%}-V4wI$$)V(zPiY~W~hT?sDfmCD}Q_sI0a5jAQjF+DlCd1PyxwM0Rh2$Mq^Kw&Ylm7`7A9y$Z+$<FrS4#SlH+*GOt-^>W{QOn%2{i)*tlphs^8IdEeA||I2De<w*pIzEnFZ<G22B?WimPwMRQD%j10{^I0Cx){e?}`X8hnbu{N6!?nk7?J-<?r1;eo|4@ScW2N|6a*k)E_!-H|KE=;SW)20ZKbV5lF-Cig(H>*8N2Y#c>PM!2Wa?j#sUKReM~}?|JvP%9@>u>_JvK=)x0WWGJW0MM(cretW|Glgy!0%dS!=YJB<cJvjW$O*f28wAI)9||M>>C`^G7=WNIHM0!XA^ff7D6ZuLRw<8CvO-XrG})PetB(Dv;w#4@KH?dr9Z<6%sP(n^0zG^EBQL(M~d{S{tIxaD;bLw9;ZBtrZ6(f8_8-4u9nEM-G4F@J9~+syY0j40|-s{Gpp?j{f+Anf}P%kNo|}-;ezL$ls6r{hQ_QhbrtJQ&}oclAj9%yWFAh8Joa@;qxTlz?GQdpXA$H`kt|2E=YWy1OUd?5oCAz%-}Qjk(R<|Y_3ZVpJkWbB=K2>+*$>uvP{LDB{?EV<TG}wp2>ee@)>)%hRJ7a@*mL&pC@st^5FB<R5OWd^%D3Dx3l5z%h~USmjqsHv}_!f8LsLMeZNcJm-g&EPr{`h<Ejyoxk(5YZ&LS3C>^)lUFhZDKP7jcga)sHtY#AGw0-hEf#ze{DAS7cJx{{hf|s<?J!d5x^<Dlxtsnd}@Z1@$J5Rz6vVL+_!jb1mm?l0bE8)^Je0qjc&+zIQZas@%|0J!%i@M9<@z%gh0~V4DkDuZ4uSq<7e}?nV@ctR@Us&UWkmfUs=O19Yb^IJ<73#|MGll0Xru#wG8F{&q!{=F&^>&u}eG1RNXjN1AJmWVYs6e_%PDYR~k~S|$7zxo4WQ;BuJpV&JC0}9Pg8yZdtCx+7W(En)C<i4N0_z0I9l}He`3@l>f_}#(iO&%1z)4_`Q`bihpJ(BjN!JuUL(2nc{FcSbOfvsTwwUnGK;c7JhGyZQ;a|_|9H~1p_bdAh^goccBWo9SAP@q<SP%sf>X}*iX%INi!aS296LQN%pP?CYo33XFh*(lme8F6j(S!E=A|}OGELWx(<iACpo}o)3`R+}cE;KWerX$b2Wa&t9g=7XYCV3X)U`x$nol%ai@>AIWxV=&4y4MeqNvN9SS*(P^@jP8fCTB60>@l2?A#jpK|7rUzqW>f>S<cI-OG58N=w{~aKluE7s~?r;ZTsQ#B5rljkIJ)bMX~JWP4Q>Noo)wip_0PyTjU4$EsOjBzZ5JtVoYq#8M|}F_MByZ!mG?;bL`N0yG~fCgq8|h9(G^gJr;NmXr$yt`bv}hV8VZph{01pD<v=DDdeZ{5YS7>i+Bil14yRiMW{Sixeg!0tA=(;#tc@*3|3w?H7Q(-_YD=5yvX5bmG9wC!Usc6B|}doFWa>Jk*hc4>W2#K!9{a$(HvO&fwdo4`>SE?fkb_g@BW}f{T6KR&eNgt_KW1{5Ucy@JbjVW;n6&OkwYE!*CKiLU7ntoe96-xwU?o_cOdEqqW(fz`l0lCWa&qieq`xKmVRXEM@P)j5p#6J933%7{{C(9cRKW4|Ck*yy;G?K{dY;-*C+7H(551fn}#n~<<8;sASS<0-<w-uj{N<|-;ezL$ls6r{Z5-{!CDh-rcHdRPn&5O21A=^0jOVSGeO;|)Mi>_>7ujdqRq6(rn=K+T96OiX)`Ty%d@O<`p{-tWcQ)va*>?jqRq6(16;J3mQgO9Ked^bQ9iPMYBMd<`Cgl8!65`4FUv$n5`QG|uav|eYOF^Re<blo5`QG|M-qP|@dpThfbdZeJ};6m-zD(;J?y&e6foT+@cd8g&q*#>)dW5-vfGtr_XXmz*Jk$x6Jv|q#U%d}?X~eHf#-kXlp>8;a-b14W;x8r@e93Ki?|5!5u(bxOqXVN(Q!-XErI8ME}sc}UL-p&6L@wjG7N-E;8>O|ZI`d|O#;vV9E=2h&2q_jB=GSB{?J`L68Iy5KN9#Ofj<)XBZ2>A6L{p5gq-rW0e+vqBipvx-;pivQ+FiCm*#gumP!~&CZwt)sp>551iKPb2sDcu!HZiq7X$|aM<gjJ1`P;<286tnBrnAzFk!NQkeAXTGIH2X7!;sIhC=yW0>2jc8h!t?$UMEwg~Iw<&brE1LVznj#jnIG#@s8RpPrV@pM7+~(<};jc<o3~39a;m1XU(h7rf@JlOFH-b7FN_FDU#r@p_q9rCA&<o>S6V8FZD5789$4#Fb>Ib%n(+)XHDUf3Qu@@-g`-zwPY{d|>muaJ}2LaJIM>myt}dt}=-_%XM(WNYg+5vu+cs{2%-YQOHJsS!F_f`vL9@vk|xiNj$`?p<@jRYyL5Q10u&t;`!nFw;5IZ8mx&`u7jCZ$qwa^Bq1S7$}YKzM2x&;@cf@6gKx;-4_VbCgKx{=alx}Pc&h`R|I++**}KRzv0KWTPSa}XH04$P(IV6oN!;&rnnL2Lm&9F?7~KDg`-p0*Uf5)+;;Ki=ex&S2%6?$(2j+hC%p5&4FO#qz>Z(V=en9RA<bFWzNB(}~@4s~Zo`IjXK<@m3<(j)^z^fVXYF;I47bk)Pzx<GHXlDd;736&uR6s5*k@qaP>@1lBHt4#2cG{5l|G&NS>22c%qWE|5*@xkdwY%(1H5Awg92v5ENPt480=*?j+Ed~0UjE+Ns#YRbELyZ^!9xT&;&5j<{PXz8nQ_I5jnfa~5%cb_whm$IB5Yya9oE*x+7fc-59*yTI~}2QM7_H%Wkglt{Y1Sx3z|n^6OR-1?yN|z)#yOIJL{51RXU^IqaM-g<26{MM?F!v`Hgx{|JR>V@9F=BSL%J3coS4%?uUBsh$s0<z2E3hB&4ziFxW`cyG{%g+*OJ7G_qF;>xwFR0a5RaH#qt9Exu9jy(Vqy><`p?uMf=zv_-Gzu!wQ*CjzlvsrU2;PgQ*80{NbPMIG+>#K9->J$*x#c`Odc<a_#4zoMAV9ste_%hzK0mRhx8`G(~imTy?TVflvT8yDZW_{POIF8;rR-&<PM{~dmZ-GJOU3nIy89Q+Q|!5u?l8571B{0`Mo!tXF3;CJE}6S|nohcF<-CngLr^asob#0R{`Fg*-NhjcO~qzB=9iQda)LkJH-_Y%1mwga+*u)PHAh3Oz%FVT9TIK*&7{bwqe3=FeDU|x6)Xbo5m5@*0^3^H^ohpCgTp)+7J$cq7&K|%~%gaYU+0M7#WECA5b2aT$^gWV3PcLEqK0MY^|EdbL3I4uCw0!S?Y)zSwN=~YODF=`;DcOnNyAR7-i2yqG`0S5UmNPj{03zA=u`-0RLB)uT#1t~AcctOGo@?DVWf<zbOxgf&@2`<QQL3)c(OCsOt&Z%rNBN3R1kW74IA{!IQm>9-{FeU&6p(h9-L7)i2LJ$Ok7!ZVhAl3uX9f<2dL<eFy5W#`C4Gpz7)ZS2gL+uT<H`Lxx`@f3XTQb##+8b(bsJ#NUOaIkS1=>fQ*3Lour4*`!ZX;qFLE4DVMpOr)IN)%Hza1`dIK#;oj$>Zj-f(!s-wh`>eB5ws!><izHXOC^Uc-3}w>2Uy;IxLj8s2K727M}*UIec+4#jaX!=(&oGTg}Ubi+Lj$25G#@DIa13{Ntg!|)BmdyJFm$tO%lQ!Jx#>bQ)BUO&(j(p^W+ETfz(chku-%P5D+-E^qTGRjeM7v*inG8(~oQD;?3Ov@4))2ndy%nbrA5O76+8v-1<aX!Y;*mSa$-j_oy&a^nv;slFxe$MrEjvq&T@I={FhLvSyTG>{{jeiZcpQcYu74p97E6lMg{-t(K9f3iQooP~9lm?|eX--;`#-uH$rkr{if2ESCA!$dNkyfM;X~R??=n?5ls+Vn!sW+-Ssz0hjsz)lTFaCNK)OqQ>Y$J_*q_L4Sc9O;o5+kLNv6nP9lg4h+I`wxXnAuIsgw_cy6j~`*DyTkCeW3b4^?~XG)d#8%R3BV#$O1w2f$GC+^^}`_Kq1x+V*#*kocvV}(7opJOdhxAJXXVvhP58WLeKNkHy-c$KmExoGTR!ntufo$jaE(+X0|nETVu90W?N&nHD+65wl!v3W45)Go}pi9bE(NXWh_)i3>LI@vPh*5tR$@fAZX=i<!I$-<!I$-<!I$-<!I$-<!I$-<!I$-<!I%TRyb@K9$PkQDx(5+z>|_(V40L8R;8)O5oU8zl4zC2{@u8zV%$@)UXvjb+*2{)(-`+tj6J+@4aGRl7SIsV2<o3~>Wy8!v8}g3(<v1U`jraQ@41JA&Ti`T(wT5GM$8x+H3K8TMI0l9jIqHtcK8Mk6#x+e32I$J$Qbu>j4i(r6UU;`V5bT|Ne)bMaFPR*9HitxCFd2KS8%-oaLK_-9z@iLsS#C^#y~^z)kwajT5U+aA^C>nYxwu^&(rVT3v|{&d1p>%ax8K04qnPo@6M&mzngidH;8x#LDLs55%11C-OzkP^9{{6G~dvCL-YSEnt!>z`u6kZFW(ZN|LySY>ihNk&F<sX_1l*O`oDhu^_QQnzDu@wxz3i{{qW)TZvXVSeV!HfeDQbd-NR=0w0~Id-f!j-H+hNs+s*!Vw^={zpYFDgGl^AR;&Jo5zg@rE%*ytKviF}pt<P&7@}-|1w%g~s`^~w)m>2lC-hJ3VJ#Tk&W#YW_Q4?mHezjD*uKi~+Wg`Sz5UaPuOe|}Tuq04rlbJ}_FiV<MS?8p&as~?Ff<)d%p<5QK9xG>(3ziy|C3D6KenBR0uhp_tt;x;=^HvM<COK(=ieYswQ5abl#1^b}L9%*$ok?bg*d>{~)y8G1TC1H27OXaxI=n~LUS2F)7+-x!U||9rN;1{fIg-harm<MMX5Kq0Uu%mak%ATGGv1LNIXiT=P`YZ&%tXqz=t5blY>lofOI3`MdHJkGIxkBUZPMM8h4NPE=8Da0u9(oy1oE~yY2{O?>gnuMuzI|l3RW2DOr&N7Iu$AppJ7q1V6FLNb5tmc7~(?df}Iu~urP*(ved#DT6k8@Jd5S?V`wZ(l*iD*V~S(w$Cuv$UEG@c')))
_ROUTES={int(k):[_R108_DATA['actions'][i] for i in ids] for k,ids in _R108_DATA['routes'].items()}
_R108_SHOP_ROUTES={tuple(r['shops']):r['route'] for r in _R108_DATA['shops']}
del _R108_DATA
_SETTINGS={'hand_align': True, 'weed_repair': True, 'sell_lead': True, 'budget_guard': False, 'room_guard': False, 'clamp_sells': False, 'dead_stock': False, 'terminal_liquidation': False, 'front_run': False}

_R110_OLD_SHOPS={('BAKERY', 'BAKERY'): 0, ('BAKERY', 'BRUNCH_SPOT'): 0, ('BAKERY', 'FARMERS_MARKET'): 0, ('BAKERY', 'ICE_CREAM_SHOP'): 0, ('BAKERY', 'PET_CAFE'): 0, ('BAKERY', 'PIZZA_SHOP'): 0, ('BAKERY', 'SMOOTHIE_SHOP'): 0, ('BAKERY', 'YARN_STORE'): 3, ('BRUNCH_SPOT', 'BAKERY'): 0, ('BRUNCH_SPOT', 'BRUNCH_SPOT'): 0, ('BRUNCH_SPOT', 'FARMERS_MARKET'): 0, ('BRUNCH_SPOT', 'ICE_CREAM_SHOP'): 0, ('BRUNCH_SPOT', 'PET_CAFE'): 0, ('BRUNCH_SPOT', 'PIZZA_SHOP'): 0, ('BRUNCH_SPOT', 'SMOOTHIE_SHOP'): 0, ('BRUNCH_SPOT', 'YARN_STORE'): 3, ('FARMERS_MARKET', 'BAKERY'): 0, ('FARMERS_MARKET', 'BRUNCH_SPOT'): 0, ('FARMERS_MARKET', 'FARMERS_MARKET'): 0, ('FARMERS_MARKET', 'ICE_CREAM_SHOP'): 0, ('FARMERS_MARKET', 'PET_CAFE'): 0, ('FARMERS_MARKET', 'PIZZA_SHOP'): 0, ('FARMERS_MARKET', 'SMOOTHIE_SHOP'): 0, ('FARMERS_MARKET', 'YARN_STORE'): 5, ('ICE_CREAM_SHOP', 'BAKERY'): 0, ('ICE_CREAM_SHOP', 'BRUNCH_SPOT'): 0, ('ICE_CREAM_SHOP', 'FARMERS_MARKET'): 0, ('ICE_CREAM_SHOP', 'ICE_CREAM_SHOP'): 0, ('ICE_CREAM_SHOP', 'PET_CAFE'): 0, ('ICE_CREAM_SHOP', 'PIZZA_SHOP'): 0, ('ICE_CREAM_SHOP', 'SMOOTHIE_SHOP'): 0, ('ICE_CREAM_SHOP', 'YARN_STORE'): 6, ('PET_CAFE', 'BAKERY'): 0, ('PET_CAFE', 'BRUNCH_SPOT'): 0, ('PET_CAFE', 'FARMERS_MARKET'): 0, ('PET_CAFE', 'ICE_CREAM_SHOP'): 0, ('PET_CAFE', 'PET_CAFE'): 0, ('PET_CAFE', 'PIZZA_SHOP'): 0, ('PET_CAFE', 'SMOOTHIE_SHOP'): 0, ('PET_CAFE', 'YARN_STORE'): 11, ('PIZZA_SHOP', 'BAKERY'): 0, ('PIZZA_SHOP', 'BRUNCH_SPOT'): 0, ('PIZZA_SHOP', 'FARMERS_MARKET'): 0, ('PIZZA_SHOP', 'ICE_CREAM_SHOP'): 0, ('PIZZA_SHOP', 'PET_CAFE'): 0, ('PIZZA_SHOP', 'PIZZA_SHOP'): 0, ('PIZZA_SHOP', 'SMOOTHIE_SHOP'): 0, ('PIZZA_SHOP', 'YARN_STORE'): 7, ('SMOOTHIE_SHOP', 'BAKERY'): 0, ('SMOOTHIE_SHOP', 'BRUNCH_SPOT'): 0, ('SMOOTHIE_SHOP', 'FARMERS_MARKET'): 0, ('SMOOTHIE_SHOP', 'ICE_CREAM_SHOP'): 0, ('SMOOTHIE_SHOP', 'PET_CAFE'): 0, ('SMOOTHIE_SHOP', 'PIZZA_SHOP'): 0, ('SMOOTHIE_SHOP', 'SMOOTHIE_SHOP'): 0, ('SMOOTHIE_SHOP', 'YARN_STORE'): 8, ('YARN_STORE', 'BAKERY'): 9, ('YARN_STORE', 'BRUNCH_SPOT'): 9, ('YARN_STORE', 'FARMERS_MARKET'): 3, ('YARN_STORE', 'ICE_CREAM_SHOP'): 9, ('YARN_STORE', 'PET_CAFE'): 10, ('YARN_STORE', 'PIZZA_SHOP'): 6, ('YARN_STORE', 'SMOOTHIE_SHOP'): 11, ('YARN_STORE', 'YARN_STORE'): 12}

_V92_TABLE={('BAKERY', 'YARN_STORE'): 9, ('BRUNCH_SPOT', 'YARN_STORE'): 9, ('FARMERS_MARKET', 'YARN_STORE'): 9, ('ICE_CREAM_SHOP', 'YARN_STORE'): 9, ('PET_CAFE', 'YARN_STORE'): 9, ('PIZZA_SHOP', 'YARN_STORE'): 9, ('SMOOTHIE_SHOP', 'YARN_STORE'): 9, ('YARN_STORE', 'BAKERY'): 9, ('YARN_STORE', 'BRUNCH_SPOT'): 9, ('YARN_STORE', 'FARMERS_MARKET'): 9, ('YARN_STORE', 'ICE_CREAM_SHOP'): 9, ('YARN_STORE', 'PET_CAFE'): 9, ('YARN_STORE', 'PIZZA_SHOP'): 9, ('YARN_STORE', 'SMOOTHIE_SHOP'): 9, ('YARN_STORE', 'YARN_STORE'): 9}

_V93_ROUTE_BY_RIVAL = {(229.0, 9989): 128}
def _router(observation,step,state):
    if step==2:
        try:
            _rv=observation['farms'][1-int(observation['player'])]
            state['rkey']=(round(float(_rv['money']),3), int(observation['market']['inventory']['WHEAT']))
        except Exception:
            state['rkey']=None
    if step>=144 and not state.get('day6'):
        shops=tuple((_get(_get(observation,'town',{}),'unlocked_shops',[]) or [])[:2])
        use_new=shops.count('YARN_STORE')<=0
        state['expert']='EXP240' if use_new else 'V39'
        state['route']=_R108_SHOP_ROUTES.get(shops,100) if use_new else _R110_OLD_SHOPS.get(shops,0)
        state['route']=_V92_TABLE.get(shops,state['route'])
        if 'YARN_STORE' in shops and state.get('rkey') in _V93_ROUTE_BY_RIVAL:
            state['route']=_V93_ROUTE_BY_RIVAL[state['rkey']]
        state['day6']=True
    if step>=648 and not state.get('day27'):
        state['route']=2
        state['day27']=True
    return state.get('route',0)

_R42_OPENING=[['BUY_PRODUCT', 'WHEAT', 13], ['BUY_PRODUCT', 'WHEAT', 30], ['SELL', 'WHEAT', 30]]
for _r42_tape in _ROUTES.values():
    _r42_tape[0]=dict(_r42_tape[0],market=[list(o) for o in _R42_OPENING])
del _r42_tape
_IMPL=make_agent(_ROUTES,router=_router,**_SETTINGS)
_IMPL.chassis.diagnostics['terminal_rescue_errors']=0

def agent(observation,configuration=None):
    try:
        action=_IMPL(observation,configuration)
        pass
        return action
    except Exception:
        return {'farmer':['PASS'],'hands':[],'market':[]}

_SHOP_PARENT=agent
del agent

def agent(observation,configuration=None):
    action=_SHOP_PARENT(observation,configuration)
    try:
        if _step_of(observation)>=718:
            view=_View(observation,_int(_get(observation,'player',0)),_IMPL.chassis.cfg)
            units=[]
            for i,pos in enumerate(view.positions):
                units.append(['DROP'] if _shed_adjacent(pos,view.board) and view.inv(i) else ['PASS'])
            action={'farmer':units[0],'hands':units[1:],'market':[]}
            projected=_IMPL.chassis._projected_shed(action,view)
            action['market']=[['SELL',item,projected.get(item,0)] for item in PRODUCTS if projected.get(item,0)>0]
            action['market'].sort(key=lambda o:-view.prices.get(o[1],0)*o[2])
    except Exception:
        _IMPL.chassis.diagnostics['terminal_rescue_errors'] += 1
    return action


_UNIT_NS={"__name__":"v28_own_unit_model"}
exec('# SPDX-License-Identifier: Apache-2.0\n# Extracted Kaggle / kaggle-environments contributor code; see NOTICE.txt.\n"""Exact deterministic unit/decay semantics extracted from kaggle-environments 1.32.7.\nSource kaggriculture.py SHA256 bc8a54879ef02c7ea64b8b333d6a976f0ea65c4949149d01f463f23bccee653e.\nNo interpreter, market RNG, policy controls, or replay content is included.\n"""\n\nENGINE_VERSION = "1.32.7"\nSOURCE_SHA256 = "bc8a54879ef02c7ea64b8b333d6a976f0ea65c4949149d01f463f23bccee653e"\n\nCROPS = {\n    "WHEAT":      {"seed": 10, "first_yield_day": 2, "max_yield_day": 4, "interval": 0, "max_yield": 6, "ongoing": False},\n    "CARROT":     {"seed": 20, "first_yield_day": 2, "max_yield_day": 3, "interval": 0, "max_yield": 4, "ongoing": False},\n    "TOMATO":     {"seed": 50, "first_yield_day": 8, "max_yield_day": 8, "interval": 1, "max_yield": 4, "ongoing": True},\n    "STRAWBERRY": {"seed": 100, "first_yield_day": 10, "max_yield_day": 10, "interval": 2, "max_yield": 4, "ongoing": True},\n    "MELON":      {"seed": 80, "first_yield_day": 10, "max_yield_day": 12, "interval": 0, "max_yield": 6, "ongoing": False},\n}\n\nANIMALS = {\n    "GOOSE": {"cost": 300, "structure": "COOP",    "first_yield_day": 4, "interval": 1, "max_held": 4, "product": "EGG"},\n    "COW":   {"cost": 400, "structure": "PASTURE", "first_yield_day": 8, "interval": 2, "max_held": 6, "product": "MILK"},\n    "SHEEP": {"cost": 500, "structure": "PASTURE", "first_yield_day": 6, "interval": 3, "max_held": 6, "product": "WOOL"},\n}\n\nPRODUCTS = ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER"]\n\nFARMER_MOVES = {\n    "NORTH": (0, -1),\n    "SOUTH": (0, 1),\n    "EAST":  (1, 0),\n    "WEST":  (-1, 0),\n}\n\ndef _shed_access_tiles(board_size):\n    """Four inner-corner tiles around the shed, in NWSE order."""\n    half = board_size // 2\n    return [(half - 1, half - 1), (half, half - 1), (half - 1, half), (half, half)]\n\ndef _is_shed_adjacent(pos, board_size):\n    return tuple(pos) in {(x, y) for (x, y) in _shed_access_tiles(board_size)}\n\ndef _new_plant(crop, day, turns_per_day):\n    cd = CROPS[crop]\n    return {\n        "kind": "PLANT",\n        "crop": crop,\n        "planted_day": day,\n        "watered_today": False,\n        "consecutive_unwatered": 1,  # planting day counts as unwatered\n        "yield_units": 0 if cd["ongoing"] else 1,\n        "max_lifespan_step": (-1 if cd["ongoing"] else (day + cd["max_yield_day"] + 1) * turns_per_day),\n        "fertilized_until_day": -1,\n    }\n\ndef _new_animal(animal, day):\n    a = ANIMALS[animal]\n    return {\n        "kind": a["structure"],\n        "animal": animal,\n        "placed_day": day,\n        "yield_units": 0,\n        "consecutive_unfed": 0,\n        "fed_today": False,\n        "cared_today": False,\n        "fertilizer_available": False,\n        "pending_care_bonus": 0,\n    }\n\ndef _farmer_position(farm, idx):\n    """idx 0 = main farmer, 1+ = hand index."""\n    if idx == 0:\n        return farm["farmer"]\n    return farm["hands"][idx - 1] if idx - 1 < len(farm["hands"]) else None\n\ndef _set_farmer_position(farm, idx, pos):\n    if idx == 0:\n        farm["farmer"] = list(pos)\n    else:\n        farm["hands"][idx - 1] = list(pos)\n\ndef _farmer_inventory(private, idx):\n    """Inventories list is [main_farmer, *hands]; grow it if idx is past the end."""\n    while len(private["inventories"]) <= idx:\n        private["inventories"].append({})\n    return private["inventories"][idx]\n\ndef _inv_add(inv, item, n=1):\n    inv[item] = inv.get(item, 0) + n\n\ndef _inv_take(inv, item, n=1):\n    if inv.get(item, 0) < n:\n        return False\n    inv[item] -= n\n    if inv[item] == 0:\n        del inv[item]\n    return True\n\ndef _apply_unit_action(farm, private, idx, action, board_size, day, turns_per_day, shed_capacity=100):\n    """Process one farmer/hand\'s action. Invalid / illegal actions are silent no-ops."""\n    if not isinstance(action, list) or not action:\n        return\n    op = action[0]\n    pos = _farmer_position(farm, idx)\n    if pos is None:\n        return\n    fx, fy = pos[0], pos[1]\n    inv = _farmer_inventory(private, idx)\n\n    if op in FARMER_MOVES:\n        dx, dy = FARMER_MOVES[op]\n        nx, ny = fx + dx, fy + dy\n        if not (0 <= nx < board_size and 0 <= ny < board_size):\n            return\n        # Movement onto LOCKED tiles is allowed: a hand can spawn on a locked\n        # shed-access tile, and blocking movement would strand it there forever.\n        # Tile operations (PLANT, WATER, etc.) still no-op on LOCKED tiles.\n        _set_farmer_position(farm, idx, (nx, ny))\n        return\n\n    if op == "PASS":\n        return\n\n    tile = farm["tiles"][fy][fx]\n\n    # Shed operations resolve before the LOCKED guard. They use the tile only as\n    # a standing position -- the shed itself is always owned -- and three of the\n    # four shed-access tiles start LOCKED, so guarding them first would make the\n    # shed unreachable from those tiles.\n    if op == "DROP":\n        if not _is_shed_adjacent((fx, fy), board_size):\n            return\n        shed = private["shed"]\n        for item, n in list(inv.items()):\n            if n <= 0:\n                del inv[item]\n                continue\n            room = max(0, shed_capacity - sum(shed.values()))\n            take = min(n, room)\n            if take > 0:\n                shed[item] = shed.get(item, 0) + take\n            del inv[item]\n        return\n\n    if op == "PICKUP":\n        if not _is_shed_adjacent((fx, fy), board_size):\n            return\n        if len(action) < 2:\n            return\n        item = action[1]\n        n = int(action[2]) if len(action) >= 3 else 1\n        if n <= 0:\n            return\n        # Seeds live in private["seeds"] and are consumed directly by PLANT;\n        # they never pass through farmer inventory or the shed.\n        available = private["shed"].get(item, 0)\n        n = min(n, available)\n        if n <= 0:\n            return\n        private["shed"][item] -= n\n        _inv_add(inv, item, n)\n        return\n\n    if op == "PLACE":\n        if len(action) < 2:\n            return\n        item = action[1]\n        # Animal placement: standing on a matching unoccupied structure. A LOCKED\n        # tile is the string "LOCKED", never a dict, so this branch cannot match\n        # there and PLACE falls through to the shed path below.\n        if (\n            item in ANIMALS\n            and isinstance(tile, dict)\n            and tile.get("kind") == ANIMALS[item]["structure"]\n            and "animal" not in tile\n        ):\n            if _inv_take(inv, item, 1):\n                farm["tiles"][fy][fx] = _new_animal(item, day)\n            return\n        # Shed drop: orthogonally adjacent to the shed; obeys shedCapacity.\n        if _is_shed_adjacent((fx, fy), board_size):\n            n = int(action[2]) if len(action) >= 3 else 1\n            if n <= 0:\n                return\n            n = min(n, inv.get(item, 0))\n            if n <= 0:\n                return\n            current = sum(private["shed"].values())\n            room = max(0, shed_capacity - current)\n            n = min(n, room)\n            if n <= 0:\n                return\n            inv[item] -= n\n            if inv[item] == 0:\n                del inv[item]\n            private["shed"][item] = private["shed"].get(item, 0) + n\n        return\n\n    # Everything below mutates the tile the unit stands on, so it requires that\n    # tile to be owned.\n    if tile == "LOCKED":\n        return\n\n    if op == "PLANT":\n        if len(action) < 2:\n            return\n        crop = action[1]\n        if crop not in CROPS:\n            return\n        if tile is not None:\n            return\n        if private["seeds"].get(crop, 0) <= 0:\n            return\n        private["seeds"][crop] -= 1\n        farm["tiles"][fy][fx] = _new_plant(crop, day, turns_per_day)\n        return\n\n    if op == "WATER":\n        if not (isinstance(tile, dict) and tile.get("kind") == "PLANT"):\n            return\n        if tile["watered_today"]:\n            return\n        tile["watered_today"] = True\n        crop_data = CROPS[tile["crop"]]\n        if not crop_data["ongoing"]:\n            age_days = day - tile["planted_day"]\n            window_start = (crop_data["max_yield_day"] + 1) // 2\n            if window_start <= age_days <= crop_data["max_yield_day"]:\n                bonus = 2 if tile["fertilized_until_day"] >= day else 1\n                tile["yield_units"] = min(crop_data["max_yield"], tile["yield_units"] + bonus)\n        return\n\n    if op == "HARVEST":\n        if not isinstance(tile, dict):\n            return\n        if tile.get("yield_units", 0) <= 0:\n            return\n        if tile.get("kind") == "PLANT":\n            crop_data = CROPS[tile["crop"]]\n            if day - tile["planted_day"] < crop_data["first_yield_day"]:\n                # Ongoing crops only accumulate yield_units after first_yield_day,\n                # so reaching here with yield_units > 0 indicates a bug.\n                if crop_data["ongoing"]:\n                    print(\n                        f"WARNING: HARVEST on immature ongoing {tile[\'crop\']} "\n                        f"(planted day {tile[\'planted_day\']}, current day {day}, "\n                        f"first_yield_day {crop_data[\'first_yield_day\']}, "\n                        f"yield_units {tile[\'yield_units\']}); should never happen"\n                    )\n                return\n            units = tile["yield_units"]\n            tile["yield_units"] = 0\n            _inv_add(inv, tile["crop"], units)\n            if not crop_data["ongoing"]:\n                farm["tiles"][fy][fx] = None\n        elif "animal" in tile:\n            units = tile["yield_units"]\n            tile["yield_units"] = 0\n            _inv_add(inv, ANIMALS[tile["animal"]]["product"], units)\n        return\n\n    if op == "FERTILIZE":\n        if not (isinstance(tile, dict) and tile.get("kind") == "PLANT"):\n            return\n        if not _inv_take(inv, "FERTILIZER", 1):\n            return\n        # Active for `day`, `day+1`, `day+2` (3 days inclusive).\n        tile["fertilized_until_day"] = max(tile.get("fertilized_until_day", -1), day + 2)\n        return\n\n    if op == "DIG":\n        if tile is None:\n            return\n        # Removes plants, weeds, empty coop/pasture. Does NOT remove a placed animal.\n        if isinstance(tile, dict) and "animal" in tile:\n            return\n        farm["tiles"][fy][fx] = None\n        return\n\n    if op == "BUILD_COOP":\n        if tile is not None:\n            return\n        farm["tiles"][fy][fx] = {"kind": "COOP"}\n        return\n\n    if op == "BUILD_PASTURE":\n        if tile is not None:\n            return\n        farm["tiles"][fy][fx] = {"kind": "PASTURE"}\n        return\n\n    if op == "FEED":\n        if not (isinstance(tile, dict) and "animal" in tile):\n            return\n        if tile["fed_today"]:\n            return\n        if not _inv_take(inv, "WHEAT", 1):\n            return\n        tile["fed_today"] = True\n        return\n\n    if op == "COLLECT_FERTILIZER":\n        if not (isinstance(tile, dict) and "animal" in tile):\n            return\n        if not tile["fertilizer_available"]:\n            return\n        tile["fertilizer_available"] = False\n        _inv_add(inv, "FERTILIZER", 1)\n        return\n\n    if op == "CARE":\n        if not (isinstance(tile, dict) and "animal" in tile):\n            return\n        if tile["cared_today"]:\n            return\n        tile["cared_today"] = True\n        return\n\ndef _decay_plants(farm, step):\n    board_size = len(farm["tiles"])\n    for y in range(board_size):\n        for x in range(board_size):\n            tile = farm["tiles"][y][x]\n            if not isinstance(tile, dict) or tile.get("kind") != "PLANT":\n                continue\n            mls = tile["max_lifespan_step"]\n            if mls < 0 or step < mls:\n                continue\n            if (step - mls) % 2 != 0:\n                continue\n            tile["yield_units"] -= 1\n            if tile["yield_units"] <= 0:\n                farm["tiles"][y][x] = {"kind": "WEED"}\n\n',_UNIT_NS)
_PLANNER_NS=dict(_UNIT_NS)
exec('"""E182 modification: Shop0909 last-seven-turn physical closure planner.\n\nNo engine imports, policy tapes, replay fixtures, RNG or remote calls.\nThe only supported market continuation is SELL; unknown execution abstains.\n"""\nfrom copy import deepcopy\nfrom time import perf_counter\nSTART, FINAL = (712, 718)\nOPS = set(FARMER_MOVES) | {\'PASS\', \'DROP\', \'PICKUP\', \'PLACE\', \'PLANT\', \'WATER\', \'HARVEST\', \'FERTILIZE\', \'DIG\', \'BUILD_COOP\', \'BUILD_PASTURE\', \'FEED\', \'CARE\', \'COLLECT_FERTILIZER\'}\nITEMS = tuple(PRODUCTS) + tuple(ANIMALS)\n\nclass Unsupported(ValueError):\n    pass\n\ndef _get(obj, key, default=None):\n    return obj.get(key, default) if isinstance(obj, dict) else getattr(obj, key, default)\n\ndef _settings(config):\n    size, turns, last = (_get(config, k, d) for k, d in [(\'boardSize\', 10), (\'turnsPerDay\', 24), (\'episodeSteps\', 720)])\n    if (size, turns, last) != (10, 24, 720):\n        raise Unsupported(\'requires pinned 10x10/24/720 terminal window\')\n    cap = int(_get(config, \'shedCapacity\', 100))\n    orders = min(10, int(_get(config, \'maxMarketOrdersPerTurn\', 10)))\n    if cap < 1 or orders < 1:\n        raise Unsupported(\'invalid capacity/order limit\')\n    return (size, turns, cap, orders)\n\ndef physical_state(obs):\n    """Comparable own physical state; market prices and bank are intentionally excluded."""\n    seat = int(_get(obs, \'player\', 0))\n    farm = _get(obs, \'farms\')[seat]\n    return ({k: v for k, v in farm.items() if k != \'money\'}, _get(obs, \'private\'))\n\ndef _commands(action, n):\n    return [action.get(\'farmer\', [\'PASS\']), *action.get(\'hands\', [])][:n] + [[\'PASS\'] for _ in range(max(0, n - 1 - len(action.get(\'hands\', []))))]\n\ndef _clone_state(farm, private):\n    f = dict(farm)\n    f[\'tiles\'] = [[dict(tile) if isinstance(tile, dict) else tile for tile in row] for row in farm[\'tiles\']]\n    f[\'farmer\'] = list(farm[\'farmer\'])\n    f[\'hands\'] = [list(pos) for pos in farm[\'hands\']]\n    f[\'unlocked_quadrants\'] = list(farm[\'unlocked_quadrants\'])\n    pr = dict(private)\n    pr[\'shed\'], pr[\'seeds\'] = (dict(private[\'shed\']), dict(private[\'seeds\']))\n    pr[\'inventories\'] = [dict(inv) for inv in private[\'inventories\']]\n    return (f, pr)\n\ndef _clone_schedule(schedule):\n    result = []\n    for action in schedule:\n        value = dict(action)\n        if \'farmer\' in action:\n            value[\'farmer\'] = list(action[\'farmer\'])\n        for key in [\'hands\', \'market\']:\n            if key in action:\n                value[key] = [list(command) for command in action[key]]\n        result.append(value)\n    return result\n\ndef _validate(schedule, n, orders):\n    for action in schedule:\n        if not isinstance(action, dict) or set(action) - {\'farmer\', \'hands\', \'market\'}:\n            raise Unsupported(\'unknown action shape\')\n        if not isinstance(action.get(\'hands\', []), list):\n            raise Unsupported(\'hands must be a list\')\n        for command in [action.get(\'farmer\', [\'PASS\']), *action.get(\'hands\', [])]:\n            if not isinstance(command, list) or not command or command[0] not in OPS:\n                raise Unsupported(\'unknown/malformed unit operation\')\n            if command[0] in {\'PICKUP\', \'PLACE\', \'PLANT\'}:\n                if len(command) < 2 or command[1] not in ITEMS:\n                    raise Unsupported(\'unknown unit item\')\n                if len(command) > 2 and (not isinstance(command[2], int)):\n                    raise Unsupported(\'noninteger unit quantity\')\n        market = action.get(\'market\', [])\n        if not isinstance(market, list) or len(market) > orders:\n            raise Unsupported(\'market order shape/cap\')\n        for order in market:\n            if not isinstance(order, list) or len(order) != 3 or order[0] != \'SELL\' or (order[1] not in PRODUCTS) or (not isinstance(order[2], int)) or (order[2] <= 0):\n                raise Unsupported(\'baseline market must contain positive integer SELL only\')\n\ndef liquidation(shed, inherited_market, max_orders=10):\n    """Use actual post-unit stock; retain first parent item ordering, then stable product order."""\n    items = []\n    for order in inherited_market:\n        if order[1] not in items:\n            items.append(order[1])\n    items += [item for item in PRODUCTS if item not in items]\n    orders = [[\'SELL\', item, int(shed.get(item, 0))] for item in items if shed.get(item, 0) > 0]\n    if len(orders) > min(10, max_orders):\n        raise Unsupported(\'actual final stock exceeds order slots\')\n    return orders\n\ndef shop_liquidation(farm, private, prices):\n    """Exact original final worker/drop and market rule, with current stock/prices."""\n    return liquidate(FarmView({\'player\': 0, \'farms\': [farm], \'private\': private, \'market\': {\'prices\': prices}}))\n\ndef simulate(obs, config, schedule, *, final_liquidate=False, detailed=False, preserve_final_commands=False):\n    """Exact own unit/decay and SELL-stock transitions. No claim to simulate shared prices."""\n    size, turns, cap, order_cap = _settings(config)\n    step = int(_get(obs, \'step\', -1))\n    if step < START or step + len(schedule) - 1 > FINAL or (not schedule):\n        raise Unsupported(\'outside 712..718; no day boundary or terminal auto-drop\')\n    if any(((t + 1) % turns == 0 for t in range(step, step + len(schedule)))):\n        raise Unsupported(\'day boundary\')\n    farm0, private0 = physical_state(obs)\n    farm, private = _clone_state(farm0, private0)\n    n = 1 + len(farm[\'hands\'])\n    if len(private[\'inventories\']) != n or n > 32:\n        raise Unsupported(\'invalid/unbounded worker inventory shape\')\n    _validate(schedule, n, order_cap)\n    deposited = [dict() for _ in range(n)]\n    sold = {}\n    snapshots, rows, events = ([], [], [])\n    executed = _clone_schedule(schedule)\n    overflow = 0\n    for offset, action in enumerate(executed):\n        t = step + offset\n        if detailed:\n            snapshots.append(_clone_state(farm, private))\n        if t == FINAL and (not preserve_final_commands):\n            action = shop_liquidation(farm, private, _get(obs, \'market\')[\'prices\'])\n            executed[offset] = action\n        all_commands = [action.get(\'farmer\', [\'PASS\']), *action.get(\'hands\', [])]\n        demand = {}\n        for command in all_commands:\n            if command[0] == \'PLANT\':\n                demand[command[1]] = demand.get(command[1], 0) + 1\n        blocked = {item for item, count in demand.items() if count > private[\'seeds\'].get(item, 0)}\n        for actor, command in enumerate(_commands(action, n)):\n            if command[0] == \'PLANT\' and command[1] in blocked:\n                command = [\'PASS\']\n            pos = farm[\'farmer\'] if actor == 0 else farm[\'hands\'][actor - 1]\n            xy = tuple(pos)\n            inv = private[\'inventories\'][actor]\n            before_inv = dict(inv) if command[0] in {\'DROP\', \'HARVEST\', \'COLLECT_FERTILIZER\'} else None\n            before_shed = dict(private[\'shed\']) if command[0] in {\'DROP\', \'PLACE\'} else None\n            _apply_unit_action(farm, private, actor, command, size, t // turns, turns, cap)\n            if before_shed is not None:\n                delta = {item: amount - before_shed.get(item, 0) for item, amount in private[\'shed\'].items() if amount > before_shed.get(item, 0)}\n                for item, amount in delta.items():\n                    deposited[actor][item] = deposited[actor].get(item, 0) + amount\n                if delta:\n                    events.append({\'offset\': offset, \'actor\': actor, \'op\': command[0], \'xy\': xy, \'deposited\': delta})\n                if command[0] == \'DROP\':\n                    overflow += sum((max(0, amount - inv.get(item, 0) - delta.get(item, 0)) for item, amount in before_inv.items()))\n            if command[0] in {\'HARVEST\', \'COLLECT_FERTILIZER\'}:\n                delta = {item: amount - before_inv.get(item, 0) for item, amount in inv.items() if amount > before_inv.get(item, 0)}\n                if delta:\n                    events.append({\'offset\': offset, \'actor\': actor, \'op\': command[0], \'xy\': xy, \'acquired\': delta})\n        pre_market = dict(private[\'shed\'])\n        if t == FINAL and preserve_final_commands and final_liquidate:\n            action[\'market\'] = liquidation(pre_market, [], order_cap)\n            prices = _get(obs, \'market\')[\'prices\']\n            action[\'market\'].sort(key=lambda order: -int(prices.get(order[1], 0)) * order[2])\n        for _, item, requested in action.get(\'market\', []):\n            quantity = min(requested, private[\'shed\'].get(item, 0), 99999)\n            if quantity > 0:\n                private[\'shed\'][item] -= quantity\n                sold[item] = sold.get(item, 0) + quantity\n        _decay_plants(farm, t)\n        rows.append({\'pre_market_shed\': pre_market, \'post_market_shed\': dict(private[\'shed\']), \'deposited_by_actor\': [dict(v) for v in deposited], \'sold\': dict(sold)})\n    if detailed:\n        snapshots.append(_clone_state(farm, private))\n    return {\'rows\': rows, \'states\': snapshots, \'events\': events, \'actions\': executed, \'overflow_units\': overflow, \'farm\': farm, \'private\': private, \'sold\': sold}\n\ndef _ge(left, right):\n    return all((left.get(item, 0) >= value for item, value in right.items()))\n\ndef dominates(candidate, baseline):\n    """Preserve every baseline worker\'s actual deposit prefixes and shed availability."""\n    if candidate[\'overflow_units\']:\n        return False\n    for new, old in zip(candidate[\'rows\'], baseline[\'rows\']):\n        if not _ge(new[\'pre_market_shed\'], old[\'pre_market_shed\']):\n            return False\n        if not _ge(new[\'sold\'], old[\'sold\']):\n            return False\n        if any((not _ge(a, b) for a, b in zip(new[\'deposited_by_actor\'], old[\'deposited_by_actor\']))):\n            return False\n    return True\n\ndef _value(run, prices):\n    shed = run[\'private\'][\'shed\']\n    return sum(((run[\'sold\'].get(item, 0) + shed.get(item, 0)) * prices[item] for item in PRODUCTS))\n\ndef _walk(start, end):\n    x, y = start\n    tx, ty = end\n    return [[\'EAST\']] * max(0, tx - x) + [[\'WEST\']] * max(0, x - tx) + [[\'SOUTH\']] * max(0, ty - y) + [[\'NORTH\']] * max(0, y - ty)\n\ndef _return(pos):\n    targets = _shed_access_tiles(10)\n    target = min(targets, key=lambda xy: (abs(pos[0] - xy[0]) + abs(pos[1] - xy[1]), targets.index(xy)))\n    return _walk(pos, target) + [[\'DROP\']]\n\ndef _proposals(run, actor, prices, max_per_actor):\n    """One/two resource bundles plus direct carry closure, replacing a baseline suffix."""\n    owners = {}\n    for event in run[\'events\']:\n        if \'acquired\' in event:\n            owners.setdefault((tuple(event[\'xy\']), event[\'op\']), set()).add(event[\'actor\'])\n    proposals = []\n    seen = set()\n    horizon = len(run[\'rows\'])\n    for offset in range(horizon):\n        farm, private = run[\'states\'][offset]\n        pos = tuple(farm[\'farmer\'] if actor == 0 else farm[\'hands\'][actor - 1])\n        inventory = private[\'inventories\'][actor]\n        carried = sum((prices.get(item, 0) * count for item, count in inventory.items()))\n        prefix_deposits = run[\'rows\'][offset - 1][\'deposited_by_actor\'][actor] if offset else {}\n        future_deposits = run[\'rows\'][-1][\'deposited_by_actor\'][actor]\n        obligation = sum((prices.get(item, 0) * (count - prefix_deposits.get(item, 0)) for item, count in future_deposits.items()))\n        bundles = []\n        for y, row in enumerate(farm[\'tiles\']):\n            for x, tile in enumerate(row):\n                if not isinstance(tile, dict):\n                    continue\n                xy, operations, value = ((x, y), [], 0)\n                if tile.get(\'yield_units\', 0) > 0:\n                    item = tile.get(\'crop\') if tile.get(\'kind\') == \'PLANT\' else ANIMALS.get(tile.get(\'animal\'), {}).get(\'product\')\n                    mature = item and (\'animal\' in tile or (START + offset) // 24 - tile[\'planted_day\'] >= CROPS[item][\'first_yield_day\'])\n                    if mature and (not owners.get((xy, \'HARVEST\'), set()) - {actor}):\n                        operations.append([\'HARVEST\'])\n                        value += prices[item] * tile[\'yield_units\']\n                if tile.get(\'fertilizer_available\') and \'animal\' in tile and (not owners.get((xy, \'COLLECT_FERTILIZER\'), set()) - {actor}):\n                    operations.append([\'COLLECT_FERTILIZER\'])\n                    value += prices[\'FERTILIZER\']\n                if operations:\n                    distance = len(_walk(pos, xy)) + len(operations) + len(_return(xy))\n                    if distance <= horizon - offset:\n                        bundles.append((xy, operations, value, distance))\n        bundles.sort(key=lambda b: (-b[2] / b[3], -b[2], b[0]))\n        variants = [([], carried)] if carried else []\n        for xy, ops, value, _ in bundles[:6]:\n            variants.append(([(xy, ops)], carried + value))\n        for first in bundles[:3]:\n            for second in bundles[:3]:\n                if first[0] != second[0]:\n                    variants.append(([(first[0], first[1]), (second[0], second[1])], carried + first[2] + second[2]))\n        for stops, value in variants:\n            route, cursor = ([], pos)\n            for xy, ops in stops:\n                route += _walk(cursor, xy) + ops\n                cursor = xy\n            route += _return(cursor)\n            if len(route) > horizon - offset:\n                continue\n            route += [[\'PASS\']] * (horizon - offset - len(route))\n            key = (offset, tuple((tuple(c) for c in route)))\n            if key not in seen:\n                seen.add(key)\n                proposals.append((value - obligation, offset, route, len(stops)))\n    proposals.sort(key=lambda p: (-p[0], p[1], p[2]))\n    direct = [p for p in proposals if p[3] == 0 and p[0] > 0][:2]\n    chosen = direct + [p for p in proposals if p not in direct]\n    return chosen[:max_per_actor]\n\ndef plan_terminal(obs, config, baseline_remaining, *, max_simulations=64, passes=1, proposals_per_actor=4):\n    """At 712 accept seven actions; positive physical delivery is mandatory."""\n    begun = perf_counter()\n    fallback = {\'accepted\': False, \'reason\': \'\', \'actions\': None, \'simulations\': 0}\n    try:\n        if int(_get(obs, \'step\', -1)) != START or len(baseline_remaining) != FINAL - START + 1:\n            raise Unsupported(\'planning requires step 712 and exactly seven actions through 718\')\n        max_simulations = min(256, max(1, int(max_simulations)))\n        passes = min(2, max(1, int(passes)))\n        proposals_per_actor = min(16, max(1, int(proposals_per_actor)))\n        baseline = simulate(obs, config, baseline_remaining, detailed=True)\n        prices = {item: max(1, float(_get(obs, \'market\', {}).get(\'prices\', {}).get(item, 1))) for item in PRODUCTS}\n        current, best = (_clone_schedule(baseline_remaining), baseline)\n        baseline_value = best_value = _value(baseline, prices)\n        changes, simulations = ([], 0)\n        n = len(baseline[\'private\'][\'inventories\'])\n        for sweep in range(passes):\n            improved = False\n            for actor in range(n):\n                winner = None\n                for _, offset, route, bundle_count in _proposals(best, actor, prices, proposals_per_actor):\n                    if simulations >= max_simulations:\n                        break\n                    trial = _clone_schedule(current)\n                    for i, command in enumerate(route, offset):\n                        if actor == 0:\n                            trial[i][\'farmer\'] = command\n                        else:\n                            trial[i].setdefault(\'hands\', [])\n                            while len(trial[i][\'hands\']) < n - 1:\n                                trial[i][\'hands\'].append([\'PASS\'])\n                            trial[i][\'hands\'][actor - 1] = command\n                    evaluated = simulate(obs, config, trial)\n                    simulations += 1\n                    score = _value(evaluated, prices)\n                    if score > best_value and dominates(evaluated, baseline):\n                        required = {(tuple(e[\'xy\']), e[\'op\'], e[\'actor\']): e[\'acquired\'] for e in best[\'events\'] if \'acquired\' in e and e[\'actor\'] != actor}\n                        acquired = {}\n                        for e in evaluated[\'events\']:\n                            if \'acquired\' in e:\n                                key = (tuple(e[\'xy\']), e[\'op\'], e[\'actor\'])\n                                dst = acquired.setdefault(key, {})\n                                for item, amount in e[\'acquired\'].items():\n                                    dst[item] = dst.get(item, 0) + amount\n                        if all((_ge(acquired.get(k, {}), v) for k, v in required.items())):\n                            winner, best_value = ((trial, offset, bundle_count), score)\n                if winner:\n                    current, offset, bundle_count = winner\n                    best = simulate(obs, config, current, detailed=True)\n                    changes.append({\'pass\': sweep, \'actor\': actor, \'from_step\': START + offset, \'resource_bundles\': bundle_count, \'estimated_stock_value\': best_value})\n                    improved = True\n                if simulations >= max_simulations:\n                    break\n            if not improved or simulations >= max_simulations:\n                break\n        if not changes or best_value <= baseline_value:\n            return {**fallback, \'reason\': \'no positive physical delivery gain\', \'simulations\': simulations, \'changed_workers\': [], \'changes\': [], \'certificate\': {\'stock_value_gain_at_initial_prices\': 0, \'sold_unit_delta\': dict.fromkeys(PRODUCTS, 0)}, \'planning_ms\': (perf_counter() - begun) * 1000}\n        final = simulate(obs, config, current, final_liquidate=True, detailed=True)\n        physical = simulate(obs, config, current)\n        if not dominates(physical, baseline):\n            raise Unsupported(\'no zero-overflow dominating continuation\')\n        delta = {item: final[\'sold\'].get(item, 0) - baseline[\'sold\'].get(item, 0) for item in PRODUCTS}\n        deposited_gain = any((final[\'rows\'][-1][\'deposited_by_actor\'][actor].get(item, 0) > baseline[\'rows\'][-1][\'deposited_by_actor\'][actor].get(item, 0) for actor in range(n) for item in PRODUCTS))\n        worker_change = any((_commands(new, n) != _commands(old, n) for new, old in zip(final[\'actions\'], baseline[\'actions\'])))\n        accepted = worker_change and deposited_gain and any((v > 0 for v in delta.values())) and all((v >= 0 for v in delta.values()))\n        plan = {\'accepted\': accepted, \'reason\': \'joint physical dominance\' if accepted else \'no improvement\', \'baseline\': _clone_schedule(baseline_remaining), \'actions\': final[\'actions\'], \'expected_states\': final[\'states\'][:-1], \'simulations\': simulations, \'changes\': changes, \'abandoned\': False, \'changed_workers\': sorted({c[\'actor\'] for c in changes}), \'certificate\': {\'baseline_rows\': baseline[\'rows\'], \'physical_rows\': physical[\'rows\'], \'baseline_overflow\': baseline[\'overflow_units\'], \'candidate_overflow\': final[\'overflow_units\'], \'sold_unit_delta\': delta, \'stock_value_gain_at_initial_prices\': best_value - baseline_value, \'baseline_final_shed\': baseline[\'private\'][\'shed\'], \'final_shed\': final[\'private\'][\'shed\'], \'positive_physical_deposit_gain\': deposited_gain, \'markets_712_717_unchanged\': all((final[\'actions\'][i].get(\'market\', []) == baseline_remaining[i].get(\'market\', []) for i in range(FINAL - START)))}}\n    except (Unsupported, KeyError, TypeError, ValueError, IndexError) as exc:\n        plan = {**fallback, \'reason\': str(exc)}\n    plan[\'planning_ms\'] = (perf_counter() - begun) * 1000\n    return plan\n\ndef _effective_action(action, n):\n    return (_commands(action, n), action.get(\'market\', []))\n\ndef _recover_observed(obs, config, parent_action, plan):\n    """Bounded cargo salvage after deviation; never resume old positional commands."""\n    farm, private = physical_state(obs)\n    positions = [farm[\'farmer\'], *farm[\'hands\']]\n    remaining = FINAL - int(_get(obs, \'step\')) + 1\n    room = max(0, int(_get(config, \'shedCapacity\', 100)) - sum(private[\'shed\'].values()))\n    commands = []\n    problems = []\n    prices = _get(obs, \'market\', {}).get(\'prices\', {})\n    for actor, (pos, inv) in enumerate(zip(positions, private[\'inventories\'])):\n        command = [\'PASS\']\n        if any((v > 0 for v in inv.values())):\n            route = _return(pos)\n            if len(route) > remaining:\n                problems.append({\'actor\': actor, \'reason\': \'unreachable cargo\'})\n            elif len(route) > 1:\n                command = route[0]\n            elif sum((max(0, q) for q in inv.values())) <= room:\n                command = [\'DROP\']\n                room -= sum((max(0, q) for q in inv.values()))\n            else:\n                items = [item for item in PRODUCTS if inv.get(item, 0) > 0]\n                if room and items:\n                    item = max(items, key=lambda i: (prices.get(i, 1) * min(inv[i], room), -PRODUCTS.index(i)))\n                    quantity = min(inv[item], room)\n                    command = [\'PLACE\', item, quantity]\n                    room -= quantity\n                else:\n                    problems.append({\'actor\': actor, \'reason\': \'no shed capacity\'})\n        commands.append(command)\n    action = {\'farmer\': commands[0], \'hands\': commands[1:], \'market\': deepcopy(parent_action.get(\'market\', []))}\n    if int(_get(obs, \'step\')) == FINAL:\n        action[\'market\'] = []\n        action = simulate(obs, config, [action], final_liquidate=True, preserve_final_commands=True)[\'actions\'][0]\n    plan[\'recovery_steps\'] = plan.get(\'recovery_steps\', 0) + 1\n    if problems:\n        plan.setdefault(\'recovery_failures\', []).append({\'step\': int(_get(obs, \'step\')), \'problems\': problems})\n    return action\n\ndef terminal_action(obs, config, parent_action, plan):\n    """Canonical guard, pre-deviation abstention, observed recovery after deviation."""\n    step = int(_get(obs, \'step\', -1))\n    if not plan or not plan.get(\'accepted\') or (not START <= step <= FINAL):\n        return parent_action\n    if plan.get(\'abandoned\'):\n        return _recover_observed(obs, config, parent_action, plan) if plan.get(\'deviated\') else parent_action\n    index = step - START\n    n = 1 + len(physical_state(obs)[0][\'hands\'])\n    mismatch = physical_state(obs) != plan[\'expected_states\'][index] or _effective_action(parent_action, n) != _effective_action(plan[\'baseline\'][index], n)\n    if mismatch:\n        plan[\'abandoned\'] = True\n        plan[\'abandon_step\'] = step\n        plan[\'reason\'] = \'physical observation or effective baseline action diverged\'\n        plan[\'safety_failure\'] = True\n        return _recover_observed(obs, config, parent_action, plan) if plan.get(\'deviated\') else parent_action\n    result = deepcopy(plan[\'actions\'][index])\n    if step == FINAL:\n        farm, private = physical_state(obs)\n        result = shop_liquidation(farm, private, _get(obs, \'market\')[\'prices\'])\n    if _commands(result, n) != _commands(parent_action, n):\n        plan[\'deviated\'] = True\n    return result',_PLANNER_NS)
_PRE_TERMINAL_AGENT=agent
del agent
_TERMINAL_PLANS={}
_TERMINAL_PREVIOUS={}
_UPGRADE_STATS={'planning_calls':0,'accepted':0,'changed_steps':0,'aborted':0,'shadow_declines':0,'errors':0,'max_planning_ms':0.0}

def _parent_liquidate(farm, private, prices):
    view=_View({'player':0,'farms':[farm],'private':private,'market':{'prices':prices}},0,_IMPL.chassis.cfg)
    commands=[['DROP'] if _shed_adjacent(pos,view.board) and view.inv(i) else ['PASS'] for i,pos in enumerate(view.positions)]
    action={'farmer':commands[0],'hands':commands[1:],'market':[]}
    stock=_IMPL.chassis._projected_shed(action,view)
    action['market']=[['SELL',item,stock.get(item,0)] for item in PRODUCTS if stock.get(item,0)>0]
    action['market'].sort(key=lambda o:-view.prices.get(o[1],0)*o[2])
    return action

_PLANNER_NS['shop_liquidation']=_parent_liquidate

def _shadow_terminal(obs,config):
    seat=int(obs['player']);chassis=_IMPL.chassis
    state=chassis.players.get(seat)
    if not state or state.get('last_step')!=711 or state.get('route')!=2:
        return None
    if state.get('pending'):
        return None
    shadow=copy.copy(chassis);shadow.players=copy.deepcopy(chassis.players)
    shadow.diagnostics={k:0 for k in chassis.diagnostics}
    projected=copy.deepcopy(obs);baseline=[];states=[]
    for step in range(712,719):
        projected['step']=step;projected['day']=step//24;projected['hour']=step%24
        states.append(copy.deepcopy(shadow.players[seat]))
        action=shadow.act(projected,config)
        if step==718:
            action=_parent_liquidate(projected['farms'][seat],projected['private'],projected['market']['prices'])
        else:
            market=action.get('market',[])
            if len(market)!=9 or {o[1] for o in market}!=set(PRODUCTS) or any(o[0]!='SELL' or len(o)!=3 or type(o[2]) is not int or o[2]<100 for o in market):
                return None
        if any(shadow.diagnostics.values()):return None
        run=_PLANNER_NS['simulate'](projected,config,[action])
        if run['actions'][0]!=action:return None
        baseline.append(action)
        run['farm']['money']=projected['farms'][seat]['money']
        projected['farms'][seat]=run['farm'];projected['private']=run['private']
    return baseline,states

def agent(observation,configuration=None):
    try:
        step=int(observation['step']);seat=int(observation['player'])
    except Exception:
        return _PRE_TERMINAL_AGENT(observation,configuration)
    previous=_TERMINAL_PREVIOUS.get(seat)
    if step==0 or (previous is not None and step<=previous):_TERMINAL_PLANS.pop(seat,None)
    _TERMINAL_PREVIOUS[seat]=step
    plan=_TERMINAL_PLANS.get(seat)
    if plan and plan.get('accepted') and 712<=step<=718:
        if previous!=step-1:plan.update(abandoned=True,reason='nonconsecutive callback')
        try:
            result=_PLANNER_NS['terminal_action'](observation,configuration,plan['baseline'][step-712],plan)
            if plan.get('abandoned'):
                if not plan.get('abort_counted'):
                    plan['abort_counted']=True;_UPGRADE_STATS['aborted']+=1
                if not plan.get('deviated'):
                    _IMPL.chassis.players[seat]=copy.deepcopy(plan['parent_states_before'][step-712])
                    _TERMINAL_PLANS.pop(seat,None)
                    return _PRE_TERMINAL_AGENT(observation,configuration)
            _UPGRADE_STATS['changed_steps']+=int(result!=plan['baseline'][step-712])
            return result
        except Exception:
            _UPGRADE_STATS['errors']+=1
            if plan.get('deviated'):
                try:return _PLANNER_NS['_recover_observed'](observation,configuration,plan['baseline'][step-712],plan)
                except Exception:return _parent_liquidate(observation['farms'][seat],observation['private'],observation['market']['prices'])
    if step!=712:return _PRE_TERMINAL_AGENT(observation,configuration)
    _UPGRADE_STATS['planning_calls']+=1
    try:shadow=_shadow_terminal(observation,configuration)
    except (ValueError,KeyError,TypeError,IndexError):shadow=None
    if shadow is None:
        _UPGRADE_STATS['shadow_declines']+=1
        return _PRE_TERMINAL_AGENT(observation,configuration)
    baseline,states=shadow
    actual=_PRE_TERMINAL_AGENT(observation,configuration)
    if actual!=baseline[0]:
        _UPGRADE_STATS['shadow_declines']+=1;return actual
    try:
        plan=_PLANNER_NS['plan_terminal'](observation,configuration,baseline,max_simulations=64,passes=1,proposals_per_actor=4)
        _UPGRADE_STATS['max_planning_ms']=max(_UPGRADE_STATS['max_planning_ms'],plan.get('planning_ms',0.0))
        if not plan.get('accepted'):return actual
        plan['parent_states_before']=states;_TERMINAL_PLANS[seat]=plan
        _UPGRADE_STATS['accepted']+=1
        result=_PLANNER_NS['terminal_action'](observation,configuration,actual,plan)
        _UPGRADE_STATS['changed_steps']+=int(result!=actual)
        return result
    except Exception:
        _UPGRADE_STATS['errors']+=1;return actual

agent.telemetry=_UPGRADE_STATS

_PRE_ROOM_AGENT=agent
del agent
_ROOM_STATS={'changed_turns':0,'added_units':0,'errors':0}
def agent(observation,configuration=None):
    action=_PRE_ROOM_AGENT(observation,configuration)
    try:
        step=_step_of(observation)
        if step%24!=23:return action
        view=_View(observation,_int(_get(observation,'player',0)),_IMPL.chassis.cfg)
        carried=sum(max(0,int(n)) for inv in view.invs for n in inv.values())
        needed=sum(view.shed.values())+carried-99
        if needed<=0:return action
        planned={}
        for o in action.get('market',[]):
            if o and o[0]=='SELL' and len(o)>=3:planned[o[1]]=planned.get(o[1],0)+max(0,int(o[2]))
        result=copy.deepcopy(action);added=0
        for item in sorted(PRODUCTS,key=lambda it:-int(view.prices.get(it,0))):
            qty=min(needed,max(0,view.shed.get(item,0)-planned.get(item,0)))
            if qty<=0:continue
            if len(result['market'])>=10:break
            result['market'].append(['SELL',item,qty]);needed-=qty;added+=qty
            if needed<=0:break
        if added:_ROOM_STATS['changed_turns']+=1;_ROOM_STATS['added_units']+=added
        return result
    except Exception:
        _ROOM_STATS['errors']+=1;return action

agent.telemetry=_ROOM_STATS


_V28_CORE=agent
del agent
_IMPL.chassis.diagnostics['v28_entry_errors']=0
def agent(observation,configuration=None):
    try:
        return _V28_CORE(observation,configuration)
    except Exception:
        _IMPL.chassis.diagnostics['v28_entry_errors']+=1
        return {'farmer':['PASS'],'hands':[],'market':[]}
agent.telemetry=_ROOM_STATS

MAX_ORDERS=10
class FarmView(_View):
    def __init__(self,obs):super().__init__(obs,int(obs['player']),_IMPL.chassis.cfg)
    def inventory(self,actor):return self.inv(actor)
def projected_shed(action,view):return _IMPL.chassis._projected_shed(action,view)

CROP_MIN_PRICE=70

_V219_PARENT = agent
del agent
_V219_FERTILIZE = True  # Builder changes only this flag for the ablation.
_V219_STATES = {}
_V219_REPORT = {'commitments': 0, 'hire_requests': 0, 'confirmed_workers': 0,
                'hire_shortfalls': 0, 'plant_requests': 0, 'confirmed_plants': 0,
                'water_requests': 0, 'fertilize_requests': 0, 'harvest_requests': 0,
                'confirmed_harvest_units': 0, 'drop_requests': 0,
                'tomato_sale_requests': 0, 'budget_declines': 0, 'lost_plants': 0}


def _v219_fib(n):
    a, b = 1, 1
    for _ in range(n): a, b = b, a+b
    return a


def _v219_native_day(native, day):
    tape = _IMPL.chassis.routes[native['route']]
    return tape[day*24:min((day+1)*24,719)]


def _v219_qualifies(obs, native):
    farm=obs['farms'][obs['player']]
    if len(farm['tiles']) != 10 or set(farm['unlocked_quadrants']) != {'NW','NE','SW'}:
        return False
    if farm['money'] < 12000 or obs['market']['prices']['TOMATO'] < CROP_MIN_PRICE:
        return False
    if sum(s in ('PIZZA_SHOP','FARMERS_MARKET') for s in obs['town']['unlocked_shops']) < 3:
        return False
    if any(farm['tiles'][y][x] != 'LOCKED' for y in (5,6) for x in range(5,10)):
        return False
    if obs['private']['seeds'].get('TOMATO',0) or obs['private']['shed'].get('TOMATO',0):
        return False
    if any(isinstance(t,dict) and t.get('crop')=='TOMATO' for row in farm['tiles'] for t in row):
        return False
    for tape in _IMPL.chassis.routes.values():
        for a in tape[432:719]:
            if any(o and o[0]=='BUY_LAND' for o in a.get('market',[])):return False
            if any(c==['PLANT','TOMATO'] for c in [a.get('farmer')]+a.get('hands',[])):return False
    return True


def _v219_walk(pos, target):
    x,y=pos;tx,ty=target
    if x != tx:return ['EAST' if x < tx else 'WEST']
    if y != ty:return ['SOUTH' if y < ty else 'NORTH']
    return None


def _v219_home(pos):
    return min(((4,4),(5,4),(4,5),(5,5)),key=lambda p:abs(pos[0]-p[0])+abs(pos[1]-p[1]))


def _v219_request(obs, action, state, native):
    step=int(obs['step']);day=step//24;offset=step%24
    farm=obs['farms'][obs['player']];private=obs['private']
    if not state.get('committed') and day!=18:return action
    if state.get('requested_day')==day:return action
    planned=_v219_native_day(native,day)
    latest_hire=max((i for i,a in enumerate(planned) if any(o and o[0]=='HIRE' for o in a.get('market',[]))),default=-1)
    deadline=6 if state.get('committed') and 3<latest_hire<=6 else 3
    if offset>deadline:return action
    remaining=planned[offset+1:]
    if any(o and o[0]=='HIRE' for a in remaining for o in a.get('market',[])):
        return action
    parent_hires=sum(bool(o) and o[0]=='HIRE' for o in action['market'])
    expected=max(len(a.get('hands',[])) for a in planned)
    if len(farm['hands'])+parent_hires != expected:return action
    fertilizer=bool(_V219_FERTILIZE and day in (24,27) and _r79_tomato_fertilizer_worthwhile(obs,action))
    crop_workers=1 if day in (19,20,21,22,23,25) and offset<=2 else (3 if 26<=day<=28 else 2)
    labor=_r53_labor_assignment(obs,action,fertilizer)
    if labor is not None:crop_workers=labor['workers']
    count=crop_workers+int(fertilizer and day==27 and labor is None)
    extra=[]
    if not state.get('committed'):
        extra += [['BUY_LAND'],['BUY_SEED','TOMATO',10]]
    fertilizer_quantity=_r70_parent_fert_qty(obs,action,planned,offset) if fertilizer else 0
    if fertilizer:extra.append(['BUY_PRODUCT','FERTILIZER',fertilizer_quantity])
    extra += [['HIRE'] for _ in range(count)]
    if len(action['market'])+len(extra)>MAX_ORDERS:return action
    budget=sum(_v219_fib(n) for n in range(farm['hires_today'],farm['hires_today']+parent_hires+count))
    if not state.get('committed'):budget+=4500
    if fertilizer:budget+=fertilizer_quantity*(obs['market']['prices']['FERTILIZER']+5)
    for order in action['market']:
        if not order:continue
        if order[0]=='BUY_PRODUCT':budget+=int(order[2])*(int(obs['market']['prices'][order[1]])+10)
        elif order[0]=='BUY_ANIMAL':budget+=int(order[2])*{'COW':400,'SHEEP':500,'GOOSE':300}[order[1]]
        elif order[0]=='BUY_SEED':budget+=int(order[2])*{'WHEAT':10,'CARROT':20,'TOMATO':50,'STRAWBERRY':100,'MELON':80}[order[1]]
    if farm['money']<budget+3000:
        _V219_REPORT['budget_declines']+=1;return action
    state['pending']={'step':step,'first_actor':expected+1,'count':count,'crop_workers':crop_workers,'fertilizer':fertilizer,'labor':labor}
    if labor is not None:
        _R53_LABOR_REPORT['labor_requests']+=1;_R53_LABOR_REPORT['labor_hires_avoided']+=1;_R53_LABOR_REPORT['labor_day'+str(day)]+=1
    state['requested_day']=day
    _V219_REPORT['hire_requests']+=count
    if not state.get('committed'):
        state['committed']=True;_V219_REPORT['commitments']+=1
    changed=copy.deepcopy(action);changed['market']+=extra
    return changed


def _v219_worker(obs, state, actor, role):
    day=int(obs['step'])//24;step=int(obs['step']);view=FarmView(obs)
    pos=tuple(view.positions[actor]);inv=view.inventory(actor)
    targets=role['targets']
    previous=state['last_work'].get(actor)
    if previous and previous['step']==step-1 and previous['command']==['HARVEST']:
        _V219_REPORT['confirmed_harvest_units']+=max(0,int(inv.get('TOMATO',0))-previous['tomatoes'])
    if role.get('needs_fertilizer') and not role.get('loaded'):
        home=_v219_home(pos)
        walk=_v219_walk(pos,home)
        if walk:return walk
        desired=role.get('fertilizer_quantity',10 if role['kind']=='fertilizer' else 5)
        if inv.get('FERTILIZER',0)>=desired:role['loaded']=True
        elif role.get('pickup_requested'):
            role['loaded']=True;role['fertilizer_available']=int(inv.get('FERTILIZER',0))
        elif view.shed.get('FERTILIZER',0)>=desired:
            role['pickup_requested']=True;return ['PICKUP','FERTILIZER',desired]
        else:role['loaded']=True
    todo=[]
    for target in targets:
        x,y=target;tile=view.tiles[y][x]
        tomato=isinstance(tile,dict) and tile.get('crop')=='TOMATO'
        if tomato and target not in state['seen_plants']:
            state['seen_plants'].add(target);_V219_REPORT['confirmed_plants']+=1
        if target in state['seen_plants'] and not tomato and target not in state['lost']:
            state['lost'].add(target);_V219_REPORT['lost_plants']+=1
        command=None
        if role['kind']=='fertilizer':
            if tomato and tile.get('fertilized_until_day',-1)<day+2 and inv.get('FERTILIZER',0)>0:
                command=['FERTILIZE']
        elif day==18 and not tomato:
            if tile is None and obs['private']['seeds'].get('TOMATO',0)>0:command=['PLANT','TOMATO']
            elif isinstance(tile,dict) and tile.get('kind')=='WEED':command=['DIG']
        elif tomato:
            if day<29 and not tile.get('watered_today'):command=['WATER']
            elif role.get('needs_fertilizer') and tile.get('fertilized_until_day',-1)<day+2 and inv.get('FERTILIZER',0)>0:
                command=['FERTILIZE']
            elif tile.get('yield_units',0)>0:command=['HARVEST']
        if command:todo.append((target,command))
    home=_v219_home(pos);distance=abs(pos[0]-home[0])+abs(pos[1]-home[1])
    if step>=718-distance and inv.get('TOMATO',0):
        return _v219_walk(pos,home) or ['PLACE','TOMATO',int(inv.get('TOMATO',0))]
    if todo:
        target,command=min(todo,key=lambda v:(abs(pos[0]-v[0][0])+abs(pos[1]-v[0][1]),targets.index(v[0])))
        return _v219_walk(pos,target) or command
    if inv.get('TOMATO',0):return _v219_walk(pos,home) or ['PLACE','TOMATO',int(inv['TOMATO'])]
    if any(inv.values()):return _v219_walk(pos,home) or ['DROP']
    return ['PASS']


def agent(observation, configuration=None):
    action=_V219_PARENT(observation,configuration)
    step=int(observation['step']);player=int(observation['player']);day=step//24
    state=_V219_STATES.get(player)
    if state is None or step<=state['last_step']:
        state={'last_step':step,'day':-1,'workers':{},'last_work':{},'seen_plants':set(),'lost':set(),
               'targets':[(x,y) for y in (5,6) for x in range(5,10)]}
        _V219_STATES[player]=state
    state['last_step']=step
    native=_IMPL.chassis.players[player]
    if step==432:state['eligible']=_v219_qualifies(observation,native)
    if not state.get('eligible') or day<18:return action
    if state['day']!=day:
        state['day']=day;state['workers']={};state['last_work']={}
    farm=observation['farms'][player]
    pending=state.pop('pending',None)
    if pending:
        if len(farm['hands'])+1 >= pending['first_actor']+pending['count'] and 'SE' in farm['unlocked_quadrants']:
            for index in range(pending['count']):
                fertilizer_worker=index==pending['crop_workers']
                if fertilizer_worker:targets=state['targets']
                elif pending['crop_workers']==1:targets=state['targets']
                elif pending['crop_workers']==2:targets=state['targets'][index*5:index*5+5]
                else:targets=[[(5,5),(6,5),(7,5)],[(8,5),(9,5),(9,6),(8,6)],[(5,6),(6,6),(7,6)]][index]
                state['workers'][pending['first_actor']+index]={'kind':'fertilizer' if fertilizer_worker else 'crop','targets':targets,
                    'needs_fertilizer':pending['fertilizer'] and (day==24 or fertilizer_worker)}
                if pending.get('labor') is not None:
                    role=state['workers'][pending['first_actor']+index]
                    role['targets']=[tuple(p) for p in pending['labor']['paths'][index]]
                    role['needs_fertilizer']=pending['labor']['fertilizer'];role['fertilizer_quantity']=len(role['targets'])
                    if tuple(farm['hands'][pending['first_actor']+index-1])!=tuple(pending['labor']['spawns'][index]):_R53_LABOR_REPORT['labor_spawn_errors']+=1
                    if index==0:_R53_LABOR_REPORT['labor_confirmed']+=1
            _V219_REPORT['confirmed_workers']+=pending['count']
        else:_V219_REPORT['hire_shortfalls']+=pending['count']
    action=_v219_request(observation,action,state,native)
    if state['workers']:
        commands=[action.get('farmer') or ['PASS']]+list(action.get('hands') or [])
        commands += [['PASS'] for _ in range(len(farm['hands'])+1-len(commands))]
        for actor,role in state['workers'].items():
            if actor>=len(commands):continue
            command=_v219_worker(observation,state,actor,role)
            commands[actor]=command
            name={'PLANT':'plant_requests','WATER':'water_requests','FERTILIZE':'fertilize_requests',
                  'HARVEST':'harvest_requests','DROP':'drop_requests'}.get(command[0])
            if name:_V219_REPORT[name]+=1
            state['last_work'][actor]={'step':step,'command':command,'tomatoes':observation['private']['inventories'][actor].get('TOMATO',0)}
        action=copy.deepcopy(action);action['farmer'],action['hands']=commands[0],commands[1:]
    if state.get('committed') and len(action['market'])<MAX_ORDERS and not any(o[:2]==['SELL','TOMATO'] for o in action['market']):
        quantity=projected_shed(action,FarmView(observation)).get('TOMATO',0)
        if quantity>0:
            action=copy.deepcopy(action);action['market'].append(['SELL','TOMATO',quantity])
            _V219_REPORT['tomato_sale_requests']+=quantity
    return action


agent.telemetry=_V219_REPORT



_ORIGINAL_SHADOW_TERMINAL=_shadow_terminal
def _shadow_terminal(obs,config):
    if _V219_STATES.get(int(obs['player']),{}).get('committed'):return None
    return _ORIGINAL_SHADOW_TERMINAL(obs,config)

APPLY_TIMING=False

_EXPERIMENT_PARENT=agent
del agent
_V219_REPORT['extra_fertilizer_days']=0
_V219_REPORT['reordered_market_turns']=0
_V219_REPORT['errors']=0
def agent(observation,configuration=None):
    try:
        action=_EXPERIMENT_PARENT(observation,configuration)
        if APPLY_TIMING and int(observation['step'])>=144:action=_v224_sales_first(action)
        return action
    except Exception:
        _V219_REPORT['errors']+=1
        return {'farmer':['PASS'],'hands':[],'market':[]}
agent.telemetry=_V219_REPORT

def _v224_sales_first(action):
    original=action.get('market',[])[:MAX_ORDERS]
    orders=[list(o) for o in original if o and (o[0] in ('HIRE','BUY_LAND') or (len(o)>=3 and int(o[2])>0))]
    for index in range(len(orders)):
        order=orders[index]
        if order[0]!='SELL':continue
        cursor=index
        while cursor>0:
            previous=orders[cursor-1]
            if previous[0]=='SELL':break
            if previous[0] in ('BUY_PRODUCT','BUY_ANIMAL') and previous[1]==order[1]:break
            orders[cursor-1],orders[cursor]=orders[cursor],orders[cursor-1]
            cursor-=1
    if orders==original:return action
    _V219_REPORT['reordered_market_turns']+=1
    changed=copy.deepcopy(action);changed['market']=orders
    return changed
_ORDER_PARENT=agent
del agent

def agent(observation,configuration=None):
    try:
        action=_ORDER_PARENT(observation,configuration)
        if int(observation["step"])>=144:action=_v224_sales_first(action)
        return action
    except Exception:
        _V219_REPORT["errors"]+=1
        return {"farmer":["PASS"],"hands":[],"market":[]}
agent.telemetry=_V219_REPORT

_V31_CORE=agent
del agent
_IMPL.chassis.diagnostics['production_errors']=0
_IMPL.chassis.diagnostics['v31_entry_errors']=0
def agent(observation,configuration=None):
    before=_V219_REPORT['errors']
    try:
        action=_V31_CORE(observation,configuration)
        _IMPL.chassis.diagnostics['production_errors']+=_V219_REPORT['errors']-before
        return action
    except Exception:
        _IMPL.chassis.diagnostics['v31_entry_errors']+=1
        return {'farmer':['PASS'],'hands':[],'market':[]}
agent.telemetry=_V219_REPORT

_V231_PARENT=agent
_V231_CAP=4
_V231_STATES={}
_V231_REPORT={}

def _v231_new_state():
    return {'last':-1,'confirmed':0,'reserved':0,'pending_buy':None,
            'carrying':{},'pending_places':[],'sites':{},'milk_credit':0,
            'requested':0,'failed_purchase_units':0,'picked':0,'placed':0,
            'failed_placements':0,'extra_milk_harvested':0,'extra_milk_sale_requests':0}

def _v231_controller(obs,action,state,cap):
    step=int(obs['step']);seat=int(obs['player']);farm=obs['farms'][seat]
    private=obs['private'];shed=private['shed'];inventories=private['inventories']
    positions=[farm['farmer'],*farm['hands']]
    pending=state['pending_buy']
    if pending is not None:
        gained=max(0,int(shed.get('COW',0))-pending['before'])
        confirmed=min(pending['quantity'],gained)
        state['confirmed']+=confirmed;state['reserved']+=confirmed
        state['failed_purchase_units']+=pending['quantity']-confirmed
        state['pending_buy']=None
    for pending in state['pending_places']:
        x,y=pending['site'];tile=farm['tiles'][y][x]
        if (isinstance(tile,dict) and tile.get('animal')=='COW'
                and tile.get('placed_day')==pending['day']):
            state['sites'][(x,y)]=pending['day'];state['placed']+=1
            actor=pending['actor'];state['carrying'][actor]=max(0,state['carrying'].get(actor,0)-1)
        else:state['failed_placements']+=1
    state['pending_places']=[]
    state['last']=step
    result=copy.deepcopy(action)
    workers=[result.get('farmer') or ['PASS'],*(result.get('hands') or [])]
    seen_harvest=set();cow_available=int(shed.get('COW',0));occupied=set()
    for actor,work in enumerate(workers[:len(positions)]):
        inventory=inventories[actor] if actor<len(inventories) else {}
        x,y=positions[actor];tile=farm['tiles'][y][x];site=(x,y)
        if (work==['HARVEST'] and site in state['sites'] and site not in seen_harvest
                and isinstance(tile,dict) and tile.get('animal')=='COW'
                and tile.get('placed_day')==state['sites'][site]):
            units=max(0,int(tile.get('yield_units',0)))
            state['milk_credit']+=units;state['extra_milk_harvested']+=units
            seen_harvest.add(site)
        if len(work)>=2 and work[:2]==['PICKUP','SHEEP']:
            quantity=max(0,int(work[2]) if len(work)>2 else 1)
            center=len(farm['tiles'])//2
            if (quantity and state['reserved']>=quantity and cow_available>=quantity
                    and x in (center-1,center) and y in (center-1,center)
                    and not any(inventory.get(a,0) for a in ('COW','SHEEP','GOOSE'))):
                work[1]='COW';state['reserved']-=quantity;cow_available-=quantity
                state['carrying'][actor]=state['carrying'].get(actor,0)+quantity
                state['picked']+=quantity
        if (len(work)>=2 and work[:2]==['PLACE','SHEEP']
                and state['carrying'].get(actor,0)>0 and inventory.get('COW',0)>0
                and isinstance(tile,dict) and tile.get('kind')=='PASTURE'
                and 'animal' not in tile and site not in occupied):
            work[1]='COW'
            state['pending_places'].append({'actor':actor,'site':site,'day':step//24})
        if (len(work)>=2 and work[0]=='PLACE' and work[1] in ('COW','SHEEP','GOOSE')
                and inventory.get(work[1],0)>0):occupied.add(site)
    result['farmer'],result['hands']=workers[0],workers[1:]
    market=result.get('market',[])
    animal_orders=[o for o in market if len(o)>=3 and o[0]=='BUY_ANIMAL']
    shops=obs['town']['unlocked_shops'];prices=obs['market']['prices']
    counts={'COW':0,'SHEEP':0}
    for line in farm['tiles']:
        for tile in line:
            if isinstance(tile,dict) and tile.get('animal') in counts:counts[tile['animal']]+=1
    cargo=sum(int(inv.get(a,0)) for inv in inventories for a in ('COW','SHEEP','GOOSE'))
    stock_animals=sum(int(shed.get(a,0)) for a in ('COW','SHEEP','GOOSE'))
    milk_shops=sum(shop in ('PIZZA_SHOP','ICE_CREAM_SHOP','SMOOTHIE_SHOP') for shop in shops)
    if (216<=step<=227 and len(shops)>=3 and state['confirmed']<cap and not state['reserved']
            and not any(state['carrying'].values()) and not state['pending_places']
            and not cargo and not stock_animals and len(animal_orders)==1
            and animal_orders[0][1]=='SHEEP' and milk_shops>=2 and 'YARN_STORE' not in shops
            and int(prices.get('MILK',0))>=int(prices.get('WOOL',0))
            and counts['COW']>=4 and counts['SHEEP']>=2):
        order=animal_orders[0];quantity=int(order[2])
        if 1<=quantity<=2 and quantity<=cap-state['confirmed']:
            order[1]='COW';state['requested']+=quantity
            state['pending_buy']={'before':int(shed.get('COW',0)),'quantity':quantity}
    if state['milk_credit']>0:
        stock=projected_shed(result,FarmView(obs))
        total_planned=sum(max(0,int(o[2])) for o in market if len(o)>=3 and o[:2]==['SELL','MILK'])
        extra=min(state['milk_credit'],max(0,int(stock.get('MILK',0))-total_planned))
        if extra:
            for order in market:
                if len(order)>=3 and order[:2]==['SELL','MILK'] and int(order[2])>0:
                    order[2]=int(order[2])+extra
                    state['milk_credit']-=extra;state['extra_milk_sale_requests']+=extra
                    break
    result['market']=market
    return result

def agent(observation,configuration=None):
    step=int(observation['step']);seat=int(observation['player'])
    state=_V231_STATES.get(seat)
    if state is None or step<=state['last']:
        state=_V231_STATES[seat]=_v231_new_state()
    action=_V231_PARENT(observation,configuration)
    action=_v231_controller(observation,action,state,_V231_CAP)
    _V231_REPORT.clear();_V231_REPORT.update(_V231_PARENT.telemetry)
    for name in ('confirmed','reserved','requested','failed_purchase_units','picked','placed',
                 'failed_placements','extra_milk_harvested','extra_milk_sale_requests','milk_credit'):
        _V231_REPORT['cattle_'+name]=state[name]
    _V231_REPORT['cattle_carried_pending']=sum(state['carrying'].values())
    return action

agent.telemetry=_V231_REPORT


_R36_SALE_PARENT=agent
_R36_NATIVE_LEAD=Chassis._sell_lead
_R36_NATIVE_SUPPRESS=Chassis._apply_suppression
_R36_SALE_REPORT={}

def _r36_native_lead(self,action,view,projected,route,step,next_sup):
    if step<288 or step>=696:
        return _R36_NATIVE_LEAD(self,action,view,projected,route,step,next_sup)

def _r36_suppress(action,state,step):
    _R36_NATIVE_SUPPRESS(action,state,step)
    due=state.get('r36_debts',{}).pop(step,{})
    for order in action.get('market',[]):
        if len(order)>=3 and order[0]=='SELL':
            removed=min(max(0,int(order[2])),due.get(order[1],0))
            order[2]-=removed
            due[order[1]]=due.get(order[1],0)-removed

Chassis._sell_lead=_r36_native_lead
Chassis._apply_suppression=staticmethod(_r36_suppress)

def _r36_reserve(obs,action):
    step=int(obs['step'])
    if not 192<=step<696:return action
    native=_IMPL.chassis.players[int(obs['player'])]
    tape=_IMPL.chassis.routes[native['route']]
    _v9_hz=_V9_ITEM_HZ.get(int(obs['player']))
    end=min(695,step+(max(_v9_hz.values()) if _v9_hz else _R37_HORIZONS.get(int(obs['player']),2)))
    if end<=step:return action
    commands=[action.get('farmer') or ['PASS'],*(action.get('hands') or [])]
    view=FarmView(obs)
    if any(len(c)>1 and c[0]=='PLACE' and c[1] in ANIMAL_STRUCTURE
           and view.inv(i).get(c[1],0)>0 for i,c in enumerate(commands[:len(view.positions)])):
        return action
    stock=projected_shed(action,view)
    market=action.get('market',[])
    blocked={o[1] for o in market if len(o)>1 and o[0] in ('SELL','BUY_PRODUCT')}
    blocked.update(c[1] for c in commands if len(c)>1 and c[0]=='PICKUP')
    blocked.update(c[1] for queue in native['pending'].values() for pos,c in queue
                   if len(c)>1 and c[0]=='PICKUP')
    debts=native['sell_state'].setdefault('r36_debts',{})
    for item in PRODUCTS:
        if item in blocked or view.prices.get(item,0)<2:continue
        available=max(0,int(stock.get(item,0)))
        if not available or len(market)>=10:continue
        reservations=[]
        item_end=min(end,step+_v9_hz[item]) if _v9_hz and item in _v9_hz else end
        for due_step in range(step+1,item_end+1):
            future=tape[due_step]
            work=[future.get('farmer') or ['PASS'],*(future.get('hands') or [])]
            if any(len(c)>1 and c[:2]==['PICKUP',item] for c in work):break
            if any(len(o)>1 and o[:2]==['BUY_PRODUCT',item] for o in future.get('market',[])):break
            planned=sum(max(0,int(o[2])) for o in future.get('market',[]) if len(o)>=3 and o[:2]==['SELL',item])
            amount=min(available,max(0,planned-debts.get(due_step,{}).get(item,0)))
            if amount:
                reservations.append((due_step,amount));available-=amount
            if not available:break
        qty=sum(q for _,q in reservations)
        if qty:
            market.append(['SELL',item,qty])
            for due,q in reservations:
                debt=debts.setdefault(due,{})
                debt[item]=debt.get(item,0)+q
            _R36_SALE_REPORT['sale_reserved_units']+=qty
            _R36_SALE_REPORT['sale_reservations']+=1
    return action

def agent(observation,configuration=None):
    if int(observation.get('step',0))==0:
        _R36_SALE_REPORT.update(sale_reserved_units=0,sale_reservations=0,sale_errors=0)
    action=_R36_SALE_PARENT(observation,configuration)
    try:
        if configuration is None or all(configuration.get(k,v)==v for k,v in
            [('boardSize',10),('turnsPerDay',24),('shedCapacity',100),('maxMarketOrdersPerTurn',10)]):
            action=_r36_reserve(observation,action)
            if int(observation['step'])>=288:action=_v224_sales_first(action)
    except Exception:
        _R36_SALE_REPORT['sale_errors']=_R36_SALE_REPORT.get('sale_errors',0)+1
    _R36_SALE_REPORT.update(_R36_SALE_PARENT.telemetry)
    return action

agent.telemetry=_R36_SALE_REPORT

agent = globals().pop("agent")


import math
_R37_MARKET_PARAMS = {'WHEAT': {'base': 25, 'I0': 10000, 'T': 400, 'below_func': 'sqrt', 'below_target': 0.8, 'above_func': 'log', 'above_target': 0.2}, 'CARROT': {'base': 35, 'I0': 10000, 'T': 450, 'below_func': 'hinge', 'below_target': 1.0, 'above_func': 'sqrt', 'above_target': 0.7}, 'TOMATO': {'base': 60, 'I0': 10000, 'T': 200, 'below_func': 'hinge', 'below_target': 0.4, 'above_func': 'sqrt', 'above_target': 0.6}, 'STRAWBERRY': {'base': 120, 'I0': 10000, 'T': 100, 'below_func': 'sqrt', 'below_target': 0.7, 'above_func': 'linear', 'above_target': 1.6}, 'MELON': {'base': 250, 'I0': 10000, 'T': 300, 'below_func': 'log', 'below_target': 0.2, 'above_func': 'sq', 'above_target': 3.6}, 'EGG': {'base': 50, 'I0': 10000, 'T': 332, 'below_func': 'hinge', 'below_target': 0.4, 'above_func': 'log', 'above_target': 0.2}, 'MILK': {'base': 160, 'I0': 10000, 'T': 122, 'below_func': 'sqrt', 'below_target': 0.6, 'above_func': 'linear', 'above_target': 1.6}, 'WOOL': {'base': 200, 'I0': 10000, 'T': 105, 'below_func': 'log', 'below_target': 0.2, 'above_func': 'sq', 'above_target': 3.2}, 'FERTILIZER': {'base': 100, 'I0': 10000, 'T': 200, 'below_func': 'linear', 'below_target': 0.4, 'above_func': 'linear', 'above_target': 0.4}}
_R37_PRICE_FLOOR = 1
_R37_HINGE_GAIN = 8.0
def _r37_shape(func, x, T=None):
    x = max(0.0, x)
    if func == "linear": return x
    if func == "sq":     return x * x
    if func == "sqrt":   return math.sqrt(x)
    if func == "log":    return math.log(1.0 + x)
    if func == "log10":  return math.log10(1.0 + x)
    if func == "hinge":
        if not T or T <= 0:
            return x
        u = x / T
        return u + _R37_HINGE_GAIN * max(0.0, u - 1.0) ** 2
    return x

def _r37_market_price(item, inventory, params=None):
    """Floor at _R37_PRICE_FLOOR."""
    p = (params or _R37_MARKET_PARAMS)[item]
    base = p["base"]
    I0 = p["I0"]
    T = p["T"]
    if inventory < I0:
        f = p["below_func"]
        amp = p["below_target"] * base / _r37_shape(f, T, T)
        price = base + amp * _r37_shape(f, I0 - inventory, T)
    else:
        f = p["above_func"]
        amp = p["above_target"] * base / _r37_shape(f, T, T)
        price = base - amp * _r37_shape(f, inventory - I0, T)
    return max(_R37_PRICE_FLOOR, int(round(price)))

def _r37_similarity(observation):
    """Empty tiles cannot make two unrelated production layouts look alike."""
    farms = observation['farms']
    own, rival = farms[observation['player']], farms[1-observation['player']]
    if own['unlocked_quadrants'] != rival['unlocked_quadrants']:
        return 0.0
    matches = total = 0
    for a, b in zip([t for row in own['tiles'] for t in row],
                    [t for row in rival['tiles'] for t in row]):
        sa = (a.get('crop'), a.get('animal')) if isinstance(a, dict) else (None, None)
        sb = (b.get('crop'), b.get('animal')) if isinstance(b, dict) else (None, None)
        if sa != (None, None) or sb != (None, None):
            total += 1
            matches += sa == sb
    return matches / total if total >= 8 else 0.0


def _r37_quote_priority(observation, order, stock):
    """Revenue exposed to a small rival batch, not nominal headline revenue."""
    item = order[1]
    quantity = min(max(0, int(order[2])), stock.get(item, 0))
    if not quantity or item not in _R37_MARKET_PARAMS:
        return 0.0
    inventory = observation['market']['inventory'][item]
    params = {k: dict(v) for k, v in _R37_MARKET_PARAMS.items()}
    for k, patch in observation['market'].get('params', {}).items():
        if k in params:
            params[k].update(patch)
    rival = observation['farms'][1-observation['player']]
    crop_item = item if item in ('WHEAT','CARROT','TOMATO','STRAWBERRY','MELON') else None
    animal = {'EGG':'GOOSE','MILK':'COW','WOOL':'SHEEP'}.get(item)
    standing = sum(max(0, int(t.get('yield_units', 0))) for row in rival['tiles'] for t in row
                   if isinstance(t, dict) and
                   ((crop_item is not None and t.get('crop') == crop_item) or
                    (animal is not None and t.get('animal') == animal)))
    batch = min(24, max(8, standing))
    now = sum(_r37_market_price(item, inventory+j, params) for j in range(quantity))
    later = sum(_r37_market_price(item, inventory+batch+j, params) for j in range(quantity))
    return now-later


def _r37_reorder_sales(observation, action):
    """Keep quantities and purchase barriers; rank distinct contiguous sales."""
    stock = projected_shed(action, FarmView(observation))
    orders = [list(o) for o in action['market']]
    start = 0
    while start < len(orders):
        if orders[start][0] != 'SELL':
            start += 1
            continue
        end = start
        while end < len(orders) and orders[end][0] == 'SELL':
            end += 1
        block = orders[start:end]
        if len({o[1] for o in block}) == len(block):
            orders[start:end] = sorted(block, key=lambda o: _r37_quote_priority(observation, o, stock), reverse=True)
        start = end
    if orders != action['market']:
        _R37_STATS['quote_reordered_turns'] += 1
        action = dict(action, market=orders)
    return action



_R44_PROBES={}
_R44_REPORT=dict(probe_matches=0,probe_four_turn_calls=0,probe_errors=0)

def _r44_before(obs):
    player=int(obs['player']);step=int(obs['step'])
    st=_R44_PROBES.get(player)
    if st is None or step<=st['step']:
        st=_R44_PROBES[player]={'step':-1,'money':None,'probe':0,'matched':False}
    if step==0:_R44_REPORT.update(probe_matches=0,probe_four_turn_calls=0,probe_errors=0)
    money=tuple(float(obs['farms'][i]['money']) for i in (player,1-player))
    if st['money'] is not None and st['probe']>=100 and _r37_similarity(obs)>=.90:
        own=money[0]-st['money'][0];rival=money[1]-st['money'][1]
        if own>0 and rival>0 and abs(own-rival)<=max(5.0,.05*st['probe']):
            if not st['matched']:_R44_REPORT['probe_matches']+=1
            st['matched']=True
    st.update(step=step,money=money,probe=0)
    return st

def _r44_after(obs,action,st):
    step=int(obs['step']);player=int(obs['player'])
    if not 336<=step<648 or st['matched']:return
    if not action['market'] or any(o and o[0]!='SELL' for o in action['market']):return
    debts=_IMPL.chassis.players[player]['sell_state'].get('r36_debts',{})
    own=debts.get(step+3,{})
    if own:st['probe']=sum(max(0,int(n))*int(obs['market']['prices'].get(item,0)) for item,n in own.items())

_R37_ADAPTIVE = True
_R37_QUOTE = True
_R37_PARENT = agent
_R37_PLAYERS = {}
_R37_HORIZONS = {}
_V9_ITEM_HZ = {}
_R37_REPORT = {}
_R37_STATS = dict(quote_reordered_turns=0, three_turn_calls=0, nocturne_errors=0)
del agent

def agent(observation, configuration=None):
    player, step = int(observation['player']), int(observation['step'])
    state = _R37_PLAYERS.get(player)
    if state is None or step <= state['step']:
        state = _R37_PLAYERS[player] = {'step': -1, 'streak': 0}
    if step == 0:
        _R37_STATS.update(quote_reordered_turns=0, three_turn_calls=0, nocturne_errors=0)
    state['step'] = step
    _R37_HORIZONS[player] = 2
    probe_state=_r44_before(observation)
    try:
        if _R37_ADAPTIVE and step < 648:
            state['streak'] = state['streak'] + 1 if _r37_similarity(observation) >= .90 else 0
            if 336 <= step < 648 and state['streak'] >= 6:
                _R37_HORIZONS[player] = 3
                _R37_STATS['three_turn_calls'] += 1
    except Exception:
        _R37_STATS['nocturne_errors'] += 1
    if _R37_HORIZONS[player]==3 and probe_state['matched']:
        _R37_HORIZONS[player]=4
        _R44_REPORT['probe_four_turn_calls']+=1
    if 288 <= step < 696:_R37_HORIZONS[player] = 4
    action = _R37_PARENT(observation, configuration)
    _r44_after(observation,action,probe_state)
    if _R37_QUOTE and step >= 288:
        try:
            action = _r37_reorder_sales(observation, action)
        except Exception:
            _R37_STATS['nocturne_errors'] += 1
    _R37_REPORT.update(getattr(_R37_PARENT, 'telemetry', {}))
    _R37_REPORT.update(_R37_STATS)
    _R37_REPORT.update(_R44_REPORT)
    return action

agent.telemetry = _R37_REPORT

_RELEASE_PARENT=agent
_RELEASE_REPORT={}
_RELEASE_ERRORS=0
del agent

def agent(observation,configuration=None):
    global _RELEASE_ERRORS
    try:
        result=_RELEASE_PARENT(observation,configuration)
    except Exception:
        _RELEASE_ERRORS+=1
        count=0
        try:
            count=min(64,len(observation['farms'][int(observation['player'])]['hands']))
        except Exception:
            pass
        result={'farmer':['PASS'],'hands':[['PASS'] for _ in range(count)],'market':[]}
    _RELEASE_REPORT.update(getattr(_RELEASE_PARENT,'telemetry',{}))
    _RELEASE_REPORT['release_errors']=_RELEASE_ERRORS
    return result

agent.telemetry=_RELEASE_REPORT
agent=globals().pop('agent')

_V233_PARENT=agent
del agent
_V233_STATES={}
_V233_REPORT=dict(sheep_commit_requests=0,sheep_committed=0,sheep_hire_requests=0,
    sheep_workers_confirmed=0,sheep_hire_shortfalls=0,sheep_budget_declines=0,
    sheep_capacity_declines=0,sheep_purchase_shortfalls=0,sheep_feed_buy_requests=0,
    sheep_wool_harvested=0,sheep_fert_collected=0,sheep_extra_wool_sales=0,
    sheep_extra_fert_sales=0,sheep_rescue_feed_requests=0)

def _v233_eligible(obs,native):
    farm=obs['farms'][obs['player']];prices=obs['market']['prices']
    if len(farm['tiles'])!=10 or set(farm['unlocked_quadrants'])!={'NW','NE','SW'}:return False
    if obs['town']['unlocked_shops'].count('YARN_STORE')<2 or prices['WOOL']<220 or prices['WHEAT']>45:return False
    if any(farm['tiles'][y][x]!='LOCKED' for y in (5,6) for x in range(5,8)):return False
    if obs['private']['shed'].get('SHEEP',0) or any(i.get('SHEEP',0) for i in obs['private']['inventories']):return False
    for day in range(12,30):
        for a in _v219_native_day(native,day):
            if any(o and (o[0]=='BUY_LAND' or o[:2]==['BUY_ANIMAL','SHEEP']) for o in a.get('market',[])):return False
            if any(c and c[0] in ('PICKUP','PLACE') and len(c)>1 and c[1]=='SHEEP' for c in [a.get('farmer')]+a.get('hands',[])):return False
    return True

def _v233_request(obs,action,state,native):
    step=int(obs['step']);day=step//24;hour=step%24
    if state.get('requested_day')==day:return action
    committed=state.get('committed')
    if not committed and (hour>(3 if day==11 else 1) or day not in (11,12) or not _v233_eligible(obs,native)):return action
    planned=_v219_native_day(native,day)
    deadline=2 if committed else (3 if day==11 else 1)
    if committed:
        last_native_hire=max((h for h,a in enumerate(planned) if any(o and o[0]=='HIRE' for o in a.get('market',[]))),default=0)
        if 2<last_native_hire<=6:deadline=6
    if hour>deadline:return action
    if any(o and o[0]=='HIRE' for a in planned[hour+1:] for o in a.get('market',[])):return action
    farm=obs['farms'][obs['player']];market=action.get('market',[])
    parent_hires=sum(bool(o) and o[0]=='HIRE' for o in market)
    expected=max(len(a.get('hands',[])) for a in planned)
    if len(farm['hands'])+parent_hires!=expected:return action
    initial=not state.get('committed')
    extra=([['BUY_LAND'],['BUY_ANIMAL','SHEEP',6]] if initial else [])+[['BUY_PRODUCT','WHEAT',6],['HIRE'],['HIRE']]
    if len(market)+len(extra)>MAX_ORDERS:return action
    stock=projected_shed(action,FarmView(obs))
    incoming=6+6*initial
    budget=7000*initial+6*(int(obs['market']['prices']['WHEAT'])+10)
    budget+=sum(_v219_fib(n) for n in range(farm['hires_today'],farm['hires_today']+parent_hires+2))
    for o in market:
        if not o:continue
        if o[0]=='BUY_LAND':return action
        if o[0]=='BUY_PRODUCT':
            incoming+=int(o[2]);budget+=int(o[2])*(int(obs['market']['prices'][o[1]])+10)
        elif o[0]=='BUY_ANIMAL':
            incoming+=int(o[2]);budget+=int(o[2])*{'SHEEP':500,'COW':400,'GOOSE':300}[o[1]]
        elif o[0]=='BUY_SEED':budget+=int(o[2])*{'WHEAT':10,'CARROT':20,'TOMATO':50,'STRAWBERRY':100,'MELON':80}[o[1]]
    if sum(stock.values())+incoming>100:
        _V233_REPORT['sheep_capacity_declines']+=1;return action
    if farm['money']<budget+(3000 if initial else 1000):
        _V233_REPORT['sheep_budget_declines']+=1;return action
    state['requested_day']=day
    state['pending']={'first':expected+1,'initial':initial}
    _V233_REPORT['sheep_hire_requests']+=2;_V233_REPORT['sheep_feed_buy_requests']+=6
    if initial:_V233_REPORT['sheep_commit_requests']+=1
    result=copy.deepcopy(action);result['market']=market+extra
    return result

def _v233_worker(obs,actor,targets):
    farm=obs['farms'][obs['player']];private=obs['private'];step=int(obs['step'])
    pos=tuple(farm['hands'][actor-1]);inv=private['inventories'][actor]
    access=((4,4),(5,4),(4,5),(5,5))
    home=min(access,key=lambda p:(abs(pos[0]-p[0])+abs(pos[1]-p[1]),p))
    distance=abs(pos[0]-home[0])+abs(pos[1]-home[1])
    cargo=[item for item in ('WOOL','FERTILIZER') if inv.get(item,0)]
    if cargo and step%24 >= (22 if step//24==29 else 23)-distance:
        return _v219_walk(pos,home) or ['PLACE',cargo[0],inv[cargo[0]]]
    missing=sum(not(isinstance(farm['tiles'][y][x],dict) and farm['tiles'][y][x].get('animal')=='SHEEP') for x,y in targets)
    if missing and not inv.get('SHEEP',0) and private['shed'].get('SHEEP',0):
        return _v219_walk(pos,home) or ['PICKUP','SHEEP',min(missing,private['shed']['SHEEP'])]
    hungry=sum(not(isinstance(farm['tiles'][y][x],dict) and farm['tiles'][y][x].get('fed_today')) for x,y in targets)
    if hungry and not inv.get('WHEAT',0) and private['shed'].get('WHEAT',0):
        return _v219_walk(pos,home) or ['PICKUP','WHEAT',min(hungry,private['shed']['WHEAT'])]
    tasks=[]
    for target in targets:
        x,y=target;tile=farm['tiles'][y][x];command=None
        if tile is None:command=['BUILD_PASTURE']
        elif isinstance(tile,dict) and tile.get('kind')=='WEED':command=['DIG']
        elif isinstance(tile,dict) and tile.get('kind')=='PASTURE' and not tile.get('animal'):
            if inv.get('SHEEP',0):command=['PLACE','SHEEP']
        elif isinstance(tile,dict) and tile.get('animal')=='SHEEP':
            if not tile['fed_today'] and inv.get('WHEAT',0):command=['FEED']
            elif not tile['cared_today']:command=['CARE']
            elif tile['yield_units']:command=['HARVEST']
            elif tile['fertilizer_available']:command=['COLLECT_FERTILIZER']
        if command:tasks.append((abs(pos[0]-x)+abs(pos[1]-y),targets.index(target),target,command))
    if tasks:
        _,_,target,command=min(tasks);return _v219_walk(pos,target) or command
    if cargo:return _v219_walk(pos,home) or ['PLACE',cargo[0],inv[cargo[0]]]
    return ['PASS']

def _v234_rescue(obs,action,state):
    if not state['workers'] or int(obs['step'])%24>14:return action
    orders=action.get('market',[])
    if len(orders)>=MAX_ORDERS:return action
    if any(o and (o[0] in ('HIRE','BUY_LAND','BUY_ANIMAL','BUY_PRODUCT','BUY_SEED') or (len(o)>1 and o[1]=='WHEAT')) for o in orders):return action
    farm=obs['farms'][obs['player']];private=obs['private'];hungry=carried=0
    commands=[action.get('farmer') or ['PASS']]+list(action.get('hands') or [])
    for actor,targets in state['workers'].items():
        command=commands[actor]
        if command==['FEED'] or command[:2]==['PICKUP','WHEAT']:return action
        carried+=private['inventories'][actor].get('WHEAT',0)
        hungry+=sum(isinstance(farm['tiles'][y][x],dict) and farm['tiles'][y][x].get('animal')=='SHEEP' and not farm['tiles'][y][x].get('fed_today') for x,y in targets)
    stock=projected_shed(action,FarmView(obs))
    shortage=hungry-carried-stock.get('WHEAT',0)
    if not 0<shortage<=6 or state.get('rescue_today',0)+shortage>6:return action
    quote=int(obs['market']['prices']['WHEAT'])
    if quote<1 or farm['money']<1000+shortage*(quote+10) or sum(stock.values())+shortage>100:return action
    result=copy.deepcopy(action);result['market'].append(['BUY_PRODUCT','WHEAT',shortage])
    state['rescue_today']=state.get('rescue_today',0)+shortage
    _V233_REPORT['sheep_rescue_feed_requests']+=shortage
    return result

def agent(observation,configuration=None):
    action=_V233_PARENT(observation,configuration)
    step=int(observation['step']);player=int(observation['player']);day=step//24
    state=_V233_STATES.get(player)
    if state is None or step<=state['last_step']:
        state={'last_step':step,'day':-1,'workers':{},'work':{},'credit':{'WOOL':0,'FERTILIZER':0}}
        _V233_STATES[player]=state
    state['last_step']=step
    if configuration is not None and any(configuration.get(k,v)!=v for k,v in
        (('boardSize',10),('turnsPerDay',24),('shedCapacity',100),('maxMarketOrdersPerTurn',10))):return action
    if day<11:return action
    farm=observation['farms'][player];private=observation['private']
    if state['day']!=day:state['day']=day;state['workers']={};state['work']={};state['rescue_today']=0
    for actor,previous in state['work'].items():
        if previous['step']!=step-1 or actor>=len(private['inventories']):continue
        item={'HARVEST':'WOOL','COLLECT_FERTILIZER':'FERTILIZER'}.get(previous['command'][0])
        if item:
            gained=max(0,private['inventories'][actor].get(item,0)-previous['inventory'].get(item,0))
            state['credit'][item]+=gained
            _V233_REPORT['sheep_wool_harvested' if item=='WOOL' else 'sheep_fert_collected']+=gained
    pending=state.pop('pending',None)
    if pending:
        funded='SE' in farm['unlocked_quadrants'] and (not pending['initial'] or private['shed'].get('SHEEP',0)>=6)
        if not funded:_V233_REPORT['sheep_purchase_shortfalls']+=1
        elif len(farm['hands'])<pending['first']+pending.get('count',2)-1:_V233_REPORT['sheep_hire_shortfalls']+=1
        else:
            if pending.get('count',2)==1:
                state['workers'][pending['first']]=list(pending['targets'])
                _SL_REPORT['confirmed']+=1
            else:
                for i in range(2):state['workers'][pending['first']+i]=[(x,5+i) for x in range(5,8)]
            _V233_REPORT['sheep_workers_confirmed']+=pending.get('count',2)
            if pending['initial']:state['committed']=True;_V233_REPORT['sheep_committed']+=1
    action=_v233_request(observation,action,state,_IMPL.chassis.players[player])
    if not state.get('committed'):return action
    result=copy.deepcopy(action)
    commands=[result.get('farmer') or ['PASS']]+list(result.get('hands') or [])
    commands += [['PASS'] for _ in range(len(farm['hands'])+1-len(commands))]
    state['work']={}
    for actor,targets in state['workers'].items():
        command=_v233_worker(observation,actor,targets);commands[actor]=command
        state['work'][actor]={'step':step,'command':command,'inventory':dict(private['inventories'][actor])}
    result['farmer'],result['hands']=commands[0],commands[1:]
    result=_v234_rescue(observation,result,state)
    stock=projected_shed(result,FarmView(observation))
    for item in ('WOOL','FERTILIZER'):
        scheduled=sum(int(o[2]) for o in result['market'] if o[:2]==['SELL',item])
        count=min(state['credit'][item],max(0,stock.get(item,0)-scheduled))
        if count and len(result['market'])<MAX_ORDERS:
            result['market'].append(['SELL',item,count]);state['credit'][item]-=count
            _V233_REPORT['sheep_extra_wool_sales' if item=='WOOL' else 'sheep_extra_fert_sales']+=count
    return result

_R46_SHEEP_AGENT=agent
_R46_SHADOW_PARENT=_shadow_terminal
_R46_REPORT={}
def _shadow_terminal(obs,config):
    if _V233_STATES.get(int(obs['player']),{}).get('committed'):return None
    return _R46_SHADOW_PARENT(obs,config)
del agent
def agent(observation,configuration=None):
    try:
        if int(observation.get('step',-1))==0:
            for k in _V233_REPORT:_V233_REPORT[k]=0
        result=_R46_SHEEP_AGENT(observation,configuration)
    except Exception:
        _R46_REPORT['sheep_overlay_errors']=_R46_REPORT.get('sheep_overlay_errors',0)+1
        result={'farmer':['PASS'],'hands':[],'market':[]}
    _R46_REPORT.update(getattr(_V233_PARENT,'telemetry',{}))
    _R46_REPORT.update(_V233_REPORT)
    return result
agent.telemetry=_R46_REPORT
agent=globals().pop('agent')

_R51_INPUT_PARENT=agent
_R51_INPUT_STATES={}
_R51_INPUT_REPORT={}
_R51_INPUT_MAX_WORKERS=2
_R51_INPUT_CROPS={'WHEAT':(2,4,6),'CARROT':(2,3,4)}

def _r51_input_forecast(obs,route,expected):
    step=int(obs['step']);day=step//24;farm=obs['farms'][obs['player']]
    pos=[list(farm['farmer'])]+[list(p) for p in farm['hands'][:expected]];targets={}
    for y,line in enumerate(farm['tiles']):
        for x,tile in enumerate(line):
            if not isinstance(tile,dict) or tile.get('crop') not in _R51_INPUT_CROPS:continue
            item=tile['crop'];first,last,cap=_R51_INPUT_CROPS[item]
            if 1<=day-tile['planted_day']<last:
                targets[(x,y)]={'crop':item,'birth':tile['planted_day'],'yield':tile['yield_units'],
                    'until':tile.get('fertilized_until_day',-1),'watered':tile.get('watered_today',False),'water':[],'harvest':None,'first':first,'last':last,'cap':cap}
    access=((4,4),(5,4),(4,5),(5,5));seen=set()
    for t in range(step,min(712,(day+4)*24)):
        tape=_IMPL.chassis.routes[2 if t>=648 else route];a=tape[t]
        for actor,c in enumerate([a.get('farmer') or ['PASS'],*(a.get('hands') or [])][:len(pos)]):
            if not c:continue
            xy=tuple(pos[actor]);target=targets.get(xy)
            if target is not None and target['harvest'] is None:
                if c[0]=='WATER' and (t//24,xy) not in seen:
                    seen.add((t//24,xy))
                    if not(t//24==day and target['watered']) and target['first']<=t//24-target['birth']<=target['last']:target['water'].append(t)
                if c[0]=='HARVEST':target['harvest']=t
            if c[0] in MOVES:
                dx,dy=MOVES[c[0]];pos[actor]=[max(0,min(9,pos[actor][0]+dx)),max(0,min(9,pos[actor][1]+dy))]
        for o in a.get('market',[]):
            if o and o[0]=='HIRE':
                counts={p:sum(tuple(q)==p for q in pos) for p in access}
                pos.append(list(min(access,key=lambda p:(counts[p],access.index(p)))))
        if (t+1)%24==0:pos=[[4,4]]
    return targets

def _r51_input_gain(target,arrival,day):
    if target['harvest'] is None or target['harvest']<=arrival:return 0
    extra=sum(arrival<t<=target['harvest'] and day<=t//24<=day+2 and t//24>target['until'] for t in target['water'])
    baseline=target['yield']+sum(2 if t//24<=target['until'] else 1 for t in target['water'])
    return max(0,min(extra,target['cap']-baseline))

def _r51_input_path(obs,targets,action,index):
    step=int(obs['step']);day=step//24
    ready,start=_r62_input_start(obs,action,index)
    prices={p:max(1,int(obs['market']['prices'][p])-2) for p in ('WHEAT','CARROT')}
    fertilizer=max(1,_r37_market_price('FERTILIZER',obs['market']['inventory']['FERTILIZER']-16)+2)
    beam=[(0,0,ready,start,(),frozenset(),0,0)]
    best=None
    for depth in range(8):
        expanded=[]
        for score,gross,now,pos,path,used,wheat,carrot in beam:
            for xy,target in targets.items():
                if xy in used:continue
                arrival=now+abs(pos[0]-xy[0])+abs(pos[1]-xy[1])
                if arrival>=day*24+23:continue
                gain=_r51_input_gain(target,arrival,day)
                if not gain:continue
                item=target['crop'];new_gross=gross+gain*prices[item]
                new_path=path+((xy[0],xy[1],item,target['birth']),)
                expanded.append((new_gross-1.5*fertilizer*len(new_path),new_gross,arrival+1,xy,new_path,
                                 used|{xy},wheat+(gain if item=='WHEAT' else 0),carrot+(gain if item=='CARROT' else 0)))
        if not expanded:break
        expanded.sort(key=lambda s:(-s[0],-s[1],s[2],s[4]))
        beam=expanded[:8]
        if depth>=2:
            candidate=beam[0]
            if best is None or (-candidate[0],-candidate[1],candidate[2],candidate[4])<(-best[0],-best[1],best[2],best[4]):best=candidate
    if best is None:return [],{'WHEAT':0,'CARROT':0}
    return list(best[4]),{'WHEAT':best[6],'CARROT':best[7]}

def _r51_input_control(obs,action,state):
    step=int(obs['step']);day=step//24;hour=step%24;player=int(obs['player']);farm=obs['farms'][player];private=obs['private']
    native=_IMPL.chassis.players[player]
    if state.get('day')!=day:state.update(day=day,workers={},pending=None,placed=[])
    for x,y in state['placed']:
        tile=farm['tiles'][y][x]
        if isinstance(tile,dict) and tile.get('fertilized_until_day',-1)>=day+2:_R51_INPUT_REPORT['input_confirmed_applications']+=1
        else:_R51_INPUT_REPORT['input_application_errors']+=1
    state['placed']=[]
    if state.get('pending'):
        pending=state.pop('pending')
        for actor,plan in pending.items():
            if len(farm['hands'])>=actor:state['workers'][actor]=plan;_R51_INPUT_REPORT['input_confirmed_hires']+=1
            else:_R51_INPUT_REPORT['input_hire_errors']+=1
    if state['workers']:
        changed=copy.deepcopy(action)
        for actor,plan in state['workers'].items():
            inv=private['inventories'][actor];pos=tuple(farm['hands'][actor-1]);cmd=['PASS']
            if not plan['loaded']:
                stock=projected_shed(changed,FarmView(obs));q=min(plan['quantity'],max(0,stock.get('FERTILIZER',0)))
                if q and _shed_adjacent(pos,10):
                    cmd=['PICKUP','FERTILIZER',q];plan['loaded']=True;_R51_INPUT_REPORT['input_loaded_units']+=q
                    if q<plan['quantity']:_R51_INPUT_REPORT['input_stock_shortfalls']+=plan['quantity']-q
            elif inv.get('FERTILIZER',0):
                while plan['path']:
                    x,y,crop,birth=plan['path'][0];tile=farm['tiles'][y][x]
                    if not isinstance(tile,dict) or tile.get('crop')!=crop or tile.get('planted_day')!=birth or tile.get('fertilized_until_day',-1)>=day+2:
                        plan['path'].pop(0);continue
                    cmd=_v219_walk(pos,(x,y)) or ['FERTILIZE']
                    if cmd==['FERTILIZE']:state['placed'].append((x,y));plan['path'].pop(0);_R51_INPUT_REPORT['input_application_requests']+=1
                    break
            changed['hands'][actor-1]=cmd
        return changed
    if hour not in (1,2,3) or not 12<=day<=28:return action
    planned=_v219_native_day(native,day);expected=max(len(a.get('hands',[])) for a in planned)
    if any(o and o[0]=='HIRE' for a in planned[hour:] for o in a.get('market',[])) or native['pending']:return action
    parents=[_V219_STATES.get(player,{}),_V233_STATES.get(player,{})]
    if day in (12,18) or any(p.get('committed') and p.get('requested_day')!=day for p in parents):return action
    if any(p.get('pending') for p in parents) or any(o and o[0]=='HIRE' for o in action.get('market',[])):return action
    owned=set(range(1,expected+1))
    for p in parents:
        actors=set(p.get('workers',{}))
        if owned&actors:return action
        owned|=actors
    if owned!=set(range(1,len(farm['hands'])+1)):return action
    targets=_r51_input_forecast(obs,native['route'],expected);plans=[];total_q=0;total_cost=0;all_units={'WHEAT':0,'CARROT':0}
    stock=projected_shed(action,FarmView(obs));purchases=sum(max(0,int(o[2])) for o in action.get('market',[]) if len(o)>2 and o[0] in ('BUY_PRODUCT','BUY_ANIMAL'))
    available=max(0,stock.get('FERTILIZER',0))
    for o in action.get('market',[]):
        if len(o)>=3 and o[:2]==['SELL','FERTILIZER']:available=max(0,available-max(0,int(o[2])))
        elif len(o)>=3 and o[:2]==['BUY_PRODUCT','FERTILIZER']:available+=max(0,int(o[2]))
    next_native=planned[hour+1];native_pickups=sum(max(0,int(c[2]) if len(c)>2 else 1) for c in [next_native.get('farmer') or ['PASS'],*(next_native.get('hands') or [])] if len(c)>1 and c[:2]==['PICKUP','FERTILIZER'])
    topup=max(0,native_pickups-available)
    plans,total_q,total_cost,all_units=_r68_joint_plans(obs,action,targets,stock,purchases,topup)
    if not plans:return action
    state['pending']={len(farm['hands'])+1+i:plan for i,plan in enumerate(plans)}
    _R51_INPUT_REPORT['input_hire_requests']+=len(plans);_R51_INPUT_REPORT['input_purchase_requests']+=total_q+topup
    _R51_INPUT_REPORT['input_forecast_wheat']+=all_units['WHEAT'];_R51_INPUT_REPORT['input_forecast_carrot']+=all_units['CARROT']
    changed=copy.deepcopy(action);changed['market'] += [['BUY_PRODUCT','FERTILIZER',total_q+topup]]+[['HIRE'] for _ in plans];return changed

def agent(observation,configuration=None):
    try:
        step=int(observation['step']);player=int(observation['player']);state=_R51_INPUT_STATES.get(player)
        if state is None or step<=state['step']:
            state=_R51_INPUT_STATES[player]={'step':-1}
            _R51_INPUT_REPORT.update(input_hire_requests=0,input_confirmed_hires=0,input_hire_errors=0,input_purchase_requests=0,
                input_loaded_units=0,input_stock_shortfalls=0,input_application_requests=0,input_confirmed_applications=0,
                input_application_errors=0,input_errors=0,input_forecast_wheat=0,input_forecast_carrot=0)
        state['step']=step;action=_R51_INPUT_PARENT(observation,configuration)
        if configuration is None or all(configuration.get(k,v)==v for k,v in [('boardSize',10),('turnsPerDay',24),('shedCapacity',100),('maxMarketOrdersPerTurn',10)]):
            action=_r51_input_control(observation,action,state)
        _R51_INPUT_REPORT.update(getattr(_R51_INPUT_PARENT,'telemetry',{}));return action
    except Exception:
        _R51_INPUT_REPORT['input_errors']=_R51_INPUT_REPORT.get('input_errors',0)+1
        return {'farmer':['PASS'],'hands':[],'market':[]}
agent.telemetry=_R51_INPUT_REPORT
agent=globals().pop('agent')

_R51_WAREHOUSE_PARENT=agent
_R51_WAREHOUSE_REPORT={}

def _r51_close_warehouse(obs,action):
    step=int(obs['step']);day=step//24
    if step%24!=23 or not 12<=day<=28:return action
    if any(o and o[0] not in ('SELL',) for o in action.get('market',[])):return action
    farm,private=_PLANNER_NS['_clone_state'](obs['farms'][obs['player']],obs['private'])
    commands=[action.get('farmer') or ['PASS'],*(action.get('hands') or [])]
    demand={}
    for c in commands:
        if len(c)>1 and c[0]=='PLANT':demand[c[1]]=demand.get(c[1],0)+1
    blocked={k for k,q in demand.items() if q>private['seeds'].get(k,0)}
    for actor,c in enumerate(commands[:len(private['inventories'])]):
        if len(c)>1 and c[0]=='PLANT' and c[1] in blocked:c=['PASS']
        _PLANNER_NS['_apply_unit_action'](farm,private,actor,c,10,day,24,100)
    post=dict(private['shed'])
    for o in action.get('market',[]):
        if len(o)>=3 and o[0]=='SELL':post[o[1]]=max(0,post.get(o[1],0)-max(0,int(o[2])))
    needed=sum(post.values())+sum(max(0,q) for inv in private['inventories'] for q in inv.values())-100
    if needed<=0:return action
    result=copy.deepcopy(action);orders=result['market']
    for item in sorted((p for p in PRODUCTS if p not in ('WHEAT','FERTILIZER')),key=lambda p:-obs['market']['prices'].get(p,0)):
        qty=min(needed,post.get(item,0))
        if not qty:continue
        existing=next((o for o in orders if len(o)>=3 and o[:2]==['SELL',item]),None)
        if existing is not None:existing[2]=max(0,int(existing[2]))+qty
        elif len(orders)<10:orders.append(['SELL',item,qty])
        else:continue
        needed-=qty;post[item]-=qty;_R51_WAREHOUSE_REPORT['warehouse_extra_sales']+=qty
        if needed<=0:break
    if needed>0:
        native=_IMPL.chassis.players[int(obs['player'])];reserve=0
        for t in range(step+1,719):
            future=_IMPL.chassis.routes[2 if t>=648 else native['route']][t]
            for c in [future.get('farmer') or ['PASS'],*(future.get('hands') or [])]:
                if len(c)>1 and c[:2]==['PICKUP','WHEAT']:reserve+=max(0,int(c[2]) if len(c)>2 else 1)
            if any(len(o)>1 and o[:2]==['BUY_PRODUCT','WHEAT'] for o in future.get('market',[])):break
        incoming=sum(max(0,inv.get('WHEAT',0)) for inv in private['inventories'])
        others=sum(q for p,q in post.items() if p!='WHEAT')+sum(max(0,q) for inv in private['inventories'] for p,q in inv.items() if p!='WHEAT')
        qty=min(needed,post.get('WHEAT',0),max(0,post.get('WHEAT',0)+incoming-reserve)) if 100-others>=reserve else 0
        existing=next((o for o in orders if len(o)>=3 and o[:2]==['SELL','WHEAT']),None)
        if qty and (existing is not None or len(orders)<10):
            if existing is not None:existing[2]=max(0,int(existing[2]))+qty
            else:orders.append(['SELL','WHEAT',qty])
            needed-=qty;_R51_WAREHOUSE_REPORT['warehouse_extra_sales']+=qty
    _R51_WAREHOUSE_REPORT['warehouse_projected_unresolved']+=max(0,needed)
    if result!=action:_R51_WAREHOUSE_REPORT['warehouse_changed_turns']+=1
    return result

def agent(observation,configuration=None):
    result=_R51_WAREHOUSE_PARENT(observation,configuration)
    try:
        if int(observation['step'])==0:_R51_WAREHOUSE_REPORT.update(warehouse_changed_turns=0,warehouse_extra_sales=0,warehouse_projected_unresolved=0,warehouse_errors=0)
        if configuration is None or all(configuration.get(k,v)==v for k,v in [('boardSize',10),('turnsPerDay',24),('shedCapacity',100),('maxMarketOrdersPerTurn',10)]):result=_r51_close_warehouse(observation,result)
    except Exception:_R51_WAREHOUSE_REPORT['warehouse_errors']=_R51_WAREHOUSE_REPORT.get('warehouse_errors',0)+1
    _R51_WAREHOUSE_REPORT.update(getattr(_R51_WAREHOUSE_PARENT,'telemetry',{}));return result
agent.telemetry=_R51_WAREHOUSE_REPORT
agent=globals().pop('agent')

from itertools import permutations as _r53_permutations
_R53_LABOR_REPORT=dict(labor_requests=0,labor_hires_avoided=0,labor_spawn_errors=0,labor_confirmed=0,labor_day26=0,labor_day27=0,labor_day28=0)

def _r53_labor_assignment(obs,action,fertilizer):
    step=int(obs['step']);day=step//24;farm=obs['farms'][obs['player']]
    if day not in (26,27,28) or step%24>2:return None
    if day==27 and not fertilizer:return None
    count=3 if fertilizer else 2
    positions=[list(farm['farmer'])]+[list(p) for p in farm['hands']]
    for i,c in enumerate([action.get('farmer') or ['PASS'],*(action.get('hands') or [])][:len(positions)]):
        if c and c[0] in MOVES:
            dx,dy=MOVES[c[0]];positions[i]=[max(0,min(9,positions[i][0]+dx)),max(0,min(9,positions[i][1]+dy))]
    access=((4,4),(5,4),(4,5),(5,5));spawns=[]
    native_hires=sum(bool(o) and o[0]=='HIRE' for o in action.get('market',[]))
    for i in range(native_hires+count):
        chosen=min(access,key=lambda p:(sum(tuple(q)==p for q in positions),access.index(p)));positions.append(list(chosen))
        if i>=native_hires:spawns.append(chosen)
    groups=(((5,5),(6,5),(7,5),(8,5)),((9,5),(9,6),(8,6)),((5,6),(6,6),(7,6))) if fertilizer else (tuple((x,5) for x in range(5,10)),tuple((x,6) for x in range(5,10)))
    choices=[];remaining=23-step%24
    for assignment in _r53_permutations(groups):
        costs=[]
        for start,path in zip(spawns,assignment):
            distance=abs(start[0]-path[0][0])+abs(start[1]-path[0][1])
            distance+=sum(abs(a[0]-b[0])+abs(a[1]-b[1]) for a,b in zip(path,path[1:]))
            distance+=min(abs(path[-1][0]-x)+abs(path[-1][1]-y) for x,y in access)
            costs.append(distance+(3 if fertilizer else 2)*len(path)+1+int(fertilizer))
        if max(costs)<=remaining:choices.append((max(costs),sum(costs),assignment))
    if not choices:return None
    _,_,assignment=min(choices)
    return dict(paths=assignment,spawns=spawns,remaining=remaining,workers=count,fertilizer=fertilizer)

_R53_LABOR_PARENT=agent
def agent(observation,configuration=None):
    if isinstance(observation,dict) and observation.get('step')==0:
        for k in _R53_LABOR_REPORT:_R53_LABOR_REPORT[k]=0
    result=_R53_LABOR_PARENT(observation,configuration)
    _R53_LABOR_COMBINED.update(getattr(_R53_LABOR_PARENT,'telemetry',{}));_R53_LABOR_COMBINED.update(_R53_LABOR_REPORT)
    return result
_R53_LABOR_COMBINED={}
agent.telemetry=_R53_LABOR_COMBINED
agent=globals().pop('agent')

def _r62_input_start(obs,action,index):
    farm=obs['farms'][obs['player']]
    positions=[list(farm['farmer'])]+[list(p) for p in farm['hands']]
    for actor,c in enumerate([action.get('farmer') or ['PASS'],*(action.get('hands') or [])][:len(positions)]):
        if c and c[0] in MOVES:
            dx,dy=MOVES[c[0]]
            positions[actor]=[max(0,min(9,positions[actor][0]+dx)),max(0,min(9,positions[actor][1]+dy))]
    access=((4,4),(5,4),(4,5),(5,5))
    native_hires=sum(bool(o) and o[0]=='HIRE' for o in action.get('market',[]))
    for _ in range(native_hires+index+1):
        chosen=min(access,key=lambda p:(sum(tuple(q)==p for q in positions),access.index(p)))
        positions.append(list(chosen))
    return int(obs['step'])+2,chosen

agent=globals().pop('agent')

def _r68_joint_plans(obs,action,targets,stock,purchases,topup):
    farm=obs['farms'][obs['player']];choices=[]
    for mode,first_crop in enumerate((None,'WHEAT','CARROT')):
        remaining=dict(targets);plans=[];total_q=0;total_cost=0;total_value=0
        all_units={'WHEAT':0,'CARROT':0}
        for i in range(_R51_INPUT_MAX_WORKERS):
            subset={xy:t for xy,t in remaining.items() if t['crop']==first_crop} if i==0 and first_crop else remaining
            path,units=_r51_input_path(obs,subset,action,i);q=len(path)
            if q<3 or len(action.get('market',[]))+2+i>10 or sum(stock.values())+purchases+total_q+q+topup>95:break
            quote=_r37_market_price('FERTILIZER',obs['market']['inventory']['FERTILIZER']-total_q-q-topup)
            cost=(q+(topup if i==0 else 0))*(quote+2)+_v219_fib(int(farm['hires_today'])+i)
            value=sum(n*max(1,_r37_market_price(item,obs['market']['inventory'][item]+all_units[item]+n)-2) for item,n in units.items())
            if value<1.5*cost+50 or farm['money']<total_cost+cost+3000:break
            plans.append({'path':path,'quantity':q,'loaded':False});total_q+=q;total_cost+=cost;total_value+=value
            for item,n in units.items():all_units[item]+=n
            for x,y,_,_ in path:remaining.pop((x,y),None)
        score=(total_value-total_cost,total_value,-total_cost,-len(plans),-mode)
        choices.append((score,plans,total_q,total_cost,all_units))
    _,plans,total_q,total_cost,all_units=max(choices,key=lambda v:v[0])
    return plans,total_q,total_cost,all_units

agent=globals().pop('agent')

_R70_STATES={}
_R70_REPORT={}

def _r70_parent_fert_qty(obs,action,planned,offset):
    stock=dict(projected_shed(action,FarmView(obs)))
    for order in action.get('market',[]):
        if len(order)<3:continue
        op,item,quantity=order[:3];quantity=max(0,int(quantity))
        if op=='SELL':stock[item]=max(0,stock.get(item,0)-quantity)
        elif op in ('BUY_PRODUCT','BUY_ANIMAL'):
            stock[item]=stock.get(item,0)+min(quantity,max(0,100-sum(stock.values())))
    next_action=planned[offset+1] if offset+1<len(planned) else {}
    commands=[next_action.get('farmer') or ['PASS'],*(next_action.get('hands') or [])]
    native_need=sum(max(0,int(c[2]) if len(c)>2 else 1) for c in commands if len(c)>1 and c[:2]==['PICKUP','FERTILIZER'])
    quantity=max(10,10+native_need-max(0,stock.get('FERTILIZER',0)))
    if quantity>max(0,100-sum(stock.values())):
        _R70_REPORT['parent_input_capacity_declines']+=1
        return 10
    if quantity>10:
        _R70_REPORT['parent_input_guard_turns']+=1
        _R70_REPORT['parent_input_guard_extra_units']+=quantity-10
    return quantity

def _r70_before(obs):
    player=int(obs['player']);step=int(obs['step']);state=_R70_STATES.get(player)
    if state is None or step<=state['step']:
        state=_R70_STATES[player]={'step':-1,'pending':[],'roles':set()}
        _R70_REPORT.update(parent_input_guard_turns=0,parent_input_guard_extra_units=0,
            parent_input_requests=0,parent_input_confirmed=0,parent_input_shortfalls=0,
            parent_input_errors=0,parent_input_capacity_declines=0)
    state['step']=step
    for request in state['pending']:
        actor,quantity,old=request
        actual=max(0,int(obs['private']['inventories'][actor].get('FERTILIZER',0))-old)
        _R70_REPORT['parent_input_confirmed']+=min(quantity,actual)
        _R70_REPORT['parent_input_shortfalls']+=max(0,quantity-actual)
    state['pending']=[]
    return state

def _r70_after(obs,action,state):
    player=int(obs['player']);day=int(obs['step'])//24
    for actor,role in _V219_STATES.get(player,{}).get('workers',{}).items():
        if not role.get('needs_fertilizer'):continue
        key=(day,actor);inv=obs['private']['inventories'][actor].get('FERTILIZER',0)
        if key not in state['roles']:
            state['roles'].add(key)
            desired=role.get('fertilizer_quantity',10 if role['kind']=='fertilizer' else 5)
            if role.get('loaded') and not role.get('pickup_requested') and inv<desired:
                _R70_REPORT['parent_input_shortfalls']+=desired-inv
        command=action.get('hands',[])[actor-1] if actor<=len(action.get('hands',[])) else ['PASS']
        if len(command)>1 and command[:2]==['PICKUP','FERTILIZER']:
            quantity=max(0,int(command[2]) if len(command)>2 else 1)
            _R70_REPORT['parent_input_requests']+=quantity
            state['pending'].append((actor,quantity,int(inv)))

_R70_PARENT=agent

def agent(observation,configuration=None):
    state=None
    try:state=_r70_before(observation)
    except Exception:_R70_REPORT['parent_input_errors']=_R70_REPORT.get('parent_input_errors',0)+1
    result=_R70_PARENT(observation,configuration)
    try:
        if state is not None:_r70_after(observation,result,state)
    except Exception:_R70_REPORT['parent_input_errors']=_R70_REPORT.get('parent_input_errors',0)+1
    _R70_REPORT.update(getattr(_R70_PARENT,'telemetry',{}))
    return result

agent.telemetry=_R70_REPORT
agent=globals().pop('agent')

def _r79_tomato_fertilizer_worthwhile(obs,action):
    if obs['market']['prices']['FERTILIZER']<=30:return True
    farm=obs['farms'][obs['player']];day=int(obs['step'])//24;bonus=0
    for y in (5,6):
        for x in range(5,10):
            tile=farm['tiles'][y][x]
            if not isinstance(tile,dict) or tile.get('crop')!='TOMATO':continue
            birth=tile['planted_day'];until=tile.get('fertilized_until_day',-1)
            bonus+=sum(until<d and 8<=d+1-birth<=11 for d in range(day,day+3))
    if not bonus:return False
    inventory=obs['market']['inventory']
    price=max(1,_r37_market_price('TOMATO',inventory['TOMATO']+bonus+10)-2)
    fertilizer=max(1,_r37_market_price('FERTILIZER',inventory['FERTILIZER']-10)+2)
    native_hires=sum(bool(o) and o[0]=='HIRE' for o in action.get('market',[]))
    extra_labor=_v219_fib(int(farm['hires_today'])+native_hires+3)
    return bonus*price>=2*(10*fertilizer+extra_labor)+100

agent=globals().pop('agent')

_R85_FEED = True
_R85_FERT = True
_R85_PARENT = agent
_R85_STATES = {}
_R85_REPORT = {}

def _r85_feed(obs, action):
    step=int(obs['step']);day=step//24
    if not 10<=day<=28 or step%24>21:return action
    player=int(obs['player']);native=_IMPL.chassis.players[player]
    tape=_v219_native_day(native,day)
    expected=max(len(a.get('hands',[])) for a in tape)
    farm=obs['farms'][player];positions=[farm['farmer'],*farm['hands']]
    commands=[action.get('farmer') or ['PASS'],*(action.get('hands') or [])]
    prices=obs['market']['prices'];changed=False
    for actor,command in enumerate(commands[:expected+1]):
        if command!=['FEED'] or actor>=len(positions):continue
        tile=_tile_at(farm['tiles'],positions[actor])
        if not isinstance(tile,dict) or tile.get('animal') not in ('GOOSE','COW','SHEEP'):continue
        if tile.get('fed_today') or int(tile.get('consecutive_unfed',0))!=0:continue
        if int(obs['private']['inventories'][actor].get('WHEAT',0))<=0:continue
        item={'GOOSE':'EGG','COW':'MILK','SHEEP':'WOOL'}[tile['animal']]
        bonus=_r88_feed_bonus_cost(tile,day)
        if bonus*(float(prices[item])+5)*1.25>=float(prices['WHEAT']):continue
        if not _r86_next_feed(obs,positions[actor]):continue
        commands[actor]=['PASS'];changed=True
        _R85_REPORT['feed_skips']+=1
    if not changed:return action
    result=copy.deepcopy(action);result['farmer'],result['hands']=commands[0],commands[1:]
    return result

def _r85_reserve(obs, state):
    step=int(obs['step']);player=int(obs['player']);native=_IMPL.chassis.players[player]
    route=native['route'];key=(route,step)
    cache=state.setdefault('native_reserves',{})
    if route not in cache:
        reserve=[0]*720
        for t in range(718,-1,-1):
            a=_IMPL.chassis.routes[2 if t>=648 else route][t]
            pickup=sum(max(0,int(c[2]) if len(c)>2 else 1) for c in [a.get('farmer') or ['PASS'],*(a.get('hands') or [])] if len(c)>1 and c[:2]==['PICKUP','FERTILIZER'])
            purchase=sum(max(0,int(o[2])) for o in a.get('market',[]) if len(o)>2 and o[:2]==['BUY_PRODUCT','FERTILIZER'])
            reserve[t]=pickup+max(0,reserve[t+1]-purchase)
        cache[route]=reserve
    dedicated=0
    for parent in (_V219_STATES.get(player,{}),_V233_STATES.get(player,{})):
        for actor,role in parent.get('workers',{}).items():
            if not isinstance(role,dict) or not role.get('needs_fertilizer') or role.get('loaded'):continue
            desired=role.get('fertilizer_quantity',10 if role.get('kind')=='fertilizer' else 5)
            carried=obs['private']['inventories'][actor].get('FERTILIZER',0)
            dedicated+=max(0,desired-carried)
        pending=parent.get('pending') or {}
        if pending.get('fertilizer'):dedicated+=10
    inputs=_R51_INPUT_STATES.get(player,{})
    for actor,plan in {**inputs.get('workers',{}),**(inputs.get('pending') or {})}.items():
        if not plan.get('loaded'):dedicated+=max(0,int(plan['quantity']))
    return max(14,cache[route][min(719,step+1)]+dedicated)

def _r85_fertilizer(obs, action, state):
    step=int(obs['step']);day=step//24
    if not 6<=day<=28:return action
    market=action.get('market',[])
    if len(market)>=MAX_ORDERS or any(o and o[0]!='SELL' for o in market):return action
    stock=projected_shed(action,FarmView(obs))
    held=max(0,int(stock.get('FERTILIZER',0)))
    sold=sum(max(0,int(o[2])) for o in market if len(o)>2 and o[:2]==['SELL','FERTILIZER'])
    extra=held-sold-_r85_reserve(obs,state)
    if extra<=0:return action
    result=copy.deepcopy(action);result['market'].append(['SELL','FERTILIZER',extra])
    _R85_REPORT['fert_sale_turns']+=1;_R85_REPORT['fert_sale_units']+=extra
    return result

def agent(observation, configuration=None):
    result=_R85_PARENT(observation,configuration)
    try:
        step=int(observation['step']);player=int(observation['player'])
        state=_R85_STATES.get(player)
        if state is None or step<=state['step']:
            state=_R85_STATES[player]={'step':-1}
            _R85_REPORT.update(feed_skips=0,fert_sale_turns=0,fert_sale_units=0,economic_overlay_errors=0)
        state['step']=step
        if configuration is not None and any(configuration.get(k,v)!=v for k,v in [('boardSize',10),('turnsPerDay',24),('shedCapacity',100),('maxMarketOrdersPerTurn',10)]):return result
        if _R85_FEED:result=_r85_feed(observation,result)
        if _R85_FERT:result=_r85_fertilizer(observation,result,state)
        if step%24==23:result=_r51_close_warehouse(observation,result)
    except Exception:
        _R85_REPORT['economic_overlay_errors']=_R85_REPORT.get('economic_overlay_errors',0)+1
    _R85_REPORT.update(getattr(_R85_PARENT,'telemetry',{}))
    return result

agent.telemetry=_R85_REPORT
agent=globals().pop('agent')

_R86_FEED_CACHE = {}

def _r86_next_feed(obs, target):
    step=int(obs['step']);day=step//24
    if day==28:return True  # No second dawn follows before game termination.
    player=int(obs['player']);native=_IMPL.chassis.players[player]
    tomorrow=day+1;route=2 if tomorrow>=27 else native['route'];key=(route,tomorrow)
    if key not in _R86_FEED_CACHE:
        positions=[(4,4)];wheat=[0];access=((4,4),(5,4),(4,5),(5,5));feeds=set()
        for hour in range(24):
            a=_IMPL.chassis.routes[route][tomorrow*24+hour]
            commands=[a.get('farmer') or ['PASS'],*(a.get('hands') or [])]
            for actor,command in enumerate(commands[:len(positions)]):
                if not command:continue
                pos=positions[actor];op=command[0]
                if op in MOVES:
                    dx,dy=MOVES[op];positions[actor]=(max(0,min(9,pos[0]+dx)),max(0,min(9,pos[1]+dy)))
                elif command[:2]==['PICKUP','WHEAT'] and pos in access:
                    wheat[actor]+=max(0,int(command[2]) if len(command)>2 else 1)
                elif op=='FEED' and wheat[actor]>0:
                    wheat[actor]-=1
                    if hour<=21:feeds.add(pos)
                elif op=='DROP' and pos in access:wheat[actor]=0
                elif command[:2]==['PLACE','WHEAT'] and pos in access:
                    wheat[actor]=max(0,wheat[actor]-max(0,int(command[2]) if len(command)>2 else 1))
            for order in a.get('market',[]):
                if order and order[0]=='HIRE':
                    chosen=min(access,key=lambda p:(positions.count(p),access.index(p)))
                    positions.append(chosen);wheat.append(0)
        _R86_FEED_CACHE[key]=frozenset(feeds)
    return tuple(target) in _R86_FEED_CACHE[key]

agent=globals().pop('agent')

_R88_PHASE = True
_R88_HORIZON = True
_R88_ANIMAL_DAYS = {'GOOSE': (4, 1), 'COW': (8, 2), 'SHEEP': (6, 3)}


def _r88_feed_bonus_cost(tile, day):
    first, interval = _R88_ANIMAL_DAYS[tile['animal']]
    first += int(tile['placed_day'])
    tomorrow = day + 1
    produces = tomorrow >= first and (tomorrow - first) % interval == 0
    pending = max(0, int(tile.get('pending_care_bonus', 0)))
    if _R88_PHASE and not produces:
        pending = 0  # It remains banked on non-production dawns.
    care = 1  # Conservative: charge one possible CARE even if not yet observed.
    if _R88_HORIZON:
        next_use = first
        if next_use <= tomorrow:
            next_use += ((tomorrow - next_use) // interval + 1) * interval
        if next_use > 29:
            care = 0
    return pending + care


agent = globals().pop('agent')

_R95_PARENT = agent
_R95_REPORT = {}
_R95_RESERVES = {}

def _r95_reserve(obs):
    step=int(obs['step']);player=int(obs['player'])
    native=_IMPL.chassis.players[player];route=native['route']
    key=(route,step)
    if key not in _R95_RESERVES:
        demand=6  # Physical buffer beyond every scheduled pickup and sale.
        for t in range(step+1,min(719,step+49)):
            a=_IMPL.chassis.routes[2 if t>=648 else route][t]
            for c in [a.get('farmer') or ['PASS'],*(a.get('hands') or [])]:
                if c[:2]==['PICKUP','WHEAT']:
                    demand+=max(0,int(c[2]) if len(c)>2 else 1)
            for o in a.get('market',[]):
                if len(o)>2 and o[:2]==['SELL','WHEAT']:
                    demand+=max(0,int(o[2]))
        _R95_RESERVES[key]=demand
    demand=_R95_RESERVES[key]
    if obs['town']['unlocked_shops'].count('YARN_STORE')>=2:
        demand+=6*len({t//24 for t in range(step+1,step+49) if t//24>=12})
    return demand

def _r95_replenish(obs,action):
    step=int(obs['step'])
    if not 10<=step//24<=11:return action
    orders=action.get('market') or []
    if not any(len(o)>2 and o[:2]==['BUY_PRODUCT','WHEAT'] and int(o[2])>0 for o in orders):return action
    if any(o[:2]==['SELL','WHEAT'] for o in orders):return action
    farm,private=_PLANNER_NS['_clone_state'](obs['farms'][obs['player']],obs['private'])
    commands=[action.get('farmer') or ['PASS'],*(action.get('hands') or [])]
    for actor,c in enumerate(commands[:len(private['inventories'])]):
        _PLANNER_NS['_apply_unit_action'](farm,private,actor,c,10,step//24,24,100)
    held=max(0,int(private['shed'].get('WHEAT',0)))
    reserve=_r95_reserve(obs);result=None;removed=0
    for i,o in enumerate(orders):
        if len(o)<3 or o[:2]!=['BUY_PRODUCT','WHEAT']:continue
        quantity=max(0,int(o[2]));retained=min(quantity,max(0,reserve-held))
        held+=retained
        if retained<quantity:
            if result is None:result=copy.deepcopy(action)
            result['market'][i][2]=retained  # Zero keeps every later order slot.
            removed+=quantity-retained
    if result is None:return action
    _R95_REPORT['replenishment_trim_turns']+=1
    _R95_REPORT['replenishment_trim_units']+=removed
    return result

def agent(observation,configuration=None):
    result=_R95_PARENT(observation,configuration)
    try:
        if int(observation['step'])==0:
            _R95_REPORT.update(replenishment_trim_turns=0,replenishment_trim_units=0,replenishment_errors=0)
        if configuration is not None and any(configuration.get(k,v)!=v for k,v in [('boardSize',10),('turnsPerDay',24),('shedCapacity',100),('maxMarketOrdersPerTurn',10)]):return result
        result=_r95_replenish(observation,result)
    except Exception:
        _R95_REPORT['replenishment_errors']=_R95_REPORT.get('replenishment_errors',0)+1
    _R95_REPORT.update(getattr(_R95_PARENT,'telemetry',{}))
    return result

agent.telemetry=_R95_REPORT
agent=globals().pop('agent')

_R97_PARENT=agent
_R97_REPORT={}
_R97_LAST={}

def _r97_market_stock(shed,orders):
    stock=dict(shed);buys={};sales={}
    for index,order in enumerate(orders):
        if len(order)<3:continue
        op,item,n=order[:3];n=max(0,int(n))
        if op=='SELL':
            q=min(n,max(0,stock.get(item,0)));stock[item]=stock.get(item,0)-q;sales[index]=q
        elif op in ('BUY_PRODUCT','BUY_ANIMAL'):
            q=min(n,max(0,100-sum(stock.values())));stock[item]=stock.get(item,0)+q;buys[index]=q
    return stock,buys,sales

def _r97_delivery(stock,private,night):
    stock=dict(stock);lost={}
    if night:
        for inv in private['inventories']:
            for item,q in inv.items():
                q=max(0,int(q));take=min(q,max(0,100-sum(stock.values())))
                stock[item]=stock.get(item,0)+take
                if q>take:lost[item]=lost.get(item,0)+q-take
    return stock,lost

def _r97_budget(obs,orders):
    farm=obs['farms'][obs['player']];cost=0;hires=int(farm['hires_today'])
    prices={p:_r37_market_price(p,obs['market']['inventory'][p]-2000) for p in ('WHEAT','FERTILIZER')}
    for order in orders:
        if not order:continue
        op=order[0]
        if op=='HIRE':cost+=_v219_fib(hires);hires+=1
        elif op=='BUY_LAND':cost+=4000
        elif len(order)>2:
            item=order[1];q=max(0,int(order[2]))
            if op=='BUY_PRODUCT':cost+=q*prices[item]
            elif op=='BUY_ANIMAL':cost+=q*{'GOOSE':300,'COW':400,'SHEEP':500}[item]
            elif op=='BUY_SEED':cost+=q*{'WHEAT':10,'CARROT':20,'TOMATO':50,'STRAWBERRY':100,'MELON':80}[item]
    return cost<=farm['money']  # No current sale proceeds are assumed.

def _r97_supply(obs,action):
    step=int(obs['step']);player=int(obs['player']);day=step//24
    if not 144<=step<695:return action
    native=_IMPL.chassis.players[player]
    future=_IMPL.chassis.routes[2 if step+1>=648 else native['route']][step+1]
    commands=[future.get('farmer') or ['PASS'],*(future.get('hands') or [])]
    following=_IMPL.chassis.routes[2 if step+2>=648 else native['route']][step+2]
    next_orders=future.get('market') or []
    prefund=0
    if len(next_orders)==10 and not any(o[:2] in (['BUY_PRODUCT','WHEAT'],['SELL','WHEAT']) for o in next_orders):
        later=[following.get('farmer') or ['PASS'],*(following.get('hands') or [])]
        demand=lambda cs:sum(max(0,int(c[2]) if len(c)>2 else 1) for c in cs if c[:2]==['PICKUP','WHEAT'])
        if demand(later):prefund=demand(commands)+demand(later)
    if not prefund and not any(c[:2]==['PICKUP','WHEAT'] for c in commands):return action
    orders=action.get('market') or []
    if len(orders)>10 or not _r97_budget(obs,orders):
        _R97_REPORT['supply_budget_declines']+=1;return action
    farm,private=_PLANNER_NS['_clone_state'](obs['farms'][player],obs['private'])
    for actor,c in enumerate([action.get('farmer') or ['PASS'],*(action.get('hands') or [])][:len(private['inventories'])]):
        _PLANNER_NS['_apply_unit_action'](farm,private,actor,c,10,day,24,100)
    positions=[tuple(farm['farmer']),*map(tuple,farm['hands'])];night=step%24==23
    access=((4,4),(5,4),(4,5),(5,5))
    if night:positions=[(4,4)]
    else:
        for order in orders:
            if order and order[0]=='HIRE':positions.append(min(access,key=lambda p:(positions.count(p),access.index(p))))
    need=sum(max(0,int(c[2]) if len(c)>2 else 1) for pos,c in zip(positions,commands) if pos in access and c[:2]==['PICKUP','WHEAT'])
    need=max(need,prefund)
    if not need:return action
    original_stock,original_buys,_=_r97_market_stock(private['shed'],orders)
    original_final,original_loss=_r97_delivery(original_stock,private,night)
    if original_final.get('WHEAT',0)>=need:return action
    result=copy.deepcopy(action);proposed=result['market'];blocked=False
    def project(candidate):
        stock,buys,sales=_r97_market_stock(private['shed'],candidate)
        final,loss=_r97_delivery(stock,private,night)
        safe=all(buys.get(i,0)>=q for i,q in original_buys.items()) and all(q<=original_loss.get(item,0) for item,q in loss.items())
        return final,sales,safe
    for index in range(len(proposed)-1,-1,-1):
        if proposed[index][:2]!=['SELL','WHEAT']:continue
        final,sales,safe=project(proposed);shortage=max(0,need-final.get('WHEAT',0))
        if not shortage:break
        sold=sales.get(index,0)
        if not sold:continue
        old=proposed[index][2];proposed[index][2]=max(0,sold-shortage)
        after,_,safe=project(proposed)
        if not safe or after.get('WHEAT',0)<=final.get('WHEAT',0):proposed[index][2]=old
    final,_,safe=project(proposed);shortage=max(0,need-final.get('WHEAT',0))
    if shortage:
        last_sale=max((i for i,o in enumerate(proposed) if o[:2]==['SELL','WHEAT']),default=-1)
        index=next((i for i in range(len(proposed)-1,last_sale,-1) if proposed[i][:2]==['BUY_PRODUCT','WHEAT']),None)
        if index is not None:proposed[index][2]=max(0,int(proposed[index][2]))+shortage
        elif len(proposed)<10:proposed.append(['BUY_PRODUCT','WHEAT',shortage])
        else:_R97_REPORT['supply_slot_declines']+=1;return action
    final,_,safe=project(proposed)
    if not safe or final.get('WHEAT',0)<need:
        _R97_REPORT['supply_capacity_declines']+=1;return action
    if not _r97_budget(obs,proposed):
        _R97_REPORT['supply_budget_declines']+=1;return action
    if prefund:
        _R97_REPORT['supply_prefund_changes']+=1
        _R97_REPORT['supply_prefund_units']+=max(0,final.get('WHEAT',0)-original_final.get('WHEAT',0))
    if step<288:
        _R97_REPORT['supply_early_changes']+=1
        _R97_REPORT['supply_early_units']+=max(0,final.get('WHEAT',0)-original_final.get('WHEAT',0))
    _R97_REPORT['supply_guard_changes']+=1
    _R97_REPORT['supply_grain_protected']+=final.get('WHEAT',0)-original_final.get('WHEAT',0)
    _R97_REPORT['supply_buy_units']+=sum(max(0,int(o[2])) for o in proposed if o[:2]==['BUY_PRODUCT','WHEAT'])-sum(max(0,int(o[2])) for o in orders if o[:2]==['BUY_PRODUCT','WHEAT'])
    return result

def agent(observation,configuration=None):
    result=_R97_PARENT(observation,configuration)
    try:
        player=int(observation['player']);step=int(observation['step'])
        if player not in _R97_LAST or step<=_R97_LAST[player]:
            _R97_REPORT.update(supply_guard_changes=0,supply_grain_protected=0,supply_buy_units=0,supply_early_changes=0,supply_early_units=0,supply_prefund_changes=0,supply_prefund_units=0,supply_slot_declines=0,supply_capacity_declines=0,supply_budget_declines=0,supply_errors=0)
        _R97_LAST[player]=step
        if configuration is None or all(configuration.get(k,v)==v for k,v in [('boardSize',10),('turnsPerDay',24),('shedCapacity',100),('maxMarketOrdersPerTurn',10),('farmHandCostMult',1)]):result=_r97_supply(observation,result)
    except Exception:_R97_REPORT['supply_errors']=_R97_REPORT.get('supply_errors',0)+1
    _R97_REPORT.update(getattr(_R97_PARENT,'telemetry',{}))
    return result

agent.telemetry=_R97_REPORT
agent=globals().pop('agent')


V9_COURIER_ITEMS = ("STRAWBERRY", "MILK", "WOOL", "MELON")
V9_COURIER_FROM_HOUR = 12
_V9_COURIER_ACCESS = ((4, 4), (5, 4), (4, 5), (5, 5))
_V9_COURIER_IDLE = frozenset({"PASS", "NORTH", "SOUTH", "EAST", "WEST", "DROP"})
_V9_COURIER = {}
_V9_COURIER_REPORT = dict(courier_trips=0, courier_units=0, courier_errors=0)


def _v9_courier_walk(pos, target):
    x, y = pos
    tx, ty = target
    return ([["EAST"]] * max(0, tx - x) + [["WEST"]] * max(0, x - tx)
            + [["SOUTH"]] * max(0, ty - y) + [["NORTH"]] * max(0, y - ty))


def _v9_courier_plan(tape, unit, pos, commands, step, end):
    """Walk-and-drop route for an idle tape worker, or None if it has work left today."""
    if commands[unit] and commands[unit][0] not in _V9_COURIER_IDLE:
        return None
    for t in range(step + 1, end + 1):
        a = tape[t] if t < len(tape) else {}
        units = [a.get("farmer") or ["PASS"]] + list(a.get("hands") or [])
        command = units[unit] if unit < len(units) else ["PASS"]
        if command and command[0] not in _V9_COURIER_IDLE:
            return None
    target = min(_V9_COURIER_ACCESS, key=lambda a: abs(a[0] - pos[0]) + abs(a[1] - pos[1]))
    walk = _v9_courier_walk(pos, target)
    return walk + [["DROP"]] if len(walk) <= end - step else None


def _v9_courier(obs, action, st):
    step = int(obs["step"])
    player = int(obs["player"])
    if step >= 718 or step % 24 < V9_COURIER_FROM_HOUR:
        return action
    day = step // 24
    if st.get("day") != day:
        st["day"] = day
        st["plans"] = {}
    native = _IMPL.chassis.players.get(player)
    if not native or native.get("route") not in _IMPL.chassis.routes:
        return action
    tape = _IMPL.chassis.routes[native["route"]]
    farm = obs["farms"][player]
    positions = [tuple(farm["farmer"])] + [tuple(p) for p in farm["hands"]]
    inventories = obs["private"]["inventories"]
    commands = [list(action.get("farmer") or ["PASS"])] + [list(c) for c in (action.get("hands") or [])]
    commands += [["PASS"]] * (len(positions) - len(commands))
    end = day * 24 + 23
    plans = st["plans"]
    crew = 1 + max(len(tape[t].get("hands") or []) for t in range(day * 24, min(len(tape), end + 1)))
    delivered = {}
    changed = False
    for unit, pos in enumerate(positions[:crew]):
        inventory = inventories[unit] if unit < len(inventories) else {}
        cargo = {k: int(v) for k, v in inventory.items() if k in V9_COURIER_ITEMS and int(v) > 0}
        plan = plans.get(unit)
        if plan is None:
            if not cargo or native.get("pending", {}).get(unit):
                continue
            route = _v9_courier_plan(tape, unit, pos, commands, step, end)
            if route is None:
                continue
            plan = plans[unit] = {"route": route, "start": step}
            _V9_COURIER_REPORT["courier_trips"] += 1
        index = step - plan["start"]
        if index >= len(plan["route"]):
            continue
        command = plan["route"][index]
        if command == ["DROP"]:
            if pos not in _V9_COURIER_ACCESS:
                plans[unit] = {"route": [], "start": step}
                continue
            for item, n in cargo.items():
                delivered[item] = delivered.get(item, 0) + n
        commands[unit] = command
        changed = True
    if not changed:
        return action
    result = dict(action)
    result["farmer"], result["hands"] = commands[0], commands[1:]
    if delivered:
        market = [list(o) for o in action.get("market") or []]
        prices = obs["market"]["prices"]
        for item, n in sorted(delivered.items(), key=lambda kv: -int(prices.get(kv[0], 0)) * kv[1]):
            if int(prices.get(item, 0)) < 2:
                continue
            existing = next((o for o in market if o and o[0] == "SELL" and len(o) >= 3 and o[1] == item), None)
            if existing is not None:
                existing[2] = int(existing[2]) + n
                market.remove(existing)
                market.insert(0, existing)
            elif len(market) < MAX_ORDERS:
                market.insert(0, ["SELL", item, n])
            _V9_COURIER_REPORT["courier_units"] += n
        result["market"] = market
    return result


_V9_COURIER_PARENT = agent


def agent(observation, configuration=None):
    player, step = int(observation["player"]), int(observation["step"])
    st = _V9_COURIER.get(player)
    if st is None or step <= st["step"]:
        st = _V9_COURIER[player] = {"step": -1}
        if step == 0:
            _V9_COURIER_REPORT.update(courier_trips=0, courier_units=0, courier_errors=0)
    st["step"] = step
    action = _V9_COURIER_PARENT(observation, configuration)
    try:
        return _v9_courier(observation, action, st)
    except Exception:
        _V9_COURIER_REPORT["courier_errors"] += 1
        return action


agent.telemetry = _V9_COURIER_REPORT
agent = globals().pop("agent")


V9_CARROT_RATIO = 1.8
V9_CARROT_FIRST_DAY = 10
V9_CARROT_LAST_DAY = 23
V9_CARROT_WHEAT_RESERVE = 40
V9_CARROT_BOOM_RATIO = 3.5   # from this ratio the feed reserve is bought instead of grown
V9_CARROT_BOOM_RESERVE = 10
_V9_CARROT_REPORT = dict(carrot_swaps=0, carrot_seed_swaps=0, carrot_errors=0)


def _v9_carrot(obs, action, st):
    step = int(obs["step"])
    day = step // 24
    prices = obs["market"]["prices"]
    private = obs["private"]
    commands = [list(action.get("farmer") or ["PASS"])] + [list(c) for c in (action.get("hands") or [])]
    market = [list(o) for o in action.get("market") or []]
    changed = False
    if st.get("tiles"):
        _farm = obs["farms"][int(obs["player"])]
        _pos = [_farm["farmer"]] + list(_farm["hands"])
        for _i, c in enumerate(commands[:len(_pos)]):
            if c != ["WATER"]:
                continue
            _p = tuple(_pos[_i])
            if st["tiles"].get(_p) != day - 3:
                continue
            _t = _farm["tiles"][_p[1]][_p[0]]
            if isinstance(_t, dict) and _t.get("crop") == "CARROT" and int(_t.get("planted_day", -9)) == day - 3 and int(_t.get("yield_units", 0)) > 0:
                commands[_i] = ["HARVEST"]
                changed = True
                _V9_CARROT_REPORT["carrot_rescues"] = _V9_CARROT_REPORT.get("carrot_rescues", 0) + 1
    wheat_held = int(private["shed"].get("WHEAT", 0)) + sum(int(i.get("WHEAT", 0)) for i in private["inventories"])
    ratio = int(prices.get("CARROT", 0)) / max(1, int(prices.get("WHEAT", 99)))
    boom = ratio >= V9_CARROT_BOOM_RATIO
    reserve = V9_CARROT_BOOM_RESERVE if boom else V9_CARROT_WHEAT_RESERVE
    if boom and V9_CARROT_FIRST_DAY <= day <= V9_CARROT_LAST_DAY and wheat_held < V9_CARROT_WHEAT_RESERVE:
        topup = V9_CARROT_WHEAT_RESERVE - wheat_held
        budget = float(obs["farms"][int(obs["player"])]["money"]) - 1500
        qty = min(topup, int(budget // max(1, int(prices.get("WHEAT", 99)) + 5)))
        if qty > 0 and len(market) < MAX_ORDERS and not any(o[:2] == ["BUY_PRODUCT", "WHEAT"] for o in market if len(o) >= 2):
            market.append(["BUY_PRODUCT", "WHEAT", qty])
            changed = True
    if (V9_CARROT_FIRST_DAY <= day <= V9_CARROT_LAST_DAY and wheat_held >= reserve
            and ratio >= V9_CARROT_RATIO):
        carrot_seeds = int(private["seeds"].get("CARROT", 0)) - sum(1 for c in commands if c[:2] == ["PLANT", "CARROT"])
        _farm = obs["farms"][int(obs["player"])]
        _pos = [_farm["farmer"]] + list(_farm["hands"])
        for _i, c in enumerate(commands):
            if c[:2] == ["PLANT", "WHEAT"] and carrot_seeds > 0:
                c[1] = "CARROT"
                carrot_seeds -= 1
                changed = st["swapped"] = True
                _V9_CARROT_REPORT["carrot_swaps"] += 1
                if _i < len(_pos):
                    st.setdefault("tiles", {})[tuple(_pos[_i])] = day
        for o in market:
            if len(o) >= 3 and o[:2] == ["BUY_SEED", "WHEAT"]:
                o[1] = "CARROT"
                changed = st["swapped"] = True
                _V9_CARROT_REPORT["carrot_seed_swaps"] += int(o[2])
    result = dict(action)
    result["farmer"], result["hands"], result["market"] = commands[0], commands[1:], market
    if st.get("swapped") and day < 24:
        stock = projected_shed(result, FarmView(obs)).get("CARROT", 0)
        selling = sum(int(o[2]) for o in market if len(o) >= 3 and o[:2] == ["SELL", "CARROT"])
        if stock > selling and len(market) < MAX_ORDERS and int(prices.get("CARROT", 0)) >= 2:
            market.insert(0, ["SELL", "CARROT", stock - selling])
            changed = True
    return result if changed else action


_V9_CARROT = {}


_V9_CARROT_PARENT = agent


def agent(observation, configuration=None):
    player, step = int(observation["player"]), int(observation["step"])
    st = _V9_CARROT.get(player)
    if st is None or step <= st["step"]:
        st = _V9_CARROT[player] = {"step": -1}
        if step == 0:
            _V9_CARROT_REPORT.update(carrot_swaps=0, carrot_seed_swaps=0, carrot_errors=0)
    st["step"] = step
    action = _V9_CARROT_PARENT(observation, configuration)
    try:
        return _v9_carrot(observation, action, st)
    except Exception:
        _V9_CARROT_REPORT["carrot_errors"] += 1
        return action


agent.telemetry = _V9_CARROT_REPORT
agent = globals().pop("agent")


V9_HERD_MIN_WOOL = 150         # wool quote needed to swap to sheep
V9_HERD_MIN_MILK = 150         # milk quote needed to swap to cows
V9_HERD_MAX_EGG_SHOPS = 1         # sheep swap: at most this many BAKERY + BRUNCH_SPOT
V9_HERD_MAX_EGG_SHOPS_COW = 0  # cow swap: at most this many
V9_HERD_MIN_MILK_SHOPS = 3      # cow swap: at least this many PIZZA / ICE_CREAM / SMOOTHIE
_V9_HERD_PRODUCT = {"SHEEP": "WOOL", "COW": "MILK"}
_V9_HERD = {}
_V9_HERD_REPORT = dict(herd_species="", herd_rewrites=0, herd_extra_sold=0, herd_errors=0)


def _v9_herd_choose(obs):
    shops = obs["town"]["unlocked_shops"]
    prices = obs["market"]["prices"]
    egg_shops = sum(s in ("BAKERY", "BRUNCH_SPOT") for s in shops)
    if (egg_shops <= V9_HERD_MAX_EGG_SHOPS and "YARN_STORE" in shops
            and int(prices.get("WOOL", 0)) >= V9_HERD_MIN_WOOL):
        return "SHEEP"
    milk_shops = sum(s in ("PIZZA_SHOP", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP") for s in shops)
    if (egg_shops <= V9_HERD_MAX_EGG_SHOPS_COW and milk_shops >= V9_HERD_MIN_MILK_SHOPS
            and int(prices.get("MILK", 0)) >= V9_HERD_MIN_MILK):
        return "COW"
    return None


def _v9_herd(obs, action, st):
    step = int(obs["step"])
    orders = action.get("market") or []
    if st.get("species") is None and not st.get("decided"):
        if step >= 216 and any(len(o) >= 2 and o[:2] == ["BUY_ANIMAL", "GOOSE"] for o in orders):
            st["decided"] = True
            st["species"] = _v9_herd_choose(obs)
            _V9_HERD_REPORT["herd_species"] = st["species"] or ""
    species = st.get("species")
    if not species:
        return action
    product = _V9_HERD_PRODUCT[species]
    commands = [list(action.get("farmer") or ["PASS"])] + [list(c) for c in (action.get("hands") or [])]
    market = [list(o) for o in orders]
    for c in commands:
        if c and c[0] == "BUILD_COOP":
            c[0] = "BUILD_PASTURE"
            _V9_HERD_REPORT["herd_rewrites"] += 1
        elif len(c) >= 2 and c[0] in ("PICKUP", "PLACE") and c[1] == "GOOSE":
            c[1] = species
            _V9_HERD_REPORT["herd_rewrites"] += 1
    rewritten = []
    for o in market:
        if len(o) >= 3 and o[:2] == ["BUY_ANIMAL", "GOOSE"]:
            rewritten.append(["BUY_ANIMAL", species, o[2]])
        elif len(o) >= 2 and o[:2] == ["SELL", "EGG"] and not any(isinstance(t_, dict) and t_.get("animal") == "GOOSE" for r_ in obs["farms"][int(obs["player"])]["tiles"] for t_ in r_):
            continue
        else:
            rewritten.append(o)
    result = dict(action)
    result["farmer"], result["hands"], result["market"] = commands[0], commands[1:], rewritten
    player = int(obs["player"])
    native = _IMPL.chassis.players.get(player)
    if native and native.get("route") in _IMPL.chassis.routes and step < 718:
        stock = projected_shed(result, FarmView(obs)).get(product, 0)
        selling = sum(int(o[2]) for o in rewritten if len(o) >= 3 and o[:2] == ["SELL", product])
        planned = _IMPL.chassis.future_sells(native["route"], product, step + 1)
        extra = stock - selling - planned
        if extra > 0 and len(rewritten) < MAX_ORDERS and int(obs["market"]["prices"].get(product, 0)) >= 2:
            rewritten.insert(0, ["SELL", product, extra])
            _V9_HERD_REPORT["herd_extra_sold"] += extra
    return result


_V9_HERD_PARENT = agent


def agent(observation, configuration=None):
    player, step = int(observation["player"]), int(observation["step"])
    st = _V9_HERD.get(player)
    if st is None or step <= st["step"]:
        st = _V9_HERD[player] = {"step": -1}
        if step == 0:
            _V9_HERD_REPORT.update(herd_species="", herd_rewrites=0, herd_extra_sold=0, herd_errors=0)
    st["step"] = step
    action = _V9_HERD_PARENT(observation, configuration)
    try:
        return _v9_herd(observation, action, st)
    except Exception:
        _V9_HERD_REPORT["herd_errors"] += 1
        return action


agent.telemetry = _V9_HERD_REPORT
agent = globals().pop("agent")


V9_FERT_CROPS = ("WHEAT", "CARROT")
V9_FERT_AGES = (1,)
V9_FERT_FIRST_DAY = 14
_V9_FERT_REPORT = dict(fert_applied=0, fert_errors=0)


def _v9_fert(obs, action):
    step = int(obs["step"])
    day = step // 24
    if day < V9_FERT_FIRST_DAY or step >= 700:
        return action
    player = int(obs["player"])
    farm = obs["farms"][player]
    positions = [tuple(farm["farmer"])] + [tuple(p) for p in farm["hands"]]
    inventories = obs["private"]["inventories"]
    commands = [list(action.get("farmer") or ["PASS"])] + [list(c) for c in (action.get("hands") or [])]
    changed = False
    native = _IMPL.chassis.players.get(player)
    tape = _IMPL.chassis.routes.get(native.get("route")) if native else None
    planned = {}
    if tape is not None:
        for t in range(step, min(len(tape), day * 24 + 24)):
            a = tape[t] or {}
            for u, c in enumerate([a.get("farmer") or ["PASS"]] + list(a.get("hands") or [])):
                if c and c[0] == "FERTILIZE":
                    planned[u] = planned.get(u, 0) + 1
    carried = {}
    targeted = set()
    for unit, command in enumerate(commands[:len(positions)]):
        if not command or command[0] != "WATER":
            continue
        x, y = positions[unit]
        tile = farm["tiles"][y][x]
        if not (isinstance(tile, dict) and tile.get("kind") == "PLANT" and tile.get("crop") in V9_FERT_CROPS):
            continue
        if (day - int(tile["planted_day"])) not in V9_FERT_AGES or tile.get("watered_today"):
            continue
        if int(tile.get("consecutive_unwatered", 1)) != 0 or int(tile.get("fertilized_until_day", -1)) >= day:
            continue
        have = carried.setdefault(unit, int((inventories[unit] if unit < len(inventories) else {}).get("FERTILIZER", 0))
                                  - planned.get(unit, 0))
        if have <= 0 or (x, y) in targeted:
            continue
        commands[unit] = ["FERTILIZE"]
        carried[unit] = have - 1
        targeted.add((x, y))
        changed = True
        _V9_FERT_REPORT["fert_applied"] += 1
    if not changed:
        return action
    result = dict(action)
    result["farmer"], result["hands"] = commands[0], commands[1:]
    return result


_V9_FERT_PARENT = agent


def agent(observation, configuration=None):
    if int(observation["step"]) == 0:
        _V9_FERT_REPORT.update(fert_applied=0, fert_errors=0)
    action = _V9_FERT_PARENT(observation, configuration)
    try:
        return _v9_fert(observation, action)
    except Exception:
        _V9_FERT_REPORT["fert_errors"] += 1
        return action


agent.telemetry = _V9_FERT_REPORT
agent = globals().pop("agent")


V9_OPENING_STEP0 = (("BUY_PRODUCT", "WHEAT", 20), ("SELL", "WHEAT", 15))
V9_OPENING_TAPE = ((("BUY_PRODUCT", "WHEAT", 13), ("BUY_PRODUCT", "WHEAT", 30), ("SELL", "WHEAT", 30)),
                   (("SELL", "WHEAT", 13), ("BUY_PRODUCT", "WHEAT", 5)))


def _v9_opening(obs, action):
    step = int(obs["step"])
    if step > 1:
        return action
    native = _IMPL.chassis.players.get(int(obs["player"]))
    if not native or native.get("route") not in _IMPL.chassis.routes:
        return action
    market = [list(o) for o in action.get("market") or []]
    wheat = [o for o in market if len(o) >= 3 and o[0] in ("BUY_PRODUCT", "SELL") and o[1] == "WHEAT"]
    if tuple((o[0], o[1], int(o[2])) for o in wheat) != V9_OPENING_TAPE[step]:
        return action  # the tape's opening was changed upstream; leave it alone
    rest = [o for o in market if o not in wheat]
    result = dict(action)
    result["market"] = ([list(o) for o in V9_OPENING_STEP0] if step == 0 else []) + rest
    return result


_V9_OPENING_PARENT = agent


def agent(observation, configuration=None):
    action = _V9_OPENING_PARENT(observation, configuration)
    try:
        return _v9_opening(observation, action)
    except Exception:
        return action


agent = globals().pop("agent")




import json as _v92_json, os as _v92_os, zlib as _v92_zlib, base64 as _v92_b64
_V92_P_ITEMS = ("MILK", "WOOL", "STRAWBERRY", "EGG", "MELON")
_V92_P_USE = ('MILK', 'WOOL', 'STRAWBERRY')
_V92_P_H = 48
_V92_P_K = 4
_V92_P_TOP = 1
_V92_P_EVERY = 2
_V92_EP = None          # panel: current episode (library excludes same-parity episodes)
_V92_P_LIB = None
_V92_P = {}
_V92_P_REPORT = dict(pred_units=0, pred_fires=0, pred_errors=0)



_V92_P_BLOB = 'c-ri}ORRKRmL9ZUXP<peoOs@ddv9iCWo5U@banNER<}SlN|^~GWHDickq{DdBqPAx5)y8?+meM^&~`V*44Bvr2-C9L111>6#3K+xOH9nbfH6o&fDmHF`o3@N6A|~n|0^>qt7X?;kx_9Y&U2r&*Itiree0LQAB5kHHO2b#p%%U_u|0&GOC3v1Wl5#hkVC04O#4!&P(w=g=Mb{(wGTtGU!#4QV~kJsIh7KJ5^{^Ng(;+M$oor7wwL`El5G|FV=DY)yXA~;H`sRx*-jMgr}dR`8dAacDVBg&=pXDAvmG{SFMV(CEvGTtKK9ofGR}ijN1UdlxY+;WVp>Se4~z5TN{XE<#WC|zv2VrsdC@pZ=1u0*qTRLKa>T*yP__{_z^Rjez}I$1xeXW}|I&YoHjI-G0=`V^uNn%R5Z8bmdHsodMgJyU2WQlAcnbw5<fz7B#+F&vpF-B<Rb1&XWNe4Quv>^(cQIn)WIv7eL~{9?;V)7sBIRNT_1sSx>}nw(#iS#~1LcC!aeXbhv}W(Qrd;t;K1PTVex36nm&MM^qv7E+9H-P=a&C4Yd`zWfyP&qQ%~H#GW7}_Y8Eo9`YV!{JhI-7!q&25H*<fK1D@Fo>S@~FIyGDCTNe>U-*!8pt58NIzzOf;KsD-Sj%gx%D@`5kzprz!JFs`_Zf?+N^kv-8}v}-g8F=4mMwmVHT#W_;K?3UYreeKI;=Yp)+?s+M}#yE~V5d<XRu6ZRmqkTWx6T$X&3$x9i9O~XK$A;V<ShOvNXp+sRHfJ2U<U_J8?I2+};ILD|s5T$rytT)==a!gi_95gc+Tcd)Vt0`@IZPaf2+@j_2j`6>e!$EdFnYL=_7_Z9EH&1DESORlK9A!uLVO0kW3<XiB4FZmu;*w(mQ7?9`!GVr?W<w2Ck*+UH<T~Cv}#%g4+Q6GI8KV(u}F07xuuGcFlo<xbP!x@Z=<wLHa{~|ft|N+k2_2Y9=>g0$D^XL0ZfTU;Mnp>@kEfRhPzE?YA61K?!aIBTzMWlsZBzYshpu2qPC=#!TE4rNY*1}YDhcmV^?B2t=axFp2ZT%KI6jXi(Rcv?>t=i{AbFqNq)vr2UDQQW^tY`33r4!hry{!N*nGNDPQ)!!v{N#9<}W=#JC)>FSeoLu&cxFe;!KS{(6Y%J7M`OwomYsp7EeKEfb!}gy&!zhx!!TXJI)8%x!=1S=p4^hRc*p6zu-&abQXmTxO-h+*6y_F-%|B{U0d$(~ft+$7tKzt_>PEoTyGs3ETa)OdV?Hu>rB?j}gGyp>f7U3F)+iO@kCxDE#y}j*k1Y!LO2tkd8Jy(Bo8?)R?w!EfA3m4GC>&7rf0FDoA1E8Mz2yow4a!ur3^^lM}CvIsj)m@i?}5J%)*=zAS+<9VVMFIcmijOj=L48k@^I$P@;_{+yf6Ma>+;Y+DAXIlB}+9J^W@s_%v6JJhsykBB<fo>B^?JSQ&5OXY(yb+^N8%r@+&{=}%dbEKB*FOweoX`)!*K4#yz@_E|!n-aON9W817#{7wVyo22$wX|(w5<Epd^R$@Mm}pMCj6g}viOLY$n+UX~#W`aY<v`kWXj;Xn#%jZ_1!9~`jX=Xg9VO^1ZJ-$yAStv0FwN}Su}GTC0I|n~$+n9aa$GsiMX84IVB;SK8VVasd^{qo{CK3;pkO{H&MO)(cs_~NiI!56^0c*4%5lP@GU>pRf7DIwaO3vu?J{)xHF3)67K-1vZp4l`nwAa}W-b9X{*7b87cQf}-+n{six>!Kw+tniqEs|qm1+sfFa{I1OAKGyi*`-s7@iA84-?xiGGBM}7ljcYa@teTd}*)5?`<R(%!Z@uAbdIS!<Qj`8Iqml%TT`jCjaE)`+Kgf_TT7iINXT;D*GAYYRZ2z+{iwa=T-I#?ik|V(mbzHPX#-{7{HU4)Mr~<xuq;iiOMSVG{vrhzd+<+jPN-Z*?Rn`a3R~pmx7;O6@0AdkWk7#gm~)W&-KJsTo?b0h59Yx|6bX*)e36>?j3f)7-4XmaxZCeD-+@jMK`=5VpvL(>50jtKE3fPrCYB_@7YYAB$c{oaeuK_y4^P|v|jo*(QJ>o+68M%uJGJU<7YQw!(~G>&6rIv5<<igOaNgt;lm&GnNhf|$c7EN&GzE`-w6Lf9BLf?sqkzj;cPE^aJ0!yBw+>62s$K65N<_2h2+KbQQ6aMwKav)yJAa7T&0<_(0ekmUno$!J%kA|3xUF~w(oMHDVb?a+7V8AdWo8ddLPG$a(3D?k8`wdXj24QUa)TA)16L5d%?dexIeQ2CipKfyUg~f&v|#iU|{!w$4^|rHAv66fc4-~SZybpg=c|B>EhfTAfQP@3%>>%FLQ?0f(e|p?55v#U2u-+)3;bIn5Z;fqyi4Mq6I9o$NTwz%#ZST*2xb)6l-5;+^oc1f{$b;hFH)@J)AhPv4-b#f>;a?CAa|g9A;VvctN*AuV>DL!l?xhXvY}|6FKduw`uutciU?)V+H%tP`01a!iBIl9g~&_4TD|9V{coW;=l{QrP7vZbZ16e<7Q|C*jZe8?LRw9gFni3aKQ25YxHZF6Fv<4Bsa(G^+I{IN5lu1mVMa6KZngS1sUZu3Fx2OA<M>}Y=v(jBbY+*r|{6s;{8FW8wM0i9UWmkoM=Os7f6%DenNa<exihRlNF<Aa%net3DRKsDLla%$D*3)<+cZU;{3cn1*ugtA7;&jfG1;@YcoC1^z(8)*+|%PjQOIal|uy=gO3|Cr=_x?^I?LR@VHJ7?hNtNkl@pUoK!p<`+5^>7U1BYEeL^R8WNEjmX9F+Ao3gjnx2y;()S}&2JO8VC%emZ{51byv5)+hu2Fymy4@##`~Sl4bf5g^=#yW#Fq%<$vR`l9Z>$KVHjcD?vv7vM_Jq9H+_2-HZQ2}Z9z$=yFU5Q)n1m*aa8qIW;uiVNz=-~=GDo^XjS!vewmZd&wnhxT0n85U#Bb;lo3g^~@f3_&V1#fDHY+IETmiXkCOTe_2fANaEu&xay1TAKk)<L}4i5(sadQ`vlp>$juT8-yhIANy@jJzb`#<g4^7@lT<NnWpTWTJ+p(E`(ru8!h>TM^w-R0(_YuIYtEBT427_(c4F}wJCgyz-bd)RG#U$1H%5Xkj4fTnkxtH;^O?P2@w<^IV0bp45Ojs76|pmm>=0SJgnx((<-ZDBPmzkL^#OjPVp2evNpg%5#Y87|VMT*e-lq{UD#rm|qZtWn7sE4fWPQ_Aox=fEh4eu6eORR{~%4sr^7R;GLQL1Hp_RMI9k?*Jh*x7&8G0;wA_r@fg<oVSCA41+)0y=migW@ILEIi?YVBaZ_=+sZ`ohGWW;eu^uE+A9?fhFJnpmpZuJUhH}%%vTwXTU#1v;rUqZG0^y?A)ICRBBf+5@@VS#lqFn=%B9?f2^n*x8j95F_yuMeA1th<LzZ_YJJq)33ZK$%hTo>z-{xW-{uAAD`|xSRvUa8#GSwPv^`^xh^XbV}gnT&T_)By<W4Y+4d3O%7!>fWA<{i>rsobDOeVOMAtp^!BG}um$G^&EMA%Z>AL*VL!Wo6+u=Zhax(<ABBcIOYWhtnJ>O(~!4=M(*>=!2nHW6}m(8s-ZYVKdQp7mq>BesG+3_mC8%W{e1r?&!zCm+e9afs6LcZBCES`Kj-IK4Y<J6f4Bxpd0hyflg3noX@s7L4l^e0Uv29|CJk03m@p~zSLVBsm7)IRYz*4)f)~|ec?`xvJ%Y0@6iN1BAs(A?^%%|`ta$-qvB)C^erYjL?+^iG7sBJ@eA92az)ol=!(w8w{ios`C-S>6P6cM=+0!?$&4d#oln@&HXN}m;Avmosl@9~bb5G)v@38Z+B-1X3W5mqpXea!EQsPHcbgEst(e9Pe584x88RdWsbPS|ah0Rhn@KmX?t~$JgXzs6AN(rVh)`*P%d7<O`o1p=4J-^j!II0eQ|$0(Q;rkD<?=6&Fa#)i6Fo&n{^de7dEozY`1j-T^PIq+P-HI98dWxPD4(ygW3LGbqI%}^qA^l27_mM;BAN}xGwh9KcIJpheSG3XHAiQlH)EH7f!Vp6;d4NC8V7Rm;WxoF$+n+t%flzg>tO6R_{L;&+=me(YwuxLXoN=!=ZIUf<BW4)3W-_`LrA9saVHpbn3g4t$SlA=w=ahQ5j?y80+}@XE@0&w+{Bn*q+tHVzZ=$|-Rae!YL8K5&8s|yo9HUS6i@}sqH%)3LgO3@S<|c@6u^VtMI>g%G6+v;Wcby50!A2yp~owHb|IWU=_#)93i%3fL37!KBwH0e3ZvY#g`s>fNZ3~jWY=WP+I;hf9alK|oC}SQB=;8jx#erH!Zw)N8m5R1^D0nA!-(Ur!HPU@IkmVD71;Ke9*t9o(+pp3VcaIVXnwA#N8=)=lRZ?E&dnjxQRCVUrLN=_=ITg4i9uN0Ve58JMi>rmdCwryC2l5;ail@qsBuQP<+wf@x$p2U6tx=H02{7Q3M<sDd>KX2e6r2oaun@<`Uc`>n7v%)VF!7l2KgfD{3e}mQ;zZOmOWc)Uk?={7l$4}h9U}X0V)y>D~^^t%rtimW`;W?L0D%R0y*O#W3tDTqaQ~)zpb8@G6?#C3q+NEYl@0uV;Y?O*X$8Eh!}kg`*IDcWjMmJXwxQo2DZA(t206XlPAb>?$<mvh{VLlJHlImZFa%n1zu?$pdIm>thdBScji?;W)7N3v9_U+Y@@W{k}(tw8sE7WUPC(5=p1-(+=X4oM)HLf5JKTbYMi<$o)`kgQ^*YamUqT{C8|H_Xz#Dznfi8tj~#$e%2H_Jn6y@|J_qw_@#iuyC3RrLmP#i-dCCCB;()8pJKBYX>PaX7^DOqkO$Ix{3F!uz>lHaeGg@%RcC<m;7e)dKtQd|jB6gK7x~UvQ@u^>!5()X(6O-C^VLH9?Q6pL=7b+=bSb2)duxOl_M3f@d@#XF9-3ph71r`5{lXCv?P>BvVGynRhK#eW6%zII(OE*QPswX^HEc-iN8(q9a*FF8R=b&haL;l{eqA}iv_j0$QWd)!S3Bt0uu50CfU9-ocbha;T^G%kq`O-#H^Y$O-;p$#0PF~_p_8fy!GTOBQj(r8J>k7zxE6%u=BjD<Qn2N;bmSic;IGV46!bUU?F}PQpdWK5gb>%zP$EeY*3Va|J=uUgZGAL6l$z*JdFS=(=AxgrQL<e~wsngwTDJBS}R#L<u*JadJdAedHC~hCS&6kkK)MCou44?Dlhf1sIsrXhY?#8!1;F9;@y3}&6G962M9?>>MUVv%fZH`5H%|~@ko-3Pq0Se!F6h?lqBJ=s0tX=P2GJ{)YI(FpLkU@wMCX_(ttOuR~Rtq!1x3JV`2lLz;YIbJhg?e$dxGvm`D^V>@O65u$+Q4G2a|P#0g9ptohi@+xhExA(04_>bj%UII4tUy`!M$bZ9^8l#%}?d|8J072#AD3T9VTm!S@5L@4<}rDcxs2WAU`d5hS7Z-d6`Jpn2_52*&=9r%{hNgrv)C?K7Ai90}}kEeE<Ms0N>94{T-J6PolDC6tROD&5;gZ{)`thAi=@axzJ1IB{m^Q9w|yZsSW>6D_gm6KFQ_0crMf2`sXF>8=i>_dRX>RlP{ctk{>|H*p~Z8nXAEUvGbA^Mjac~cc%BW`R@^16~^HgxCT9WY!!CUSjGrvWwI{@tm6Y6oj4#;YAe(-AXP#mh!LAb!6U$&k``y(gk2h>Guz^YJe)mG+!^PC>@0<mqWmaCK+N!+0er#eR)7?s??xsdYd5Kt_wuOzLKToXk(ho_ZX$BMU{+drGUUo}ku5XUoSE6@Lg(RK#!lAkb6}1l5a*<snOuS%9cw|~^qN!V4B6wEn=a;YWPCG<oSEg9-ih7BOANT&`N8)uDGt3F#KD#vsEMtoJ!4Wb6)snceo0B8qn<1jP)bS{PwGf8P-fbmAcWXs-pa+tJ}tJ9hF%V1(OeOJ4#R?Iwg;+Rht;0w!{zO{Fh^mi!fc2A-7B{4=S<L`U?FSYT_gB(6$b=U;CyFz{$_k5n^>4dCV0gz(k%6p-H@rQ*+G<M&z>-SaWN*bG$kO!8%jAu(SBKi*+7p=VloI*abV<Kk8nsX-O0l)04#lO`<@ZM)W8gaY0>N+2F1-VD&H%JaHd86l;Z^(XVHkciTT#J)M92Xxg2mVhU|q~EC}=u%<@E>E-K^0bwQ6JGx;)bP3Kt@@spTBdKnzgfD;wv8~6}X970bLFch|`45}u(BjqIU%v<QFDL~ZHk(X4r3Jfua_TT(rh^p1$gF|X_6bALpc$yaf)}s4RuSL>^j>Snd6H1SyRT|A}7_EdG2TEZy`cN=ZWZg1?6T3d*UC>-2s!Aa>O6eNAV+5>6)heTE@y)23Vp5E?D)m>od-ayUnvf2!#ny1>*TZYjm}_{AZqj@cVT1kEBW#T^cZS!vfNyEc_VC&w@bjND6#z9R6_7p1hV%fl8>fhu$<dhbXB$dk`q9>Zg8!&qhz<p^HbRL2T=0yU09-<flV+Zc+-zIQN3;bAdZCVqlaQt%K!=ES%8b+aDyn79P}xKV=pr;!kSstsB}!Sv8o_X;a;Xy}!6cvZf}2GkDaIWkwssK4N8>!<;0(dX+NimUl8`ttptD(#I!81>fguJH8z+h#5Xd{buMuex7&LYkGl<5hla?n6b;9_Z>~#Fz1n0oJu)`e~9<=erwG~cW#H+&a8!!QKte={XNCfTxh;bq;vm9yAG|uhR6?N7NKpk`3?Mby-1`42n(q*544@TO`T+NdB0Z+RiOOh92nKMiSppY2y9vpg<>IJ`^sF?wzx1}1ck<uIjCWb*SBW8XYj#OFnV&K^-J7{M)cx;Ut2HG$kd~wSP!Px@ABv>Y(W!b<xPC($uqsf|kioBTlV@e!PH2XAT>@kf`xZ1;mQn|MDxdY7|0mjYDIxiRCZ5jgLK&WepHZ6UjF(L=Z?!!#3^fz3`nv3_v$0*qM;lJvu_^(y3j-k4?fs(lbA5E!N1Q8wl1zp^e6iLW(LLLWCPoy#bRJ_ShKqR5)YD+@)*Pb{SfZpipl&L-f&ZSH7yajFCDx5j=Z13Qq0f79lb}Ijfh;q5bcG<dD@3Ind@|f>To02sGv1k>HsXx`k<nI`TS!DD$WM4lWyhxPqn1t5Qx(e_B)N;=V(!y^e6vvp|D}|kB&uGvZl!VV3ZWZPdlsdUhNkC`*$&XG+JOtfadALhSOiW3XGrY=i%XNkiHa$Y`w|!bF)vP_d=QNuwCP9Nej+M~7hru3<3FZJbRZB-YJYcBWF#u#u7avNMwlPA*2SyDP!hp4z+9&i~h--*+WT^u=kQ#aV-$aSHF-1&7ko%o}51!#K(k;Zj(k;XS)%8+RwmeKK&UoOEAYqPCsYIVrW6;b;Ceh{=j$Ih@^Lh)I{47dn%7n+yIkjP5H|DVuiw2l8AB057$X!AfM;1e<Btqd4N~jW`i^tMBV1{v3qSm3~W)F|8wFssNTm?1H#(U8Y?wTRMCxrBR8BC^o5-^YiYQ-|IKOyMU5tS>B#1|sGfFp?CS&s(a3s)O`d!_L@er1D1M)jj<+AxHJEG*~1h}|cJq<fCt0eXZ|vz~~6yI=>S7J!HEsg~5EC77GP2dLrC(p)fcH1+>8ZtgI+OdEx;Jx(6_lRMyy?2y9<S4YDFbAgpD*!WCj%aDn`C(K3&cIcvP77rtW7{7%8zZ2{(0Ucm@vd{&KZNpDc5eQ%JyAR8?WihFkX?$S8Br22j5{Usa<*sKg_4NQ<v|;?wgPuoUyPk*%oVh)d0q}>Yh0-y4t(LB^4!lPg8F);BXe^L!0I6`-8|dxEVlRdZSn_3>12c^_kkF4P(#ccF!X){>ifu*&70id{i8hh(3Y`em7#p3%PCbRHYA^)<G7u1(Ae`Tpif$+XIVPTBAxxdNor=i-A8CK%bw}}4z?W(3k-oki^8rI)2Vb_VY-mYH1=@PpyDDDnN+l9fq{R@nVrD^8*|0QWG(8tb+CzoP2eMt60>l#(Ow+I3Hh5&TT=*as9Hps2L-KNv3EL%^^qfeW#L%FkJ6HyljW2<IAXVU_InXS3!N%0j#GKHvOsLiR1dBlS_$o9|HoF&@s0ki-X7PtA@yd{0zeK-=*iW4|D)I<DPAXUk7C`2fOYJZbMwbvIZym1Bv{eKaG;*XB6YvjGXNpMn(<$g#{DZ$oW}@s$;4V|w976N>11rCnvl#x*k5BADn%y>90zgtK|1*&}I5_x4$w=B0Cr?BeoUUFYa$quT$4C_n|L&FL7j_aVOK2y#lS!oX3X;zVXyMD!olnQ8rAh<iz}UMzy+o*CqklUmRGF@hXhW19Kqok;#Qaqzc^d;m@<K;>p{cu|%5Vo_wpTny?4==zwSDo%a$1MQp-23XR3qXU<X1uRGO=vwoEa>eJR}6A>7|$<cIil36IFVoI-*x9MFwVF?U<@cz2^V0C>-eNjz#r7ffCO=wFkPRQkblIS~JwR9j)i*@Q0w<<7;3|?4fU9aSZ3E$A!Ggg(0sqax5kT4YHZyvl*fYxgz6?NNB1=G|M<M+i-@JiFq^7rZ>;q{!K#|A7BEG3VND_H%Bewg{CXk|4SO_URMP&&s?vWw;iKnpYp8qg~RHg)ET>sy|_n~PfebSNL8B!-~RvlTGPJLK>T)Q{^&ub*C#(?yfX_$-mL<XQ~;eqR{`ba{P#>aGjQc?DuCrNO?4fu&;Nvk(3>hi2>c?vz}1C%n-;jLfa$(Q?EUk<eCW)tGTC06`4<&0_Q~H~nf$N9Q#ARp7XNr>K3uv#^Rg=S`NpW>3t=!wTt+4LQ<eiio}%!|l}L;Hi9>Eoaa07x6!lesIkIGlkF+U?{E%6@sz1~G<f6yWXAn}bTs*dKa<rpN;Xxm?Krne~HtPdTWY6%>t_PwOBUfeY9?ckyEY8PIr*lRfS+{-Yulom@*Xc95@woK8Fr1vDZXy@Eca`)4-Chv&vct~w>ft&$RE)8sC&=>bwGwZ>bHcIO8uG|ogpyuESX5B(%qXN+^_#h?V2k-{1YtaQEieWbg%WTm$qEqCBdU9ptAQu1$;1HhFvxRa^1L{_ze=FF!9tiN-0$hSfvPkHtj=y$vS1!T%t3S4G&#Q<v+%BcPJ8LD$H_d;pXsspz1C4-MU}n}-FW4~E;RCbK<2Kpa6}sI9@gf01q#3|4$Lobz14~2<m*p20!#4?bjHFbl9Yl|Bt+O|e`k$N@p1`{6I2ea<hNdjT#pRx!jnYd{W_ygTg;!&A6cJIW`<pj%OMLkjl{`Ck|9Smmt6+nG&nem5M=Dz9$DH&A9gu=`Qpg(qSK?Js}f6`r8zMHIG~4zEUbp@KeC*DL0Isnbf5FkoVoezX7s+Jq7RSwQ_y`#KhH}Dj9;65dDt`M7yD1#9p67*znN)EYiim2+&#J_zjgKzzax8MpJ_|meTpd8jMpuhxXwFN86+0iDFc{y1e(t=tO#Fs{{QqV1r3iqN@EXa6r7t8n~riqI647}r&5Np)+>;EWjOj^EVp$GgSJONrVdUVkw}s-Q8g(LfoE~<n=x-NGfsje+8(hNmfz#)9mvpP$FIVl_v4$=MFB+xX6mFm12RP@4(~2AD=qNTgV|_-sT2Gu5J@Jvhkbw6Sr%cRfYQ}{Rk@9`KV)HqbQi$$EGjpL@0(OWXrub8W=zfk<bE%<r&m}GmI^(ck6cnp9v_fMHaRfQy`3_1I$GdS?}u4Y^ZCfgeT6UD4$QCiFjy9rw(rs|Fv(4~pN}v;6k;D&1H$xzeLo_R^mt6?0vtf{-BHIdbgSI_Y83vR?A9RJXHE}-kn?y<UyuVqpo_#cYIj+YXUwKz5rg(ya(=$}8pX>19HJgQd*I7v%FB_E68gqduUE$;JZ3p7Bb?#;CH&96qIpI>m3L^KBRCe8=(I3xjLVMEM-*CS*2@b5m&=1xCYB%%gwYL0d9AJRTYNLIG6Wjq5>&#`kmARPf;+>j(Ym5Lr*ze9LLlUwiS|k2wdyX6sAz5M37>6)hue}5ga~#QMj`AWpRqEb&V&Gf<-#}#1yp9Ihy~ikV{gh++T&VuOx!QcTD#yA!*<#Eexk~Axr)OScvONnw_|Y7pXt)%Xu$MqUrFd;W0-q5y%72b8RqzAA<Is!*m4iwMs}3OK02goG2bauz2ws|?FdU@v6v`RVlNdkVM@<{v=CJ}q{9xQH8?Iy))##9M*!oaXA5%PP03~fqG^yz%nCc>&u;RWRX?+49S{iV(<Rgm;(%u_2!h1zDDI_rZBeDw1ku*%Of?QVb?kIYM8u*9$gx4`h1~zGA4&Ef3$o|s-;w>_4L2#OkF2K2U$>fu`AK2`zEU-fS2B)+TZN{!?f6@z{vH3!pIUdTUS#}*5USm$Lh-~k>EGUy^uK2O3Ed*%_HETPFLM3;)tK?m-K~-rZHn@PGXA|1%P#(pgk>MU+%h(NH&??YyvD?%dUgPe!-eHAFbiVbA3K5;Pk|=IO>xM>KwQ({uKIL!)xi+Jnh=M>$~P|^@!3m3AbpdJVAvw*xd3vK1m_p`K}l`FVZYBYU<C+PiIK^d?LbU@A!s$<7Jk4Sk!SrJ;xAoMsxazc=u@j72<QO`0gAM7%dvw{>y|M@K}!iCq&@7J5~1lF+ML%i<>c^O{^?a84uOTu)Z|I(IbX{^C<R-5xk>3lMxsyTT&Ejm6@o{{pj-r3atG7{n=4=2CYhrC>D?}N7IO>UzXU^4EdTno&gd83&3{1HSiLVV8UY2M;nb^&Txxnfk+_^d>c@H_5$%<$u-LLv!<z`|UU1ZzeiWac8zJ1iTxj6xbl{$3{drj>G%l&tbQnCnjiqwy#tH;v3M5)%5ztngT~70Kf?`KT-|ln_!j(lWlID4CpP}1_b0(&mdBz#($=TN1!A^lxfIS?0MCo7s(3SIvi^%~?<w(1(36cMxRV$n6sM-pwQJ1V5rc69Fo;Pf5hWNRDf(hao?}*NxA&ZNk|B1%(Gw$ywQ1dx!rAp2plFcNkT)+~sjP|D{42f-ss)_QKcwsT^AF<_*<qBjm@k&-vQ7o5~{hGCXP|dGdR2wDcY+gOO9a}&-Vzvv-$oPiremB10Cs;WH`6ZH8^^PZyuRzK>(iI4dW3R0k3zS7FD-}!ZyTp6GLE<1lTEM7KO#T36G5Sj^i-aKYm0U|On1+Q9dE6)>F@;~9l?K)q2rUUOE>KYOpr87oJXh5L?$>t)6<OUsg7&}(5?HlyC9)CJuu*mJOQvMGY;Jg{K^%sx9El|IVMdYaT1Y@rJE=5|Mw@hHX5|(m)4MG6eAPEm8^<e&CL%2U{VmDCH8+0+#FFNNH5d%uaJ@}_5Ie%jZ=Ao|-4S4{I4cJ#uM7c<d{GbUI2}1W`{3mDmHYz~s0ax>RFnLGw!uHyx5<9+prUobD_-6v$q%3S;pp^eLFHIl(lY@9B>r@`AH(<IdhxZRn)_$~f2Ri*S5&qhB?JFVZmI;4LgAGpD^bKCu}NYeB6)}lVP5{k`^o!WP~Z&8kzB3JdZYZoz5<y7ys-6@77&ox!Rj?#OKDOjNMnx)APPT~>OmbGldUg>qXWu>XL?k>#4yh<x*@wf1!xMqW4T+*!Ft9+7^&*p8D>Kv9HIT!|FGApzsI!pe1l*n@vB(ZyciYKx^;bDtKJQ4=Kp154{xGs!Ap5(TK|afv~mQmcv^tw-U_K@#roT=>)%2OQApb7HHFAJK`g=!rd?j75Q(-dD)$<}O933DmU=RzcKuGUdn3+HD0LgunUVM)4qZIknRaz!Wk>c9rLgT>cs49O*a1Xg=8<p(ptl8{l1tUnN&jfeQi!-prF3G_t*m)M6{jXguIpKgkFyk#Q|Y<I{>rElFM9O7zQRd#5W&kZ8;L`_?!^!Teqj-7UiTYG8(fqGRJAX3oPxt~<Yqu!&?nE=372_5lmYw;cu>C>md{@^wpJxJ;4wmpeG*jS>GY!qgu__YDb~LHNn%=(EW9>j7XWIo<|M+NY|_k8SQXPy<}{>T%-<tgY?{pIb@~CIc2XFQa3*YnPq{%|a7=`SiWo?!<+#l@lI8CNEY$azCz>9y?oCnHNb?l(mK8Sn5!m3#?(LW_{U9bg^$W<-&;1v!@y!1G?A`nUH{RgGJJ78+C6%|{Adn-ZHjDj^Z%6{JC6co4Pj9+{Yc(WlN05<qM#Jt0Zt#tG(;D1l`hkFbzT^NH(@Q6i6=y(rx(C>l9^=iL)vw}S&#Dq1yH|;SFDn#or`%Nb%fMpEpjY<Wjx#;F)IGX=ujWtpiPF`bTRbGIBD`ysbVFT~zD0b*zx{2vf1OL>HTQ4z{cb2E?B`ADoV%ow%kOgncVfWAvwhtO%uWg63mP-^H}nw6ZVv{8iH|L76Y3g7NhJ1%-67h|j(SRzyK<s8_~bREBY2R~d4Z*pI2BB!Y!Rq?x`m9rewos7%V%5Tm&%WSKm5N}Ao}njJRe$e;3PWsVn;prT0L~R;rVFy#n9{I#Rj8Sxa=Hw(XBHEO%WQpo6AuJ$IFegE=!~K3UiVhy`0)MvTgLzF+DsnT%vR+0YcLV$f~hF#o*frGr2T8nCoQk5uYQeK0Je%yePl}fHwuoTdkL(`pCCMKv&w26<|?`eppnCyk$lx->U^?-Nw#zT%82eYsf?f^EwO2O13=(xmX?vLS6&cGcYh{*5+McFkb0*uLL2l!Y=?k#gsVS)=Az#G0Kk%g!NzEL5#j>E*m(d!<EaXydmbUf&fywsp@}&(Z;4QBzL+I@B}i~(o=1#O`YOhCI4GgldGV4VW=iub<_~V9p!AfVzhZxz_(Fy2Xb3d-Z?2$B<1GN>1?X^!{~H2!<}ePH==!F$Z;xJEW^YUvO2w`sbDBJxwA&4l?hi7i3F>LEdZwM8I(4>Ak1B<a=B%U2OG(XnuxfuciESq30QW#ohU>$?sOM}U|l-McmKn$kN|vq^w`YuAi%r_t;lbd(>Z%*21Uv)&L*$)ejzC+h>0G=d=WkUmEx`^+gbPCH65qlA*4@Z-fr>KSo#nbC$w83T{%98n=Xn1PmM7glLI(F(z>KXZy`M@LT?XV6{nb_a{i*eUAFO1#R%sLw-XcQs*8`EhJ^YtcA!Chq~S^yBbd5?OT^xNfCNfJnU^Qn<+DPNvkLV@ZEY?#E^n6lpxmX4OX$)WR@;$T5XUKag?j$?+&2FwUW<a-Y0U~9-R-LdY5z(P2DCtnZI8(}$CWh*(;iC{%gPd$A)DbtO=Jq8A7QeSlIh927iMUvoab!=YAxxg%51GlCJ5MP4lg-5Gzb;9c`29xqQ^vnnZFLm7QpM=@_olJ&op8lB3i}>?L=Np`P3wJC!4jG+cC6P7)ho(Z~s4w54Uxu<qBchH_C-bqjNf#3=d|tU_H7-wR(X%s1RcUkv1ZN;le${%^sksC5r~rm%{Ip2eCadbMP2WR7Ph$G#k<7fBzt*?e^hodV67umJd+f?d_@?b(AfraOLAvHv=<x5O1jN)(e3?Onb{Vam1c$Z-Mi^f&%vl3QHo(+ZA~6a`abO$%NN|k+SDJU;t#gw@nsJQB_q)(3tId!z6L$@uHfj`N~Zuq`^V382~&8XJa9t;u85LSM?zF(bW=R;ib9CUs4Ox`jF{C&a!XK`uKOThzzuYORWDi7Y@Z;o?QE2?fBdVmVocG8SVKyoHnBwQrrA#4QBbxn`q9sm~gUc$_9pewXm0Kd!$yJa+_obY16-C^sSf5CeZ;QdQeyfQWdNn^pyAl#+l@WEQu8#0ie|#_BSX9bSC<j)F7rBez>CzI%7FAOR<sMn?V|GOdfU;qX=b);WtBog)4aY88mcp=zt-QG?#AIa#BVz|6JcyEJ&Y3v?AiRMHz45`rCLwepUcd`(hp+qaxpeC_$avHw%l5(}=4}T+_1(qr)b!;&2dkE690~GhBjqKS{mr@R^X?M7pjGl*<r2FXlAMjlhNGNS8Wz96xOw^Yw+q)TZv<<LP4V5gs6(F|^P6la(4#^=s8J+#Br<XeiG$h@lSGw&@dq%)D}<oDR6CaxwIn9K?r@f{b(5o?<M3O+6<ukTglX&*CPh)hr86Wf9{IPm+^WgpM{P>Ew&vXPoMzXS@AScLdIQS7i|&=@?hq?X@6M>|@THlf1B!z;u;JRp;NWdyn5Tjg`Hdn|=8GYn|Gek8!!7CubD2or3y&9oCfG!Y*KgGoBpQy810`hZXl6F|k3*Udlm4dPCmZlc;Q)RXb$HBz6znl8N^z3N{83kX?g{JD~v+(jFj-Cd9guMO$scPM-3EIn(yULS-s*gl%EY91#!6j+sut_pvb5OE{MeuY}ZwqOFH5%@_$@BX+D={Txs<cLJM1YK`r{c=7iAUVXt5^bx3DkY@~onOE66vy26WC3PT(oTn382HTV1EU2^0aMt7Kg#RqjHzz`vG$g3)^9-a^-X_K7V{K$rjzIa^ZJ(yRb2JTJqik`Om}AY|s5e<Ea=twYjJY*1|9tp;XHhag=7%ggId?G=bvHY|$tqcnc{w0Bj-~LZwrXCFOrnLDR(kRNj)a^V^Z|D63VfAgGK++L$?ZnCZ?|`PgzHasKSe-omQ`SFT-aX#;rxNfaCIc}CJ%yZ!vvh8|2ohR(9_@aU7ipP31!Rj@0>oxB`L6iY1E>BzY~pWV_irP3s(BVHa^CDbDZmJC$|H(9D}Yl_e7{{lLHKd!YWhW#TnaFth7sCG<3E@nHVF&@E6uY<rlf@*WZ)6S@aM2=7YK+sxwCUA3ijifU@OxM-%SCmunoM$`XA+h?@WzuGc_W=Ww7IY6p=GnkG+U<{my!CDPRZO&%E&k6mNF2N=&HYr-i;XEF%q*P;fpBi?Ov(n+-qV$V4`D^9#II@7Juxj4sR$)cdTBf*UVBsa)oW14Cxw-zTs;=N|cvqxm0d7H(lMAy~aq_7{-m126+himOPRTNYOr9E3Gl1LBexF2to(O-s%NyuFNm7qR?&;VmBTh82~i<Q?SkBMPQrX$mmr9q?%z%VnYR~d`^N^}zW>=18raIpGRmIDED>Aj$Ukp<9-5roblSsm5v$FWBPpODQz#Enx~Lx19N>`~aUC5W;SX25Xmm}P0nX|v>3DA9@q*SndrbEU9IDfMdN4bkYzAtyfA8T?=59oc(;IWhQut-PODPB0;k05p>g#g@DnJn{nw#c7r9l6owvx;i~X0hDa5Ok4UsHa-NFF{F<MGl^ACZ0N^q=D<Y2fWm6j4<W3BBkca8cVZ#lk~4b~4lzY_U7ZwbW-F*dn+#)FKtNHV4^>*}JcxyuZdx1GqnaAhLC9>9(0Xkzj6HZ7SX>;sh?zM^RSp0Fs9ld5hme{g*Tv^Qku}I>3Jmf&s~o`I*@Bmwsa>a+CUHs;LokwQuXG4x>1FQpA#h|sFE|^-kO)pgYP2KF_}*?zbR1aSBB>^WIB}tew;sq)q0|M18&_`P60Vf3iL9iEo9!ZDStxjbg<SHq1i2Wwthu0E{%-ion5eD83+kVMgR>=nQ<8sC&|KCnMf>nQa75J45K%~)Mes`8dq<{3)HEpBXK}7K4)xWn5;&m<Ql^zVtA<x0yG*8-Ui`JF`k#?QbTcK*pFM~f03$NIG7$;DLr5Z)au`Drn_X1&E~7apI~)<(#TafHs&E7Fg9a9e3zMFCipl^f>0r~GMdqZQI|8z$+Iz}*E1c4M7A0>eLKGD0Ldn#gND9biYq(`KuS(O2ZgKY5XY5EgQC{p3WHWmjEDwoMkE7QQr`#D8Ghw^7nopS(c`UWw()!qP{K4Sw&^x)kkipuk5_6|-9)(v50Kip#jx8vvRz&j0cDbT>E>573#Lk`RrQ7kR6)iz63odT)QFY+&NN1+j*ZR>hWLAV}<{+d$>w3oq>SsPU4@*XqN?NIxhRiix-wl~75;tE>m=%STZ;;zpB<`BoV=nP7p~ppMxn}cjBWBAh*;u7w*|M{ubcuCVm<C%#)g7}9%eQ5A788(vwDkvSqV>R6Ve_q_ztC%jr7zBvUD<@M#@4*#1E`ynheNusuz;9d2kce>c3V0QH<;bu8iQ9TWkR-;EbJd%eE*X_zuKQa8P6Z}pFbJlpN#N79Dn{~D1I`?Kb}9+H}hxu3cJ^j`L+H?F8k~L`7Id|KM~Y#act{1cdq)6^4O-2-nYE-&yU*oADw|s@oW8=zM((s2miUUJgtA;URC3t>#y-6{=EAfKj<@qvf|p+hYxuVrM~0KSATu`dwTu7sE1YVneXg>vemMGNN%FXn-`nI*8XRD<K=Cp8TisE(1hqfBGTT$dQt^VV#;q+)nQ6r87la1Z&&RlgV-i|k*#uAo`X*}K#SbF7pXorUjZ1Y-r+I4DQyQXdcjyi+ga3wtA_Gs``1sW<Gl8{cUHLhb?hB%(_4<O-g57|axbY$&Jl!>=@B62QLgR4(`|L;%}cn-wQAFogMNJG4@-FcuKTt5H*Z|3U+{X@QCSqH<#Q&yDC9@Ey`*sSpkIIW@mvocRi+#7#?#-^%j<vhQR?#ifV{B0w!86)&*%lRzzdFE-%OlD$#<`;K&{3^om_6;6Ms#P74koO1pEH8P@C7iZr?-S{{26-*Ef5yi<9oW_%-^~y6V%xZ*B)4@*DTKjzA6{eMY{&<EQ@6-~Q|UN&9G|yODfxov%KrxBc3#pI`i>mv*@o30<>(TCYLXm+Ln1X3*~TedB2BpSP!e$1S}0Df$ykFK+Yh&-B4#(%v{-KU9jZ9O3$_*r9HQPMYUte9}5@?;6{ik-r{FlW6Tc_{N{9|B2kmUHbVyyTe62UpWyP(pKe^fSoJE$Um-h1~b>s#PBy^Oy~8d4Z1ol9bE01V-Zb^0T^(uFuO6;T@vT10OoiR{)>qJoEL=ti*4grC?w>ZIV+3sDT<q&$`#deWhC;VJ|H!FB*H0gNRwMh(8g3TK(R|_D+D_ZTe4<yV@*Kr?FC3@5i#=?*ad@A9dE=MzU&B!fn)@PWfbP5?WYY3{YJu@>W1a%>b**2lAuoFPM?ISJ2(yj{9gcUhP+3<c}i+pmA4h6p<FG?mr0ip{24tFi#~xvm~beu+aPy?n$EGpyl9<TGOf5M0;<mT{wI+$DslM%%hS)qbX?S%q12%)6-Wa-s3(Z&^Rtr85arFI_tWdNTq!@rwNZU~3<tHGWf|5S^6>()g<VKLAZr=&G$*Do2kia)0Q@}$zz(+0#m46m+>A<d4xC7zKcaFsJq5PQw#&?4{7hC|unzLYiKt0rmBKmZ@3F8yK7;h;yX-3Ac*E$Nk3vL#L1dlS5r=;eUJ!&_-p*$~kr5<2RFHHak<_33^MY|Ycatv>q;u1^4W%<8Q$@aPwH`?*yrk6aKVo+Pu|ZFyg%#Z`I(eC}UcIARXX@ncgLe*<p(#8i?_SM})$ubrV_b>7*<EqlDcwLbS8J-}PPq}To85knz1NTEr{gVqhhxLYHgU6AOgA(hqQ20Uy~~R?Zn{01&ZWK^I!^9ewwvRu8|2QMv2t>h`($drg)AUpb$->P<H#Zs5Y~^zLuJPgIMv6x+1)Xtb9<zIkJ>EVoi|-MKcdJ~?gsXD`>UgI?fzH2LtJkE$Jed3cyEmyvckdh{vu|a9Ihge+X2Py0J*=r&;s{5-ql*<ch*|;GPy*gnKJ_PLJM#D<=?YW_bas)_my&$%mMGNwZJw?o4=*jVt9YCoR8J$%usp7V-{dYaGm!>7b<vijxeF%%1!CT_<=yUA)Qg#6WLXsShx@2-9~Y8I@GuK+Wt0+J%9E6MdfQXv)!Eu?*qVT5WR+^e3lfWPZt5nhcL}A3FvlXP~n7HzTb7zIuPNKI*}{e$e`cser?H2?=;`ll@~Uf6_P;#m%3-SyS1MVJy5_K7GkYBvzY42#|Bn*4=XekoC0oLW_HqUYSIoo(|Cw&l$dy64ooT!;)gd=E?r6lm(>FSa@n8uPOMs+bS!cH4B}?K=;5FH=BRtvwr6&rVqFXO`6yuC-ByN+)ADqs>k-(L6g{-+_yH_x&*_KYicOz#K49>k)9IAvieC@U1pS=SXO*lzPvRFtqoM`mKPbMpi#_}Tk>J06<x=~E&g^%*^b@xWizh4tc#eJ9Z(;h3)GAe&@o+K=iH7UG0N8Wl-7Lr09Lr>PNmCP`e6;umOdGwOW7}#m_x>@JvXxXYv0(!kF7>Dx<YtvE>SnI?YPya7TqIWCkrGC2<NYkyD{W3rwIRBj9m`n8OnnXpF5t2%`Mph&CIYc$$Oe8@J4CzFv3Y~Om_#@z4M|Mj#IiTGm8!CIdf(q!m%-Z++Z2mvsMazSWrS+-ZVLa72^^X}na$Y<!QVjm%9yjv&IDHj!+>^nVKG~338Je79_mq*YphnV9roEt%7N&mNq+EJkhw6@F|jbQc$@nUi_T?Bio0$)n24Zz-VAy{70`MlXy8FcuO`XKagBf;rSvIz_29xDP>8#2Y;e5Ef<=q$5v?3hS%OCgxDhd`@BqNj1pXhL3x_)7S&e#0OFpP2knOUd7+_QK9t}O!i4N~%UGoO;xMI7h$!mSt;xx|()|<$M+Ivw(5$hTi$8?6Q9A+m^YNIMd^75Nsp>F!qM@639C#)h)4(dqDB8+DY-sw>Vs7b`hqV+!P*pezayN2+BsyjVgFk4PM^7-tg%4Oy6^)i~6I|cHisFcP2&J&3--4qunLY?RxEP<y^oSd``dj#iW=ao-RbXC2QDyNG}K<%6eyEDC?bY)4fA!ldeEWN8L?D(Lrhjbv-dThhSS|cYa`Q2Gkolht4r;(hV*&BMyzw2cyh113q@DI`G5)Q{!ea%Rh4@ZRkvRFhkONCc(Dr20IxD)9(qxzS1M10<;`65z0_P}3MCqIr~6X9J(JxEchUGRwS4tQ&IihvGTf)J<ZiM6B2VQQ$LuOS_F^q1s7?)a!X!TQ9}Rd4ci!cux+>|AX18~V%Gg-32Z{ykH*@It-mw4K|$-7UL#sa4&H742Z*%=nTNOU|!cP#$hm27^7SJRxJ>c=VNf;1r#>BMSgAZ6-FGvxRiXsBX4hHfM%`Nkj#JcxQc0ok!Kn>qC6av25)8n8$m<N%@xJN*#GiI4QlW%@~uIZfPgIawx83l5CVlXg#Zy=;5dtU2@>6K(C=F*<-@J7Z}p*eYV$w88b(Zr8z%jBWF&H(ffj;=qz<UM%A6o)uRCeS#ziE?-2_g<(?JMPqM7JB@bF5T+Xh(FoZ^VN-?g)U@Lbe-M<4PAF-EXX3<`nt2x?wC#p&JJo61B=2gz4t|a!etbL90PY>>^Gb^;RzH+u_9j7-Ej_$BssU0(c=DtCGj;s6Xmo4n`+GjDU69}*7<elpoXS#ZrJWdhGq_=gs_fBK%38)tpws-&BqrThMIndb<BCXDIw9CH9f&kwxo^-V_))?v{x_27#a>E!|dm*Mhg~Q+fk$b0aGPtDGFTG)q`sO$Q-bvqb^-I0_-{Y`fgT96S!3UN8zuz6b@kPlr)LtV1AV)`cNAsO8`k_Tx6`dj67megKd+Cb?(Oi`qN7Sz8;SYf$ij?AC_3HnD>idu1=+~#aPEh#pGyL9+szcs0MnMAHsF1R)wm&#9DvBa*v&@+iAAM5#1oq~;-kQZe3_eTqU1ZK2TQBivX@&_`HG}M0WGy@w>=Bf(sEre~ZG$|r({<3)9_Yk+$0z3!@qz+|nKHRVSd$u9Y7}%*a%qB!BG}@7p+7RBM|t^#)tu;V+PKp6PDxLPoIP%bjZIDup^OWC9$Gvk2lJ&|%=chaUn8R<&6N^tS&vhgvzM!~(McB5C2Tg)Rj8LjaYlhGParexQ@Ct%T0~b=p~DKkR-1|;OuMyB1&i-?Ynux4%s#3y9Q5JCxiew2=q!0l5gArwk00cEuu%y5wB)HHJZ#+`(V+#^3MOjf0l$v4k~Z7)Jh2TA^>FUJJlJ*2iCu@F_7drF^7{C#(}8yyg{1aCTz1ZIN#@Jij$QOQn2j^((hIA$^bK-)#9i3s#nzWX)7201hVu5s1pBKm>2%)}=J}Ws+=do0$XdKg;#Jt-zP{N*{axH$Nlukh=w8)+eS`N!QCv}WrM2>Q2qk_{!EL0TkG<d)HJ~bvC!l3}tJ{l+ac^pCU7veTgG6o%@wmVie4)LIGg~W^`LdE0oeA&QZ|gnvZSK^!Rn)g0Z-0dVcOymmd+%KT-zZP|s@2xx8w-9J?pOP_J?g&B`!u+F)QL6m{W)`%XoaUr%k$11A3f@iEw7Hl4T<D%UC+zgANb2PTz#sNdIq~3%~4%NZl3&beeBn@x~20?KZ&vijZuK+QO=G5%*`JA)+^~D3#1~q5fsZY0z>Nq|DA7=@%Wit6>k}j@vHYPSRTlX6FUhSi?a$Ff6R1k>Mhanq(~bjb;7lS+)+XIiL68<&_W|Yc3c{xn7|T~|Ea3iJAY~gaU{9Q(VLSenP_XPKd`N+Uvh>YWH(jRgHLg_<SpbdwJ10-EA+$fv+56-c1p;Zyo8#W6)|eZ&Y7&b#i#;CkZl89wz9-4mujyq*+P={hR(hFNMVw~<aG0&yzS{#ClR?$-C-)@n@{fn{lG<5J-i^R-ojxdCx>h~#x*J{g*Pm%q=V)0jv+1s!=NCg4uhmNseyW`3`%Z9yCRqS<kOXph~dX-N+hYV0J;wH;oF@L+gwujiO`^tB<9Tgmp+E6(<w<Id*AJKGw;F>N_S3)`QTXQ-m5-~m479+PMs4wx|gKA64wcF^+YdA_t%t@w_=Xod;NN-s0w(t=Dq$9)#=><WJH+^kiM(aTR?zb*($*iWoR&;<6lE?c8v9B$evVy35ayEi-JXHyNMw_(YPE)=?7kG+B($GWgr<8{##Vm%9&<g(hh)SbMR#cHiU9K1@Yewb^|eTVn^so*3{OJnR=u(D-L?Q&^m|~h#7Q|fisqd(b(aEt1|w?bit?geqvxUMUu2*$-<xXx^sVr95nT<^RAFpWxu|G=dSI;DctTzd#jVIc$2K?Rl`XcU{XkVi@kodru?vW5uq0=Q3nSggAhld-iAtJaE~Ug^ODd>Ak-F79G~2c&kWY7AFPca!d&EZ+;Hm!VxC=+I`^!Coh#h9{Km&o<dEWM+2y9@t69EFal(?)xpMmKFEr8@E@)R0971XK&HpU;lPR2lPM0|<u9iUJw<Vm1-?xrdq=tk``3xc(j7RAmN>R68KxDSGs|GSv0?L~+q+nS<Ln4GkQ{QwnLP}>IDwn%hO6q=<o_6Xl)rb%Db>^TQqjI>W{1-B;eKNv>WpE6`JmtKAD-CQr`y4I>ORJ*?hAXtR{>~Mlb&E*(?kyH2k26!%82&OKMOhYaMvIY#pl{F%1M)J8Vu(7nFr_)#geT#$xVFxu36W<tl5@GR>qw638}QJ=vUty0wrmvW#S}OgEeB5IU2^M32?sTyJlXR(W3(zzENNiFELel*xJX|RkA3Q4JP(Xj(p&;jltBu*gt4OEv4d%|r)w&^$+(o&Fh8K7%^31pcrOM4NEY*HAa-B}bYw_qKg}vhr+ObqNx)S=bP&CbE*uM%-gD_lw17C(OWtd_!31OT5eAWeIsA7Y#adk6uzbgN$Gp%u>7G{qHHQc4c6gn0=t|4|(j2CS*mcfXVoYu$U**1#zlzzAlj}nXFz@4E?S1htlT?Re$O*ZRf6a`4ZPfiy%V+0-c!R;1yb&Z2nP~V=Aa68hFY{NkEu7y_e8pI5C@A-Y#su^^O)-Moc-O4RFW8K4`HdkyQ(u}vVoYd%S-0=tBv4-v6wS0ls*2eRevm1-OixV1=KuIgAoRx>*SC3SubJ5>Q5}uW9<-RDWiIf<lx77%4pdlCdwI6^q=B5Wd+;Qi7sC)V%u+mosVtQez~0=}8=3M$Me;=cNMeSGyV&k{)a;HW#{%97GE%vBSB~OjjARnYCK5Q{$hMwIO`A#HqyC6=nI38QK}$4ys_<P&QyJANy((whJey?(yDeh_O#v)^6Z}r3VY5fs75N;J-$k0Zyd-BKVmmB+BZ>=**@N>ZF<~MW8-noCN)rzdLJO|Ppt(-Y-dL&EM9#eB5ilTUwypz%B*Hvdz1)QIIKzz4>DvGHwP^nb<nBL~_CMXz{_p6_d>rk+Ow@4IG61=V1}43y1pqnx0}bUXX-MfU0MgrA0C1akwE$QlIFtg{GOzLfOI!6o%Uj6**>{iBx_0GTvnXFO|F3<J;Xe$F#L^RKN_YuS*JJ9{sdaC8bqRpr!jJ%xH9`3RV*eqq(^)#EAAe*WC;j!8z@z88fcio|V}W>P4M}~3n>-)gJ{X-tI0Kwa(XNkT3H3X$gAbP*AgLmsCZ3OM-L1ssnKLa4kc!^GQ7iqDgt8$f-NSqk$;Z^AwLC})cOch7(oTvSoS(gL)XwKVO9QS@-79uh(RWu>;%x=m{Xv|ZQGDTv?DMHNEuuo<Tv6&!2bs*>QS(D;jZ+l$897q(eBt-(`orZir$1#6VG*j}V6WKB(;Hw$p3vvL*s^09wH+Lo!?yF#!{QKEJwknq`9iZd1~dHPBiVX;b<)1kc{R1aF%LBT$^uZ*fvbS2VklyQYSbgVowFv-Q}!5ktD!T`GBnasPhGNSsTp-=I6MwV!1}^u`!>-HOzG^{S{R-gy(?#~R`hpBWy}WWaVx<=h`MpMAbfK2uF!T>b!}bvoP8-4<O|ES=@g_T7#*k6_^*BSEW#01$Tf?=mYwD*yln4IXT!T;Ufa8)_qHj<gAxhs)X7HES%DJ<|B^kec+v5ZDzI%1M^B@SB7r`l9RWRMg7PtXVO~MMW+YwGPiJ%%mqW1go}QTvw0Qv;nF$QV9!5EXnOr#R6kG7+nWDCv+8y&m7V6yd;)rVQ8HZ6K<b~e&Yaf*`c&9CWA4P_os_)=8Xg|YvPPfK0!^tIk7cRG%;jX@!IdE$^#h1y0_P%g(Ta(0G1k!Ldk70AXX&d*TGQH2-W&juwIW7!CvUzP1H|H9XQtS!1^}bShI2n!DOHqdrW)TpZLr0psHhQo2(92qa-rA&k?rrq`B2ANDz>{3$3qJ`F1DM~<0>VFMkvfNQU)-l-KOTrCyGbT0Y85Pu4CGc4vnR=q{kbHD)fs6-4?V>Fcg(5QUgDK#4%)9%^I)*n8E9mHv`EZXlwiHqAgDz|?k(Q@S3UMbjMx-Z(V!@oGCK?2vF{K&<!|x8L*X?Pvd3!;85k<HUk5Sq22pG?Sk9PJ;ja@nP<C102&;&9Mx*$d{uW|_X=v;X$z57+378c^V)t(>q5ty-SJDu}bX!TYID~N7lzL3gUdlk$q{%twrFb}IqCsurJu5GNNRHi;MOUJFAF`v9us*5xDiJs*EBa4VC4)ONqhTCln_8cAy74merh^K&I2EyD92Ig9PAEH$hdo7lnTsyQJ8ZgVBWCEDnVJh~5+^=shxK@@s&$l4SwGz1fmk@A&xuKb7Tpvm0v>r=TsHm5J;*7bkC*cBAl0cx{hQ*bkCd<b`g^(Gk+>n{uC`vh;=iW;fYvSn8X}@z)mXQ0(2thW+J|(-HhHtowV1|lD%^p<uEmc2`ToPp_uSv_7ni>Sfi)NUlU&%uv9fJ3y3rMi?S|f966k=-&8lwHTOhMn_J-dV2IJ_(sQl69Qym;fxtoG&GL-Pd0*<x}NEjTsJ#0^|9d^uNkP4vll)X}`<H0cM!o#M~JH>;%9o}x-*aFd#d@|pQ?TqOSVC7f93sEa_l&|PDAkez=AB7EF>$|$F!6dzxN+(9w2BWtjX7Jl=uQhP)p)?PujfB8E@F3;V34qFde~8w1kNIJhVvlbkS*Csn%)jLnujhKvWCDHHo#i1P@^zc53<j)dUC@Nb0gC4;ea)q^v1O31_B#K@l=`G+spz_a!r%_cjGZK6WD2n73h;E|Z(gDCCVda^C(DJY7u$ZgB8^TcwFQQm9qu7$rW0pEThaquO&Av=``J$&3d8>H4ZvT;A{dt-dL5dK`uoIe4V-II1h3)kEy+pG+>0_x_GRA~;THgR4q;gTB&4Wr5Y=H;&Wui0Z7P&>OwT=Wj%@JI(Y+bpHxUBNw!23G8XF+wzP;MQq^;WZVd`j?co3U$W||vy05cOpg{XWp5hH75;n?tb$=-pY9Gvk(*2*-h9RY5n{I8x1k;P%!`!RNubTm6V>&Z9F`7DQkHQBU+n93Lms;9?tO+JibRpDBqvLDsNW!aIgQy7W?c-Q+$nT@jbj4zETCT<T3CQ#H?>JcV7p@=hLdoycEhqYHX7ckEhs_LW)+2eT4flFcZM$BTxz`4{<n-%L<A`K_x7?gBJER|X3HR9P5oC^*``!*|Ay5$)sZ}aAT2Dv17;-j$hmHoXdN>P`IWwI?e4@yjGb&MKXuDdX@hK1Ktz3&BGz@UN+yYgZ5{4MkQgvqGMu?hY_oY;mTX%BFV!6uj-mA;M>@4<r0spnSNq-;&_I#VrATGYpeqiyoB5T=4YJiY<r1dc;CP3YsyMU+y^CN%PW$?7gGCT5tFdjC-z^W^ZXwn8;c(*K;RlAmRj&GufE!22wp!`kXfgz>*AltD^_UW3}E70u@p-Aw^t0kokVg%0b4(<Opp#K$|Zut6PKgTlLR-k(8zEe%CAp>rLmBRX&%DO|$vWt1lpiz9w*>Th8X2C7C8WFYiyC2dvJsOcO%U~OswZIkwXSO~(kNk&pI8%BQR7dq^Okx?)X3h3ftlgOxqO}L|kt}w1?7qL-6r$;($kSDS+Ba+Trn=8Xd)p3aMPyWtZZQ@VwO3QIhQ~&_5ay5$wCKg~>m>MtUGc|U1OUUvfDYg)uNrr5!tV5zteh8}n`>gaLXl9XR%d&1wc{<EV5P2up`8i$fU`&JJX7mdqSUYk^dMJxgaC(`dl@FRcVtwbjo!re~-j?h=>>FkSvB>pt+&$u|Nb;^`E<xywr6z~5%hL5+XStSy-{9PfpQzPvXS47I);Qc+nBQ`@1=x*A-wO-dlFwdmSp@%x_1bFmn7wMu|D-x@SsYNz49Y~V?uhAj@>*jaIB5McoIEN4*Sp3GWtVq*_x3%#@ga9u&%K%Zs~;VkdK5)G6v4wlgE-~cp4US@T~tWO>a&pd(enu2h|(-wU>DM1@)kb3Bdmt%!B8i<U#|5s+1$NHGKpu^Y#gEgO}%Wk>9GM<rnuG-h*bsTJnuBeE6}!V)6dSZwf1&7XJ#TCYfIq7ls;dAV5^Tqnpw|I2qXrq9n+;aST-p_YF}<4=kp+35^foIf>SEqIkTg+UySsB{-cUkp$h*;60OQ_iB{#;qE+>cXjSgfs`>%ZDjAwDqE-1OT9w}!t(xA5Rux98rXH<I9}=w+3&nlF3Rd7d16Jpbd~HI$z9nEKL}Xjytp%C8dGtfa>vZ6rKwsBYV3vV6B8zL!G|pnEFZ9XTe9rE<A*cn!72m6zwvJ4QliQ11AOO{$JD5@3TS_B%u4!ifYwB*b1!^MS7Fs2BiSQbz4P9t~%Djp+U!9&&ILcl#5<RpbWk}$hstC#rfX!<RGAU^s)zRoFb>s$vHkBw|@-GQ6HaX;v3G&f9C))euhmC7NQdV!N;Ph+0rU%cTd#i_V%}si3lh}FOHjT1|tK+3yOp1=V@+@`m4jn;QvM{E&4zB!xLILF9MP@m8UGXL;${;8KWp@y1&swiWn_tdkVibvBWj`7NG#gp!a;a<Z#MgQdnd!V>q&x<VY(IW*n||m#a$8Xs0)dHj96hM$R-i?T7uyLu=m}lkTDp>=TrFm(Q3P2Zw6sNs3iP(ZP)L8<bY+uSWSZp@Ueg27h68|}4TKCm=E8t3WclLo9=L1!P(P)1WBI(>*bi88?T$C(O7ezT4GXcdOg02{n}|jd(N-euLv%PN7&>U3#a_rm{~e&t;vQ2LGCW>O`Rdxos1ORCqhfIhL`Bh4#+8wMwNRmCF31skj~)Erg6f?a$qeK|s!)QUNotjJjX|VT)$NN4S5Mn}t2t>9$A=}LD*Wo82uWfry%%R9P)}WY97ClFklc%c__T%LHMOfNk!)uESqYTI*m@x<4f^7lj1eYu@UpYmStzMt3+H$gN>`N!CAuG!G|mbhKs@KD!e3k-CncQ_JI??8zQy+j9HA`pyO-bt-#-L@^`hZhaqqK~cdp1tJn+}oAXw!df|cF@!MaN)y@J0=9T`!Bp2^4Huliyw5{t}W_E*4P_3p!W%eU=IEH}rbFXF|c6|S{?R-nf%wig=Wz6UXL;&T7**Yv6MzHm37tbw^1JKg>TZej&ZOj&$yzSjR?s7U-PNZJ1~@+{ukwsc#P>Jsl}eH>IlPVnbQKt3L^SAaqzJv*AURRraS9YZAQ2rTvfC=V%<$}IHCFc4i7CBEtC!$k^S(MK3LL24Bf^84x|`;dDM0FHZMo2gR06H+7r&-c|Jdc()k7}@5z6yS*T%2ZTmYyE-h0%9}-0o@78>)l?RkfAe<uI!^8%p^rz3hQRcDN`5@6S%LWUM}cv*O1+@DsjbY_=hO1+%wi?@aDDHfJ#nFjxIHMSWR85uC%UDF}CB@mqoP%!_@y9$abQPJq}_^dE#0~T8Y9S4p?iX%Z_E)f|3zgKP>fSphbk(%@{?epxXi+5{tPK2~#@vEjy7RghdR0WIsRV3o+TqJm}557-XOZ4+^7HuXC4uK^RRzfYy<KG)8c{GXNI{6?{<8ysMLt=d>~5aGm506P-@R<-~|j(GrE|HMF|8bx-{uAn-WBzoS8l2fHX@EfZ_WO0Leilda&cu;@x^#_08SfPsvRks!wk#tS+^xI%$=(Cx3X;wkAGG9ww@?pYLzv>yTsc)2lXXh2`ooVktqV&IfoNCX1#wZehH>4*1h*WCp~EPdF%Lm&!c)!zyPq7dj;S$OfXa(?)R@ejJ!84b(1VC9d;KajhluT$xTN4aIrJH?moq_VPRP_`WmF(Dt;;>oDuN%|47zVITWPvGtq3^doSD2T~dPj$-VyvpUKq7L|n?CTL~Dck!z%D;ZC2v~CaA`Anc*aNm{G737U$hc-H3m1aOpki1%6fzuNnN^t)^g$fQR5*%x@-{K5GNF+*?s9~+x2U5YMU)jmhz-;A2f&>r7F>iY8a3NFCIw$?;|bY0V9D5_`oxynB{<)S*t~J)Gx|SQMU-TwNzf2)Kr1~r{aFl$j@%^!K(MIYbUq{$CQaIlrt${G0t}hLpe&0TQx9R-Aee<MhrHjQD#;{$VMEEKpu6>!nG6%kO;R&$_N;8YJT}DM;V#&e9qqpD<xEREL}x-Hkt^cXDPJnI;hvT?P>q<8s`g0ZfY5()cA&t<+wptoP!8E2yuB{1n}NEGPC;SaE0thw|H=yr*FvkeOdZ5GD3EL_0Q{}V3rov#?geClBw&P2;tn2he>+C=207M^?jJLn52tiikT>Md4<H079xG)F`)#T-4|2}xJ84h-)3c{J=cn`>S*L<}J~+u2JNPI_JW#36kAWS>LE<#iNU@VHXK4P<xv-Pn4fALBMC=Kpc4JJR*ab5a?C@%?#$rO)QES*4z%cROhWl6ymebgaUaC)+L33tMfCK;15#O9hTq*9CQ55Q=<DsR(!ZLPft)%&ly*zW_lIvbW3DefobeT`lgBLL?elg5g72z+|jyUfLu9VYCMsMfbJu}iFlCkJTiXOPxBsJAG`2eTcfegB;t^smWTQcS{swM1|>=o(mcth>Fz|M|0uoO3^l)s`YA8)!2IFPv?WJPLZMRBSqD;RVl4(UpK-y{B6iciP6o_e(i@M{@m{wWi-a_IA!yI<Z3@q2t<;p;1>tr&pAl^fRs2KqCvocqdf_UqI-rYtBk#FP4qpIBu^0oeWXj;H;3FP<b@8bSafZCZxDL~~AN%t=@?n3m7LRzdOY$PFrGPab7}V-@l&`Eta}d17@)J7l?ZCUl>lv9=&E_>7-^a3<Y`UXA%~bzKelhx&4++r;R*$?4CljII+nA<b+zeg<RpcOx*p;B|PSj<xTfpe!CF3uh0DolxLE{2a`}g+@l*XY-8^^hlg1Csv0fWT=N7GiMKQUr#JLDaxgx@Z9@bCsL*`7r-KnvA2Wh5sReabmk+cfeB+)F7%!!3^r)@vB<?Fx<5I1IUw32y$j);!5m$a8l<rF1P-NA3`obT>&Ryw^XIt+lxVO;vMN^y3eV1tfE6bSp-v-=c<})c^UO>4R2$13)l4>zi<u*kX8Y-kfUa<}6uqNatpYg$6@W_x4ZGkKSQ|k^XcD(DajS4F{j)l$0@p-?nptQI+T}z&U`>W8Gl_g8bSyEgQycSbkg=o;hcNdl8jb&E_)Bn2mLK*iaZ{Z~Oefegp_~vd0H)Z+Z+-@;!}CGikG<K($WYN{@~kInauyW$EfeP8EV}DL00&a5-O5sH*A})deMUM$SmvV_XXMV3ECHzp(1U(q1IAR<Ce!dQ@YCA?pzS}x1;E@3bEFxiK@;P)q-TQZD)mx9Qp-k--z;I?;KQVp!a@CkS<w=Eca}unMP|>XR6Rt_ds%s0lbG#pN?vS(;pAg44$1TnKB#<ff+1(KZqck`%<|6Oe^8t;yWOa$RdT9G5oZ7biu#$Xh8-rXktJh-xU0CH?hLUSz94}4E)AlgzP27n?Mmx<1upQ0pm2gyA&a?s_MB$-309Rw|GITln%n|~yX^+9&Ve2g1Nzxr1nk?r1c<Llb`?cKk-LKSMIC3Zr9MtR*GqkfQ)7_7^yP&yEoGUfLD>Sv0)brV2PD{WAe=`XomnzQl#gyLs^JeFklH|Oyv~OiOVT%ANFbo66NTI)-f5(_{3Tc5FWm=@-74uJt4xwvq#uA#dNp39I~{)1k*dEX;jQnZd|SRM<y(C_<y%`BU`A#`!`k@h!&u*_X-fN8*0=krSHQPD@EX4k@!Qy&)!*bw<44oKnOJovc^ik>Io>?X>Ty;a@%_|pL_J7U<?*V$H&%y+3mZoa*9h@vT-76X&eA~uJ3RcO%P+VZ%h_3L+OI)s5=|&UaGzs)qOf>ygDIdShc*mPP9w|mRC|ViF-<C%d?v`+wEa0S?wfWOhgkrZzhS8$(IoavJ~f+u>#&T**rIuCm9glhM$&>};I|bOG0DSWj#+A=@&Mxqfe-|ybt^w15lcb|jCXX{N)(=^ITwRBNpjG5|CJrnz1f()S+30<N@v2fS&q$)@Ceju-n(dyT%{u2JIY<NeP&*2?fCcq=c_loK&d|p#NhOt6g|vm(GlPDyhyh_FGiL62rBCoIIlOnpn1S$#TOs}?i(edlW}+$R<o-x_qsT5s9Y}9Cg^AY!>U`1U`qtO-nc#`tVuVIZxb4*YQlbPcYPTc2<4+FS5Kv_4JlrB$GCs*y)dqgAzr?(P~!V;8n>M(%3Y_4-c#d^E!SQcCH6iS>P&H^7k%^cw9I8D3B<5*ZHJL>yJiHZg6d1r-7)Vrj(vM4-5J($nA>g_cL(puh}0dEas!vTHpRI9xpcw@d8Nz$_<^*eHGV@B4EM{>GvZQl_deRua=!qjHTk#A9SD)Sn#(uIKc_gl4WvHbGLPa+ceYZa=33M8FT<%k_1n^Z@wOn^JK)`C{$4~^-;(y58Dnj#hW3P?mLWzoswR_@T)mp-ds%4)HmOcBN>Y_qT3xIuy-iS(!c_W?KbiL%SK@|0O0pe6$L%W4xuA^zv3TZ26=G|vhzyXpU=D$}kV)+TI~q=GjAC&sMI9&<EjtdRP9Rx0(eq)YQ->S9V}Z*6{kTJBl#X&PCn64J@L4LeTTlxpN1XkH^y{pEmFR#5z~wNm;9{_q*8JBpP&wH>ZKabpfcWnOW)cO}#mlt!^z5-N?Rha|Nste)i>Y@&L<1==QDRpse7{AeWkBUUc2Oq@e8%@Y&Im?v5rys^t{C>DMAJX}(Y-LvH>%;)UKl3dy%9#cX@n79G{V?B)G5c?ju_~IaUyH|_>jnJ;Vk+|e0a~cL2myzG6T5jXLM6b7cU9W?r^Dg@Z@p8zxkoy&qAxqwBIMBiO`+(wr=&r5zp~TdnWMr1dB}}f`R4^{W<tO46KK-g6?Fe4j10+hDJY|YcK+;yZ4$XPn^*2H(8kxx^N_CQ_=$oPE#OWLy7B$?5ZA_wr=G?2DRb9H;eWa0ea;{Ruod0!Ll&NcVcc%+^j1fh3C5L*MYh#*<^_uMCF6J*P#Q=fEd9khwl(K{6N+d9)xy&^v?`CLUeZ<<X<*23X3A!q@t~i_8~iycXT43`!)A%=;=DuMigMeCg;?`o=z}w_=BKIu^~u_`kU$E5Lx@;a1LLl+%;1E@?ZRs%KeTVNHWV-@+$X<h2U@WfT7ef@qghG${~4V8<@|S9Dc5NP^0&TL3rl?3J3+R$P)GB#H<Hy|Apd_Od8lMTQCgi(*#LD9_6B1dHhLc8PwmK=QsW@KYre(!1&$pF1z8I;cdFf!G80kO)n6>UzN1!4m6ZxIslg->5sQ?q2l;_aH)WR?KSJ+HRSJM=n$b2Hr?T0J=pRpIEVlbfrEbh#>DB0HU33<&QDm}h7<D-<Bk8UA_ipQP@aZrrY0UfF&_f{u?g<^+4>B?h+1ZN_tv$Dv54Ydc+ZV$`oy4GvuXg?>c|s7L+Z|Dh2##N7>g<_cHl5mf)f;a@ALuyOF!d~*B+Dp4QG=OshvYJ_SB9m+q&A89a)SRAh1j6f%yo8Hj9()v4RZd)W%yf#^hDWYaYl8v>k0kibDaVYt9PQI8Vv7<AOTN=hbCVt%&+Hi3!nZPV#N5XRm5yUQKXpjn-P=?8&p(i^|h&_N(-m0>P+4kmm5BwfIfd$knyVYF|M#bh>th(FN4*D0jT}^`vzAJu1mkwLSv5to7GqJL^|2lQDVc3SB2_Zr2)lPfzxm8_(Ez4}{D|<2|o#T3lo&xCF92kkFy?n;+Dj%K6HP%F5#(IHDr6T#ns!SOG_v`&5=vPDyzu8q6oMr!<zi&8+PrViw4tU2pJ11JCnRtd&UpB3YzNLpdp4lh^u7kfb)SwkgLoJIRj_Oa#mVBPZlr5&==aDkhFkSs;NHJpoS49C1liv(fwU&VemLc{_X_nLKyV!AHb=71k9LPga$lOI4_x)vkkg#R6WevJ@a^Pi_qa+eD%9z^&&wC8*W(vrfKNYA0uINHnqM0FTlLut>+WVG{s0a0(=)W;r1R1|>TkK99r-3mcTeDzqXZ5_+Dstz<#sveGBVE_mMo(QEX|@yWJ7Gb{Mf{YqZi01J8ojqh!!xqpRZZR}=1>m+N;4t+&SAl+L6MY1Mh>3d^feuptI=#s9Xgh35#<44&8Y)ZkNaB6iJ3GaH-B$(9-+HShN!x(_Mw;Wb8z=H^Edr8Drdv*2i+`je302q_}jVfL~67boVU7(<bu;wPQs--((H3l9_gFQV`@qOtfoS6EJ#`?Es3H(9$OL6#uHM&DsXr!c1P!KPOh}xoMCxg^<E$E#Y*<2Z3B-8OirzuZI)FWJI@mxe=Adv#IIaw4-X>LxDdN!`QhS3Ttlv=zW7G_#zx3`VB%#>QpJuj~kZ}>HXx?s*qZKc`^M@U72{$(n-I6H4^R5l!W@Wyn!xLp#Uq2nfdXRM+^RWvgs1w62zWI@2JX|WSnDwnuQ3OTD!Ox@Px@sy==S#N1492j*04q-$&71O%N^-EP{Zpm&RI=&}VG0*uETuZUW#5|1fLx65|uz}ph4jCmxI*Z6g43}ApARpGw`_3t^?0r@Ktrw`2c6OFGfSpQjI%b!~`s#KrPlzv+jeUM_FxQybyM_sbc!}uq$L5wcY#VsPwpn^+sm&(@#>~-6b3JGa>B8*V$DX`c+dnJ#E)^n5RfW{oS5~ARiK$1l<s{A#$jPk7jxryWfe_z;W$_uTHc8b@8}xN|lyT{i^tCtE?YjcvYzJ5_ur+6K28ug+juUKZ1gwU&n(LabM({uwu_p8FuREj6X9(k78D+LtdV>!kl{vkgR0fnFInN`vc@hqjTrx+ZA{8G|wi5U|m>x|4F`6r2Kv+5{mgA|M^<<~qge{_jXpnJ~xnt>v=pc4trr0jPwmky(n8?DyHWKQ57R7;1j%}DN1Noqt7>eEoooqpcLn!_g<{C(nttr0gj0vpH_UbtTF1+{(4_P*sb0Qwt4<kuZqE}&$=#$j>iFBf#tPx3$)~!wQinhim#Vw5yKJ+R<suv$F6=%lP=ATL0&Kf>MUd0LfFNI&t`4gHWCKM;gC<0~ZXKyMRYaqPOk-RB2Y#HQJ&)E7LHk=)WUkW5`-#<N}%+DswBfno4;dB(6SeczTvOMN+WKG~7V@`CIwep1Om%S>Zc^27`cBnaY<MNRQ;v#0VBJxjDPCw1h>MC{OE?aK%gMKJ6+S>O=I>-3(X@%>X9fgCK?u`#*UitIaF!--<p6rMwGGq9{x>mu3VK<N&fe~Hcm}%6NMngRnvdTx9VwGsJsfZtkr4pOG44jxls%%}9*2d~A)Tid8#Yk%zi17g(%aA$E48o~kf0sn=zIF+1h2M|puO(J+yR)g6?!itzFll4To=nO(^@MQdGw{`lccArUV$5p8v>T(@Fy=<ipU?g5!O4_&K~y_vv$;pp`pSso%xVv;x@7FwjaVgMt<JED$j?rTA5@}1n;bZ2_#2Qbs*x3kzv=MtkxA^oeMdq6L@E)GLef5H_l+ynbal?-cL|J2dD+sb-bQs*bno5UQR<zgh-&t0Q*|e3Dlsq7X_GQLNo0b*GFyAXNTr>zkY^b=6L3nBhj&?Pm<8L0SWl>bCB-mAmg}CYJ>i4lImskG#}LP!f&!?4#UaY<35n!NGSOzjo+HyQkBTx(Nop^Va7sYCY3<2b<1fdcf@PDyf%Mm3*f*pu8CXF(D9AhaqBpwh1Hpy4b33TF@Q|<?pH%{?d<(QCnf;iJC15ssyI&Dgv&wSx3@OWd=%ZD}ti7aH?+jDasB$1=A2MUjn!rz9DkZl(_u6fhiN`W}XafrCz{%mA2RR^r@9Vl&Um?7DZ3P(teS2R*mQLxdN5y6)SEuR<3aTDhP4qXThg1m%I&>Gx%UWz<*d*s%xl72p3$?s(p@w&o;P-57dL@_&3-oQN*mxUErOaNoj5Wj;30W^19?F`K^#EOYJtynvpfxAETXV9U!EZEvL;}S*gH~T^=WOT?h^OMGA7e-rqy6!jkp*l^uVqG5UB%2Cnp?>%zyO%nJ=MF+NK|Iz(1{_!HAO-$GYHE>uB7RiDUav$*@@lb2d|22$28Zl$dp9~CZ<%Lp@LECa7yO^d@5Dx64E#>7u3OTx#e;JSvbzMiF!C#@>nbw|Ngf%dqdB45u;r1+PQuRsNx+Vk$4{xsc%V++{Qx=_wkUnticdEH1{*vV<yC`zdJuNvjgZW0E-(`-$sd%w?Zp$!QK#VLQ&0|=!*I4p(~EpnVi$xXYzDAlefx@U?d-Y+{qEl<X;NE>w<fRefB|f`2hGl?4qO3Wf#!n8+kkBIw8vvN_k>%v=;K|EmVzl1x6<l$2L|Ru`IO&*#wSk%Te;gmAhbVDQ^FhW3RA4iuJhTrn@wqOOrg$z3!$nZe-y@I(=xNOGYm{DI#{%W~KMFwlnV8GRN6Gm}9SDV8o^{IHXDiL8!M*3jzVfiZR)gLqW@e)GB#6&g@fmbVlCF8h}OA`up%5+k+|Y!q&2t+`V}x)`h4BLhY|0w)Ime%wRoWFETmMo-LU?BQUuJ5x&s$Qs~6Zlg8#@g>kNpxG_Zq!l3mdZhn!Uu@^|F_qmErO^1Nj!srzPA*@@ZbtFp0i~<Y^QF6j5*^LPLd}apQfxXR9@4@Od+lT!j*sD%!FuV-}SI{U012&r%=NQIoQ%UT2V%wDD^y>vaFCsTET)djf(aG(s4LnhxW)e)3+F5e+wl?$|W2f*ST%X7fJf)M;E$j?49-(QMo9>V0jB-Kozh)j20lw<A9@&)xmAw7mR`P}0nKH{oPv{V>jtZ$4#il>F`Wy;cT{?kgBIm()({@=eI1pTChK^C)dHe%Po%k2za%K~2)}-FOQrj|Qg6F{H83B?2av0yhiBsy5#7#|R$1G~no1<|t*&~L!T)+1@T&eaNy|bm)#n$3Pjun||7Okqg13g|{k8kM>bukG&=-Scj*Ne2>8!G=xMx?~6Zwn{$LSa`F-%d2rV9T8|N2An>qU{oC!y*#{KXzmgNPWUfK9JwG37j!<<D^O@@ah&d$dtNlT*`c`h#?h;_ZU=$QPhaczMnCt2O1(E>P$kju8@_8GydM){5Qq&a8qISoSD#$&<GDb-z1^}$I^nKv5Kx$>~1W9h9Saf2|XOj=TW?roWoetNJr{LQG7V;ZI=ke6pb$dK1FRrPU<ZLWKie!+=S|}0@!1CXd}u?RYh0_Masx_f!Pi%Gc)dTh@Ijt!WlG8K?oAcTw5f6-Wd<%?Dbe)nTR5v76zsXQKHC1;7mgSUJDnR?;|aNMnLG8A$bqUi>o=)E4igAQT*8xl&a*4!VQ|9WpW_R(JPf8O*^c8WQ}Eu9$(<I2P=Vc3yRRFB$nI>u^hY>trwO#K?zjJuidpG6gvIwtq9w(q$jd~K`)grWWWSp)?k`VsJ5R}WjTRU#5TADrv;5-)(H9>#QU<7EMTHKB|hrtHfr|=y}haNpd}-4UWtLfq-h{<L3H{-UqZK!{GOYs^@XqbdjYeV{miUX%=GAY3aHv~7Q0DWYn{x0p!Ys%VcLY!f2zG82;jg=Ok>|=iWfxjk-CDF;Uu=Ie9h_iF}uD`Lp%2c_Q+t>7HQF_{A*<i=fLl0rdmL3<@pFF{$?<pd?3{2tdX9No?2c=hica{sEj=3>pS7|s@!}Ym^>Plk+DUR>qBDoU}Y(_*kh9_E-~?(OnM6=w+62UD<Z~|Y{85oLsu02evrLBaMj&Lu3g0w+o+?$E)fhW^x2nS%ZP(0&@s&JYoC=4S8Uk%r$qwVvI_i^6jRC!yX=B`mHv<$*Pez4bfB;eJwXm65bwuVqJ1KSMy-OCeUGB9;IF6X01P1p6liU1;KOxe8~u7PfV<q|_iIJB1IuyC|EbNo(mT=O^|Q=de8QNwjrj&-&a9X3RXOYH>E^SvL1Ah9jI>Zr9V`h)zqkz~l0KW;2d~tSiKF~g?n^7+3X}RQCso9lF5Qd$D_!H_YSM(MHC;h(;`_6iKLqccCY!c-bRMfZs(9&Bwaz)N&d%#WSWq9lL*#W!e&F|5v<}Xq-MPK5=PIh`+hFFma<_XGdfN<>dF4D(^$=g8k?(Pls#2|!tTbNdljuu>x3rvlDupHLa<No##THPZgw9&pf;!sS5cmT3XTo0~mxLK!|4e`QcF1Ssp2#_0mhZ;+bEp<~1+fo{5PiPz=lT$Y*MQD>Ktg;&79Q6NY`WNu9<<v^bbe{HtEZZ3wh%K!lyakrG3VglFub*)wVlw5D*crDeeL<Hh|v)ZFMn(fJ+1ctv-c*kwq<F0(CT-4+I#MOHzG45!dY3aq&k%?)9Oh~7%^jjWXU5&3=yr$Rtap`LX>dXuEu2pCEKD33?+~mfZWK1M@R?(VuXb7z{m{1BW6fQNUZPs{<Zf$=brnTh>XZ8oS_?6=bgLHKD$|at-tviN5|h3FX21z`{EM<urJ(VNmsKuP>3Soy8cj#-O(hf>YmOCu;zSpQp%fP1hdEkz;}I&>~J9@HghKEf~>;-mY?NjaWEU9+RR8)A_PDD-+gCs<=W0~o1<>(O=}Sa+TPciJ{|6Oy;oytniPe=9vutW^o$8L)w6IC5y~)#krzC*n@koqa<t0eoOY79&y*$a8S5f|h>J90N+udDgWkF}5_%o!V}T3o@hNzg8%Qq$k*B9i&&)8=K%p~~7dz18br(YF*xvUI;?c_I_}MX#!n;T2?N8yc(G?GTCL?dc<<ev(n93f#ts{6?9^p)j+x4%x-?B#4^97~N9+U=3U_WCPni<ZAH<bRMvsP(QjV(tCkoX#Vh-QMG+9LMc;e%&|g3n%y+x);-IJ&aZ^f73#_CHCIJN!5$s^jCb4F>k5?&OKS=^TgOr>MkcCr+I`QY@qJ>EDwto}nRFbZa$i)beOcC+V+xqrRt;8Xy(WH@iZ=ti3>X*~F#wwpSGWz%4UX`yMc3o;7Ry@Ad%fB*(?F>$f-&y@x#9o`=jLa=G_N%<L1Qy|e&<2$b1A8-Oq%857;F6lq4>>Ro}aHA=FQPl)P@gO_z_iW0jr|4Un!dPzbAlEqhel`a+J#G-sFo#qe?ijEIwXll2GRZX^!Y$1ZF9iJ;bLaNOOaNDmBl9Yi>?V_}$i9}!7SlYy^IMz4s<;(+Ej4ea^EX4Z{LiefCf{NcP<Q1PysKW_OLvgj#sB3k-2&*!4kUCCL=Nqj%(}T+k?z+*2SJ3s&p2_3y206xGu+dtt*w1{}blumW`g&|OT1`A!$Es{c<$&p$)URd6-b~k-I%`L1y=o-#<0xO<&ech33Z&v_^o<%&2ciO(Svs2}J0|M+YKlH^ijG$#bYYP&ta{0-)hT+omQ=ee)3Q4@=B~}g@CS6m1)}S-vk5u23AwKQmp+`5>w9K1oP=>He#fqQ_D1)-KSzB01c9=k7pW1mgKokyRW?4$w9F3K)Zecs2+9eJydf0ZMge0)1`|kolI=1UuExt_X;;-7-5Dyx(!E?jW6cYwAt_)ID$V@lFdg)5I_R3(MMs8{C+G(2*>cl*lZRr<R^=blbd6@5LYPxA=(?OzX9<XBVek#lEc$e851W9Js&b@Rk3IDpC<z=^`@q|uBsEOxjf8Y1(AxK^pRP+Z<nr<hb8Y+KddoD^zfjMs36lSBY~UQ3L454W(vv%Sci<d1Ys!mY%f<^Wc&`QvlT6%!wwfe8!^}``mXbt`9#*eRd|N~UTTK*W4~m>EYcVl!ZqE^Bfq(FA_!NyD^P5E`FAi`JFr4Fv$xDANJdxUJBD`jA^<n$csP2KkT}_7T)da&z=-B}lr$a!^q>z<oX6eEhbhK4ZckVW~p~he^Q}jVq<+$0y&GuY$%zAxn8!-Nc4?H@Im{VW{KQr(N@x%nwYanyde9QgRRbc<`yT1rrN&d%O9V4^kc%2C@VmLh0-i8vxNj~1J63!>&o9L-=NsLwwCkah%koDR>vpYvW3tmXF!kxsqIUhmBC_FwBXsXRHr-X4SqAR^rUeCfG;^%DUu%)vo0C*-R@Q$%g2B~S(XNFD4Ixfy0$kp@7N{#5NB-K3uKeBtS&+={*bM&$9Q9N>o5Mp$a3Qi{rEA^?v;uSu#Q<YGDR|-98V;;{zduA>mXxw~k-6=T_NVmj6Mhd81p4Zu#Wfl<8vs2VY#oNYw38qEl|HhY@Aim@K4hFfnj2$Vne$)CtvpFq~g&9w0{pT*3(f23v%SzYtLRq`le$&0C{%0C{LQH9-h;b_gWV+8}sRi{|rDtZXl2qwVXdrw?1e_WTj($<I|NYhz6nn<)BIoM*(9O-xEjHVO10P_zzCqXs53u#HQOMfCC{z{{0iO~9h+LHku+Fn%my@$(?3=wLa^-OGZSudM3|d;`r^I+ltFTd@0k=A=k)PrkQJ3)B;=iw7-YETVUuh|MM+~xEN;;8;mJW0MpfBcdK#egIl=e*quw^KP-HdSw3IT`3X3LsF-7T*Fq3^9Ea%WkIO>xVyNEWSl8rpQ$(i3{ybIeB7@V4>Dnw}6m+!+?T1NNOuL*ZCMY1BwrL<AZe?Y&uvZ^_X!jR+GhiI%Knkna*xlDdc@vy&ELF~)-Y$|Oj1P~Vd@kWQl99bzAeL{s<mmIl)7AL9)ZByX7@Jy0J%1Tx6~^v?9;hQz!Xo0r!H<|=ZsWGK<NO6brD)KfG_w=-HY^bI1NOhQCLd9Q4<=bhw4G(1;GPI<{!?oC8VE=0iEu&o(hkdtB)>4I1SbRf}?d5Nr>g{*_p)(XSP&N|i9X~j6&398x~w*ji`8!FPHOr!RAMm^dr96_W>fVh!8m7s&51Ss{>+SWAKli~4*XtkuGW;a_66O^a6_!_Psa*V-^LCeFkVd=&p{hl1L@V3Z)6F{54ZX<5r`U~$*&0f!pHSYEj>0nYeZDMPc(cT+g4=uKqOC-Z<IErv8j7xaU_6SulnUwj>e~tc2attS`evPxUg}mP8DOI<cJzibPds?_9cduR}WSvYRn|`m_jUr?B8&{-g(L8}JW-5yZr+!722vB`oGE6k;3T{kmQ`7ZJ&425?wAvu?$m=qlxTqkH>#!~l*2`$CbMwQZACQ>{iV{CjYZus02Ruq{W~4j-Bx31W#ytJ!SB>35rQFvWyYngGVLG;}WL5Oon`<?G*gz)1&ALeI4-rM_ThV<>B5efh3+m?^+Bxd8i|$%l=*PrJFP&n3=^~}2-+eM7!0gtKr)-wnDH+F9AB>ydW0K=MJGpf=nWekM&NAnt=ek%Nt#@!pM%pa0UgDNtfUSkUzERz;c{%k>+~CscI(C&<ra7|y$`j-@>}`yH&TR;8bgOrG@>xT#;}p3SPHw;b=67gjc*~3E7K>T?O@=Nj2mkViD$?w*utQw?nO1`}%y}RubstrQIgB29Nv>g`QKS|M0re>;y7U1;?<cq!&%`l28u3s*rr{|YE{XOU;d~@&DHCYIp4_JwFE@${ftlz*A6NU`pJM%bzBFYxR<y@Qt0hT}wvO%{L+Y9>Oc$uK%&uwedaWQXpAe)-MTgE2Sjnb=7z-4^xY^kpw@b_Eujb*uWs~q=mJ=UcAM5yYH#`;BroS$cu_;Zm`IY3$Iw6Oc{0qZ~@k(wp^<E-3(R7_vB9oyiE0<}RiusNTW%c>#;jE<`u9w+>H>)F-Ip`jDw?wAWMl$P<+v1qWskHpUoRe>hV}h(*_~aLF&T}`#vC!f?lQ9VPkVx1-<&qjnS*<M5?({`*ti5jYaDP<?!Nk|CvvD$m!mDjWEMgxNvvJtW#>g@M?e{kwZ-B8Zg`t6b59B^95_k(LR$j#~muQwt%h@Ov#V8hy20(J;XmD;8nqCoF?e|yyld_f*UbdsuBdXZE=c)yiB;aO?_BxqIF}$mLK*g#4-q0kPV%^YT)<_a3i%oi;ZIs+K7Q|CHg;vg<<+}y~m{qiSahS+P#t=#n!aPxliD+ufvVXWvjB^dzKjCuntrs^Wxhbc)gG)Ru&y2ENzJMYYg5(ArK(|k~=tz@h0h-7GokwV`0YafEafc(NQkG}QMGq29<?3G#6ia2veLmrVtjpE0kTSKa2ZQ&eWL2+yJ;mIGJxfgcqnkRK->D-!xVgvlU*8`<&=36teK2s+#f7N1>i~*W4bkdXJi)Pc{%ICfWDNKy_@|2Vu(4iopaUvQxFpehP|7n0Za_{$a2o!qqIaLwkQ0oNINA}A&pj^{1!(Xa*tt4DGtB8Tg=f)78NzX{OH&XhVc>K6^avcl!vhl9F3a)JfCXj}&VE=&#atk(JJ*F~wrLDfek$7rax9Ile90O)La!X`p^nx+z*x)Lrsg)BL+Zq5(!7cOG{q>sez8;$bCy|akTKjJvw7eQu<};|AM6e0cLhGsY#`|Yb|m-Vww2YU0?q?RCo=D*k7a?jwNp{7T6!i7x04&E+isSne=~9gSUhH>e5_v&ZQ=(a0Zpufc?2=eiPp**EW7i5htm`FYiVd9!F#~UJponF5;@W~a3p;2$NJzOS)EEtD=Vgdv5suW6Mz5C;Knsx#dp&@@RBbhyT%ruw2<n_4fXI5co3aAB1y<>x=>Bfm8URLNM;zRgPvRuk1ar#3!90eMMf$Y?<P}FirI>!pJLqGHuaywo@(*+lFvlD^cY?ey+PL8J7&A)cN(dzfP`5-lCjx`CaE6dsjuTACfh!X@kt5+o}7{U%%H~MQ-#t0_x!H~sn`qhbntP8KQrU_h<Ij3*^oFJ2o}3fLi$I0P|eAy<g8iuD7(7g=MEs5J|ke<(W7Y2q!QDuM-RY{FAo3<9#{yenBUh)|LFUPQaSLbWpth)Vj!pMKjhusD+o?a|0n!oooclvVJP5s{d)RlFo0DbIE1&+^#!nsjsWeq1RM2TtGjrwoe$9jxd#)^5Uwn7=g~a>XpV*?v8!2d)Xkyj37$7mIZE#(O#fEmA2QEjXTXB73=!usndvW#C}OjFjtYc1Quugxe6aVp0%UnmHK=0_>t&Zgu<UnRg9@fVwyu*qC}p>xP)!Ud6|IBhhU>6+>%}%DGB6;on<++u_6#e+9c7RxV+Y-Xo)w!eq_-omm8IE_kCFTYAa>&)j0Q;7>fVvMuvg0(*+5M=(jP>P6{bT$p`8a_A-58$EYR!s)#>;90aSjj>rS_Z;ahm%+JCI`Len$tRI(f#OR@Nf0?4;?T<ANLTL$9#W(pbAGkGg?pQ5Wp&5?3-oAS(SuaTg<zo_%4)(lOt$fx!woVhOGw~V!)HfkR{B%t;`#q@NR)FOxB{3zWP*E|ctqW>H?iiF&MbVjnDpF;D-0?9T=GWuv9p^`JAO?%is(s7vK*|?FmHd7lf!x%S`h!2y(0PZxkvTznZ*>uGhb@7JHhMH9}oVy*TpZHF*MY?@){ku;7r-maqu<;5A=P8P#s~?!3vB``5pJV^V%7e=W^#^h+zX6k-?~%VO=}~}6i4mAlNP^B!rd-cpm};noz<aUgSNs#E_{NJNCK-R7X%i`t1retvMoW!;5J)LMqiH~eir%o?1yW+zEqmP*uTi(&JTj^0qn;hXzDe>s<l{%f{$LwXfC;yzrXHW>nSO!lFc(5K6Vgl7Xk2I?G<`HwNF?DQWieLz9ZpuMMrzU%R9*v06oe@kJ|`Kc$OmVSZ+>94k@Pff2H_)QcTw=jWCl7N+U-(6gVutY8)q+fsF()al+?-6h;lE1vPCC1`PI_IT&DiC`>THb1MYklA%<1wM=anN**_;cgV?<h8z#m*R|l#AN&kbv0{Di8(A$Ayat{81*AK`#Om@h!CvPfOdt^0`&PamZ0l|vGoAEE|%E(6!1{x2@9B1tZWpGj>TGNGWVr*~>4Z#RP4Zcf^`Ka#nQ8WNb4k<A^vG^%2As^S?;E~32%c9amtjebCqtmoDwYeN%1RZ_JMimnBsI+U`YlBDdD8d59=3vAH+^KdU=O|83npQ48w%&E$yf;%rk3=kLS7nuOuXOe9u3w$J>v}%=xA_LP%QnK`qz(u8e#@`lcAMe~Vg!8FvT5CXM$uuZuVlZ==DG<ky-ZDN>XrRlD|<txvPhV^o+yjnZ}H<OU+7c_Cn6yhHiTzy{^B+L%T!#FoB^&tVd9sX%V|)lyY9`*cT#ikhTxlD#NTuQc_$Y%J=@4fw?Y$rYSowM-zF{lT(`a1<Its({pVPZ#0wLcG?`F2q=P#WJ{U=36Fv5=ov)XQ9UvKEnv(IIB-+@7C*Q6=trEl964YY56{Dnbcpw)aWf+Q1Aw%m)x|I}20URm)(p7uz9TmFn_1@eSdeDqCuh4@6wB~zg*3_ssl3<Q2KmHn~w(110y^w48Dlvq@r3l5Z(v{6+K`=tL{MZM^<(K&b_0HN@=xr1X4WJsDyCF8{185}j!4m}aY=tqeJWSxzB=A{lp%YuUI<W4pZWM0&LnL>fjoH_5V}JWAHT!?M*`_XKvUacfrGh%**_Pb+X!ok!s7@(+G-*}Ng@T3Xj^VF^?;5;NNf!Q^8}eAR6e4uVqcUt}nOAHftENuL_6jd7n|>*097f~3JoTt{kQ*n1hAXWg`PV3sj$xLjq_|^Wi!$m@-ii_31e60VGm$=#8b6UL0|U5?vI?Vu7hxV`kKLMJWj<psAR^vh>kf3YDK-0V#sTX$UW2LP20edCq^d>`817<cZyt5>qBaXeF>pvWnG0GICyL1SV3RG<HmbW~svoqFn$fJDe`!$ky|bkg55GkR<qEZKb$1~~W=DwIGJ@brW}VN`8xt#YHj<o88n774x#XDePXP$o-n8unJ5Q!AjA|-Ps;Kr!w0S1lJerWak+JGeH#_;A7m8E_iTY2fntM41URFtcR`fZPh@3&^UqVrJE{K2H?&`^h?|j&#t-8(2A{oSAdF!UD>3W}=MFK(tL-({InNJS_7HisvvPTaOS<Yr{#)jI<yn*wi1<Rv5CS#=qq3MrHzl3Z3ysY7A?Nw*f%i<dD*TT6-AU$pI>g_u^IbLD@vim%?)`(&3w4kCoz=_2zy;jeq0jbK+@L_$;tEsb9w?8_0XcZC>z>)931|S96*QwBN@6vz!PTig@@@1n<Gox^R<7;5|inNw@dd-<x+`jm-D*0TC(QF%D2Tw99mr4p_jw{ZE9jHmnsu!(}nKWbGx}JBH-HzDZ6W%?r93*B4@S(R7Gg@rv8rQesU<ruft5`3=@ppU5?x!Z>YZ{1{w>!zo2=>KB8>w`drA=0bS=u1)ICDieu=l`){=Q?+7VU!m?G4`pGkH%4?}qj9bt7D2{Nu>L559bEwA7jbL#=QI{hjBEa;@sNq)fW$63JdebFMHA?NLqQO?y@g-o*<p4>lVkX`oDoXkPQc679g*4_h8lWH_*)w_Is|rUWHr0_!jwa3oZLQhZc*+rg_xOvh(Rg3t%r_+d3NJ@cJ9V}Fb2h`9dX>WZ?Ho5K_86~S;(BkV7gSEHIrZ5yY2J~}~ckvY=A&dIs1J}&hdohaXg(?75*qv8pRr1hdveI5(eSR{WPLaPF$zw)uF02pg0K_)iHkv1_dzrBoMRlFDwwbvQuF<Hd{*D(?d5=^EgTH(ry9V!m>E-X3`sx^q*51>bHP!u0cB%pl?0FbT@py;0*H3K$RdWK?ZxUicEK~!P@zF@VaPmT0XO&{jHM6>YmIM1f_v;0mfs__8Mm-Y4LNVp`{Z|MvXms|QGD(w+pL1X1fBzO8Abg}OMQJ`uMS0byrd09B%!1^}Qr7Y`Tp>WVEHT?Hq7q}LA(yQRweNkQ=?{%r~U}}j;FtGu{)aGUi%F`{z_gita=^97d=o!ZGV+~}3qfHxD#s);2sNU}-1k815!O_MIj&@)kE7h<Y1g(F8pdA(jEw4=K(Bo&bJfM}C7<j?(6SDm0fSP8L?)G|U4#hMTRDV`T@*s>XlkJxnS=P)NMt1(j(Xs!A`%6A&pMTapKWV;ZZ>Pp>&=!Xw`(PC;)6az35`genpHViYnrtG$V{U}atVA^M?maYWZ)5yJQ7Ewv$adPySv_4u?G3_F7uKJW)t{o6m7inMCXvHb1DT?ogiMn0jTjAeX04e)I`1Xy-3}n?iHYS&<RAqytvq(%7j;(rP1-G~eIY__u)aB-8cepsZK=1Zr$14ob3Me+cMXPb`4t>b%73^*OTq^S%r7JqUp&20@*3O5a#GmrrFd(g%uVFXKh^ZN5%UU{uWpFwIc6598s0=~jplJ3`r9a)BuL73^^j&`PfP95C_guqE9~hF_Vl`rF(MxF1$e@qCi>7#_ulxpE1QaNPp_ccfJb!xBi3_)9HAjWsAXfpY=UZ*zKn*;16ZjS=1T0vg+F3WnFuOAL)3*m)QARtuL`LTmuMA|bX_4yzr4=apMBU(o-j*)U{-Y0<eXKe5CvkntN5<2_fY&`Kr;qk7CV?-yRj^H)+1#d1JSjmM^;>-1spWo1Bp#WQDv)9!l<~7b%^y8_wNY~IHE|7i{0t2vN4dFQ%yACU6U49gB59QP=&<Q{^>Z6WN0uTk*7E&@@H@A^^(WOUk8GE`Vq2$*$f<kIjB>4$90($LF&j-pAPzQd=Sx99H3-zIa>V@NB-A<tobSSke(Ot0b4S`@CWPN+ahZY{9TXbjg=sa@HO&{H~>1(w~{X&!sN?D?RTOIl+Mo)KXpDFqh*_&%JvkiXWfe_Zj!kI_IA`I>3rAGQYNAiJ;<%T)C&-%%!6nBV)oP|**SSW%?Vj<?pZ}r$v;TLIkfuX!bLUl8)2A3Q=KE^Z`q#ke8c9bpmUeo>ZO6d?$(%BE;M}|1O9O1PD(HY^;?a~{&Z*0T_WIG8bB<k#<2O`-iOuVNymxrL#-}iXrO&};IQRfg8<~@U+Zstc;NL8<fy<qhiiJ1zn#WWz7moES>H|d!*XeyLl?%u7jGH0S961+cD*{1n|jEq!LWeeb3->T)B6?YDauWfb18}Q8*PTr5dXbX*~H?uYfkMg|7kCI21=oY<d=4&;Yu6jgrp7NW%?%7(7Tt5!W~l74Y@X(iZ$YnCy{8q%`g4J(~H(->p9Slyke?itP2N0s|%OACs-(~%2CVj?K?quGQ~&MD%k}2g<3bp>!t(dt6~rFMS@^>3q0b#8x$bozwp%sq8nz;ORZ<vVrLg9^>tZ^TK$O08$)Fkh^~=*IB}46wiaAaXu#F#PJm=$?mA=ngk0(gI9Jo=c&fLeiMH3{c{ZVqp7xqEB^Ya}-CKW_U33R)Q2|@Chp<ef;5<gk0VN3%zhe5cw-}OdnSAH7SGA-C-s*3~CP`U;pU^Rg59>k$=6L<to6KF5sS2P;KBH+6vo7k0MYXqzAra*UI3Nt7uPK_8iE#M2g~U->(w-*V;tvq)*SDaM-bjFdvf0v<t35U5x^Sf6^UR=KGLX1WK-7hO&#G(0;T1(-tbkqyB1{_^ph&EXB7w)L>DGzvOqHci5|G9`Uyu{W*{PKs)!haw4tFzaSKMaL$w?w%ae_&$*!v0ui&JpNU|#Y6-~7GE9|(;<;9ubn+)8Y`U=B2W4WkVtb`b8+2Fz>nS{Gqu4v?H~Gj?lkTxn{21Z}{-P8*2hIxQzjY@}Do1L+m=K;K=7YvdQqfn>~qHo?B^jeght3HPg>MKPZhObW@$`fVYmexwD)Gb^I|1v!>e7idUgt2M=;xfJV3EISBwBM;cIUHM=z095}We_bEpFjzYQAVvrTO3iSOKwI*DX%Z?3GRm{a%ZWOx(fSs+g<100crg}6_t5_(<ZvRUg0Q2QrSkXUztnJFk$x`JwZ#4<ltG|nO4`gysVSMG5Ub^`QP1>d+lH^>;)=@*5S6&en(K9Moj3mV@qcuS_v_E#CYXqsWRv%@Uv)<1cjh!T=Tsi4mRwTP!1IaH%2{Cttsfgg-C^Pd(jz`e@l=*p2jXMow%JkCBG^e==qhjcdc+;~v|HkA1<+}skqJK_>Z2!74_}u9Q5^zYL*WCbUYZ|kr{_yje27?3=cSf0Rq8F=qe)C42(dv1j>Jv}RmTvsiLAEqhb8<!<GId!f8<2~t#~$#)3CU~IGJMN@Ab2iUkCnPsOR2{Cw<=xVTo<>_E|M5UxYfDUaNF{AH7Mup~uS-PJIFx7e|9zdMau9hP&3!U~oI%jE=nI68Vie>qNLEdj+!!!f0VIERSNt8GW=cL<H{gfBxX+8g+x+b&HMs|999wlxw2-%SKzFr|UjP!Ja;#*Jc!bmUEqKFK;?-V=we7X9ViADq>Y9=5Eui?r=iWjo4=8kge~=ILi8N_4Gft)*DHW8_yQ57@O7`1tLwIZSB4ph-NxM3QKiba}V}%eQCZ9!5FOp<(v>rRAjMsKwYYEJ<ryIGZlt%Yz;WZ=?Zf5rVY1RT@GrYT<LFo^FcR=3jaKmcZ$#dlzYDT{@bWP4t1bC<7|ZNp{oh4e+xq3c)^kn9OXG0B$R7s4Up$&gvkhppF*)WQLlKA4q{RWY|p^VnEJ{7WI!dTyhNIev8ane>jhQ<sK?U4c6@3@S8tC~|6HHGdcfLYoX=*!JF=QOA6ic<*C3sjwj(k1K&OKmM(&qvomD9BzjB)-T;r3XH}D$Wbn#buI7U&{B11J99S8$V<_1jz)2d41Ti7N)ZW<+WBJIp`AhVki$pG;3%cBvaVVJDC;%I@Tc-%Lbx#2s_$I()Fo0fZlmd%PfNE;cS>daBPc(p7odGA{yPpS)6Wr{hk0zs433iIF!ToG*NGDwnZDyxc0v}LqnA>5;hr1O!R?2NogC>msnN?3G~3g&o$k<yzNHX+G)U$Q8nN$pHr95Z<u-QxOf*CfVfb*aU4qWN2K&B0s(zf|Ell3G?M{i8y@bptnYJW|75);_j#NMRH-KFUBcETxt5B14DM+VqVl>Hq19+<n)x^3naoax&s*BvJdOjy2IHLfRC`SjI1udhVt&h|}@C=~^u?tZIR7lge1Z27RM#Z?P4PY+P@|Lu1%97Mofi5p*2FD=l^_6$p?~Ss=OBZ0O#%Qqyo<XDZe-QdCu5Q3Z`lk6pfVh-(*N&=9xUpj(b}+~g>c;GA?vYa;#!?pJDJ!`vhoW+R_DwLX(07g#jTF~hGJtg=iyWE6^VzOg1+14XA%1BanvT@RZ*D={g^*2h$@JxTr))7=aH9G4oI0*Vf#C^;lJNsp_6XcFeMq$H(*(fLmORldy<;YbEFy;DU8XP(03a7TnLW$2TNl63zy3yR=mI*$nD<QN4w0la-<yF}X|U*mMlCBxZ?1htM3)-jsE(&DKcHT0M}WHmZ@855w42uG@mbt-d$WG+H>sjqpnj!*Qm5%W%sO)AHm0%2fbH<@=#@MmX=vwzop_}W*{xTwo4fPPD9!eikTg?Opr16EnIMlftOw_7e}(ov&i0E2Blcp`fGW})NlPm*QvEh=56Vsz#5_43C?B>65bDVR5^Fb?%<9aQq?O$%h51!y|a`~*dwT<6{u;M+7;?N6~4tNr5F5IV#A2Z;;yX3^PdynM{E7KL8<nku~*NAhhs@GO{LG@7rl{A_CmMYK$dc8t7}#_V9_=$;j^16496N&m%I9xWig$XnrpKXuzxX&@K1-kKg9kHh`gR1e(OtbO#CZquUY)eT`@$a1)bvC~TNL`4&C)Slp*7tn=lqySscS+Y`fj1V)u7bnGr2_qDXhT^C&#D2FQ!bnD$x}mJu+^*^WQK!?3L{P%&h~0jJ9nv@E))<;i@**e$A9&mr#a!TKCW>p4n3d#WqhhE_-xD9>tU-qz?1>5F2REcakmW)XjHeYibkq&I6q0?5{WNv1KCF1Px)k*S2#Bxr<j-DA0)OUNgbgP!P`7w5bHlg=y#?a!X-KYa%%5?;-l|(QKsdYnNEa{^)ul}dfn+F7))fS3$=DS0k>|l+{*2iSLix~2cMA1WTjfY>;<pycfypJ<oA1~taaS&D@VX^Bjt=y7K#`C(QKgB6{Fz2QaQ-06B}%p58_}+Z2UY}Jkn_pxaRyi~CQ`6F)|XgN+Y3^1Mj2#}niIR*I6+M2^)a0-be7){IrN#``Ne9jF$ubXv;8Pn7;?xxcXDFpK>hoH3sj!D5VCkQfe0U^O(ay=-V0y~jb<R#(XZo_B$w|7yeq$HzU!aHblCW=laWV{fQ|2Zf8TU{W`<nnMChFI&1~g>)Fr4}1lDJ2oOkx#D4~aVQhB#-h(39QGt&iwOzrD9bCzbLUT4S4ql6f|xm!R83X8(XT>Z$Ufs;IEZ|=>reqpTEu;|^{SD<y6Z8BF$QUY_|CLg=G)Gz*mrjKO%)2DVdNv2Y(K2Ecay7N7yD1!D7;wk7+Wcs6nXE$*d<z37jKE-q15Nf5kic5+-VIM4Y5*f244h%-9c^$Q~wDPq|g->?0f=V%g0)wiTFZFfZxdvt`I$!vEqAv>Wv&0o>C?}LiM?p!pnh@vX%1&_CD>ULsZ<r=^tUmR;U<1v+`cR(D5r(8y%BbYf6$HQm>VFLHpbHZ^b{X*eiBLyiiNWoItY<vqVcamfL&+$+*~xo7R#a(=W=>yNp5`PLS}B#3+eO8uZ;p`it<N;Gx75J6%D4js=_g1uDwBGREVni4ww)wF?-{puQli88bh=r~o@wJ&M;E;#gG>k0-@`Mxc!=lb=NAdO+jxkhQaCX9l!xEU_NmY&iT^xnB*hCK(IRoq-j+TE#&c(*9HEn6q{&3IkF*E3+A}HEjEzc*)tak#pI3M;2ch~ak);7v^JvsW(mFpIj3G`EHO9jFaig(0^MbKsSb(`on8UVku$&97XumA!*QXh6F%MVEzKRh|lwF0)btgB!HEqUOgKhg)n*ZJ1*aBRqcG_keZ`_h~<8)2%UkVv%DHHIH#5Sq5UD+**%f<>uw_m;4c>59Gx@C-ymP@p$p=<=}go-Idg#RmbDw$KWo4k0~79jQDsLXAI_VlB9PS0;x7pC~^e6i+?>MG%x3k%c*+==qxf@)<#vOORBy;>4nkT1DivjZ$|jswJ{I<A4wCfe9$Z)n!W=bC$;Y+}S*mz%-?9Ui6X_Z_jdI_4K(d+;>sXIE5_>(y#r1QLXCMP=ROLw5vTg(s8%Xm4ui0K%+894S$dvwO3MtoJcSl>~8Ks<WlP{0=A2^wP;w5H7HCVy~+nm=kufr{h>zT*;1N_G&?3e|Rs;%I1gJL8}!_U9K2>GmbEQjFbiyot2VdjSPy42cWXe<g<mcG?7yu5#QC<QP7D3kEgwtzud^BPnratuyA&}^%ba)OvKtkh{l8o{SGk`S^#_pQD`S;PDG0RvgcimM_?wM9_WJvBhxznV}lZx&7wb`V>8Q~v-xuZo8JTWs?*0bdc@a>@@Gz$0;utV(9^meA>B}CzHaJs$v40eJ5h3+?0><6txsZ|$t}{VpPJBj$Mk+8mg|);YnYjzqb^9!22(WLmYz{R4<Df36Sh7Hm#A7AitKU!jHn1v(<Zd4Pr?2q%P>A_K0c`uLwzEfsrK<)+)9ezKVy^c$cvHkzCMj8E{y<n$@xzmBp(k5l{&Ijv82~;&4NQ4!)-vpI6h3F+sA#TBN#_$-C?fxbCiGqlMOOA*_@TIjkkcw+clO{WyYf=R%7(PZQb6ZFW&}fEq_M!%j`*T2BzjrHIJ}o7ou-fAlVe3Qx;tZX%tc6(&(58_Xaqh4xP}x2=qD@Pn<WNxRsH*LX2*tqbe;*3Ia`jB3oIQiqIaRn$Y^1A(=sX(5ZNhBm~P8Ffo-w)|R{p0PK0{b;e9Gj-=31B&xEPE9D-C9ht2`8K<MqBLzxMtUXZPmx2z;*kJfb$rW&O>6NpBhU*N#Or=edk*ZR1Y^3T04+hSuGW4R4H6lo!psF)7p}p)H53FDT6u^R{Aeot3+2)W7G$ybg(C}qkh9@~RIFej8K&z6%uVqx>@4GMA{GmL^f<s$CI>%@-Ev*$Bwut*{n(?#1*qzgj?O!4^*Mhc}zA5Z)auYULRUM;DiC<zcpK*~`-<Sol7t4FaT^@slV&xUMrEwl_;P!%8qLh7YUh?tyO2P2U4GiDg^KUQcSt>ueeud<}0<PQw^C`LOLGd=&4)_z)QVxF0l=P$ZWHwC6ncksfAzj=L86An?0ddjX`SKH78tMUl#{(OfO+t!`KT`nOpA>pxm)SZ4J?92YG$&KR!9sjCK49VNtQVu$F<y-^7PO2MBZpKkVr*l7dod_8XSXB7w>;Hr`oga}TFf~w+wAI-kJf!^pDlV{#f?l+M%8MZ@)xTA#I&>|cO+T@(0(LQr|qiV-u*L<cF*VlPY0z(N3BFMk!R-@7N&eX9%2FY+Iq2h50r%Fs}Y8Kv0sYLqq8I*>>lZ5#q`hAdon5&V^z6k&i#Vef}a?E&H$08V@CcQDJ+x?rKM`Q36IEdK2D?s*7f|yLwXKn!mQI}<hJP(=Br0Sw+M9dHGHk}><$uXC><RL9;@g2bA;v83-~E9Ts^Qy;euWD7v9xln0y0#v=`x*J_23(#@T~d$KuhL05I@jUr+2@&=owMBeqPLOL<1Mb^J^g2n8{aqY#TM0%RYx;z@Zsn~8PD(l}y2Z))1Kb~RYi5n?U!eA5!(RIojd-qJtCH=M(jR@K`$N4i#U5l*d=8OS~BRXtR9I<Q6=MPmpg)WB6W<<Jer(~^{v`PH%|1#((X5{mp}AI-`l%Lg7$8XtrD*Ju2x$hYw*4G`2uG|z+H!7h$!kO)!##=2?^TwFf36Z;MauB}VJjS1HaqX22(hId<WZR`T%#ub-l?8Yu2EOr60wPbHx0+N*LIPpi5?Y2}(Q6FJDDah6F+KMZ$E&(#r33q$5VL2U)_O6)&gjdV~EQLzf&H(0?wH7PP9Dqd<$Z>WXe*oTR^&b_c!Xnn+8U>8;g)CCx0wn`SFI?$8I@zy$6vcb4;ftq5zzGxU_?kt4x&{n5=d>03S7Vz--qWTSW3X5meCt!>cW+z*n19lfmK^=q>;;CM#E}vUm1zud?n(V6LEBW4HdK4KqOknej%_Wg7@UShfO+F!uv!h^sN(!YuZGQENjb0IdnL*koBg}8eun7GX}=AEDK_p+IO`Ls!hro3S1M7kR+_)_JNEw^7-c`}=Fjd6q8Se&gKvg_@Dm5L7J-+hW4#yN9SDlw7f9%YoGm&{H3bF&felT}03BM+^~D1tsJh^cY*c*4m362g+5|$xNhP@pUhnCMy+6_f9-d@m$)CU?o6%Ww=?&`chbI>7IT?3Pc&Fz(rEWCEqaIOsHOHZ5r%&<ln;+_7kT&OiXcN@3j-EiBJ3v8%b4b>y`!j;zXgbq9p6C&&KhK^eCvl}P4Njtf)P#s4f7$e9Q-MINz@znGYEU_66Ujp;REU(z68^>kjEz7QXvPPca3Mc38TjqY!;{92?Zmb4zy387z!aeTR3G_cZhmMPgsy#zbz1lqqiLw(WbK4xDsQh<eXb|IryJ)1H`vO3=9iATH7Hd>q4y0<prLEAIVuCiSgha&GC}q=c<&)w1x4G;Cy1A*hbtNU7zS97G3*2{8?iG&+C@C|PkyjcK4Gsbeu(&(IzgR<c5P7CrkCGuIX@Iq*fYCGK5murN6BL=J#&U_<%x2$CYCR*`FJaqAEEQJyH&~$jmdwbl+OzpXM?V`ehs6}Ip50U7v>Us(}-beAEf6)jk6oEe2;mlXsv!D&1_nZ^cY#Rn_*F6bX|^PR&zSO9m8pA;<hyn|G$2SDe&=QQs8no1r{|_aKCrv!bgr#%Y~&f5lxD5n-Pze5tIDOauvCqH+iuWIwLJ&PNFS`7FDo-kzcxdf?xWM9Jy&V-loaaXT+UsIkKo>QDm1*j?5fFkW5O7yqYFMGv8mi2R?d}1I=Wy*Mw&-FEVAS$=s0@s(B?6Bwv2mnKHigSFc9&=kKP`UytJ5GK8C?<7V*Q>WjTTauLleW*m_2HyqOKn5Aq?n(yf&XteIGhpNO8+VD&oo<X9J8kL(Nc{3ifq2Ri}F?dI1jE8qK#Ke4RgR9#Pt^?ZYojP}Yoqb*o9P5;7ybOe1uOo%&e5BS`&59@8y1)K4W;Qc?sfX9o8gS*hRVmKUrSD8=>T;L1-oh`lnT`2bP%}E-_dhe8+(wI*)zu6CvwP*aWL$ho!b*g}+O~wnEH*sIEo|QT0OvC$H<7NS3ym%r*!#x$45O*L$!xl-v<BnuMOp)MNS=FJsz6xwH`es`ps4BRKQvN2G1jdS?}KTVqCAu0L@Ad2Lu8~CkB<_Fi4SU=9G!V%czdBR2yL$&1?B3Fcj4Ii3p&uAZIqacA7=H)xau*PI8vqgcmz5#z$_Uz_S+BS*0ZSFHyQ(Orj)r7nmuU1HIbsz8w3lN9SE!FZZbpft<*rATYbhJn&NZ~Som_J?9OS9G@wvV-Nbee6ws;b${tk^!laMt{Q*#SHKVfXSQCZsx2hw&nd>C8DzjO1Frn&*=&7T-Ap1+XGc@c#a(u@|MP#v2Z2*-19?0@2QlfztR7Y-nQi&1@Z`8)lKr;1=Y)bO8>NIR})zD)Ma<SmO+A|YOa(4;vOz2Y?@E8YXHV6hY3tIKyI!6X%kWcrlIS`X(D(dD@cAmu~2`}L}N9*j!r@~aX(Oj(;0=60?fw4VJr87WwO(7CVbAj(cLfN(+Gh?WNm4*2xXUG*8h@B5asS#6vu~4rk+K>MpCdts+z=8AL8^&k#Ad2*g^iMZDs1uBIK670vXXe*$1f~YmQ|nbZne1?{g4Y>WtIltp+89GLLheX;ry!z7J@qF%s%Hqcd;i8-IUPBYA^O%~#^fTmhFMxHzRm5E1|^7o7zRgaiCD>m`;f(nx4pU5Y|xuLf<Yu&V{Y9h*p_TsGULgOX%eLE<Jtz+dsAmg3LBhhgBRCgDSfoLoW<aN^JWww)SIE%fXQ~xMc$KDBBA>z@Z~;OHK=~YpLf5EN-3n~=NR6o;m#(W$}C431vKpI8IscReCDmLnRsfKc#mGZ6a&jAxDb0z2y^o-mxnoGoe)RKX+<GCxx75NrUvhXeU$cpej~1Aol<bND0T0QiW-_YtQ0urMp7w{!DQaK+RV&;#)~UWaC+qN)KN847B=pMW)~|A<^*W>UmCrV6X{5JKzXp0q?l%YJx3N@I1<Z7(7uRaL48J>z=I-fdxtJD#>kYTq=|p?cnsfUIeDBvvC8d!j-|8mY^(Rh@aI162JUzRpU7xqYx%g`!-Gb1RD*ebgDJUYs?zeG+s%>DM!nluc}`Kmq^y*1Cm-xq2XEf<N@DBzOrPK??z1%;&I89wFb5EED}Z`<v_R1kOOC1j%zZA2UE_%ncN)je4})ZBP3Qu1N4>)*)Ew<L0s-ODBdQIA-NyZ8d-tfZ!LG{q7z_r;1K1PX-G-0dtK~=Iu{0$&yL2Zj^V=f7-Yzm?zvq7G7De|tAL~I;3Mz+2BX;RC(=typEwSZUJU5#-agj_iqVAgpLNd`YNggs+&xwFMIi_Tv&qgECNINMgJAs6Irj85Z_(!J_1uP_jB&raZFdG%+$IF5=zOl=9(36|VY3{9e399)}1J!x}Y=$}yrM!b=4`~v?+ji7#d&Yh~bE3rX8|8O4S(5wvgh*=Nc$Aw<M5d}kB`+4&_EF2oXt>n+u-6IXStnADCq-+l=w}YnMV2T^-SVK7_?NG!03S=syu3;^gNe%ri&jF%G1Vx-q~eQQ;G-@Nt3|wrsVP<lDORRyxynO>aHfS%W>Un35_qLB{6GyAO9e3d<w}-v=~j5NDq>haF%Tc3EF_8;wUDxgeZ$PAZ4`&MkNMy=H>08i+&C33d7n=UKWw(4jYo#fngfkTtZkmCI?2F^aPe5<iOAV$A$iCD`h#fgaQnNKjlR618NKDPU)T5QyZi8A+;vExF_?+1)OyWb$67dVrJ@;F-|*ELl=Hsb*NGlhX;Dmo=(m<8672=8A&e|JITdeZrVs@mu`7AsDU%aK%yjF_a3e^*Thtdx-DpdxLW7xC!UK|Z6Dk>RgrVsuwkSmTm60yW4;TYKv<l9jT<PcsBF@jWwPrvvKi53PnD|0#6hSRR*h@>4xP)|qQI>96;ZpSQxCA^*>kbkLQT&avIM_~aoR#U$HjdT%YF5U0u9!9wNc5D>0g~NVE9x2{-A|f9p^)wt!B7lg2#`P9#?wWi0OS)zr>-9_=k`SmOYPekpAgIfYwFB{$@)h2@avFyid00d@9f*hiLruUUpsgb=Gllctx}8J^iJNPC)Eepe%n{m{3C|Hiq!8P!JIG$W*P^iPdVyDqkqP9fX?EMe3mydTIQ_S)a8O9ry)-cX!k@zDOp}cHe3!;G?OX^ov|nktI)-`b_O6_A}=XTv5S$Bct#bzTJWfNAlEtLWIjj?T}-dFsBPUlV+kzHBU_NI4uZ9VhQ~8bn(|XZP7BGum-!mmJ!p2MV&a8P-c6kdghxryq^6cZ*#xjzIHLu^f@Md&=hbUzNRZNw120TMwZ$1l3{y1Cy^!H@Xe5Sh!APbc>6!f**IotqbkD-vs!BtY+K<kcD5tTh&UN4SuQ3b;Fs`mh2H<r8q%%id=>+gzzfuiSjeBOYniLEdLeYJcP^EF_bqAaQzg3|sOzuD(F`1btt&kM0K3X`dT8}}3o}HD>$ZCmlt_!5+n2S}bxyx0FtdASh_0Y(tsF~yqxxvN=(FUa#JAvoIgw^(MupD;1L$kzPC=0qR;sGmFOlze0b}RZ9?L}$ZGY7-|ht4QV(KpTn&V%(vFLbJ>i8a(R&)f2&-#F>{_FDsC5iJkK74mT<Mg;Sjx5I;DPQK+Lgm7hC?~O0FkOS;GER5P<>A(F`sMvl<<aKDv$I*O?eo^si1dGPra3(IHdW+xkAq<P5Q!Bx~F&M^VAvE}P=Nu$*Qwt06!k9m8#J0-kda}%}j&}6UJiAPWf5C(3D?-y|Hwu73pjbNYfARfI(GRo@recaz5Et8E%EfJ*gX{BM2<D}b?;`Ci=iqTM*C6yln3&MQUreC`>qGRmElar6Gu!M!39X7nmQEojuVX*6KGS=XN|5_v6Mlma32W6X)eIvZ&aP_!QTn~oH6wH;KD(F)w;RHr9V=KqlMg#EZ)BZPUx%jq^a4!tV8Kqay|Y^lXZA;kw<BiwZTA;^{+x7Ff%EHOe&Ok8$<?q2?yzWeFvvJvBt3m1XQ>W)X)TgP3ElgWF;Bs<J9~r1Xu38lLea~K{I2utjwM7cPXxztICQ*<Ch3ALgNqATTnmaq9`X{jz?mXJ2~t-8OD~8y>(RTnVhr2@jdVqRMl+94!Z$ZkU04c2jSOMeG8`}3zlB0(8#n^$x!4|(5yCpd%nC3#?Rqw%O@AkO339VKtzYPNgd#Un$%B0Q!UN5qp$MR3mTYw)63pv5uw<?pxJ1m^5sBh$`z9mX85M?jR1^L~NbqM6nEoXD+=*;C`sEM_k4e9Lg0Vo}U^5loQ#Of!f$YiXNwfzY-NlKPhk+2WyvA;av4EHlBgq^&vp~DbQzw>Z1-ep6>%!=k!^Es_&2^O96wR_`Uha$7)n0UjnHJxk>Y@yDnKdR}7|4H{C#iZ>bzV3ef>HH&XL<%uAZkQ1rxM2aK*e}nPHS}SA{Qg5ifBax2jLWhl-^0j&e<UsAKY>ZkuJv+e?pLmr9aajhFWTM!-M<+XUrYav5-Tnic%PB|0--iKX)~*K0m`YDxR71KdUF=P3ZH1kW1(y)agM8Olb=s>^mPl9X7?c;pM5XCtji6#8_Y|*<*^E$pbxeZxn8|YG-U#0i&0}9QSk7_;W%X83J3zR;FNQ3-&V$vs8m<o4t`Q3W+iGjGnZh8OBIOuI{Oo|GXU)F61NC(qh|2<av$a&`?M9xTvBPbdXMxjIDIcnX6vf5A3|{utWeS`ye|LjPgSUIk?{c@i9s>-~fkJb7xR%HeH-F!~p!>h2s>*69$szkk7bHcW_W#5RWCsF^5AlGNvl5NuWN>Zr{am2<L(B4}Pg$Vs`p*hI1VpR{0$A>-N2zAo!aUq9X*+Q1QsT;lp4a6VTK+g__qqHin7Kt|-A_ip~<-Bek2dJ0NyRv%7B<^sChOcRs+Z<x6$Fr2+o##`jhv_JfhUYV+Upz72fSZ?Fva`rQlWCJX-JZ~NT~k~cLZZ@lVy8w$Kzy56j5(9lH_$)@+MoPv@mFGZIYEm=`eVh&P*k2d+Q?eB1d?Oi+IO(KxF>J7p-mfKeN{(T7Fix9pvWkVA@7+W{oRgV3&4|f(Xbpm{LaU(xMt#_8<oH>i9puUCgt&c<LXE-V2HD_n8?%_&r#5d~l*g6Cz<^E*N?z2c8;flAs{_d@9WVX9kn=L=sXKsxi+}ncVoUPtsA3rxcmUGyAc4VVxv9nE^ANG=YlbY<k_s7wvUA+&i*u7~-^=Q_uv+9MfolE<DAj(q~3Fu)zC6hA2gpZwo9QvCmv-H0Feipjw$oq_SFZQ7U%f`f5pMS__Ma|_CmRn*Dp$(IJ1vBOsg$bwELm11m_1Ogq!^1yW1q+_lCLhallF{5TgxI_Ug4tFlQKoy-KQ%571-<~bCSRsCp+pgKVk8y~ibDR54^Tc4;S^Oj^pAB4(nL<?w&JLU#p^^uVEvjY_?>o0-#0ifGqWMO8O7FM#Vrp3qhsU@W8L{+cN+#4hQDgE>(<O-)I0TjTt}5hEEF73LW=73i~vyJiEYf1?WiX?PexV5uSi%w(H;Wz$!O7U_-m_?>HY^Q2425&_a4&5m;}*%VFvL5^L)6+*zj(n2kzd%*zh4XQiaW_i#9mB;jc3`ig~X2vT1<q6n|QE5N5~sCv&=*)c-nfDa_&)ay6x=`*5bRoyLtCbTx+`yeaMk27@`85~dj<BRGddTxukcn|T}I;QzWZ`hN-@FhgvWwof-TwtDA(j447QcBBSOJCR>m4l|FH)WluTX6S0bPDjWxBI2Wb1CJsS+jlU5{*nxOnoMILnk0nj5P*pl8xm~+LnN)ONS?xDPw5hg;z+m`Q7CP>lrGYjoF0eDQG!A}$!$_YoWR*hEox_4-ojp5H5oZozgC#=@UW_x=wz(XDvv3~SlVZUzu~eFaT}QddP#V&Nvu=T4tXVUt*n_V&a5<Q)S~lkC90p#p;eVOb*V(r9+le3!{(d8w*r-MP|Ve%U2v<7k>=*?HU=`~vMDji=x^~(6x|H7eFl?>3Xp)DH$@-Q9N`x!xacgzV3`RQ1@i0Ukr8p8h6lS8hys7{_lT3ag_VWS{CC-?H%4+<mZw_}b(81IjTcB1*XuUw+~L+k-Taj6zxHrvJT{%qt{JFP!lTXzW}x0R8P1z3lz$M`LI&!$sK+{cq<`?0n&Hdx@vzWkKE_6U@le){Vr!aId!%Axb5ft1lR8T1i;=`V=~Z=F7hA_7rFUeWOgLKsHtRNeVBb~qj){JUs(<tMj_CG4Xs8zFn3{TUC#JgD9Sph^7B3Lq9jz%KqrGU#H-^9W>d#U}!nlA9#>6JS09^=Fik!)snD9BGZWx^&Y(|Ti*61Gx^<a~2Y*wyPJcw4fz7}s?hfMSO3B-sbHFH@Vn34%v`q)}0oSi6TWhZ;(;9mdojjIQzUvs}gQm_z6|1?*+fFi;i+vJi{`2t`w)!=-(`Z=<ShSx`M$g`$UuGRE4#_esmAckS;+j;r2AiXiq!-*38u1SY*)T3Anq?R~9UOMwJ&`(#on=>#4qB$P<PL!!2VFLBdA2aqaw!uIai&a~4<A^5!fE=YKKlY5@-OQGuBAV#-sR^$qcd4snB0m9D#_*tHgTrxsAN4kW`@?A~srn|YiL6o8CTDq)Wxv9Og9UWU9YT_F?$$~*sPQe7VEA)isXO6J30?jYjb(h*pg^=506C3K!Ddg0M%sj`i4-5K4w49FMRGVgHu*5{N0pLP=v-!*r0s1*^$mDar=hE6g_L_$38OF{0QaEmMaoj5Wl=x5devlh%UQ^xR3sZ0h#5l~S|pmRYcX-I6;4mtielnz<05;5y`y&c1WJXv7KdrImbqL^fK{D}$(xBcrtg80jvV+X`~8<_S$tOtnnue<QU8npMjDys5E)tTt&io7EsKfC%Gq@qxg+I#nJ_I@CNo5Ocyt4Jeys}KYUljt7+6G)Y)Zrh5l~aHNRvh<NmDvRS<3<gy^eyMXk*07z>I5DPh+$eK?qF|Rrk5xd~l?&&$B?bC>>L$6?@ZjNp(^hp0q$VTn36*P!w61USWfyS2>6W)<?mh)RpelpUKhg62sFLl2W--63&@bcM23As4tMInL~UP$4vd%aW!R4``O#@gbjFI^9hR>M4uDckA)z)SNX+Sh;_5jN|m<85u<Ly&$XD_+Chfm1aI-*Lfv8Z<-06I_pUr}ZhK?8M{`50mdVXKf^tX32yC+mpd$Mz;6kjSLd^OZbdH``(L{tCS7|72dl9CYo}cAV&Y2TUy<!Pioi&C8XXI$U0(b|=@x*zI|2(CzPqxo`44{cCL1<r8Pj*+g0j~wH32c_wOHn+Us9-cZilw3q@kIVSp3t#jf|KGi)9*)xH3cR4Gi~NIZnC!Qj4JX8QTtR3hZn6XmuQj(>o7IOUkrZ~u;Iv+@DC6r8(h5`NS6kn>g)4TleSC+ZK$tF12gd0DTyy(0nXA5Phe0WE~jzj8qL83+si@a9Ro)nC(inV$?XB@%mP!K(r0=Siv0;2KZ@6a&7eAZURAIuy-UdX^V)+shbD54RzsQw>mKgvKc5l$)Sbj9Ct3Q#a~v7F$3_e})uH?bo9#@jEW`(^@So-4MCkVp9Y7_Wv@7NYc>FHWH%M^r()71&?V9)i{{RawgJP-oxUemP8DGwbExcmH7T;&YrtIg&i!Hq-^W=@psXm{ll}7S+eA$NAecAG@FPn?a#(;u$*E$)mII^W{N4D^TaAce0$hNp%-kP%A6VLeV54LAoL9AVNR>$n=nX^f@L?tbw6_W}@sC|%jex1~V9^*-sDi-3^uc98DVNWvEa;W--CAC+OOs_rw=qQ3a1tiRD`(V@zrU5D+^Z@1(<u`g~LkYW@ojGsQ9|o&tG(&XBV_@eE2$LG7DXFQu2<j8ZECT~WtulI(0DouN;|x%jT)LTclaxpfL$Z4A5{pKwv`S)|9d)lVnPN!bTcZLmxJu*6sAspMKUCs*sxha|IbxrK7q+(k@qxM_2vviD{DiK?5&pfelyASVI=M==6@n-#Z^pgwzsaoCGUXNuf@gU{Nkv$cx3&rrr*FWfAV&n<zRV%1B)rvj$0Rlv&N36%-12ba)_8qyl9hsap>#r?bI5dryGQ7K1=&kjbDMd%WPC7wcE)Q5$R^<Zx>VB1S;=waTxsTmGv^A0eMw05R99~U%m~fa38A{lrAJX1g&<7M?86q!R?DULEtgha5GJ<(u-+Od&AfTMG3I?kkIC8tA!?C^l{a;mAG&F-|Ap0$=cm3JV(e~0)(m(ujjQPKvdP9?!o}7+4A*RId03+K`le9Vcn`B1HR9No?UR-03hZa`Sgk;@`m7F%_@FoJfYjh%i>Z9eDl=fW9wktZqdM|_8mYA2lru_?QvsWP4yvv&Htq=}-Ygm85%&`rI7{S$g5eqZKfnCEP_NLpn~ckA<+sUdZ)ia+a6*FjHl&m&W9mBH>9L=S#SYQ83f$nS>#1-w$|j{o5M3+6DR5-h^G+$wYIvY3k}zQ&UrK9KPPKYSMnMjDW)AkK&$cBBa)vXG&ft^Lx57A!bHb>EX8+VVtJ|!GCp6juREzg^nINnJ*TlYsB(@4%IFf~Vf66fJB{U$o4A`hqVP}DqZtHM6h?R2g5S^g6Cf_9c6h`}RgGhp=(;r$LuHV$*WSs7|5*hS?pp_w-MKYl$dU1Kwf6!CL-~aLg@|m8dROhOzn-IFmG{cD%Zr0L;us@Tk$W53%xkXmJbc@Z8+O-Wc=M0h<C*v)u_SQ%1N3VKbi_%(a%LpVLY`lrnYYN(SkVz`>oPM;Et>n8mO4m)tM)2G|EM1fkTCp`O7IDi_y_AJt-jojf=1=S(8Q^$TmA_Gm535f5`g>KC-@J3@BkNz^@#6Y8{e3J0@%Jwe!^qehl=<?#E8M&xb-Yz2tpIN}e!;EH^wqJIsNp~VzIk@jjQURNL|xw5hUyL4prx&5+k3T}%BuUZUELt~-I6j)E(50BaNE>~6l^zBMZa{znUrP5#67Ek*>W6jVR6JfUKESAj4a&<?~0{HT`?_xfr=b(dQn6s{(4-Bri-A9Re;b_iW_y^Vu;qG2@;Vf#yPYb82~K$xg|WtR=8tViw^L<)2-`RGm7C7nEA$7UdnX*4_|(vEJVY+mUdgfa!*c5w{+XEdWWLaR!+(Q4h&m5@b+F)kwVFpE|w<ElV0dY#TUv^)MZ-4qdLKJ@(bB0=_-@nmzrwJmr+!{l~cy6oe0Y;GoHm?d9R%E(8huu)S`tIpvk)RM9ZhLQBj^G^s}f!jnEGof!O6@x5UTqTI0UNYoGqeJ2Ulb(ZupjuIb*3HZg38rk)T<b*r~l$%=qaifPPd_1vhc=@gCyyeb4r&&{m%$sa$Z{;!Mkqc3u;qBq+VoE*1${__Y>HpQbLSBGlCoZMVT>wpU^qdV~H5k&ZICdHJ`DiIg4|D$(g31$@S-ziIw&X5(vh3t(e7<<}qjC)We=S7FW2P^WE+$i-2QVmTH;-C<dNUl0A<AX#NMeb+IfOVug<=}+&oC36yhjv4>bdx+c*lr_bOE*<iUai3pxX#*pPnuc8MF50aOU;A*)!>Q2$<D25$vruxYk?XTMW_KButIa!Q#^Z7LyFDI8#Cn}x$!(n7YNzN^JL1nBea4?FcdH8=?!F7q3?k6;&a;3EVq8=9tDniY@cURxXg`O!Ma;bXr3@NAU9@#_L1}a48QGIhh2R(KP6jd@bYyC$ETp!+&{Q4Ofnba<(V)cu%cZUo}j!_Up$ofd_YO(7((~#1bvw6<NF5l#*ufsUX14pfLdYizU9If>}4ll>YdDl<FBK=aPZ}G&eIpx{>}z#T-pm5d?HlPp9nSZp0GybTc`{4-U>5_PD_I_;)#O(?E+=2lXFRpXfGX<0TdgU*R@+U7c65!r%H#30k4A*5^u1yF)=3a+yS#s;z>M=HQWs>PS<!CzzskUlN&ev6-hM!pt$G)F^;XP?2KGAQXic18i=BS<YH5p#}fnvAVs|XcNByc$JsYb>tGFSw2jIU%JlXa&<~-mS79I{DuiJn-qu?hWXT?q)~F~KRQ&agIp3iMRSX8}fp2$`D#WP`u=2qi@_oq5f}9RYHpS-aJyf4IL#w5p!1KitDB?-ee2Efd0*T@54jH0A%rs4PWlV9J`L)fzkho~~X^$aL$349*ker_7(F}kL`tF|)_2bbakH<OW(F&uH86EQ28RfB*fSH{itZTues$(_fC#o0JEjzGA>zwwcdHU8P_yS;GQch-=uX@?;hB_Wa>jM9uH?yv$2z$;{6!EO!pPZ4vi&EL-c3ks-dFAob(~Sb5pShp&KPVfo6WU^C|CBcQS0f9d!Fin^_?GFUU|283IDIGZ0?$84rO@cLO~_i@OEXftrj;6lgz=6S?mw(7%0~P2?S%*>+90Y?COMEbxALw*e8Ng%ElZZsC?Ts;m=5d8HmiLwtcG8rSZ}|A<s^Tb#atb~9cN2$1o~?%v&Bp6`m4iD%El_a(OhpnrONFleQS<p+x+h42<>#@k_f+=X)cNCy=?K`S^I06?u!Jo<(|vOU!J~_<*@zJi;)mkipZJ>UwvH&{U$@__l9PydX+~nsimPrKjwuRrGM)OD_T-s6D_H+WdA<hlKMmrn^xd~$;p=%Es5_`ETO#FJ48#Md2(N|1hwC$RYGWdxUW@0rz0-8rd4t!R8nKeq2XM*4-qQasqXFxJpSQT-~X2nU~7F`e<*HslGRV{K0>7k!>8a5SbEC=)%P?|Q+f+Xi$)DpilS7CTGdzZ*`(TBww8|xkuHtACOkwO2pW0RgSfAPqatl4yRR!mpQSde7+FVuwJRwfh&K-$)tb**ksi9_2V6QykauozG$txyM96Ki9cKdL6Dm$0z04}=BA0^5o^%DG^As%{Y%*osVaQ6V9Mjp^N`7`bAc53FLR&-ctt7$*a!cttC1ZwfZZQ5QHW>Hb49~tM_F%s@D+`fW7?K){FA0SC6;?^KX=^RIkdQHOZ<PIX%eqRMgZDN<*$<}@avH*FjV5P8V!VxW_FiqK&U31gT5j`VYy)%Te#Y&nq>=$^YB=nUy-p0q-ehHGZ^t0c0iYWkZUckYWhByKDI8N9jKdWPki_;NhZHpJ%c_KXxu=8+jkN#A3_j}5&#(=DQXxmXgc4AsthkVB-kbxS>FWU9#d?8HvZj=85&W9XsdK5avzL5oQk$Zhur&;-7PInfm_$UEczp=cTlchSR~JM{0v&xqX^I(`dUPwOAw#}~lg=4~I$=h`q0w`iQwCxCL^DBxRlErDQmF2v9h%)sXf356@f0BsG_O&rkZmF9=*X~7chWZ4TYN;|UUEWl3cuh5(XgMmXd%@9CUvEPsUijAxSQ&W5$c`HhMnxXvo{$jwKd|l2A>^uZKcrCC`)k_Jh7OowKbx3+f1#}FGvn}^I?3YK5WIDDObxxspIxd$A*lT^)L*z5v<COlzoBan9PgWEv|=W6R1g0ty&w9s<O~w@vu!TV8CD=nMsqJQJ5u{zqxXz>g@7k%$+VxKogWt7@#Cpww}x>)0to90Eva-7W+(Ar}h$N^mMfb=B~y*P}b-|4K%2B;^cx#hHRLmu(~%RRPiMG3B>|@Q9YO;8L3XrWK5;bqR?WSR1Pu>k4h#7^@8gq-^He4$+{Zl*CmxyOb{3stVqy`*<DWc`?-3mJ0)Y1QL0<egPn0g4JZoXBGk8Ow29TTq<G*7l2;QcoDoI-?TIhL2jQS=y6{PTek}mehGAi#s!CXIZdu}70<)BRmx$Xh#821nt54XFMD+w(CxoSJU^Kg!nkg6}OvSmf;)$oF4_E9-lV+@M>9s&%y*1OpX8LeLvr9{>>vx}6N_w`QO0hErToYYrY8}$lOOsu!+aJ7XevAHvb%***2rp2bij-c6zA*^}!l7IgkUX6}1*&2o9$NBWVJuGNR3L>qpjnTjp;od9jT2+ZD*iEZ?(>TwEvDFdiJt+CM!g8>{D`mkHp?r0CcusgJ)sMiDbl^%wwdU()=fO5K`{WKIFL`_lFfV|@CfVGgoFoO+Jx#oX6qZ|#+i*fnV3a3_Fedou2ih+?w@@B07PvAuF%icQO>$9p~sZFlueu_G3W9Cv@!wdNpuD&IYD9Kz%t$>m%l^POF2dn$c~XkzIxUVhMbk*sR3G5pNcj?iGuhAZ>ev77`lz#Gz6){VUu8+ex-lKP({dX+xZkjGqe+5F{*#swGVdYWLTO*^p#zCgWO`EX9H@L?O_w;<SFy9R7Zkl_te_U2~TEfU%}R6;|KQIr%ZHPKHYq;D6ocD5C0rg37|22D^*I)+)Dz2OK~toUIuRe)z=uLiqQJIS>hr{B7|*_W<Q&5;#5*Yx?tIpS2}*JZ&9w})L?O{oD)}4BJz<DjEFg5&psP?T5fh*;B9c55Fj-Vyu@m_MXpriSYp;_l0vx&+*|x=IhS=O7iMGJNLh#v4R*jl#{Z3u#lQ4>Nn56O`{`9}nV*oh%nYM3crLSzG?-$vlPi3v2|Zm2=5~1X;v8t5P)9754=Ptnd=jPF9i!wdKS`Q-)%PDvY(Z+US4rV7t`n@R!`^U$jkF54$84EnAqxWGXn6rZquvtuq^XtQ&wS+6T9>g78>nYInA(3$i-N>hrL~zQ#P)<IeI|c05?9NX_9`a9YP>qx8#K-G6V0;BD~@?EWxoZ#V?UiaH!hoz_>7dn0@vii8W;!ZVo?N=;{3B2f_hV2Tpa^RP?uH}B|>}?Jk;}ZMu5_hr&<S;mv4ph`(Av%Ak~ObpM8`K4taxrZ1vUXcyk^&6F!;h$8&1{<jGC-p3P9!1fZS-6A*Al44TPoJNUH<Q+5_np)zv}n(SFbK~G~I>C4V3`I+6XtBcL)91V!GNJWs+{I*ae&noqR4oTz0v=~1kYGe(^^em+V8n6B&-_?1cvCF=9`Ku^m%MNiE)Jq`sw$5N(aQphs6Xp=q(7A5wbs>VZCp)~5$=(sWoDRTObX=VA(Ed*6Y`jWDMeVcp;^zGy{qxKH^GDb7>;C7DuJDhp@c%#l`J+qmql^5*`DggS{4;!skC%`6Yx!CZ`>X!*8ww<TG*G|6Yg>MB-&Ou$zP90`KU==S_ojbXFKqB%>7U^T^w09a|0Gn}h^6}H_NesF<*)uD{(1G<f6!}*fCtIHk#+w8zg_#(-8b+4_4VK3{_iB-VQkQ>X#WgS>{8W6vXAX``>esl?agreL!nWtabh!27(s$(DMkIAB(+h3_(`x4_Oz4MtZz8Uh4GZ5WCyJ)Y`>#ww1NbPz8xA)y}gj@ioL0GB%;%P!h&MAAMf4r+VlWI^IFuK`zB()e5ApK*AM!uf3EMRCW5tjQ;Yt(&FD?3HQb)j`V;;36jqIq<&c&gdb0`e>K5l#bU$T-Wp3oGO!fTwo%Ns6LE9c`GJ4f=4D0LIwrs~~D#CiL7n|c;URVfJ*5fzrrp=Lr*>q*x_0gJS^NZt`K%Q@7=4x+Y#Slc3Te5T6j-q$mYn}4#@2hX2OHDECm7~yu{wmo#>8(NEf#Y-gJL-k)3a_tzhs|HZ`i_2^pX278+kf8slzsN@pZa!G;r%b}@4>g7-=2$M#O|D<x8>=zLw)tTUR<1a9q_%)-giL=jvcQrX>>P-y`1cFH@ClUF2%Y{;>W#P$H3;r^1I=3-B!3y%0KO&ft~Ah1N&gx#&7=QUhL}rXlyU;kI8qPS9taQ7WYAWOLwl-auJq)hId}-@Zv;Lv?+Ia5@mfwE4ix+5;hlP`_A@?E!(^fgto=eX059((m#2hsi2u0h6eEVS@;TqS5W;*Ooat)v;KII7y!W_;6fYh2sR7Wney6_^3byQNG5;}O)lA8h%#<y7-u%QJ{Uemh)gdpC+|OjXgjD0=^^xHQfG@=p&<q>E{M5ntLq#D>k&DVLy_!<rTbF|n%jA^AJ%h9t$~obAVCL6-<nY)9q>{UEZEpc6=9nx>nk8xmg!e&Kt5-Xy9MnYVvFhcdT0WME5RbXAQm(sp~St7l%F8(FV1(_4_7e%#>U`I>fz1iz~!yuW}Jo?!Zmq9u_xEiM9h5s$8(G9Rsm%bQ#N=QaevEK2fKQUV}Y)~&Cxa!?#(-Hwe$*&Xzolr#7nSx*`C5Kb8{uqwJP%d-uSGU3j-A@l3%ZIUQT(rET&}b))S!tvZ<zXNcat#A*^hYTT8OA5JuXKSj@=AHoF+y@jqMjVD=vmv3N!5tb{8XeNhB4+=|3Z!0x@!Ig9TTIU~rybk6ST1UK0jI!AJ7Ovb$4Dx58tir28ed&cDkNbxk>T68>V6V(w=ksM*0@jmufQX#<p?m@!HL{^-ookv(k(j!iq#tr;88my+lCnQ?3fdUKZHDvfS_;@8n1IA#R8=x!Sn`=V6>j&~*03%62aJ}%e=Idw8vu(E3KnM_bj9s04N$>YI(T6VOlUqkK{Kb4ZIx~eHaa>8$Q*@(=FJqW?C5#>D>{Gy`Hb~tow*3&<g!@lOBOucqwhWA)IT5+lZ%?QeP7Je9Y6-?I@W~8jvzP3zwDIB{i>p{a<Y)9+c&QSN$H3VZ0-oBy6dX6&X22~{)kdJzMfNP~2pu)pOyQ>Kwa_6_NZ(A=JSdBr;7JgaMp$0sQb-CuwAay)5QN`C6el!s6%0Kb43Cz8Tplp76ndXvYaN^BO}Xh%GKWGa_1^uP@7M0V;m7yj*8=NzLu;zTdNLo`eoJdAh7jCS@|rA;<;jPMy$LSJPUc`9ar6!}ohZq@P|$N>Gx53VT~Cv3FfW<NYk}^1H%gt?M52H@8*4_eT1Akx?I^_Fu>1r_fsD~fmlwfHy^4T#3X^=I6-{&Pv=@1Zfd4)bo0;66aI0YsXR~_%n*mB8aK?rwN!`ORMQS3%`19`pq1Hz<lLf5@wRgj}>8@6Iy`wu{e4TB8XM$>`I}>p>pCvAV8Lec%dduEPdZJ#HeT32!9Z+%MiwqnC^e<WIz_6J4)KSz7;K9*1qL>dyS`qF$0k{JmTKT^CFkPhn6n18*3ONu{M$nO%WHVd`2M+Qv5Q3t|1%!RqQGu*i?#d0|+&h!jh67eq2)WYwz541TG<g#V8f9Qmz_JkW8~5suyZ@Ni>}N49&rehXe5RAvbKF0IHY6#i@gdGML&VR8M5thT0did|v}Ha&uJ6w*)y`BC1sWDeO_G6F(y8z7FO(q$Ub|)1dx^*jrW?tWu#)eYo<cpVg4*p&NZa7d!0)Vg=y5LdH*E6=N5Ilxos+zyFAz|kf<gTICnG8q+qo4hxTqu|%Hm>wl8BBWtcHLzmV?HNw^B*4LXAuiw7T|ZCx(vxc|5B?fx`np^5AdSD3QM({Yu0IU5FU*EWb)TuX$ovTvDECO-C7AVbL|y%OFT7$W(*fj)4D33O2#Wuc94VgzdZvp8+x@lHfFNR>G;rx|_%+T^jxy2U~m=D%zn}NGXpECLCF5M>2^)Xk6)WqUQ7B1!g`U(P-(Uc{G_un=!CiYG}c*wUm{WuQ|qsxREOLi{%Y2nUnE>Iqjwm=fVq-OF(KCkPAL_B2#lY!ox$Tp0Q&NP<vtBXSquHp_5A|TIu4b+v=Th5piA88OBqqx;bTUt|%l1313*?X0>GEPgxhLp;2#sM5{qe-e%_5>S|l<C}*DD_CSwU`!pvYM`OykaVzeGn)dSa3a!p+92V6*(js})zPBYiKE^BM$mSwp#ocpUJe2i&#~C936$NUUf!eeU)Z#`UL-c@)W1h|DhR#xDZWJd)Dnhoh7GKxxPO=?YG=6RmwI43aVqDO(qF;ioY+9MUB3`W;eBg34U-@2EK;kD+g;jg@N+Sbuj$}?5@L!s<Hx)Jpd|ZFcoW^#}gNfX8T%$cKQg%}M(%vfTl8{T52qOB43=?G%6%`T_O>b6H{8Oa52DfBX=d=f>0=`&d$=-L_K0?86&K3+kTWy-JV~fBP(s4ga=;=$cQG@*F?|fK7_Bv5`z9)jUNSoE!e0m{*)lmVf`%>~(bg1a(jgZ+Qe5HVFr07e+3QQjDweZ!#4}P71IcTyftD;%l(t;TjOgGfaxFrPREV>Y$7%%jS1y=q%F8mM|GbO2Hc}9UPArnx&+vHv)9DrvxU8}vnqM(P?F~6+3R^e3R7dpFu2seIRx>oVOTiI?u%}m9E?H1LHs^9#;><xnm?@_Ej^_()uqd_$h!zz(BHp!b9R~kyAJ5qTDP7ur<iy?R8NN(HgTW!tUFr_65BOdU_P9Ti+GAW<{bebcxam3*aZNPIo+s8%2bLD89I$U+!b0+y6t5}(;GgOn4e{G^!!?E7mQ3Ow%NH1oc7--^vMQhq6rasUDN%F_W-KlvyW<3tx#FHRhlzT8~aZj}b77(F2#CT)Ez$sKC?J2LPMK&?dDwOIm3u{P*NtX!EmNX{Cr)5+H`B5yC9Ys^3mH1d&<7Y8!S>EYA?H?mUNKelrPdCkUW^<|x6hmla1=`caXD_K9qR<)MLK~-8+cQ|b&MIc6K;|1OzJC1Qsnb)h%5J@KpLlU3>IEEP+JmW+jvfQ5{)iCF+zv`la5@frXcNVO>X*FXSYWtRSg4j}c&vZrNGWQ6kvUXY7EP@A48bhsO+c|xDFY>L!S0C0uZ#!W#(kj*j65BZXe*rU>*?-zBlz5pd~QY(343oU^59^Do9DZ!4lR;iyQcUWn=@hX0@0tjy5VuD@j<NNX1&H1TyahFM+xEbryg+LwMN{?kZslg;a@#QfL`FV5^2sI9%B4+rdxzZL@&+m^moDQu6O-Sgd|&Nrt>FSz}Mk5F?H6mnOZSNAw$$pq*##A=g9itv2+PUa=c^GW=WD}URrYwIrhZAvQHCwl~ZEzYt6l0V<hC_RLSBoK@L)7R?#+kxzufV*NF+mv0$aB$<vh8Ar4A;lGTW6z(&n3?mUS0>LipYQA4EqT6@i-!}!&Wn^BKkLq8Z9G*U)Jgaq*-A?OT$8mXO|kdA!Nn=35o1?&MRYtwhxZ;8@?)yj{Xg_xoS9!aNz+2{d#U2|t1Algsa9=WRdv1^rm<H9a`VAiBvjmtJZNi#zSzes4<i&fT<kA1LSw&WhgV`=$SBN^r(+eF!n70U$G*Y^4UcvU?3(<{v?KXCQwuEm4tYK7Nl3!c@Eo*5lbQi5K|tlo88(NM%1NWAr`ct`n>KXA=2O<txalp{nF^b?n#Cee2B>JlSk$WJ2q%o40hZq6z$xM1q|nlte&JEnEHv*Xdnd0>`{=~3|V#!PKLY2kHhC#>^!YcaLsv2{(ZeppqhtbO3U=|l$>R_jOeW;6R88@1E^i7n&0L;B4G*FGZcKgYc-t(o>)Ti(8D{iA%d!*#PO@h7>&<kW`YwT^a3%`#8WiLlx2_Dkt=!Usia?Y66<EcR~tQ%f)Us*|aS%(D2aHfHY^2bl7u0`Ye!_KaQ)g{D9$kAaO;ij-;T@)>2WENc{ZFF?m<X#=$p9+r|%T`BGa>n^JK=o|JWHgT=sUytLdqL-<hBi}(JgUPy}n}D9ec*Rq2FzkpR>*dpnu?#)irmGV1h;!!Xd4$rfrE@fNEnqvt_D8RHx@mlBDwO6=HbXsicCgUyy-3k;>%=EIsFWy$U>@4MIfDv`=GmB=({nb`tKPIxE!PrB#!JCMt9hbJz#w)y%P`4mf)JN1YSv_w+8+x_CW|p+l$WPpgm9ZxTeG01+Y9bZCqz#pAeP?+9un#Ad|g6TJ?xQ&m&QnCBV<)pKcsS#r521$6SAsfhe|j}wn-ZMx!E9bjFVQ#ok%Pw(+tT;dfBwB)Rwpvva(#2(+#zWI%cftO2|sCzcp%e#Wyy#%5A*Ei>Q_4wML3-uWK>uZr5onsxS4_3KV*9%0q|){PO6!N{t~8QBRKX&aH~~8^=KX69Q_UdO-o2;B(<Z8&*!XexwGiPJiA0v1h3(nH74SoJdt>`;lGT0e}f-f_KjEgLSMmy}l*Y`=6*6{2zSP3dcJ}(DY(febIO>i@VlKGvPL$;_uy+EE*<-!RY;zP?i4YZSR?s;dSclIsN%&BfJPuWv=y_H#-KT>CX6iO(KnfVZJJd<Tjv&CPpP`)BI{tWK~H+bNYzB$N+I!b*5dvRY}7Xb|sOvbf(u@tD#5QMCm1KrAGCgiSO}d;#+3DxUrya(!j!yB-mh>?eq`RLg%0TK}m-rH@mAFKHLgD-rDBWjQteG&bSl%IsuVwU7llnqN|9PY%$)cS$3wV%J{~WXD3<a;fcb!k`5QD5*a1(k-E)az6%GSho=1=TtfuRlu0^5qz#Hl(a#cdZKePzqwY+L8kQMmkLD@T%EjNqn}ZxG4j^ww>W%LcK?HTw^nS5hHOtn50ZhN1R->nuCs7@6_6e&C9p8`4{}T%YQ3_iAWcUK44P$%rNL^V>#fxhPYPCXtc@~Rs(Tnv<)&q;Ja13`WxBSx^97xi+ysL4uF|`elAIUs6xb|Cpq@?N~jxa+t%j$R(epr6U&u5LGo_^iWg%_l-MH&_97)+xc8?(~?+XnC_T$j#hRla@22@3KVb<TVC^&u_~UJ8eAX;t}_bKzUx-l@MAIm*m>j<h=_eCkmDTHuX=CAaf$sVufPHQ~B8EI*jK_yQ;ZDVs_#YJTw`avMKVRpKq?LVrfb8NYkGOSTl%kD$)8IZj!~^+I}i6PEK7i7q=j_z<G?*4ztO4&n?g$@zL<oo46^gM<2|bFl6A%$eR6L3#)Q0X&AX&?Y{Ki5%D5vm8X-mHKeJP13o?LE^8x)CYb<x{+_2dh&yVd|nxRottNV`&)e};ax{ABOQG?>dknIT9$|PNASF8b`d5I{|&|c_Kmt$`YtCK^mfM?mSYNsoCYrfr|o%>zFbP)Mz+92j)^&YU>w$v73iZjqkp~g^!%&t*Zus{d}39nd{pgQiIk1>nbPFYH>p$g10_oW3W1PGsS%gV1L&%tMsa_^sHqcBot27o;0kh%QO_6!-^ThdbH2m&8Qb?KE{TwxVeM=1)ZGfKaU@M@SsrMuX-%&UOfv&%4)V$Dl5!3_`4gK+FbTmViwTZ62-EsAQx+}7{J-;3%Alwsw9gw@#Zzfr#Su)nWW1=`7ThAdtoi~w+#w$HPuA$HY0ce+(5c4MdiN$5$cKqu)t+TTL_$gaTv0mJ%{P|oUih`!8S1n9>OQ8c963Wh1MvBlNQQcO-sbDb@WdH=s+j>s@RKH^48{Azg=v|9lHw@MJ_GDH*523TN1DpbCe?=t=<SaAWZcXt1i2#GMAC`JY1bSSgEWoV#q3f`j59sFi2~bmmWeN>4>kG6h@g%)-&B)&g2jk)jKXUrmRCop?zF&PGRxi^oVvKtZw$-qKw-?9O!S6-)*4hdJ|7{}18KLo_O*ah-QinKoD|jBr74o{|CIYJh7UghKNq9~Z?F*bPYg5aID4k=2h-s_q~B1i7X}2#n@3R&(8Tb7FQv26-X6s<;Y(PX<%!Bcfln!+*o=9gUP^pWJ>Weq<?Nf+LI+2OdIo2+N!6A$xQZ$zNs~;&b`}N?_SSxG+p9@FPC#*gp(yxK)JkoD%DX40Vm$aRN6IS7(hw_0;0j2Ma<5Pt-h&TxLkc{7C`>wO<VC}YCjnVm-A(fj8m%elkhqh2QU?R0^}L4lbmZWJtmRK&8vL0CCHr&*bI$9t<ffi2K$;)NFNl!h{t;MYfM?j&V&Qk^Cz|8=s7Zhbn>to!pqmaXFR}9$(ga(nx`&~!lMVY!%EWEiN7t(FFk#Ni(#>IneD5L?Bup%`u!D8n?+8^3d}k(-Pit?~HmITk_%_z`31bw^zZptXvhAq5>zIG{J^C}bFa#vpPsU15n!Xr%^^Ba(z3(PWTxG(<HKWPPPHJ23Fn*5<j$m~QR$zX5)M^>a&wt!as0aMH69%r{Rl5lyZSg+D3vyWRukQc?lh<#;fG}95k0U3p^(GuJ4dWr<%zfNk{<2*D(~E1L?_Bk%N0W!P&h4t7Su!h_D>{{J2VQJwqFFt;XCiQ(VJud+gP0gWR^Mt9&JG1NnxUli8VBTkBwby+Jt}px|JRm|y7^DObKTIDem2=<E%R?#nSMKB^@w+a+ZhQ>i)<M$ZG&4GV0>tNYl7+@9^wk?Fo&Dqmeb>l_%^O<5w49*bS=0|FM`|dZg86vf4&H7S^3z;w1Z+uXLQyhtFJv(&62nHwrg?bJL228jc;fCsa!|4XxC5tREuo$8rjNFjFGK@t?N8}FTULdx6U*{72mQxf!~iek?p2LAysLB8lvJ`ENx3wR(3d<-ms(phQi(STOT&Xu#Uz)Tv<RtGsbK^-n#bJS+T?XrY0=2%9G)Cr<>`95bOif>iY0g6dbaBdrmh%t=ExTGxiRJFHJf<Lu>dk9WmG^_}tu^Zbo<LUY~CE@SWMQDmM+#)Erpv&HU^62`6=sfkd4?b~v3UMoU5Ne|5;zxu!n587SjTWy<T$PcQELX>;exsBDJSsH-9ruEWWHLq(|gXV>KBQ{P`_HlO(w3y9*(J2IOZc+F0+7w*i3;cf()w$Pqeve5(6f;y|083jq~WU%C+bhz!n^IqybXL3^qSIucynk>Z6Bi&h8_DmDVr68D3cwD3&ZZrc!5w*x^u-cB7&T*G%MeLVt2sHJLd_N(g-txSNL}ge9mF>{Az44=g(=`@HL~rxvgY2&1Fbidl)0&Xk*yp6IgOsrmUFU<0jxn6rDp&WQ=*#|fvwQnKN^te0`=bXuCZ_Yi{Ifn1pQPtENS}egdV}c{qU#5$cEfxNS>o6Q7^E>2+|hCjcr5X{5Mg_*L9}>l4O#j~s`F`%D5CvQvtW?EK<5P$HRhkuKy6X2m*Z30Cj*8Pw;32Yu!a3CD);Lq1R}Z0lh=}3cl6zph&OC+Jkf9rT8{C#hZhzKhHBXH+C9X0go%kCISzLZmKm~p9M7>KM|n?r;j=iw9)D@Uz0Hz`eryu&SD?2It+ZZsN}3zsV5jHDJ~eBKJ98%N4BU!8jjS!vb^<j`eq?5*K3im{LOj=M;B=(RjXFRo6nYmD9%X?v*JZyxKOH@Ee8c{XtR7HpzwB7+=e=b;n7=bCunfP^osJDr!J&y4v%LEB4vri~=@+zQiPdFlH_5GsxG`;sL4}oiWSi6<tlXKBS$L)P9G3QtJu9<G=qV<Yg*{VpEPQEsCQ1Z}ZWKNqf9oR@)*mH2S|3s#<_S?<oy78)A$eB4*Ovp{OvL76nm@XlcIhKP!Eqh{U~k6)Nu2|0zBwXL2#yw~@^iHMDx+>P1CF?3yjr@9V!x6D1MSvgQpIii);mYjN~u@4q>wt>gH&E^@}Wd2aXS3n&_Lek$pS~)PNoLE;hcrAE_%ChK~#chP~&Ak%0=y;(Y_SXvOPIW9H~!kN0sDlF5&6+SrT=TEtCCZv&N_$YN0{$83;6stRx0W$nPaM!PEJR7LC^x`1!-4@x8(J%Hg_xb3ln|pr~<N>Nl_%1vYzIzY!L42n4HolyJ(65)N}6-u9)0gWGhccoR0on|Qx?1H{b{D;t93vMJv543arI=(!-MypzwBPL1`Oj>Vfgv}Yg1&}C(<##?V=tK2NK73a%_xKKa&)>&yMt1+ZXZ$cr5U}d@QAvP|m<!qY4`C54!UA_l|GKDQQ@B??C24MYfaF}Nwo?f|=@(|qK%x4+9BO`gMs+>2B*`3tt#Oe;4g+5*9RoR%>HRRvB7X>@Fyk5(8C;xgzRfj-Yn+EqXs+LX>6{HubH8>-iNy{)9JC>3B-HySX!J=%b=2hJXwhJs<BA3c@LV-g;py3v?8DhCk@5!sS#X-DDVtJT&N^hA(BgayqkT7-Db#a7@+N{CcONu%uebo8#D}oI-q1k;qc=6Sj#Ow9+tGOECvKUFSGp+E|S!<2McZ($qLU9^ufe4xnRBy&I@f%6J%5S*8;PX#J%Ma8dJhC9ZmkvJ$3>LD3d}XKwQ12R6u?SKi5YOK1iAgrotcPj*qVNP$N+#SXN%N+YQL<|~Lr&hxeGO`k>_s>gBM>zjq-k~r%mnhdF?m=g<%A+PDxc1P&=dR3Hh{cV_vnxwjiP4o&nHkJvDne~nQ6Hv$FT?zi^4vy1_&{6&(#_0NwQPJOihU385Na44vr{zMY;em)+QjA2$yhj1fI!`-l_DNMLjefBpfRKaS|6GdLhVBQ&v0>X);AV<NwFryS-Ys=IKG>J&o~>F~>Ztx#l|TLsjkCT`8-p?Merth?FAvBfR%UZ-j(Eq|=BYZ4z4vNxEZV$Ht%tk_1E&5Wy27c%fIuyNDMC8bYHYeW_Qz&-46#V~n}h{MP=yUHj06D!y8KuDQk>a~$6BzQ4nB2n&C@GkvCGNQ;(I`}yl%+~r@|qv*d2mO{oRoJ0r!LY$O>g(37sI|?2KGy3b6s7$CZMgNqZrb%<z9dcJ$1?xc_S#)R{Z)&E?<fWM_{B$sTKEYBHBDH{epQ&k}E(CnV0<49D7gAfY9c>B2ehx5or0YW5Q-Y^Gi<hHHH1K603j})@D&RrKWS-moNXKy^YxX01ShXDziiq*T5;wlfiz)=F#0#HxUioq#_>94@5gWTe#V4UHP4jo!nsN&yv;+}_fQwHVJM8%DRTGHdmASiX(@Q1bf<^cPu~iG;q7t@rTYuurB_ooAYo3}k)CBE}F<GZ;f90uJoT<PPIt<;~4u>tohh&T>T;%?W<-|xk)m}7Cei1Xm7B3LQgTNu5tTl0#s|w7FBfV$P=`&kRp4WgPY&$l%Y3?d#-4i~!@2;STEO(g?ncHW2|CZh<)#!~XchRQfYb|d5&K5>qT6*z4<~NndHE2=fnFPrBkmspAlP#7q&_zvQ(o|+1cDUN8Z_o=0tO$C8r$9(3eR-x{5I5|9Cdvbyn>jNn)U0S?jhZC$(q1ZfNR;}h)v96};C@FAoL~(Bq42Q5oO|{TIS-?3p6_+EM(gMiIcwH6uVdWQJsD5gga(t4<Y&3vVt|}ztTWz$Wi0FF`Hu6XoA^vYGbfTc92>yHL7uo1X(DkiLLwOz46<;JVn6O>W*1~(l--!Kg;8x5Wmp@`kxsPAb2Lh`X$SJD`&YU@o#OXXJhmYiN=@xFpHD<VgFyrme)&=23pTl)U1kaV{BRsoOUr>|W-n?#0s(%YGR#M9n-iQPPBq+h@o>Ui*K+B0Nzw?~ZhJ0f{F?g_&UN5!)iwj=78|$UcH9_be(aNf#ctcLfcEzoZRmIaZ@Srr7A*MG%zXk*+`hv1KUBI!o$&rplOETBo~p&Y#PeMzoM5|MZ#@kE`TKT~+SK>Rpq>?7(@(769wJIVns%7gc=v+!z3L~)!|PU=cf{>yrMD2#HDWnhdP~o$C!R4K&D6;7mO1Oadw>{TmV7fgUQv)1EJW7(dtLrz?hPv>)nwS{zzbq6E=vm7p)=Ux<nz=GLr3gci?om)J)+=*78I+*tO*|>gu`ZHJhRhxc8}qC7X&=_88RG|EiK{bE@*YAwB5Xk&aU4WI{VMOuP4$2a52CaUf2V>Fm9wW*zQcCB_Q6kG?L0ji(VZ3rZPai1M7?ES?H*=QS(_vW~2VMt#~H?8BE&qE<O!t+aI`OJS!StIFdPQwTNfV%FHcR5F8hbh}pzPMX83Q$g;hHsu(_@v1+~~OTrjYBgDB+Lcu|^YmcFd$s+*=aM*XXO4p6kW28Cl%n7zo0g9$F5yzZFdZWr0k}#1+uI@k#+j!;Oc{1Y_paOb@j!)O%x|C|Xjj!wPD5%k1@0fsHgX=UME&a!H+%_Mh@UuXREx}FOPkpQTIH>uUP3MdvFt!kF6XyCZe4XLHakZ@fNOoi!E;k`|(YuiCo-mgXxENrTo=$pKX)`)En~tQ`WGGC%0NTkDk?6h|hgZb|-=@uEue{EjFRq*ds1{S`1#5R9+l|h9q3*mLnXGD{&TRH{SBC2SUey?T^LA5`Q>4;kIR_uLgfe>@dDvHh+Lkj?7r0#~nd5H_DE(J#o$`o%yH1_k&q`?cV@JFZ29*{Lz-^vzvu5WSwCQ2$j4wSCE6+EjpwVU!bdo?RbtBur9e!$D8QfLm!AQKqX=BrM<7dxn8C?p%{+Tr?5jXKZh#s;yeziSkroIT^o;QDb*H0ED+8qx0-CG7@+2I@KY|8D?Ux<vEC90*vBVgM8=`7Bu=M$mH?txR|!eXd3F@S#zCLjHf@{ha!`s)w_wA715;^YEDV6H3%cw0%p?0SIFe0|?b60o9{5c5k(z_8LXg1p8oH{;$4&B9*`11h9NegG{|%G~hsiJ#NnIb~1PTu7w9wp_%i$f|7ZXs(8{V7jFsq+=$syYH=G>5S!=id3`Qq1FYMOx!Vc;i@HRT008ZM@quMupG&u%ii@8<69{j2N_3i+{CBrYH;58Fe0DG?+_3C>mTfy%g`>LtwYnI$8r$Z?Akmxqd8sL(5cB<3oT9Qy+B6)x>1eVK)!BL2cLYX9o{@iSyg^+(Mng;43uX!xII~Z-ce~1)`u9(ewFGJqPoNHPy&qS9@N9yDSp7SgR*^ymnzHZWaF2#-A|e0yR<u9!!xxQcH*PP$H{cU2U0xSe=g%9_lLdJeY_;d9!3f`6rDJQ5e@)&QaucNi>Cqg0XA{z?YN7Vo+L7=Pz_Sztb{rU<QQEBydBiPj3+;b`A3vym^qQm5Y9r2I-2eyR^>KN<ox^u$LskK^HZS2*SY7Qlw!_7qD@KKQi;pw<D<z2w_tj{#P38YOPDHYyOtlfr69)788@Vp<aF@<XKjNEp3;MOyZbl~_;BqUkKCmnwK?c1J_t|zXiC^Svc<pOw%etgj0cbT>mrZbG|j{vNCuMDiy!-+>Zzstro7oM)u+cKma!>HaX{7If+6EE^xtFAckcR0qn}e^<T{sfnL12UQ!X=VXgds$)Gk6_p`nIZt^lM;VahbO*C+b%wg9we=Z?pYR57Z=1Ia)f^8rOU6@75;ogg*quX}!qD_MKuYC(3)#}+Y_{B>E`Wx!kMDhm^H0AGUJ`OX#O!XE9d!0E#B)5<}CCUh~yb1v=i<92Kb04ml_uyK2*-IjA`x6@lVN#mYkq)Z4)yAQ|qEpe1SN`&ij?(u-_DZ*3*ZDmwWk{RYSftpF*A>E|Xt+J2;>{6iv5ga@iO~qD?=>N>yynx&2nPfnMp0rNlX#gc}6PnP9akdg)%Wy!>F4Q79wRsPHy!e16w~c$^wBvVB$Ibm5$-#>A9-B!bt8Mm!XDXBml2Q=Z_F8!g#mCjp6~vFsl|f3XLgq(fn*t5P&VE$9Npy-yXUGRr|G1La>o)R09`Ar|&H5sD(?DgF0Gdb;Cjnt)S$}#H)}SPbsmcWtS>?JXqzLJ^`M>%9Wsos_L4=V$EW&W<VN??FY}RPu#o*z^K`ybKso`SGFY3e9nt|2X?7_+Nskf+NypAd!wW#({q+S4`q?gA9aM;8aFgKn(dH`h42(54Y3j-@9@v604-;^YN`7fE%v&m)Oj5GeuZTt7^g9U&dBB@xN?T=*jq-*<kJ(G&3pQ#`_gmQ<11bEI*UAB%1klmTJR_Vy1_BlX&Y0+6kQZ^V23|a$G0%V4nFb(hQ|Ehph*#FM{>c%iEaoEP}vkI)ihL%Z&8&pRdr&Y>=+5n4xiTv0h`EU9xOfbB#As%g94=J<brh2dg+gR;&MRu`;s1$5keB?m$7)((^vgM_dQXf@BvoW34f61@L%&ua$%F-wPii%53EGqL?MJIQnHcG0TYsw{j3E6?bu=9H2h(2)ymntuJS|4~T#6+SjvuUyi@y1!$5=xG$E0)T8+eo~AD$YPNjAH9StbEbPt?ed!1?OeeOWoO;G<xm4^Fcv|kBb_yyOdo5K4X<Okx({_vReglwqL|e2%1h-5lLxd<v{vujTSpZ1#Da}4<>JlWvjZ@5HUj>T*;K{q)oj6r^L1HZ}N*tv)JJ3EtXsd*(XtjpfeE;71}^^ilMq;S+sLBy_-PXpWs%3F+wqk4udNO;Z}HAD7q%S1#kxv8+L02AVt#{r6<K8eNsLs)L{sNf?5`VwUg?l7r`5P2UI%Gstd{iHD7Cz*vfTe)AC?z4^y7nJmIAb;MY(V{*&Erhw@K^a*rqA{DgV1A6aN^YwIr(Ib_-;m`(4FNfdNmKI#D65m+B&0hA~;5RdmNC-Em+UYKR>JjLZ;oOz<teabE@bW|Mq5RKFniFWDYM_oE-hlT3JcPf@7@3`T1a=|nXJbDXVettGbqf?8J9*roa?}hsEMS~!!05`LHR3%0Hj4e-(oiM;N-vO4?30)?)OO=j#(2dG-GS4O1K-GWqeY4-*`Z2gLcLuv$z>FqU)dy4H3h20qL!CTNPZvYyMPm1$dR|qX2Qz{W3wU%-yI@9NeNf31mGx?^Jj;Zkt`g6a(dBw>O!fSD7`ZRGg(02=@hDLKj4GdeKT>E5n&5)z*w?lDHbxPT%-&2I063!oRHPKdYvUdYkNIHH8Br}f@}niOifZbe)}v(GMATqe1xSjlWMTw7_um2#=f?;Q&=Pn6r3rx1o~J7hhn(4+O~_4%iAfSYD_G14f<+-fm>Z;^Y#UK%&LkA0T>wIPVH$55Ro0m>P0UF63zD8dG~3yrGtt_{z|f_sef*$KDrP2ow4l2Opn&d-MAbx6pMqhxw3tJ$yFd$HdX}!dZJbDUomsvZ0Xc39&Zp4f=f<ZXFDkC;)S!nhh=mEGd-J)9G&eYLK95jdLuK-WN9f32B^Z!}w_?CltaYU4w`XhEkQ}RWK<or&!p@2W3ESm0!X@Sx?SEh^-A6k6J%o@aZn@)Ug9$a^=bu`0ieGvsSm!E_;OvJC;vQeoCbW87#W<Es;XoZJ%F`43unG>D9*1QI?a+=|e3FbK<WP{@p&-^JH871ANDU3q=2-fLEH-`T`O2gqibj`>GS2uvRrj5NfFwj(+CSXnHg%oa%^5^VG9@fvPw$hIEAnH@MKPhFVYee{D{UGHC)8Dd@5vMc$1IIb{N*2hDaj}DRbOlNoYdR$LLMLL#V=;02I^LxSeiXG3(8HoNmXcXDWR1Yd7EtcGGHD3qJ)Mj>-GKF$o2$7@F=dv4VhfI$JG9^$@XN^ku)aqTvhkAOs;GT#a>j=og8>4+f!F8DM+)cmet_NoSBPs0(XdUmR$;9U~g*?^3kn+?ochsCbF3hjKl^A%0{a7(-~n1VypE>YN`_4)iWZ6fJ{MSexht4XJCw}w1Hq=R8U&_O$b|B`kMp>^?s8Pq7n(3(bv-Wb+?>i_!)J{UR4&NCkXvX7=R>nE3xzD_Gg(w0RU_=)GMM+)#=%BP8*?l)cbFw4At|6l2oqgWfK`waz6uF@hGh2JR&vuC`&Cw_<>!pCA+GcAu?k!7ffV2YyMSQj4;Nl0_L?;ky2d1UA=3Eq6p+$Dpi4O1)rFET?gACB{NHBMGg+b3w<#vCwV<y*w2WXh{`B4uUIeTw90au6r_V`L~1w}N?eIXQ516fHDS8m&BS%?k`41E{#Rw*^d*V4ld(bH$(2Lj>z8-1`_*p(ejM*Q@KHKr=pjo4UX%O>L!a+I{RTX}nAa=pdu8jzSZOOKAH%EK8vLv_(=-WzwTL5g!_#ZCfSM`Fm8};e*M2h{TLbTPZB47HR4Q+m)LafSzFkto%=kFIuBTlU)28cUTHnQO2ky1)a3tb=;LKYJR+W$>Jj>E=n}4@8G(Hxme7iG;de&d+WUi7z|6|<G{^CvT2lliQaX_39=ew3~!QKPc@-DC3Ak6lX01n%l740DMp7p2M;_~$${y$)qpEvL0nNC<G<NA(RM47=KlH<&N6*W%ce(d&W2(Yigca%a-aB+aL-Lhr-2W@DXTSu%=GlZ(K*`-BxIGyezt<lfy_V@?q5v=AIufC#1MnI-N8G`AM5CrWgL0)Tou4(>=b3uEfo#P<Wj~hS3=I2t#ik4QYKeoJx`8^D`mJqf*dTqenGd(&bf$Xuf-ojZXCg!=N+=q^pdOq9Z6b`+DT9?r5J)A|@n&zVm_egeK!>dK5G%YJy5frYsXL84+W>G>b3Sk*Wtx;?m_x_|o^dnW1sEFf)(NNjF$UvA;yS?4dsunb<O<D_DP)Ht4?kV3fd8&`w8t;kLt9;fiEljIM2ljJBs7qodwGr=WbQ^(GyZ<Ywjr<aNc=OoJtQb&uoDa#;L71WW0>;!MALkK_#`d(g+<|o<h~Tj-V2wJ{-iAMtr76+S!j|gwcgn!5T1L}G_mVnA>CsH9+cq|Z+{hy)5e)H*amfg=6J{8VsJ6{GQvx5yr<P@w+2Oe}v^WsRe5Un2lF<uGK;-bY+;}`=dH{W2@-tb!+4>eFk@YS};R|1-Z>;83byAd09!E6o8zfw5<B6@ZQali68r)%#-Fub9kk1#^4t8<!IvM5txs(6mXIkPa<mqmAkO)Lrm$)Sj8H^eNIC+-J2Q@XfIY`8#xH_h|PdOf{>3VSsDk5~_=!&$GTvn{cRjxg(y{0>=7#4R@&1L{~8>SMwP4-c4U{tafYTI<MmzlShYcp?z*1EoK5Gi~hV-!a_s%VZUYB0B=yi`Bm1xjJ{Imr!ii%S_cpcKkr#pFz|O?N1Ds-9yqS_P<1$~f3K%BC!ruNT1lKdf#j?eTu<7UpuMIL%goKK%llytFw;?)6qgEQ+b@5aq$KkMo|aSJ_WyoS?@~Qo)3H4btsS>5vmL>_M_@`2WlhD$??hWegSY%~(jIhH44v#FA8tQ7&3$+XfRbsj6s>{l;XsTZ@t~WRMt_<pS~f5~IcQ%i7z?oGe)tWkJZu)E<NMJaQ#J(f>ADojg&y+@&>>o17(Ghcd)ZN(?&!b?l6AE}*V;zGWMEriz(NHlA<_O!6%n+sWlp&b~>{0pPh>NRwKY>CF0{LeRF)BenC0;_%ToWTr4g2Sook?+MfBB*!13F)}i;E}I})5?Fwj@s0<^K84IC!+m&{odN5h)PjELUOmg(n(uSUr3;_zs$~m9b2>R(Q^U_qITUKqy<#=%&<obk=tRPr++uGXR?pX79gyW;l#>fpu$Epe+dFuHU=UB20I$94{pt}9Nq*T(e;L}!>+c7I5YVm~G-iNgN)Y&ic#71UrePY1I5fNxh1UAcEZf4WQAj|J9Lm_j65Tdtn;=M(jL{0EVR5xqc)D*>?QZp74cV&d^DHkw_e5Upt&<4eZu%<q5BGY$GPr)_i+#8GQ%W&hTV{JQf+dRQDVMvA@w9cigIhc!Fj2m=Q7~DQN(?B~o}|aCFM^e;o0ciB&C8L;cxBUJ{?saFOVJ)D`zvAVtS3?zn<?Hu#1k+q1+rDoJ8ph10d8+aj`hi2ugt&I{U#x1`!>)ZN{j(=M)qG73w(cNu*iq<@zIQ`PNWUe#l6LCNiH^U$9%9+DI@pA(VdnA>2NW)R-e-O!8Dy%HbkVOf&w@VkG7d<3C0#!vD58cspob84+fR1LBU9>k9r}!#<qU|k_k}4G;w+8{M4~x&5VgoD3g$1jR+nSN@4d&YzbYbXESk62b4@`M@m9Nyc3OCLFFnoXa<~TigEA;&Ju>eA*o--f@-vu7ZN}&Bo;ih^Zi@jZn0o`pJKrav~PN|STLJur56jB#cV1C>WqItv4GV&)t;oeK~MT9<EXMAZ<Y<bQqYH2Wr9S>l0K}Mn-(wN#sRGNCCdayqEt);$!i2G4ze_0<=7Hl1xNqwR~sA+433nlkbF;ldhWp@qa-R2(o>1wMI`62Oq!zPHdsh2^wyEW<Ps2xO{p)X<V?F$k38qL-+L6@JuDgw`(P4K9$1xR6W2!<n-c5TDg05Kl06zqjD|!82i`kCbmn`{Xvz&iZ6Gz2i2@~v1?kqoEIvzE!YB)2sEx}A%SCz2oI#It=JiY)5g*10`0O!d+Z&xuG%RKSI!joMTXMG`_0S{~m9@~s4rE`0;UZrvChX91E4zIpJ@fjIlscOHg9#_3Bfj^}qf2hd!TV=lvg2=ZJkYLA=G644B1IY=iKOGagdT06WwLCBDey8ss_T*1HRR%da%wq&SSTSp(280H!|miQ$a-OT-NosN92q{+n3T@4-NF+>MbmhCjCGmq`LOW;%rm!)GJWL7lU0OdsRdd!v6Y4n@uhWxbP8;R#%?tm8<W)!qB)AM|8zw=#(f)88~a(4q}TA!KA@7ud_Lv_7dz$*OUWowe){t_=k39Jarex|N8r5Gi_0cCK}s3vWmsl+*ZsE`n8-j<RmtiCm&7x<ZG|Qj|NCO7w8eJ_kIHCDMs=|HxxG1|J?%{gf@4j@zb#YXL0A##z<V<84HSfFcH|6<Iffjfc6kOxcUYw#VXscaA!pjT&=35Wk~Ia|+7urO*Oxur;#rKkEKRCQS2v7@_@b`b-uy%FOaxv}o-O#V*S=;g7Z@?7+Qn8wvF-b!S|FJH?%P(o)qAT=lS7n!Z0tAg&sM5SlvG%<fM{tHl~ojt3$r%Up0ZuGw4oejNssGS?y4B{)X)cNp<rhA#Z#;(+uItbuLPzQ6sDMv^LeH2gRp~wHYE3*G*h$S{TbCetixk03QTJj5^o~g_3N%mt}C@Ga4Ol7tK4oZbhkbw2WRsLL(j^ZY_CaL;mSoi<~6gJ74utW;ahT&^7z^A(TfiXKNnXowyocpA9mOT;mP-=&^_KdLgUZf{9bdB+jzshi10VpHrq8(K_@I9+~fr>ucY4yUXyM)ui&>k#OqI8iCcBvY)JKg{U#6yh*`fFfzbCK2tQbigES$&f*)XDUt<r-E$ji8h81{_-vK;GH-QHl17*b?sBL_p+mDW|nu+pzK@P?Ra&TT7U!11#gf5T+k88<xc}RxZjKUjo748X39}I7h-y3f*+{PPxQ+?JyXJE5Cu#MYy&211Kp#6j5&WyTw8CfJ&$2<zw$F-x)`xg^e!kwHt7LV2g2hwSur3}4v3wBhD4}%c7=o45gi5X{qGRRpr%orlnsR!*kc!4$&bw*<tYCN%6X<~)Mvwf;LqNfz-V4ZOl{ZH_HHvA@(_zOW|k>aEG@gsJ_ao8thIEk82uqD02lJUgy8XuiB-5aKtu`IQvAjc7pagm_IT^%pdiDhKmwmAX`a1b+~qaN11P;(~OU;p=SeRi0Iz8)-i`Psoq@fJAA<%JB9eLX?&p*0o96`WKyb3}RvI7xn9b#TeoD|`|X%{g@Mk57uPCX2F67HF{$a!zEcDjmHv_@@=01W@6uGh~s)AxcuS3OlG`=667p?q5t9y}&illlnI2i@(_B3%FzbnC;l-Kpt$1`Zy}d*T&e~^U3FHFyukFpc!+I!j$TK=;=PAhJ&k)kMs3Cn@Xt@BNO_DCx8JBkuCmm8$)-7G(&F3Dqz0nvfRmPbJ3HFRGI?BbDm?N;8@aYCv*@SZ*@Mb?KAHACpnnY>?~e-tbAwI{GTxl+nXN`NR(#dU&<?5F)!wn`2>V6$d^&w(e|lsi8a`RiBdeM>Xar!%4Tb;p-5QWgMmeK@&_|I-zln}t%4qD1D#it+h*T=E3CK5zGgFj-FDw@(JuEBIYvnmQJSW>CHrc9=Sd=}`*i%d;>h^F!Sn}`s;=ZD4h*e$$uVz3kITyLsuD0qEpX*V8*q~YDE?03=473s&?>Z>jLNx?j){@MWgwlXT`a7!QT*7<EK&vHa&s~UIb<4SBb30@4GLt<<}h}pw@SKvEwi<;_+}KQHn`YXl!&btISkJnuh=D4=*RDai6ppMwKL<ppvKTYX+UdpfHMMCOlOtdm%5B)BjoHjaBfiv7k6@TP?mX*9OM+NYY)i_-=bCaB(|bLH3Vy8iJzmLt{+@}RcYS*n2q=|0!0>rE|*zZSM$I&b>Og2fe0gA&n2z4$L87HiCb!3bPK~ME)9wG=NfrOFHwO{q@tU!h`|X;c59;9jIu&wNlvFyC0m3c0afx}Uh($=g>N2h`oqIiN#WyDHQ(m~c5$9a7bql+pe%Z43dXkl(Ez<aq-6Z=PVfNe!j({VaOlCPKT)NNHTUltK`MxWjBznoB#MH;)R`<+mDL2eDxVT~08VbT3+$vj^QOeX_~lQ!fs&<4R<0P`!tyF()oV4dIN&42#dH<dlra0iXA=l3H8i;;0l*JZhfwkcnd`X4fV$f<`wHf7C>{Qx?-Y_|vDhfQFRU=^H7N<EnU|meBe$Z+Wb=4f7W-(UK8OTZX?UB6Bv#p9z!kOjB<YV*bW{b<$$qp15`}`UH$02q0Z;pv$n<<(c-oy;%$#Dg<!N6mg3R(lYxi`dnoPjY9yHBmqNTslU`Byf(rWqLL}Ao{Zfb;|_JE*Kw>g^UopXId9&u%R8G@}A(k%^8@s^wjsn9}c)4UYgI+26<SY;}+w{&vou~1euOC~B)v@J>GQP<d&?-8=9QB9Y%BtNMn<?>0-XBf84gG43CKE!3pkuUFR-0Cb|ZCOKdbAxt&j_uoP;+Y1@)pD@+DKE1Z{WE!lEFc?CCgfwMZbY%V9!to7^(&AHIdzLzHN?w6=OGw)M+h8(6NENGDdj1pMJ*&#KAZvT#K;8@t{FFc+NECF8ZO*{;;2L%xsc(u%#b@g>;z-h3Tskctc%ApN{}{-V(km5%yFvB(N<MoVurc>560Mgf-%f;rf;D{lr43%P(GPaG4=oNhhUN&+7-IT^0Q`2l}#fkxCjXbJf6H{p_;<w_9;N90o^9o$%X7`q*n+u<Ybh3X%qJ-er9KY+<lN`^CrWZH+{knWPqHY{($^%Nw4aArB`_VFez<|FV-z&ZZ*H<cK;%=D%U3Ws88SQ8Ln9sbGHs?MC0a0!;CYl;vR%I-n0<YJ5s9gcKrqQZwUqk$>6AG#syg|lY@*TQzz6<5|BU0iiuU<L0X9^Kj7Tuhtsp*P+TYZlUIskYkIXe;lsP`TZX-3(f$wC5F=ThCH*~lW~9Zt7(sZK9`jDM34+1<vrJB7k}^Qw-oZ?<%fTRdCu2m|vQH2ii|f(Ft+DP2X+ks-;|sQmiS{9rF<Xei@Jkao1kS!oL#Z^I`2SfkB?HNnJl>*B*eA9(xy-ognL7&{x`oQls5hG=V5A;PS#${$K^`zt1`{PvW~iB+UADpEOA9NCJDf14D`I63n85(aWnYOg85M|Kl7KT#s8xT)V%NU90#Pu<Jj=`4mD)?W#Wm4?ulrf3J#XMWXP6a_ufd*J^XbLi_Tt<;;S<8Uz@CCn_iV1IloKr}A4iL{t2YdtjAMS1BTY_#_e>5{@%nDgCi9a8jgW44G%vliniHk%zCu2wF}9T@)4HKO2dkcN9t`Hxo)&#Fy*3*DIt_)F(@@A8(XtH@Vo6Nsh!kBc`qdn?(>C!678)r~h0B-3c%@HKT0H`G>4uB^mHF`A>pOn{_&Dj$+2C!b{L5bg+RrFpAhe%=2Rgtcl_L8sx<5gxxL+x&j_#+0JoJ^$E+x-jC#S5&*OXPLFWd4b9H1r_@&-4oRXT{gi@1t9ZUy|(;G(6Ij+<x|gYK%hs|avVt~#Em?vUti<dg~4vm%P?rgz9;eC*oV_aJ!7Jsz4vw?h6+6SKndhN%BenM-|0mtXy0uJDZU^iHnu%B%>x&9$%B*Z%$J!f3(NDiGK;UHJN{*Eg?veR<W5E<9Y(g~=6W;?-uQ(WeG6N&8o%VX{PNeankIb}x9tD`^<v+Xc;l%dfq!67ikn@6sTF1Wpq7?J>ARS!ODLhdk0HP?W%S6nFR(<4a8i@D1Y{KF8B&@WAsO#WP(<q_>fm*j~Xkz7%d&+8svRR%qTUIP|oS@Ovy!Xgk0Fmxuz<IpR`2ggW03s`&!7VD5o@>FQ#~3z?yfh0mUF3h81Om=f@QFahP&M{w%X$f$mvh?FBS$cQjf$2b}nQlO}pf+1h0e5Vq;!xt!PX~85YYvC1qk+N1Vazaw>lCDGaT!n4k{O^^@R_a&YDgvRr74gIo6tW}I4P>9_bzCa@8{%61R#_`!)y=N@LyKF<>6^G#=vS1V`>LtO;aI=Wojz1ttG<`A*6uB3EmNer$&rBH^5@-uwE_X>RKG{Xw!(XVALJiZrG59pM32C=8f^>%$%qNsD&8!8vs%MWLqB)fb*vICQ*vpK5{0}`z78x>xAhFbwTUF<nfPf{kn$-XDNJ|bV>KUvh#zI5n}7vklT=E)=q-T1AgFyC8F%=iDt*5k$!Nk*P(55fN21bC?JqkN#<`zJ83jZsEIx1oZXchGg3}If#!!pxBkWhC15xsOZVYeBvCUmkoYH|9G@HL8?p({s9thap1xINJ;nlM-D)?YZ2b>7nF%pLAL3T*o39k9fcn_i7o*h-*kprPz;RKJyBgOh!s>-A~4u;(XX@XA+?;Wq(fx5<s$_mAYtpaRw-5ksbOU>oy|J#_Q0l8Kt&#iytuz!-w81C7;hU7p<wvaVD-$9OxDzi&HWdymN&&`zgF%1V}qDZAlyaq*TD!M@YpJn^Hx}!1Lt&Tj2g35|c!gxU5lYzEBQ|I+tVLnwx<0HIbX0E%<CY$QKCM8P7lO+E}%TAQ07KMYNoH!*!4Grc*(ZnGw1ys<Wi!ph#;&W5&ip7Cac@S&I3Hq8$XxP1+c(Rh9`K*rYkg>Sesr=ge-c%#QNKx}7m_|!>D&ov<TXy}#f>u_$v36-`P;{0Mh%%t&z|f-##h{Vx9mocWA!Qe~_G|GG@~G`F_J&rNop8VWEMWyN*uS!QJxXc-UTq<`s_CY2F__=1ac*H6-CKh@Ep>Z!J^#0LIRCOq3!;R3c6kMiR1W7BH??QC&;^4)`^491mP5HGbKMJWuS&x6&MUZ>vvb(%vhvg!?4xWSVRtC&d6vebt7yg$t&y7OIT98%wB<zEe(A-k#$t`hhXxgJaA}8Wh*WD(n6LsNDY`A4O8yvVTq0UzII(3cXV1(OxV^Z$GoX2der;kuNor1A_MWKO-gs{y2+uQe`Xd542eAN>$%97n*$jppcVZf8MoUYdjEx=cnRZH;-1j>@i#!*~+wN4>jv`YTHK(VGDruWnOJX1i&CG-8Et{!tRBR{6GjNe7)I&)pQ<KBKQGoGL`ilOjtmr%gM;cgP7`L*p<E6jMC$eWZ6y{%3Fkz`+r2)(({~iQ}dzuC_&p<PJ2hx2ms+Q*`m7uBVig^K{7M9woHd18q_N1~F+r-Hn&LgFQ+nO#-TuOzcmSPndJ1{^!RhWQDpluL(Lz^Kw1;#>B#JDgMS08bnnazKfs!*u<@2m+pK)^9b*ckH_2W&gSBi3}jPg`LAiS8BROG|dLGl{qM%g1b{&rF1&1Vstgwg&tnNr<JuP)Mbcwk6O3boZV}KW)LoULUjoI}kBX-Qq&|v;vU0sWJ~-hzS`e5)5#;Y*aQ1YOg|Y?d6=<yHS!a-zH%7Yd5sDCDS7bhQxAYWEHaQ^&vkWF;Ch^Qm^Zg7oeTuu50;TI3Oco$ydWJC>4BE?yRQaOv_4~Gzx$DIem<Yt9_QmACAs;?LTTm?dURE#0Z?8;%6YrNJ4;xKf^oV*Mr!L7c6H7WB&qH2FdAaBmP+~k(_Q$JBA0lbbz*YcW&$R1q1WBO$)MarqFyE;bPKG<&y{8&z|W{mZA*nq(@WYq~|v-F~xU+6sS$yMO2>r8>=pNppEPZo<bm-Bb7CTozW!bO_%^%N2rMwbk}Bb_WOw2oCpLL`x_MYw9}s`ekP|ZimFG|(5l{<rFVm8f@-4Na)Kc+CD~0S2hYzDK0`U0q1tqbA4jGyyclOfUm$YWnN<=i`|<k#$D>vx0<plHZMpl5!Cd=DPXVyRMd))`Z?_5Hh}UzKf_#$Bej&1<uVftb2=8VLdLDL`Bxov90wGxB#Dy@Kz*szxWP$9e;yS>oZil4}T@DkSkDT^dtoYThUU~b1FG&{^ErD!$Vp!fLh$)a`f$Lo_tXObP_%3#fp6woeEXb3zTl)(SsKI=Ez{5MqP&HD5yILdElM%e1JfdpDxs<3r{J5?Ho$BL?!@_7l60RyMOUK2xsgJ#*;o$cD9%UP8cN<$&P4VFWdb@R{H;hX5za~7du}&t1wGVBuyjkQ*!xaWHdHV0&RHgqDZaGq@>6O|KOO7ifddmwLK`25xPZcXvAP=S~6IWh{0Uam7pp6&e=;wlxh$NUZOUo+cjGLO*$Q?3$*y{O^#lr3P83|&ZtZNpil2=cmz>|{f5LFcdx-O%`C)%|<Jz19xU%9{1%ELT!{90<p`HN-F5c&O-)vT|rX#Ms6s^gDe-JZj(U*~sxZ<`{2`oFxXwzG8=^+$xPuJtK_|Gd}9ItLkaY136Qky^y<%R{rN6(1-Y)26V45no?a>%F1f{xn|GUm-l>j%wa6qC6-;FN77>%_CLw$|<M@8D{H<3k|!DSdxllI#@!}W@E*pvwD;!6wJn8&s=78pS`g~*$3~+DB47Gc_e!klZ)WVQOo=2J*1ujDUu@Sqv=}hhZd6s)2Hj5T*4f2B-#qsxaaF_b{IE5F)1e_pa@8ZvJ0WduRrqg9jHaO1z_xDFk}8WhOrZB5SX^8y3#mx3!v~I-XGc#76JV;gj{^A*MI#@SK(_n+wF+Eu=&7+GSE!8KcESK3>iWQCT4D$ySuQ<re0n-bz*hw34j|7iiu`QCI%$ZfH!h#HlSdTVtLj{3)EBNoP`p?NE!1YA#Ox66;-lnckoNyW~8WRQ@LU?#BATEenRS`1<X}}VgHVy3N)soEv)Q;3Rxxt2KGaUsl0ePo21ZNK|D7XAvVm(2gk9UGX_9=v8Na#=6$$jbyd~Xb}$Ek(DK-|i0U#~rR$$keQbmUWFUVOLE`UrzeP#4!u#+q$RvzEpB%cqEV7@ZaKYk<3E^|hNCkBXv^$EZW!+L0?9N@<;8GWSsH3*%GOLPRJJHO`24i7C!zic%@DrCPsjDm5mh8GNw&+7-UPr~TqEHm!C!;YYCz`1&>Kw#>T6`nN9GM4Y32p`B>kTd>M6e$iBq!$!h_{%HSQnQfQp+;h+zRLIEUcP|;<&nnl{siM%34;&`gkNbT6GXvqiiJenU;l>_?8R~V|td@zauJ5?L4Uo96!sn>y@Cs9ibFAqnP4Rh+-wCS=!bqE*dGFPF0|0`-*#6LS?sWk<flNiz3}&bxA^!9k~@3uKxAiiVK$3_0>>e`EjKd8#opXqIR4v208Gd{N8&6gYR7Fu0ujq{fkG1kuvJb>PCg*zPyYI$8c*=qgatzJ$Z=@zi2sIx_Z;W8a@gVqtO|@U<vEhpcdste3v1pqE(3$-f!2eEa^uxWIS+18){TDGRr%<7}<EDjChWnb#byB3uwGfVP5Ih^%Ii#!mfs5_x2TXoYivE53x7OInD^O4n=L8kgkc6N7dXV*xW|Zc-7=#6r6_t*apJPf%p{;gn2UxZiYFD>A^O}dDlSj=q7HHgv~&RuLeR~QiT~4*pe#bB~^I$5Kt;IDoY42hd_SE5J;<*^V-nK6<tORf!;HUcMXB@Y6#E=6Q##^%2#%LJuOeOgIh2)^WyZTd3Hneb0-+w-+WJ)?d}E4mP(0`%xB3>&IIPj$Ko4`)KZ#cbpYjo5_WScsvSED&H5c7T4`JeRz0pkr8PPH#!AqxUDVN_N&5InQ4940Q4`!-4ezicy<n%pQG8@MxLv(TR1Ap9BL+pTpVb#Jh7ab$v2*L1_<4<0%Ze6xq9H%aW@yfZQ*A)4GJG+|&-v~B3}-*Ovc%q**VRRNGR@~c=>=;`68O&hcpglWA6Ip5hi85Q(e&OdbP|bsfDwX`?9^AX8r|=Ht(i;IG&-1n^6TV<yxumw$HEL-`3vCxQQQ!F!c{^?3d7b`$#iKQh3Uez9K38fOt;gSk&`er3oRwllOOHLXKf$IAbPqCmd>PYIzu4!INQhP9w3iwFabQkBSI+x#a3k>u@eOHc7a5e7%>rK`YBM3MiL^JOIbz8QYK}|re|&i&*CViQZj?<Y*fpfH<JRxaZX86Tr*sn=+zIJBdE$=P=&|pKofa(i<xB@22S=_9bhX7-h#noTZ_<d!Ub8U@y^Ee*Q`U`4*t)7*@~awZs@WV+OhOkMZX|`A{aYWg}%<z;tIpiC*+rf3kQ~unS+9X<ODBp;BCoq>tykGX<wZ&`NyPwJ%%*$)M(OlIao)J@S6B>`#G&bm(n6<YKtOdix#Vk!;Mpf9qY)>jz#og;3GJ6<`{@PZtMhB&(YwTfv?c+35FsXI1^AsISedjwTUDbtsp@-J|T-U&4kdPJVYr6(bN<HMgCP_J=)>^GTDuRlF;hfQ*ThThUK1shjE|#qjP314$owty$$o(dtVVx7$$|tiL@R4I9U=&m^`9xJl^{_P@pNYe=Xn!%Cyxxi`leIWqT(vFjKwCzGqZBqlE03!cbPTNXUX;Bw8tdwWxUJuT*QY-45N7dASB);P(Ee{j_()*s_n4kqzieMd4eUku<;VGymRuP1NQE{}ol4JP1E+gK(9YwsH8|B_?W+#Qhs3rpUq$s<Q+ItP`^6QPX^DHntg?D7W{iEMcshTy0{?_<@xrO)-H1c{0Ip)S7Ir<`hk-C}T@7Za2&+G0-ofx0e&Om5N`4ahHr#8Qs>*NUlxV@)+P;?L>+|{WAnHt9ARXBb4gfCsJSm`5W)lhWmJ<ZIqx&fj-=jrjL^`(%{XQ=9#)l(Ujm4Yd1yo=SXA2Ecjrm2S7UU>Rxgdxbk<rT?*b{<tp2Ba}>j^Z;$gM_&Le^lc4?{%|x{`&3P3SiYg{(_@k$Y^^+eA7O^Fjo7#9N1)J^gxMH(-v<7ZqDAtmf%6|8N2Oc}eiUDF$7FCkkRk%o{ZCMfKh7lt|%^-AAM;>j)h)e8YR@2kLIqmqOu*W3xsnX_voe4Y@qx?$s0{ZlA*_e7P87D3)1%hq@MHvh%I_7u&yDR?u@C{{tmEK7pzQ1n?V4ZZ{GxIZL$2XcpZ_Y9=dPd6pdb23Go%xO4l$Ch^GCYD$V!3K0eR0}Xy^j}VqRY8sd>7R7DhnLhOnn>eIc>`U?V8W8q#xV+KqbuC+1Sq@qUMtrQhc^6aR(K61ejSr%h-|q<%=2NhNp!fk91U8O?U*S?y1dtIenDlJmD<w5@x>(I_xl1n2COAv){SKFbjYbKW`z?fE;UHbf<`i`|KXjlXjsFtPZ!irV<r$3NRIa2=OOs&1Zw`oucVDPJx~=u%`|AKDBk2win$Xq)h<`BnV%XyB~EFP>}PTQS{Qjuq4&4%oHyZ;1a9nEl`}e2;|SCXW|&!*?o-4GGWZYYpx<V{!i<S+EVUkhF^y`^fs@yxEHE$A)GpwcrLm2xkho<+G!bR5}oKMH^cxrK-lg9LX>Hx+D>BP(pRH`TaqNv?I+lAYzJ#7+4eQ_QQFNNMgO!`XF_L5SpXmoihnrNLRu{#5k$i>9R;w0?hNimW&(`|NDoD-o=2$_%JU8pS^>UVSnXN*i<%dRUls1GU1lCYw5qzi?fQ-k>69JHi#eiVEX=xf!9d$>i-Cn8d<((cId$$mhak!TqnuPxl2T70qbMJ357<UvP2>ewt>9r^4GG*y*Mu_s0?GwqZjzZdD8-avY2qy?=Hi?>xhw+DQVsl%R9}UUfnnMSiu*_sq?fM+BJxRwI7%=$uBaiVR?ybIU;QdA@UC0@ARoy-dCP2hhYMaZFdwQIE3Ku{hf0(pr?pgy{FL;<1&^E-#_C)D5D-qsh0_uiPD{FJfp?&uz=qQjUvXN}7aQR%E_ghJ19^2RUH*Oae=`5IC*+TXIe}mS)zjQESQwB;iT+bZdVWsz8DBWl_^OSD0WGwgNF{|0AOV&b!bBbry488xr}Ij`-qEjJzq|(cANg{T&dAvqhR+@KQ8{{wgwqAZWS6Hblz(+>?$IM+*99^krx}|+tIN;{Nnwr!ZGQQq)Cg<S#!+j5fa$;tBJ_<6m41?)6FN|bA2P)8S0qN?0VtcPRrB5U&Yc{&l7uH!?)nue^CUL;5O8&-)XqlZclfl?gu*{)Q8Y%uchSIsn$*Cq3*&J7w9b`ujU-0a5hdL=_#0pBykl9~`(b6kW7n{=;u#usc$Qio2EU;E3M*rJ!F3IZ#M3VfiPRNgi*Fkh1$pR<66jJ?WYP|6Zv=nczq37pFmmu9sl05DWNpxIxG^lDSV1mq(yy!_39;9}ClD#uo*FpqUms;iu=GZ(KX+$U;1)q2C;V+qo08>BLkc?;&%{mY;(c#&;y3I*+VT8;w*a5w*Msfg?X9=6?zQzbbmWJBXyQ!}@Zp289eIoGC~GnF1-2u95VnII#O<B`64(yK%o-8(2qlE;l-puv8BE)tsBb6Rc!0P0wjS(aU(FC2y*pz`=&R!^`GPg;t}AIGuhau8kN(ue^uFzE{9nCQMFqF2Mds(Q`X-=+if98>Jq3tZ;b%_ZlEFDr5=U_rppzl*5aQrd6vIKh$;WRGw*r-P6o)a-6r!~a3PuDrz7Vb<cI&HqTP1Rqh&w34kp!sRwDteY!dtJ3Jzhtsz*R052hzQ`aTY3qc=Ux$V4b%1?{4!BrIPwnG}G$?(_D_4K8SsSC#Y}f$N%{z4g0IXe0{;Z@U>LqzQIX>RnctS5<_zQOq0SXysE=pO$tc>uKa~XIL-_G3Xw&bU30{EJumpAkl&aTUS!u$vHJs|B!K+;uYJYQiWiYzMJp?~_h!IS#;bAK`#8PXy3e-?I9C?Sw=f(p%Q&whlt=(axDlQp_{g`ylemN@2ekTL#3o@In+OK%u}QuWn{=XgD>kW$O``mdLb&P3+1~s|-$Gx2clBj!fI-SPHXmIBP;WK}J`jB>&&aag{OidGL!iD_gW!5Z+?tQ3FA=1)fzvN@(2dacu(}Hy*XL>uS_Tv*9gOsEdEWWsA6#FkC@X!jYzCyFwVHfEWg%XvWl$<3Z;gRX7@;k)ZLzzqDVS8oVZN>@R6~AA@AIdFY6=9zzAh+?X5ZRV;Pt1}z3RP)FrvWG_Hb24`033$0!*vY<^TB*7zdw!0#|!f2_SZHH4(7T7<QY9ofS3;ff@mcs8G&Dy!Jr&lunwYdjS!7g$8iwaHN_PSRH5bJh)Lg;fPWA+zq)Sxkb6Dgw6s$y8l<SHtsS<1RJ<?)iW+7J;M{N)U#ym?5L{BB6Oap3&@M}d`?y}8p-?KtI6IO09j(Ry5ZS`@sf)9qSTnSg9kE0kcp=0x$fCGv|AV7g<t0f`B(~?9jSixkjyR~&ok9(+prpj+Y^WLk*UL#=#Fhlx?Lsmqj(4tCYwQ&tt<jamtaO>>{gpxvWqRfD{^tb($}58{DZApK+lD2c#ybg2*RUzPZ6C$+NWfqZBQ?oQ~?*QHyKo|V})&^B~+KQ3M8F2KwHw>97k6UV2wMGIA|?5(T98XD2D~kZm1+}FsXEwD1B!Bw}7u9n9kA`l-%tibjugA4RU;lki%^JwW)2@GReWb0b*xDU^{o9nnfQiop{6oSd;;Q4C)$l%wF8fUJ#EoSJ?+qq}_8{zT7%2VVT2Xx+sP<sLdGECD{`bY#|nh;)Lca`>r&b%5v_N7h*P2#vqLhq2Mz+0n6x<SESH31Z%fBZKm)7#$gdWB<0eXl(UYHg@PSFl1yMA34s!cRgCgfFgG<`=c?P*#Z{g`5@TuCK6{6oN2%Xb{@&V%;b2S)2qqZQFul+@QO9J2yh-0*y$Q*Yy}B6u_$(prHgeEj=?jUZvVr8Zl^LA1_oqHBw+?`~2iGS_Y)SMKGbvi(>10KSag~B>+vX5ml~+36j^Kp8Z2R6Q+d%tk`-j6uucYq@S@9l<_KXH$G%XCmlQU=7E-x(@iP0uW>I6IN_OHE}c}DC|qQ^9Hf@UTNYe&xA{6;@QlmR53khHi9LxBr*61<8@G(3BtYEt`U5A5sra`(oS<e#WkM!yLY(A=TqT<Lz>FW-JxY;0mSVellIL_H<g=JW0^f1o-o|FvL{{%Dwj?uqM=F0CGzHqL62wHvq>ltzv_kJt@0z@WO|+EFnlP^|=nnTZWHX;es^R<-mK`4^dz!UU^hb<blwk4Z|rMaoQita3b0!rpc}J_2n5`D{XohHIC!VxeRBlb#i1nPWzo5p`&cmv{j_i?k~fg)!a(fUa3o26hCKeFZVa2;46u$p`9H_7Vu7M#z}kgoXnE2m?B~61@dBP94}7jWzTUEE{=Vr7K4-^|xF8KU*Ir@p1lR3j9gJiJOP_N0Our<vx9<?cynz?<IKK%n55Jm?}@g+>|5JkX{lBkv-)c%;I#><6exB^pWZsj|RrGMP29?L3`uEs9_<cMUtkLvo!t%G9yPN%CZvyEhj=AKyi3ki!gp+6~@<eZa_41NsOi^-ZI!f1T7CNC-O%gcoyyNkB(+*ub=o6s>R9Q)MCgr>49yNLw3_=b(UN>ruSCT;CmDHwtZy3@|tnoP7B!X#ZQ?<fLB9{2_1=)^Rqb$lb(ilYJXfhKhBRzR(EJSnI$MH(6KI>QEnD5M&7|{^qyr`zNNhu7Qk}{klyp(K^)VD+ea;~2gTh)X7@>&nV8jf(v6njG>740+$^1klx7(d4;d$$)Vrn<L5pKR@*}SBnG$yww87xy+J5dMhbmm|+6Lzt>uy<y=7n3fket{OAxYaZGDR?#2bX?t^W25U)=qJvQ1~H)9Tn2DtASIVDo{rXl(?Zio`d~0xL9$Y)0y>#16$vHZ?Z2TtRJ8CabHB3d8CJ+Wzd`evs)148RvKrm#MR#(8-%SVR8p6?5P}_4vdc4qXzraKvxGECkg!1POVIM6x3^$;`WJ;#DF6+uRU02jCv6i<Q%1j8G_H=%A4dGkka3MlfAjA+d$O=kcGurD3R0?j|Q0YhO8_l+;$Pdf5znGItsYMROC43=EZrX*H2!7Q=6TL7s&rGYc&%NS_xr|JY3Q12~*g@rf5G(i%e^k!=ZSmY}w#f#|{E#^gEINB8oPGBkWZeY5O0k#u4H(CU!zS4<J>Zcr)AS+@S-{^eCj^*&F~&x}HjY=XV%^$<=4NWd!E^nRY?YCjO?4eSY<;QMu$p4wcIhxS2q&ws!sQA0&0FRgs3(pdQ83D217Hx&y62Y&KJyY<t@SxAQEuH;(N2NL{F?X)De9_*_{?<1BX><8ik7$!y=%Rt<Jq?{HCP>IR)3P5PQ42}&95PPT7(AVhx_=%Djza)8uJb=A0Meh~&8bSsGVq409#<o!%1AAla+)|F4<^_Bj2?C~qaF@E6_I9@$|iH~234sN;i;5q2!)r0r;Q+MFy-#Ag{8;TaM9=W3DjluG~K53%!P0SlCi7eaatt}stv#@6@v$d*a{Um!;ZL>UP6Rgu-V+(hVE!5%+bVpBr)OTVFMLTl`<oT77<nMQ1+7mUpzjWrWk4eg{W`$a}KKALd_@EAp$%Xytg$Zgh6I6YiyyU?>OKIriCa99}d*Oh(+Mh=EM{O%+EnQqB{W?o~Hr}UerXkBc<u<C5Q_55lX<H9WdbdPtfY5ftU%21tyY|2MtcqqAl{IxQ%ud(1bNxt^Ne=_B#ab!KCkfSx8n3Ro8Gd%FeXAUQjF+tKxiMi(i$I_@mU+69m^U6cDX1{YzlvAcZ+587vMAu}^Y_m4wodRyiO`(Od_Qq@D79~7wX+5<TwHIAH|w?bYN3zZe`hh@Q%d*tczl_duMO&+PHsufoM0r=76lFr@6Ji~>U&dS57B?(JWid^V3!A6;S;JY7Q{l)6efruB{P273~IhV5$P^*hQ1J9NT0PS2*ivyX`)3NYbtGJ=@bP{Aw4tG*ZVtdZ`2yH-;DE#**Hg&f7cgHB^?NKAA)&kv(U2{iEeZDDJ9>ES-Sa_?gHimHqFU>WV^+Y`}UUik`CuU&KhM|E(<1JIwd)#LsUJ=9>J6XXaVK&1nU<?_(yMCibJwLh4l$r9x~j8Xm;<cON3v4>0R(4%T~Bvw(<wXi|?^)#m%x6-h0^^)GU~<0>nL+t?+8u%CD9!nmMk^){a+nS+)i(TMtRdwz%sK<s}S$U|YV$IQwXB35At<Tb?E-i)@#t_v5s*3lHi=8a_%vMU0Gh<~?dM0R-#N%S=s#mXTe*%!-v$Swt5*XNv7(Ap_)6Wdf0pdjWYfw`VoAtvC-p!~>zwtc7-qN!yrB>XW-c(pc07p#E~ZQO}yt+Ga;vENXDcnnXGsr))IHIdX}ZNlMhd7ffF`oXDSabqz9Gm_v7}z=H$RM#1MNWEp7M^%yIYJO(3C+G6i%M*X<m3Sv_!@yymlCPpZm-kBI)9dudLZyi{|okF)rXriKez?SzyM7O`T(f5CR?Kr=Q;M2DuJrXx4-;jn=em@PT{EcfkEs!2lMbM0xofZ8i!smTxcI6#v35y}fkQ~^vkf9e~&yq53#S{J@AbI|H_nXuO-J@C%pIDDawS|NeuyI-<=(AD_q4&5Ohes6E7-9e(jk|Q}<n4}t;t5Y9M)_k>a*<htoAo9Z$9N!VH9we~YWw%&HrAhHt(*D>b-C=Xe>A}Ffz~oe6DDpGFL>vlH6S(C%y`Bvru#MCi4TU8XqWycoRv@rc(i>^>S;Wr#h5;+b)X*TMbAN+pSkp$8K@OS&se(Sy~KyoL~kL9f1*G0r))+z!^rx5*VrFIU}arST}Z3m$uQR}`6i~^Im!eOQPebTm(w)$a%gMMwwBZAc`sa6Xy<4QS>(WntF?4|cM2HZF9nR7wX}Mr<thbyR{ob-{5<T;H$cH9+BDHCe+X?Uze{65gD>?iEb^~)za8KW`OkIFP$6#r=u6Bj9u@Ux^x0U^k&d~sHM1xP32dVlrr;4fVZqkuM9AVkp{NW#vy9N8Kr!)x%^EHYw_6(7ZhxDFki+e<J(^sIa)N}sI2kYynK=JM_cP**bmDF~xEYFfwsKOb9hVBgj|(S(NY75JAeg}b%z4HEKeavFXKJ|OA$g!`G2WpL5G_CK7_jp*Cd_tT_h5nGL}r{_non$`Wpa)WJTW>Z;Hds1u<}l!e9HX!`wURXg-&-E!O!wP-&0Y4CW|O6Hlz8trywl-0qEt}!Tun*QG80G&*!6jHie^iGZVT5;F|F~)CmNIhf7n7zFRnoX@oJDv`Ts?g&9XyhGJC;-N6i15&yJB>drbz)J5j11!xaW_lXVWXV(yJ3v8+KU_rrF06exRLq8ML!{a|#KbTyR0#K(E1EeINIVwx0VARDmA=rCYeFu8^2>QoFUFzg}V=Tq+>WHW5LDtcbKJC<2D43_I+{zNMbZ-E9Y#~V0R0i5ETw}?Eb1|9dNEk+JfBOT<$egK$(v_XLw1;~a;0c}+kY(L2OC$gyNHo|phC*w}iIL|N%zY6ZI#>$E=V($bks-y9L2`sz1FPex%F+&C#~RChCuaaYoKZ0?;t~cQL8kPY(ZRdRM&UjZj3*1^U9b(NJuu|ec8Iv4?K7ai5fAJ=2Qe!znDI_BpD}~e_K0>An=m(n;Q`w`@Dy4mj5ryPhOIOT<K`2ZUK3fUT7V^rGR@!Y!v7~Ez|m8HWB0I8-$<LT<<xOb=<<%>m(g5prNMzQccF6s$0Q+EI>(XTH9_D}rJ!~pO&|kO#wSaY^(5dy=Cd(SdSf7AGm%4TEuiQhWRRZ7H1D<iF)x^{D8=g6jsYa`DLV;p@Oz6aMk&A%U3VkPP;U|DU}F!fD+gLJHH~gt4WLdFkNYG;bBc_NF&(?oF4nKFW#M1^+LP;OuI4Y3>*&!y`(Vqg<*=vBx@<D*1+JJqvyPk0I(uflL<7CIUM5TAa2ei6tCvt9Fs%-+(`r_O^Q&rbzhCofsN463xV!pSQ~|c~?-tt(+}*!)6Fza~KfotSH<vsQUKVbT>L+BQC;&^{`4Z{@H~R?R((cT~d)~1TQh@WBm|3-tw5+CuSO<k?CkwiI)@ZYUCR31^;!Jhfk+6!kq~l5#q!}mHY~d)|o7Y^s4{hUJi)QWsejs(t)b!6izG%E-4%1?=0fXvDQ-s|Pm$~jbsg$q;7V44kk1l?+>&6LXZ2&*$v)2FXUmm`X^x!3YAI&2<<|;WAaG#V1K)g#-?6jb2r^Ny=N@uMbj~1v>ZqCX>{cZR*iiiDv1Kf6`e!r~;Wy_bN!}P_2KkQA-1<y4!H%QRG*5)qk1dSIA2f?lphI9BL41WM(VI*+31uLJp;U6NEsjG#S7LjRPjd#1GOt2+-<^OuCGcjx-UHJEd!2X24AN>8WZB+Daejq(ge`=TVh~oRHldP0D`jTm<rBhCqKsyU>qjN6gEOEJNTJ)6Eff2(%A=Y-gMl>GU0&!w2B+hrF1C`nvC`bTgbJdn8O6UiEmbb1&@4cCnST{oJw}ktwUQdm)osvWq<%zhps4scehRVpMydD>p^5WW(eq{*=@>+{W$5I%~PK%KB8*E&t5IdN#YJ2}jvYzvQZN~crS&jsE-nAYKuN3iaF)YVmJMY(Hi)HAnY8x>$rp+-^Fj}$Y_Txa2AlA)`%Ci-WRnF@>c`pG;6vHYKePVP{2vjdDW!hh@6|oo<tv{jNVP)*jBF4BhDp<7m-4AQAwE=tBbk-&qCG>X~2ygV)=B2;ZJKw?NIIO~+Uv=5~XdLi<F}y<TZy|y;t)jr6?quOAzq)wXbCKhn+2^QFw=~xzHXWAcf%VI<P4TfT9b)&LWuwA{r>wHd#G+bqqh8Wgn{4S!nEZ$^^qY>AU!~=0tgSR%oTyG&ef1IVRZ-Gt(>r_JZrgOw3@uE?_S(zSRh0_z@~LGfOFwjJ-g!Ot#VK6%1lPmsOqBS#jTrLUZ8XdoABZ{GmiDiAa9q26|NVlO0wexyyi|R6<E*`z**;UoGebTA^njGk$PSRHSl3K5Bi}i<*H5VE7|^l;r8L5f1S9KGZ054MINMm2VtQs>21yWP15>0hxZ+aAzmw}+_Y|bQz+N3uhUC+I4~pt=g?19WNQha)4Kef}-q8?13U_8uovjfKSXJ;{NwIo>6?rF4ePQnE?Jb4M>kU8HECY)RM_I{&PkLN-3@wT{N{_or+mcyEC#Hyrakt|=$Ijk_<tECwChFP=iRBdGfI47Xe-F{ztMRL$wYou8ph0$zSm@<dFFdKT$M&5kPsR3~{k`4m@IMZnp-7U%GIVJ6;>G(v|MkoL`t$4gb^rSFEBx~-{Ex@4Kfe?|zsTRtukow-HGYYY_aE}t{%bkxpY_*oD3JL1K>eD2jW7S&e|2Bf|NO#!$Y=ALzkbkX|1nQ1uHT72+pqB}`n7-WUx~Ld>nQ!YJ*w(ZTyuy2fM2g(hxdA&)e|TELV5gq{Oof7#+x_)`tG0c_RlQKPFH~tZCkWIRTLHq;I#uPu|~;RY|)_wHEiosG5G#b(>@u8Pkg>!V0v*kDokX^%ufRW$>{zUsf&BXGA!DfI39|jS*=y_!D0_ad!bL-pXhy)Qds{KP1}9@PkSR`jvGkMI7wn=-R9~mVpzUf|3ZA{uZATs(&Xm-dVK)bJLLJ_IECf-*ROElQ8_GM^%PDHxT=&@-c;r{^h$dj%+AK&_ha53a5r@?uJ&Sxqkqm!up_rqkkLi77di#K;|^<^6ER}w3(f|85UZ%m8z;5vU)`oH*fF>tpIO~(&)Sh5+Y?+pIii#Of{%?DmS63#!^<17ys3BWr;lO(YF3{Mf!zBbyBacOS&ySOv9$0}WlRRY(2M0~;!mC_f6eQgi5pWOztii@&$xZ3ORqQZKZWkaukm{0uxwDTetrGI_7Gq0!G3B1ntZaAP{?|Y(Zcf0S#N)K@!h9j?3Xt;i0f5);}lku%)58Be37f@tbau>Y5S4u<2PdIa!;>+eZ7H?<n`hkCi8k=P?p6ig!-qABZZ7(b%zK4tHxEEU3ClW<9-awW;X|9diCPP@mw9hNZUHj;p$$$b(i1oPlQr!{<=Amn>$(l8p`!wH}zE=bCx06=6c4>S1eaU|CTqGE!X4OZ*QWT4tX!?`o%JLy}%^>#%&n#XJJmTGjWMgp^pVdPW2+ZqoX|K&v6H6CcuCX<__;fPz(_8=P#UnVUkCx`aQStwU>4O_&E{8)5Yac7XADOL23;|{2BMWe=vBR@PJrj?@cu-QbeLB;qC%HavCoVfwFIGr$dylNou!!ra?PoNAgGz!{MlYTaZS>$iL#;pM*Q6`B#_9gU#r?vE;trhiuqndyyA!FRgNyF8PrVjY{Cp#dZiqlD~JuGGL=rv$YHu;*~B<AYB6j7s2cU@>a^Gki9Eba`YYEld#Y>7@)>aBopL7@*X{G;RgD`wpxwzfqO8#0^mnI_14dP=4Y+16L0>GG=a9OoTT&L=N3lb9biB9y6x=Z>X-!@3C3$6M}u<r`Z&72JQtc21UX0nr3x>wD)Awq$>m%S*$YeDatOO<qfFv9l|3lfZ&tSRfcJ{ijz+-_j_)ZilY5FL;H0P<lW8~sXblu|X_#l-{U|R0Di2LD?I4MRvxD7mgs9mFa7ucLq*PHat^%ZCBYoVPh?IrJAdgDzzZ0yxeb@LOc7H9DKJ-5_Aw7TqX4>(9tz_~i&jEI7sV9KC-J_x1icae15Pwr<cH-f5<PzOuPTTPX?s5CbK1mCXrn-dl5&3*n(8$i=L0cX$QjP$KiKQRSIVa&OREGLgAXLJUtyNsKA3Uy~Dj1W0u0cw8{Ct?7#Vn|tXm;&EC8U*v9th>^W!H#c=-!uCQ+de-)ywYWn?<5WyO*$jqVy!V9v1?Y8<6(y<iSJ&{am^bP-0MOY=RMFv3W3oLbiSoo0wuZ%gOepK_YX(eznUaD5Z_NAx*AR82|n%nD)yQOnU$$g#1p$_TDMCt}Zq1!L7>uU8b6d{R<`wg#mqlzje-INAw}?|4?1EjO4jUWjUo&`WHqMQ^8~#M55gO3j%ng9U8hw(T>7&Vx*GU7B!AdY>mcDNuIWP2SiD8yo9;!Xbod&`(dUfpqnPW)?%LSjGRfP!U9gDb{z2`$t88tnnWh5L?>Noajq~)J=&qhC>H~czFximRRitbml&KalmDFDZQXR%EMAv)7>?nf9zRtn0K7Ins)15;ZF?6QPjWY3z!m%z1JpBsd?hwy#Es6D{gubf$17*w)drxF7HKtjlQDt2BgR*3J2A@OATs}i!>vvJkD)$F@`@`6@tf35f>cfakg2Z)x@6lqePLyW6Wcna@^@ugRw#g3A8-$#_BaM#Z-QuRhhU;fBylr*5e?ln`7UH!+T9?)q|g|weZ>#`aSgLsA3f8?DfrXXF2)brO`071Laa(V-LuGL?cW`ty<Pln4*{)A6G3Uo!Gq+2xZrq4Iu=<LcU?RsE(b@m=&TgP#vL1k%5SSom+n-3ux(~STNJuLi0eOle*(bs&#WVJx}_si--8-V=Nw^}L%tS~IlZN5VG1%Q!!YBst9Hzm&Xl`SjM21r9B2&$_jf>{&2`naSma~c9ZO^rUfN<vUenZmovHG$k=Au#ObLnwIk_4UaF4Gzzh(jML{<C7<^6yC3r$jcI)V06-YpKP54=U~p&CJsNjL3LWrcSq2WH%d-4n`Da;|C5$<T)xB&Q&j4`lq|OVrk)_>n3=HT0qbBDW$nm>{9{&XKNI<A4Jm$kqK68k-Ei3ibahXPhD{Ryp300!&PM6|sI>3yfV=ZD58Dt7I#Cldh$B6@6}4RUw%zZa>bD05spAN1^B)ZUd6QfKL^2t7p|qG-*;-0dS?q7=Hr<w?33VLaUM3&Cj9Ua}Gq<miu4i<18CC27$1nK1qs@0$X>k=Yrq`Y_fJM=8PA0CXNgEv2JvMo%R-(Wlvb69<+_1+T{Nhkyv93Z%kch6m_m*MXD#@(8wJW*_qpS3iY`NKbU@cwz%5pc;W@q&`?KWb+LBS3ir<oi@%D<Hp%DbPDDID7(EUKj1qz{mFi(3y7N=(J>%K)MP4?;2eIWn@v;me5u@%D>X|JM3+_=`byjov^Iu+k`fTJ5V|7Ph-fpN+hp;!BD7su-DWOY?8h=z~U|uapt;8X&qST~`6W#VonmXK8r(UvmXKW8w8r7CvFRlxSEvi-gs%#3UHgg8)JWI;FKOp9*tj{UJ*hx!&<9^kKJ68~VWRl(GPI1qMHa)wRmdRHmJ58io=6~a>P(su4_0F~Hl@!y}!WFL<uHF}}`1Zo363s30jofLk*DkXWxUqH(l+eCfyNrSZZi2IM%eC%V&s9ro+^O#d*K%%q9HcEiV0G%XI^{H9TO3s_7oT>&iK`!}UrV=&c5(4&KI+o*DcITT`AqO^^k7Y{Fn1Q1K=OWKNYH|~f?Xvpjx!e+4O*%FQUVh}`F9m_QQZwbF@?zM<Uf<k0~O@}BolQI(8GS_CAl+9HrFy&+=SzmsfAakPqw2=qbFtS2ZK9uFx^w_6?rR2A<415fx3lM)iJBMM=zd-Cq%siRsO;qyBb(?5xn&#92_Nz*gm^A<#2q8OAN=_h+{Ye5Qn0Xk0pc(ci&J2qPE%=&gD0aKK)O3=g2xv4_C^>?jqC=pUAuhH=NVD*VaZ#1x1obh9jKi+Q@8UEFA$;9*MzaXdb;H#~JfU9?f`UCeF*fc+o~ii4S*}<}+(uSXcJZw1ByIl!R=)^8QRDj7M22CaZ}|$4IV!%)XvgOy=O=?V=yUnKs>QFe;{-PEi%J7_IV#y|HC6a+&E*RC%Jd?Wm)@qvD1uWn_EJ?GXtkxdIib%eN<p3l;azibZ?pF;a+!m!cyfq60;0lzSqVQfWg)ui$zGErq}Erf1Ntg+~Ee+s~uBg|#!-xwKpghr?!pA>ALsK#NGWE)@fxk$%0I4E!@iEl*gok-s2&;~rc-o+XbR`IscGEvrj%bBW6Rx9|o8xQ^3X40Ez&W^OakVy~E~E0IhpxlO5+4^m*wA*#rR<B9EFPYDSBnG+c2ak)~i|3vZ#5?11pITTRw+Qa!kSo{8nplasf&2F7=P=Z$A94lqdHeZHEeD(P++dXNg`NOv<bk|Oo?N;Ai2LpHRlJdgx5^6AVM!|f+qF2=9Ia7uNZuK-ikPR!cLq7Dyh}rT@#o7wLs~9Hp>(pYvD|+tQs&>?@#scvjQ$x{N+F@r?h{UxIE+}vGX~w{X5qvT&Hb$fSj+t<~W{4IJcMMIWn%_n73d)^AUQ7pNr5a%z4Z-!?&mw`kmdpuKu^3i#H^3~{uHFe8cXHwpCnE0yn*gm2GZ@U0+3w=s?*1xs1QMPn@s*xgR!AB3;+W@si#}jpHba~!%#36e^%xVF9^idgYDSc;(j%R_rJgVaJ6&qf##BK0pwKziVu*<FgCogD^jHX{%O^6?0O3tJd(-4b`Vle`=tNYXSxf50l;*dKi^GCaNQ=C_iQw?g_=BV~67ax_k;~6uy2$~wR`MP?Nlud~Ek?9HYj#HBbrk85v1I1&n|DOmene}yf01eEaR^ZTV9OF&M43S>sd80wHJ`-3GJj%#oA?xsj|-WL1&0Lgt+e{%9}ZuYB;*5y2eQel>k01}Q~TM3tyE!*Hg8vn;Ip{Ak;?D%JkT+d=_8lWtY^zLw|cApa}agGZ^%k(v@cDrbZDj>%)DK@Pf9R37$!#AV1DP<Bd?q95}Pe0-+x~0DZ)}jG*=ao*pk)`5x>Hg&b7SA%R4qOO)9h+f9vI`z5U|m`{C7#=#;W}MJe0dueUx$(LW3OQXj9CBO@gqw|mPQ&Rkskpv#`EL25$cuRdk`Ip@Ho?)tMPLdmkBoy#H>9=GH<#iQ%DbA$Nu^fy<}r3I6{4(n@*E4{wdi!P}XN0-;()lV}JQ84-!w&D}>wfMxMG(~A##5Fd(R<==Q^1?AcW+TH^^ZAIfOtQ5SYpChaXU#8d*^lPeJ;b<&Cd8x`9L2pSDwdDv!7yVs$qHFbGqWzHMFG_Z&NBQNqRao7^hGd*3AGKfCEyG*DKNQAky-1h)?F8(5am^&WGT@#Dmou-fSN7y^)g)+u20fB$$8bf;I9(rL*kmWAZecpvN4BIap||OY8#*Mp4^IP=3yfTaJg06psl$0@L3{G@uijbj&9REyYR~G7Igqf*W9s~q0mNB)cs45Ncs4Y4;eHcX^6AV!5%G4uF?FI%R9TUokIoKm-FQMAi2LTD9uc3g+m?iSWVuFs`Dlj5ZD~WWc_#-B<eXclgku8MMZ+`>ONnqxxV_>0=Dcn7S>pyh-LID2tu%_vxhlZ*XfQj+)yleZSMEazqQ!WI^s%bKuaFA*VWA%wtv+Mh|RbNwrw(FosoD=ExS{cVIkymSR^d&E283YuUwr~lSOwR^tLj#ky?+ktFS>N_m4oIW%$=b*F_4_U@@w9&pWUCAB|lddg~b?ysA~<<Jz_&cvK4<dU2zW1N44E&=tbMEtb7Rj%F<j-HG11TdA|8#+r}Omav>W>RZ>2Wrz08_ABycDptqvdNSwFYcNgR60(;?mS$sd8*|CW=mmQ_tcMic)hw<y!_mBI-Qir{ak|>cJ6`ihvcqbNZdJA*G=$eja^oznPECSLjIZos(vBx~R(IDG69CtXVoEUa?PhhfxDh2StbwWu`kw(Smq5rq>(@cPSUM3~nxnKQHnP);G6g?g;e5x~Ry$NY6JE$GT%D<vkir6uis84ugcxK0n9q?)vuDMd)XRJl*2e%9!T@}X@&_SM4>q{;vpPnqKN8PbENq;*1w(6v^Ajp>DLhb<4G&L{)_!4e$B>87Ac(BFAg!Oe_yb_4%n59^V!u(h<D&%*Ejjw31KkA(X;YUeH4tAK?{Pm)DrE7ZvWb$~I>gB^R6(5{l(*uZTvYDHbub}hg@IT+9<4^x2FnFHa$z13GgmL%<U^=x1aOp5ft4%p#c;4{!W`P0|G-vHt_7$?-&jCbPt`eG7i(CNc3<2Vje;&6d@)tWsa~z8Cra8LRKYHqZ6yM0Q=1ic=wXB^=41-6feNr~aKUV}sEfBOuSBE4F^W%@Js}Ks(0G;#53Xye6g4y}EXENWO%u8IDDeT~rLJ9IQbGG%#z(C9urn}pdbVq^+IB`iRw5Q@WTmbu=T0u9$nTQUk(Pjw?Z3TA!Kx|6o;L&#4SvDoq&v$Ol~4&BK7kilg;f${OYHtpO0ulM>}7qinjEfH&6@CHykinriyUviWl`7sZ+~GUcU5>B5k^}tm#%aD^K}<D;IB+qTRhrv__Uw`7q~yQxe3wJc%;D(A8riog9%*evfZ;8k1U(l7K=L#vZ4LEM@%fRcpF5Y>#;vbz!5vKK!WSZo-o)%Da%SAO`94%?P0aHGY!JnyZsy-G%KN+Z6`YjIkU`*A(^)SyyaU`a9Dj8)>g2IL#sEN80I9lI^wcfMixO?Jjl+si&<Hhq<CSJ8JyH>)Ibh@_Djt0ku!YzqIpVETf((|5;hQ?EzeS)a>-myyp+DY=;4F`<@p}TYcy67uFZjydA)GXG|<8#y=$OYDWv{TBo|lf?Nw}f@T@U(ZJPbDEAbYe&$E*tX2MAgU+dpKSQpAzEr&<^=icZZL3Mfk6@b7?w#beX_?=uk+s`u^RDH0P1OED8>)pMY+wBQFivkmpFFNrruF%EIF8e7|w7&Bb7Ev^*%G{M*?)Qea9x~jMsX86tvkjHdR0ed)62qzSP8khThUe8Yc7WD1%x&8<bFhVlaH7tj>S;_s1xVdBo6|%hCdHITJK=uOj7vhdbJ?Q05#Ij{&13z}ie-;s`niyaZrISy`@m`Zk>*WpTBIpo66}hAICG1pUM=x-*~I&yw0G)u9W3yALit7<J=UWl<FFYEX@wYFiieb4F<!cw7JD(_lBN)J8YSSGoi{U^VJ~iSvBawX%`f+;aB`!tkAlFH4wiVwXNwOsKtCnqU}8wrKL<%5&zCJT%C>Cd`}4NV3C$dhD*B}bAhFDmbyGs&2R~uZ!^p#=tFu2>c+Bp-y26|D5m012u!X{5beC)`<;TuhK-l=ZvOs={{@63-YxBz;b<y3&S4V;*?ZN0+{o*ADJOPGluOYw(wO$x08dE6fOtG23dR`iO(rkLK>(KRf7JTzp!p3A5NAchgMnn`)Ylb^VwSvL|!%O};E8H;3VHT=#*(M(|qh@rIgNze61WGj`9`5ws#i3-PBMc?Np!QHjVba0i8#n&DrX&@mLFSG)p!FFt!nzV&u_dCDk#vissM){RDq8a*d37*GQO`DJJl&RNXenuMu3Yd;H-rVdsdA~p9jg%>?Ss7b#TH4KpQRwjK-y}XQ=-kW!DaW7*%?Zc%Z`U|#!cOh;8#9KZ0qu;wn>`I{rKt79Tj3aJd{;uyNsQ*THXJqlK~4hA<}^$3e?a>_Hk=>^%dSi^rE;bEQsBr%l$2SXU43EVN>zl<dl)qGfs+Ty+yLJ43rJ4I@mo~21eTa6o@*R(6sCVY)BBa%%CZ)+GMK%aNN|(WhWtA`T}v*-O1Z_<$BnJnVGiTC>9oNV-V+BPk@j6kz5{L1qokiLCpW+TlJv+rRroaw05P^*^7EmX1r(}5oR=PW}f*hJ~)AEE&61`&xGvIXpW$?O2cK%F?BJ6Mv|b%E3NSy9^5uJ2Onz}Ui)^^&jc;+X-XT|kI^wKPqT?2D${16L3P>QzrxLUG%2?nlPfqz9VEqPB~vO~XO51Sdo$(0>H}7P?KRkok&nXG+$!5)RA5=~se`t6)?Ua<shlMV+dk-9f{K~3TX$793}qcvv?*kPv_vn~hwduxw<^!;&cX7;aCl~Um&c8n7oIkXD5lrdoK>nZ#f^ch8)>ZH;#H5=RV^8;diP5qga*DpF}!q(dL<8L^VLS1*&bUWOTeABHXCOn_AVA(%YiLFw?`Pwp!enF+IV<L^gVl5oO9szlHT~BA9i+O&dhIFnFZ-uQ?Xmc9^*<Vw-TqHR|v*pM`W;Fl_R3fbyYsO7g?{WnjUv{UxNH{GWI~KXJ$ayQ|2!ZiPHd=XG~uizW{u1K@0Wkxg196ma@Re8`$5cdd1=BwyW$q9EQz$Y|Dl{?n5y9HQebDp7X&Wph2YtdBds8(iz1hF-_C+5t&UYM-xkr&lXF6x{B0{Z)<!FOQ^Q2jyC(7FP|tKA<CYn4@5KBV#2zP)qnjUBXZ}=)=T@Y-73b&AZc9&q7u1ak8g_03zA;;E`b;c^(a)5PRsJ?#~f`D&0J(`)=9)wz`i~RO{OH4{akThRG{u@)2Lp0w&=(0Y=c#_IYkwP*}%j}Aea%oQ&^HRX64yqGTMh1LiMbOmfZKAj2DeeQy-0%O`}FF=4#+62z=xkrQ&qhx$|yf{mI9+q~ZSNe|Ig_edlLubR89On#<^m!d%@J=4kQsx-ggcsclKFWrNU|FJ0QSyUL~>7nXXQVR|=ZxVYL+C{x9y<(t_maf)<g#DsBsD(x|fhu&|a`MVG*ZYE3ohnz4Vyy*>>@JLDFuqVohgpOIp5P=y_LIX@s7{k$c&rv`x4EIwz5p@b|E^+^iS9<n*F1<WK(A>(`&8_^8R@Bw*D=oBEPLxZbHBi1>H#5Qtw*@J?c5*pbXG`k)Jo|WEXw4PAgP;{gs=jL~9Eog2cR<nH%RZ)>z)O`?Gk@%s1UU*2rXH9IvxD8<&Q*2UY!!S+H<{RGnp7<nSN54CnbDqD-SFPZtrQDkA0UM_?pEA&U2ZK`<yOo)oF!OZIO0qb`=QCI*2FJatyPw4FxOII5mgxoOXU8tLz;pB`c{v%-YDnjZAms0Egr<JsjR;G(wVN@w!V#$?B86W(wsua=TM)-HISq**=@O9v)msUXct|Z%xNOD9Go4I7#|I_+7mTg4yfWy)n@O7(Uzn2Y!qCyPkpA@F)f?<RKf-55<K?tIMIF`<bq-dPYtxs!Xg??id<HaDL$I1X)wspNRR|C{}236nH-YfduwNOQfaGTK>bkd)ab`n4fl`<3Z55Oi^2&$ebEyh!NjL<1wF&RNjk%{Wb!`0X_r)CYH_&=#es3|7gh>8S6-Q-<cQ1IEooK%VC+ILtp9Lu<V2Xczfaz60~ifB27}g(4PYAV3C`u#+%yrC9$vyk6G`wwR9yeh@SjTvn+VQ3EDKO)@Q<Ei*qXNbHf>=gV%LPB$YRT|1gX}WwR}m}d$kHwks&YiQP1~7TA)Kg<c=yW>dq+UMD~$tD{b_6CDTNTJVN2<B$Xko04o6mHCs-CfS3Y%pi>JzP~2>g^kl~iF%4V%1~qDGCr;X01gJ~08vJM6H1jtNZEJfc8K5A?Xp`fRv|^f4mi7Om*&?XMLiA)Dl81ca!bIy}O>yD$dW@V*+gw4BUSzKkWe=m;X%0Y>D(_nLf_ldb2rDHs!vcaASfm4KI50Eh9eGGL+lCk2FO$#$q&XO?J!qbd%RDPoQhT#}b5m{lwU_=cA6ra!R++f{qz(J{NVB{)9OiEP7zF9vOu>-Q9XqRpE<KQR<iPJuUgH7N7R5J$6~?e=9tdON24@aKalL2P_sG^jj`bm_=Ab_IENBag*W&VU8CBJ-g)VTQQ6<4NLuL_k9%Vts!NQF%2b<jQ*~%0#4^_-Pp1G1`?124$Oj&~Y5hZCIZ7+8DA!eF1)4nX{Q*LJjRCUV(xs#tTH&CNV-yZ+;%GYj30j?skvSC@&q@3T)Cn|w(Q3FyUZ5B1Qc`5}F`a4Tr+F4e;UpS_~sKCab4dB#O4>#ax!?s|i6VCVX5*M(Ngp-vWAEH=Lfi-z6EoAVhDY=N=O9@^QxkvM4m0&oE|Hf;!<@p@o6mjazs?B8lcb&M3Wnp%c4m9htTH1tD%sy&19B@Jwh)p|pUc=DC?0MYpt-d|^!^7Wp`FHOKe`m(E*~8z3i7>Fnn8HDby%%sjxPNl_(Ar^s8+h39fKAuH0%D@a(dOz}uTTY*>N5x#3{N0Ae^c#XjRq6fQc$DQ7iPa9G6C^vKVZ(cCWe~Eg8`#h-N=S8FdeR7ArF-dW0jy>Tzk%I_-o#8YXsb1N5DSGx6mJTY?+Yv$?v(r2h(CjKO}>ak>u6QR^3ooocbkQlJ#IVxXXQ9&1QG$8kfNF@^W(CyJHJOf6dP_ock8cX8#l55`KwH!RG~+Kt>?Rf|{S_o4AA-Tc#(AdT_&cH0=t?@VOag0lRgk*R<obxs!Wj%J(Sh7K1_f#2$gJOeDB)SF9&{TMkk92n^?xWg<m#GMyfo@nJzYw>x(SQ_8(<gLG!z#j|qB9j8T-6oC;m_aUocW<C5%$`kzs$*T77s{k8cq(z-1CzFs2zRz%D%UAzss?qmetSMc1v4P^Bl5)6~Vey`cuoQIowEm0!6exXm5y+b9Xa1d=Zfp_;nxm9Gx^bZ4`GvR9ARJ&x;ROo*cF*Z%hK?{+T6wr|9Vv4s7fdU)@z~KzKsk<6!@yEYX1ELqAx1nlxg@bF+tbpr;ZsFEQp`9^d}h8FaiQzZ)GpMnk!?{M9hZt(&qQ;K)^A^TGW;(FUI{Liv5VgY^GJ0$*b-;rk65P0aQJci?<8dxi{t?OE%7rzZ@re!fuC6$I2Et)M`M8w`l11aJn|-)xuh;H_M&~LeS9qZ&YpqE3_u2sA3-bX{iTF7>gJoF5WepJeUo&(u0Er<Z%dlf)|6>ub-rDF7*nwR@`?&4XouMGZ5g64F6*hRt!Xhroo~%(#+Mn58=j9rIC9mUdh3NSh3V+76P!EW6Q)G2C*`u1gau#J9_C7pfUIeIw>__{+Q@1c$d3xigdyCvJs&j0SP&TqXu|@_#&I><b3A3Nvm_mitj^<F-!uR7O%;X)dX#0F7!6ITpExdgy2>fKV2Y;99k_O{ohQ{8h_(*d$&_1DbfVkY!c8h^q~gBlJ^1PajjL6%X?xp=!_R#lT4?5$sKcgqW4b5_vm|qr1h6?4F9cAp5Oo9{GhF$4SFX>ye|Y7V_!Wj+G_8I!-nuRs-;B4?tw_s8{JVoKmIiOdTcCqg?~fcb;5hChwc}V^lnPu_YkG;d4%>JusS<w`auILjQFN!eUeXg{_<YAhYy+<x-d%c(DVd32Jk!_N`bXqRv<o#(-5ArAd+5?qV<<ni8LsVQ=yvgi&*%cSz*C16z+Nn$#YD1iZ)#$UuWU*;yBec3vD!{Bxc!h)SU#1KFo&aLvf6`Mv`+~RU;SfUGqneP4kG&VogaRAj$<K;W@O{;&Kw5k<Z{+-&KKXyoR5FKcIJ!0OzYLn>(#8qx0t(LO$26cY~J$1u`_GE?cO@?2P5?F2j2;?nep20ZZ(QqcV*q^Er?}f*SB)u@^Y)qvCo*1W#u^D`Y!Jf8lRS5nwD0#m%_HpNUtV2pVFGp3n%g>S8sJ0j80OFFG!6NOL^I84r_mPOEGzy7P;&sZd&7B&`Z>VjB$fD*b)l8w{5<F$+2nC>&nSZyI+$yUmyJSS1aJze(x(g%gqZ8&gvDsTa3or<i&6ei?a4_yXL=!+D9gi^h6NpsYPjIlqc3c+U%cGJ>vEG(!M!M@Csr{kM!Yvz~M}n_Vl-@q!R*2QiSNa_ol{uDBj4Z@sISl-sciqe9`7V>-AI6k@ki0GsWQ=S*4To$V?EvO23kY^uoO=`?S>Ep-Gr?Jo51^9Pg)gs5AM>hK)y7jR!6;qBt{<3F$Fd-7&G6Pd+gAnWb{n(;~B-{sqh{bA|1wj(-L`QNmx9aK;lEmWSNJB2MU1&=jcgFD*`v`9#C)H=G<Zi|jYe91($U{2ZC<WeFLS7G>i|TY@g@#=FJ3QK~Ts_@n%kPJ6Rf#22Aim@W_Ge@Zq$a#PtZ?L-|V$_A?GpIV}E7_G#>{iF-`Qwb?2(bKnV6S^q=P-r!$*yNtCY4N^I>2Zt$>uY=`ohy(IJN<Rn#uw#xsTEY|J}Z^YU?mXNrT7dEEO@nua!-C$71`BG5|ofkheV`XOr~>KiA|=8EKwWr<KO@CK~rHPc-X{Eoh7Rbd%4C%;-{xTS$L~pAatJ$U{ctE*K{$lQJ*Pblce9&#y4}+QaYbxQUSn=$c1su8p`6-unUgjO2OkSPGZS;1D(ZIh>Zv1fz@mBOtsHjwOqx5nvA3xoWWl^xm(*!&h-CmZw(8Jrlk_z*4=r+TGSZeSVk*~BZWFR0W!dQu}xc)4y5yre;sLFPM8Ib1n`q!>%yI{v*rI|@7-Q)+xGOJ-Y&iM%jn}e$DC{K%h~7DIoqmJC#R|~mLO!k_~KvSi!XT=M2H|1MC+l5R;3UVEwn0@6-kU$ND?2S2IDn(QV<jj3W^|Jh?fUV9t1&OY~T0&e*H4$SaYqtYhMy_7L&Q=7^9Cq`sls&)_#}o0*b{F(XniW;BaDLZb$TLD}DGW3X-$;SqWM7(zrGIgJ`D|-GuBHC}*{DqOmlRxp4}-!_B^BUJX9<Z`q*UF&h2uyVGBj<Dq-{s?lc#>g_VFlaFi1A&^_qraqW|d6uR6N+Rw+{kEcp9{V{Z-R8b+&%AaukOw06(c^a&qvELHbrY|D;klk&<_&^N6WJSaWxh@TuW7XSW<!r^*xkf;kepN(=-SR1P)bdipJMA{l57<9G6ASs=exsFa}`UAs)a|8x!5$b>{cH%xg4&L&RLoqkxA`MM#~srFnK|;Ax6(=lNG*NzQv#jlQ46pCH1J$cS8_ciG9xfF(1oVub1K68)M>|9?}2Y7m$_;5H%|gn57^vHG+E+G?pJUgpsQhu6ayMa5~$ysu9XsB+W1nq|`|&3w)*qP8_hDI0T%D$7XR@S@aEAtnY8d4SN?iOlxsNu3VJt)ezn&8zxDz-r@Zl#AcxKF+8r*M&j@Zl3k(itc=1so|S%jN*oFlldlk%5}Ob^;gl?l)G|zVjUbC>P&HiT@KFt~H2tzJQTh2V3Rlyji6)rI8gh-ek(sJ5?K+n=yb)qR&bty~s7HM;O>!rT3i_-t0s04iL4vfK$SJnf4XR)fMNnat#+Cj8O(@s^Vt1R&5S(l!`k7kp5;uHual>+Caivku1P3tTtfLzu(ctpD#tgZ^Py*B?YQ;e{QoVBw<bGn$sKcP>73u!Ri}OKEsoyk&MM3{OhfPY&xSGOoW9mM_SO5#XP16JpaSVnO0iv=crpI0H>uKyqL{5N}QQd4jg3YLsr>W{h)!30$Lrv3iBUG_#2=j!Abb(>x?6x6>#R7})X<+!1A1x(*a^36_jJ(oPh2)6}_oNIGqRELd!V{oINhzs2)i6&1bjEZXg!BaZGlh?KmLw&M76fXm;U@K4!OI~Yu$^@f>Q^vB`5X<#-U+l!LJ$#!7zOq7^NzwpEC9tt-;Mf_Dq*51qUMF6GdidJcT!&${xl+G8>M9y!m%+%g4!?EJV8l3wqY(^)#auU+y4!ia%t?S#h=|!;}o;ywK$FaU$IG5wXN^Idf&b`_T8WqRU*eQE#ZY=TwvL-n~|oeSiH4>6K`wcD5Hn2!{@S!mE>DNa3W$diJ~w15z5xPdDaDGuz+bBCY8boS2ffr`|nuN+xwBL+GSXb<tE?=RAwr$qY!|im+^$=^9azX=4#NsiAfdx_S)GH(k&ylw>m`be9{;)NerltT`aYV)po_5;_^NAqw!_ogH#3_B4Z^UYvuFQ33+qvU>73UGe<n*D~G9R6+#zRQT^|}meMkoUoS1!=e8^GP8ini1t1xf2U8W!^Dx2UukJabnWe^@P#c~BtWv=XYXB>EwJI=M+oJV_S_S6gy1;A+PBVkJ+EsPg0Ia<!1!NWBSR)X6Rf~2ut=m~Fz)E@V!Lah~k!;YmcFPo!7*sfJXokRty8FUhRL(393*ny76B+K7groBktoF?EaQAxsIL(JK){V#Y-h70m#tq<*Ue!I<b!XU_HCyT};;g^_f%&(>&_;wx{_(#p)7H;?4XMqv%4_Z>H63&JFPhgtc?byVFPhhcO<r?9sfk}Gso~g^Lbl2xUpk{1v{^>yrjIvy4OZbvX+q`)^{?kL+e9XNUyk)GL~J}`x)nD0%bdInTyl~DNy-8w`L=TL?ZbcRopN%LuA&>1iOSXS`;g1oQXcj{8WUflglF7&H90r7PFx|ZR_JFktGrDe1n?!F+iPLkapZKd>mur%s4vSXDiW!ICDQWHSyfah2`Ws5<Qndx%^~onmZy|iIlW3jld}GX22|;;4J%1beiy(lr)8Vy`f;tlF?pe18EO*E)OKRb2J3>%Z#11w*QyI<mkKZ|Pn`>2O2#fygH!Jfd>BQZs2Alxxn<Kc{P(^x;W=ur<k49iI{|$Jj>PnB+H+d|psbtnJki+1;fc>>nO`8eztbADPJH-{4Qb^6IA?H-taRwQM%2T($`?(Fj+<-YV<oN2Ry>46P8%o3o@BN}QIStcLC~C}nt&k*9Yv^svQTvl4-n#0MkjetE5A42XSKH&pwpMECkkV<IH+{ZD-fcbJr2s7rAj!bk}MRe=K!f?P($B;W@3hSM+GDe)~<r2)Gh0$KL011-=f6xk67`44#{#c>GyJs4C2MqL<3JweUclKgHS0I+rZ0aclGA;T=;Amq~vDDasbY*v$5;H11mWMNPxC??vf~v(Xrm@Mn=I~J0DO%z%!!k8>pk##qMF^T9Bm_7W+Y*z&PyVbH^O|MAs+ko%P5{0s2vgN}Rfu2*tj4di~OHQ{cmJ_Cak-7tX8u=~<-6bD!3FanUva2njP8+q_xo9Oiz-9oBp6NZD&u|3(fLg1bw0n(*Rz8{^+>zB0vKYdK%%q?t!JtvavP{^XRK^4ycQhBSrRRt;&b^Mf<FZ~M@<E#$au>)!OFy@hOS2b2TjW}jtY)6Bbl!F#p-v0BCVH!j<aWw2rzFnN2x{zeJ6uJ;ylv+6XPE7#m17USl{e*6s2o#S<@HF{e&H`~T7r^Wd4yRUk&FVvFn?m6U*BuAcm{5RidKA)!7w>sLq*^fa1(x#!lyt>R&+8e+7AHBuAJ+FrF%q!^X4c;uqU-J(uquq<=6KOq>fm*qWIN78}3*gHe!q0+)a{Q+^H8jDMF<P#sJ|L}942KKOTrnm{ygsQyjaSDf>%Yj|v+m^5<V%G9U2zgZPoLBuU09Uio<}};cw^QM#Q;Pr!kG)O9@%yu+%lukjucD1f4e2N8c^a1PrQ@z@&ndq{T6?{`3(X+vkIRpr`{~J6-%opbDs|R>{i?48=xw7O!Z^yc<ESm%IqAflD6{wRpS#aW{@(doRXk553>#<05Ab9JnBw>93x<(xIhH1v@eqcE9p>xhN#obRI=mYC3_=9hV20CNez=^0%Riv`}L%KS=Tynj(-fsuZ_M9YusX^1cM@`<bK_58W^((m8^gD0<xMFwx!f2_aYGy3K~d*gytl{(EYp$2h6M&&ap_%+7x$EgEyfn&6V{F*3jltwk44?VzHHCyjl0wgZU0!D|JG;8dsdQm?sp_<CzDSXtU{Nf|hOLs3zmKBi1yvKw;4YqP6ocl^}(-GY2c0ELqBb&F=Gw!R;3++`UqcIp{WC(Tmr3Kbg>{Rbbj~DHZ^^Z&82z%1dcxO&2#6{ukK4tXYHo`g<&k<OZdRO*4UcNa8z|fjJ|ad?V{JGn+0l%?*z9n{DqUK#`;Td5uuflY@>AN{;T0Rv-&2`UE&U!s$!AKrnaf9Ghp_)&kVjkq|1&Ng(UXs?CVHLZa!q0i?t7JIF+CZs?_E+=j5IwGJt(J7+Nzv)-4|%k@c$ma+O+{t$)(dIlqDW&^<|k*b=p20kgZfsV_mo>HuVog2{>W(y{-BpiBFv})oegM`7Le>SloC33j(6qIS|z1J-wbmgM$<tiPdNhL=d^O@e~33UO;!<JyoH@vYP$th}tj(Q7)obdZ()6f)Dwm`hoU9q6BIA(a}ctFc884{noDRxTQk?q(PfYO7Kpnc4+!@)8C6gob1L886UL*28axQ;L@kyu_^cT#XV;}~h?jRS!3Po0A%<H$kGvVPpa%7~UT!1!5nX&_W63`Y8k@2kRoaXo?4y}Lc(9)*%XYcc{Y$rnqpey-HlTfHEav=VGY+a^nwcdpT=bPm9Y2Kl_r(!)SxTM1ScScTg2vPojJFKNzo@iip&s9LMh<I0_K@*2H$V!F9S%0_}0TvyfBepQ!mjh8GwYl$mfR2PGB`^8T(FOQiHg(--ffRWh;iZ9IFjgT_)q8i8@K>RogO;27_x4C<hYVo}0C&Em0>&DfsJLuNEXG<W97=yO0%n9nfT(4@Er3DI20uO|6du-}Fe#lp;h<V@Y5{FiD{4_8cgc&pHOyAKN_{6ufe6$-HbBW1Tv6JyYO932=l#$Q0s6iD;ptJv#2wUi~-ESBLQ=?E4JMZL4prd7-Co1%?$T^ySfQ$-cFrXaKl*`(=QY0nBym2N_#>pv<czpwFM%#IWKf8_u1kygr-yDfGs-&U)=f8vo<mE{Z)8V?*ZItDR2^Jq`EF;uG^Gb+OfYpPTw@_p>P3dfc&oj%1JDI_k-1)?7>|&6qKTDN`VRNjRa~hM!%llkBw*R<(O0OpkG0U1#8s6aVkD1|3^lwJ*=mZU)-n7Cpr;OA;8q$H@f$3m-^B|lp{sdJH(L=CJ|Ab+8g05sR@;kTe)i}N2cDvLQC>OdN<EQKnzx7?$<obcQb?bi04_<?xcUy@$%Kj0ipG!B3&iNm1IWW$a1G_XuFA#9-XiF|cEQxhN^VpPJeU5A2NVZh&?bf7ridB9AtDJ>>U1)GFP{CP?z1@i+(ZotlYi-EJimGXjJ_KY^8CTk3XvB;Epk_oj3Ow%O^8}pGbyHfaO4nnIi~Dv#$HwQ8#^Lrc&UDh~W^?AF6Gh^YHb7#W6=(CNxgb&p*XL%MzSuCuzS)4m8}fl?%r$)reV?iktYF$|g}G?yj6E;fxm8E&dY()z%ga#7>M3>^+)lyW3v_-PGnUB7Po1P>0@eTQv*ts!q+kUbcgAhp7$n$liza7X$r)pgowSQw9!um~6nwh|%jaexa<I*{e6Bm+cwbr!@MRd>2=2|eh*`I?m6r^sgr3KFTB#TJ3^8kb`6Op>o`7s>2hV#tIwFzaY84Y0l+un=?Q`!~nYvbYSP#(?Z<8F=lF}w7b99my+O_UJaS}qne+))=oJj@s0Qczn$LEO|Eeqm=!r?6=*<u30);sKSX*z#n4aQE7gi-l3b?!Sf2uu-F&YQ(_Iw0EJaW2!7b(QW90Q4w52JWVZ_6Gs({^SV?105Xy(&1zY_ZZDH0{KDRLzl9lX=^xYZ|t6oh3;n{9Y%|N1qs||x!f!P5#qi-e1GM7nDuv3{JtDfq11dq1u0Dw`ko#HKvK6o^%O0h-e^gpT0}inZ>;rDFXZLXG|^9ty)P)Xm|#Gea~*}{kA`J<k^lrgQOY{?T}UH7cH_zZYC6Z7V%k*aeDgxB1F?J3a+59(%0BFw`qJeIH$XYo0mW~@^2+oE+1PX@`oFG6|HBtYJs|nG6Lp_d>oN=aBvQ}{0nxue$-to?hY}Vu-*V3`p}hgh2#lB^>Q-j19rD!;9ueg%A|OJupb~?(nByi0H+*4UNqE&WJ+VtQi?rQ{cag4bfW>Yr-gO|YN`=MVgRuAk;$6WUo_QBtf<;VhOm`slnOp%y)ESVQa#y{`gk;wInN}NC7bF|E2I0xL(3t1Zv5f*dVlL?C&N5a?xJ13xBw{_~L}VYEZ^_M{zp>`>Z#R<4tU3ITIJ;gMX++8uF!G;#c-8?uoxm2si8^NqH%j=ETpS6$t}OG&zd)TTS#S}Os}E<HC}CGeIVJfIx5v1M%8=~I8Wd)5*>m0AEU6W!?^-0-Q2;f2QZ;j=iDTfa$*jWWw`4wf#Q<z-c#63o<3gQi=ZOZoUOh<!85?{D!tmS)ze~#Zdj~DyY9>z4A2I;hN=i-lh*`Jq<L5)_cS~`+r)dFR%FS9<_8u>5j>FO{mXgesKJ|b3OCzkhd7^pXZQQDuM+SP6J{BPyQWQclV*^?Rn%%RspbL}CJTzyxwMvpPQcO6>W|)aFHSu%WWxyZ7*072?Z^E9<pH9-o?DjWKMNQOk4<;dgU|G1ZmE18eJVcY#(vU>pL3>_dQ&`+aben9%g^oqxIuJkMn~<LNumS2*=vd7I92A5!Z$nMCpG<CDfgO#_Ce*!*dsgM@%CRF>z9klRRxCk@@Pu%1r|fA_=)(;!>5{Kkn6G}vf8#@oKOMb^v<6L0nYie14a(B^+_>PSC>Oi|Val=q@sddv6n^wCH9?0O$8g=TGA>3|ROM%Z9>l(<NX$z$(6u8E3kt2fNGPVoOOyib(Wh8RfugYjwUbEDbbaZN9AsCpjCM>BIxpP@S|G4yVbz{iB7`jpQ%kicvP;gqSxV>~LnS$Eu^wt&2~>Xi1dwm%;;=lhN1zDn?E==c&U0EB)+?d!37PE|=}^XV`+GQof8<s5ihH)rFW@GY=F+wqBnX*-8@`00fjKu|Zd#Nn=xY%#GoC()F;k})viHPpkl{)oNNt9a5SU7?Cdy3%Ezq-xhZN^ElnY`3)6_dh!ISAmlBQokWOn)m)Z1%}9Z?oxDE8}LlKgR^?SrgEG(B<xoS7e{bT+z2u7mtWN}b*^KMdZ7Z*WWgILU5?r@WcT9{`*o<l^a(4vypmjczbAKZ0ZfExLM1{wPGHTTQdA8(aLo7w2Q-u<VTU5kxe)60NN0#7TT2d`MIzJ%Mv4j)=bR9l{6wK<m5C#`fTsIx^2}MV&~~pZ;p*B`$_9XQb9yk|)kcJ8=ISleTgsR7A_daBLKn;CstzE=uwjxicM|=IN+&@UODwD8V|33&l*djKY^b+eB1UcBWm4q$0`!_>Iy^5H$Smbd-Ao%B&_LiEd+&f(M8y(}ZYAAa|aE>H&AcjI3v&9#@|F7mez6!;ZJCoK*b6W?sV{Ff=S*xF@zPBC9k1!(Yb~1fZ+kW;mAdl_}_KCW<q$Co4F3#>pO7&g-8WsXUL*EI~rhJAMX6bIsy_eyrKxfz!+BIn>SSv^GHlIvw6n2d7?;NAnc)->LsO{GNW;{95ySVXE^@h9(r6GkeMK;Rq5w65#-*i8_FLs{5Q6g^5Sw+Jogm@r#{#3WCQY^V;VgZ6>_K1#eEucaer#MuzSXTTzY>464*&%QM?wxn{k#@gx%Z&bEh{3@ZXpUUw+|uso&NrAk!;y!TOBLCxA1F?u&IU#+&1S(4Jlh{O-&gLJ@RPKy?F_edsIuvK*;Vxe3#Xrc<$tns+Y*#PX;v9Z#1dojpCHt2USs_wtg{3(!l+FxM#wr{2jy+5v$D~NuH>fg`x4CT+wPaKQgFn_HhBMX#H*_h<-mS=S04a$3kk>!K(IZm3%<g4@1^5bdt6=J_~&q1MYb2wWCBrjGpYE~q56^=A`N^C&ZjgMBKPfX>Ti+Z2WMnVYOW?*8~yM^!JN<ArkYbD$|ewQ&V<{4tV5}cn$69G6J@wKPfX-xV63{u9k`$lE^betKvRz=o9<APXCu8rMKNwIa9)xBmrpMM5dtc3O#**vKq`yBcm5Y2;<nxDlmZQZ9*7D^DsJ<tRN0<HX_`f|Z4DLIN2#_GnI*{0*jYdnI{eDDdqXu#pLop9O|lTqO1h$6_~x|K9Wz!2n(nZ^rdud&764kwI4vjjyQjHwfJuj4#MaplkGR`+3ZFd9d_n>rIEpNjimnGWDpo(W92FM1>9aUKkg#C@kYxDejp?BOdM<QA$RlIlmehJhlm_Vx)a9+b<vdYu2kW?KJ7RiZvXm6KqRI@!L|<J82`yC8Tpxq>^AoKhDSA;MtdQopBrY9Ax<Ht*){2&9^<&@szGDX1qg)WkT$`@}f=ttM1hSF|XN$!9S`Olzg5V7?Ru4u7{=P9VF|E*PpQ$y-#;vw@gY1j!A7YMmAlh^B$j_uzt4vq|?r7Di22ruvpadyuOWI4M(G_tOl}gm3Hm_S3k4?usHfVS)|`|9ljlW5-JV0c$<L6Is5-gfb9R1v<_dWtOPIF?w{Yx&$qZ5QjsAa0rx3gDNzE5t80URxc21>&w(dg?jdVTIpO^WhNZVMbMd-5YoWls+VPC5wR}UeUHBh^(DZPr7uL3D`&d8xO|EtKV@?Enj29deAI0()B2Omlf51`R<L3dNz#|tNzy|HL1P;T5|99DHMb<Z{;27!N0>~ZGsfbg{^r2uC^HQfl3N9RBk&QW_lIm%2RZR(>}n96f_KuR4(3-sRD}AuDfF6!)bSgfn@1k$^u%;Vx}{nQ9t>_i(Y%HAR@B&`n=wfjS1b{{9i_D=+{>feB@=^WT9W)t<>-1p6tH1Ws?4R?Rhil*2k-y8IK6>RF-zkx5Q?q0;Q{Q_OKE+#ja47@yQMc!Mw55*(z6JZzBh<qbl8Jkz4<q`**w!h$%K=my%)Xme4;Na+o?}>PGbK@n?Hjdc=`L9=ekZFsVEC70p%5+%yGJA%i}3q+S*7gUttOZi#;OJ9*h99GegC`o{tkZE5_0SS*%8(5B%iT&~-I{ANT6&)Jeo#9<dmnIGPE(f6_LiOz<#X&varT31I;s%(v+7O58q|+})F0spHb6e@L?~hi2*Vi6X&%6PmWt)m&k7v?m1(Gv`ypmdv<9n$0PTdPHxUZ1Z-VeGFrnU16~Ozn0>{<yEQBxx_HD36Bgx+j}X`>7GcacsY!a79Mmo0O6t&I_E*!!$v1`@iRh99nJh8zh5oXl_(g1x?+kKBRJLeVu6WS$g?P^(Bf#4?%mA7UfF;-HYknWh=jUli-au1%(^cRs(Iv53ZWoT^Ck})n}N<8f5WT?nq^6MR|C|11$1&YEW?w0yk#dqR%jgW34jK{jo0d*w&cP#K-RS@OYQhAN&m!O$J|i>4V&1MDm8IElU!bp;W<surqwaN0dB2-U^FgERm}FDKwg;=X`<%EIdJ-z-r#gjZdhI)?rie+4W6vWSv2jtc>sisajT(6Xc*o)5$NubnsBm7YG_GgYQ%bqEY{I%fYbvyYYl9h%xO*k<W@ag)9P~8&SW|&nkev=Sa$!|C<7atd5v&N60+hZyKkoLyq=AL`TS%)Fj{+k^0NJm6w8PYihvERfcIYQBp_Y??KN(%UE}uB%IUm5968GsNQ+0ascR69o*iAmqZQqvpK*ITrm%JCITOqk<)GBaM+x!=_4g2|#o2VTR<;0ehS-yUe4JW)azyE@@x4JFlxvki-;fOM<vuCkH8YxI!jluG;z)t(#*c)QG4y<_<EVTmx)C86o58$Tlex7;Aw1M6X7H4H_eHV&aK#oul;FR0H!;tzE<0(&BQ0hLXixf&Gdw^9Z3qsHY4s|BT%5B1&xM9QeWe~>G?+-^3Ypv7+P0mDb39~sZi_Ouxb4zt;fMsZn17oIwV-2DFVselcjfdY7q>JQN?k7DG<&&`KOs4kG~2la)2T?Vo-n$vTWP(I&}>9D(grv{_`2rsxssYqG(kQgE5(FaHz9PZ9BbI12IMX>Q%P-Ms^@5!-DnU_8_4&fWR4Rbv2E`78iQkgAx)>YL5%~hB#CI@8(hQ(WkOP0K6$CLH5(pe=+^a;Q3~I(U|jxpG%>X=0mbWyY2q}*sV8zoN6C*FQd9vQ!aa^348w^zc?NWs`ku)kv`JYyFU26z1DKAui-PO~XljeDdrKO!p?x*E0N~j16gqU!XDDgBCe3lt<`gm=!9F1jIUA9{My04{D$Q#!7KTpAsrG^cBnoawlaws>X2TKV&;SI4UGmo0@T{w412)Z*TH%P(2ATEk&bfVEW|qt$m-0MwVNPU58{5V5nY4A4#~X2(n&`%~Z4^w=*zlwTH{i9KMRcP%cb?-+wli}o2P}`yRx;-PON)?T|E@XiODO~m6#c(TJs`8(8gV(~837gMG-orry_5>7huS*_A#QYnSU$=(&1h)@H6l@Ox$j0g$c$1p!a%L27{EsQTSd0$WuGRv7?8wrXC)xvCr43<5*F@OlZ$u<!RDhlW4adv$;Lldm9Dy@I12-5SsxZ!ye+d5@fRC@BmsftINnA|ix)GNP8<ZHEAP;U{>Qc6SbEb8$uZO)ujr;NTYUA|6TzO+<*AowPw?lC^{vL)S7si@6(yzm-eX3&yX?{-nT*nSWW!&L5sg|jwHliz+m-0HYbXf?Sj>9_W8t}nb5s&J5-1jn_RXGkp)EF{k#q#QbpvO3&CfIF^&(E>1loGNmqrzHxxxi5Pr8w1#I6ZYw#mCjg2B@0NGWW{&S<E!^4N(|CD%<#qlF-!s9dZ}*Ep4d8({x92MQBABW}`ww@YoW3|ljUxy85g6co}Su?*E%0m=l%Iyp07nG<Y@E2jArV-FlYCCNrRsdp*5OuaUv^Iw^y`K#o5m;?}2ag);=vrez%Wp!Q5s4vL?JnL0-Q@K|1`~XkdXd8Sl+_HbJ`7JDGmpT)DPT8$`IlyJ8c{%JuQ8vzI!ETcd(_9l*#srk$Gsl{_DFvuw$(AjB!|*MqWZ5&$$DW)mW}ebXF+2@@O1Z1q&L@(&7L?aS@!-z9KUM5vTM4)2fD+<h+<md<@<>yko_Ehg?+J3>FgHzJ4JopN)r5PfN0lebp|Ryf2~_=c5xWtmp`QLHRk7=_Pts#-in|#n^NPV|?U5Vu{84llwVMe2OXcMn(Oo^I2cc@?f$=H7QT>`kg*67uh<syARuZH`5bs@)a&a@6yN||uCXF_pL-v+e`6m{^jVnX?L^JRc1ve&>+9*#TGS<=me4<N@W`rj1dL==Uc)$QCJrdb^w>+Mx7KXQ>QrvOHK2ja2{`px-gYfp(xFa0n*hr$-`d+d|JR(fQOnM@X<(P?9LanSBCjcv+6KFA0LUj8xDSnJ(-5@F?S>mHln5Cu72n@>s!<T^JYZMaXzyctfvvqqz<V}sF;P4EwwTXlw1}{AE8HkcbwNJB#j&{q%KW07FUu1(-etD<?GVZOHzurY3v5D0PWg4=8rYg4Azu#B`yk{DGKFU6cIrf1<=SEBq)=otkB23Ct>3sfVtVrI@CrSh8gSb@CYZIl)axgK(o@PUX*9C+rN4eg#vIw&b@&}0%#7lS#x%tFRiL;#hIz0T8wE!L!Dp%#=5-jZ1pdVG=!Y3!%e^0D{lxJ%YmIEQSLro|w^&rU0%piI~Hq;%qVh1l-@rJ2Ror2Wx*P7o5ZDzZhF;;sK$Tu;k6V#VuN?wKa<Q>@o&WOoV5xBg8Q5m(*DFZ-~QlzYuT#7PF64G&&%@n2mi{@@*g;Kv^DTy>on-iiz?Q6uQ2zitw?H<<_B^N9))ax|QE9u<xkHPz7LKzzPQ~X14q;Q&%b;hd_O6lK&HG*b7(XA{`@?DR57mI-HNj-Th`)IDXuuYhb%0GCf=`;j3ZXcXno|WdRvLIbat~o^iB+eAckDoGES--viC-H(V&+=4O$l|w)vKa+%Cz;2+nBQKiKq%1#)iD_z=mIs4#HJE!OC&|hUSLurFH1f)rbxqY#5IZnwf?b<a@FhTIfd>g04(nb1eiPl(LA@Bo`k*tL#K6P)=DN^ZdI*55u_Gpm1LcG3(j#>+l^^_jq}DGDTBe`a_u5v+^v9elWNdVxSO$Zq1fb%%5}E8#PpE|$I8`71fxA0$P=?7>wL4o3Kb&ZG*Ay?HzMYfMODXO4zt>BiKTZn)ju(ZCulCS==dP9-hcN#Xg>kIatE}3HpISxQQiyJZ<Vd+hh0cynt4n%F8kPA<AT`F8dt0B{dvRQ*AKlkM*G9=TdG6*OGkT2iZsYJJ9%6wSdDaZm55Xmz3++NBLbJK{6<gi`(_-pXRhm+5XSluMEI-3Kb%wwT6W9gWqimsgV!1L2}*G$J=aq`839>rPW>VQlcd`E#-&6Gca`H0m>L#$)|n>jBQMSkkRxuAr)44B`6Imhk7U|)n?JHY#7yz4cB9tA|LG3{+@08cDz`UkIZBg<lfNV^b(a<i%7ud?PjX&v)X~)Bg3xfo(b_dJEsEyljyxrirLf~;v4!3sre@)o->yfJ(i2vBVog3dV_!Pxajy2!Ii!~if`km~-bPcc8)y1R0U55)N=51$t@=Ntl5iRT`UGs)3C`+|j4WGD8{qQ^3JE6>aB-PGCFLAyaGpmL<WM2|mFBl`yRwND%0C277Do5LTQpFyO+P;ly&<k*4W#Rmrvx=0$*5y0P+FEm>mYt;%-)>8#|K^n-hnEomt&a8ro2Nfta&CZQp(cx8`l`<c`_j#8eEI=SvSMd7Ab=PHeRc)1xsiwWsbDV!PPFNYSOaddj)Tk!0r}8#x+JQEKRg@{8A0%00O-1xr1`WEWlTT)LM=Y(Fv&aYS$p_#40mJB1?ln9G7?N$o4CfQ2zA)XuUB8F}B&$!hL*YfwG0(#1$}?{28$Ac^dMG%X4J>mUQU?yqK{Nbrg`IqbbbVA9&Pnc-9FQD?P>~QmkVftZ+$z4=<$@0^EZL)6n+@AiE|s7^%HHafskGhha53DGh@D3`eJg=;{d`RmxDLha?P_ohV<FUV0YzT4#c156kK&$p0ph53Ns+b}8Z_hJfGg-?9a#{`{D=p+`Tn3A2ZU#KiTb(`PPr>Tx2cj~kUe`h^%z{E5w_9GQbz0>g)=A*lgVI2I-upCV8>nqgUR4@YBm&x&r*-CM02$b`GADOQrx4T~t*3?GXz$PHPEwLiLQUUmqzVYavivf_X$2#ZVHrxrie_?5|~Xk7(yl)7l0O%jOHtj3MMvNXI*(-MkKgK@Cc^^=@dQ2VfnCVK2wo@H{`JbPI<N;c1=vaE2`=q-MV+>H?R9y@Ogax&TeL5exhgV$<|tFqI%B@s?c?v+NJ+->9;sIo~E#4VdS4nY!Dmy!%>nEe2a+m~WkQ_64TqosId&cQC=rS=|ej8wjsF-6Z)O$C>FRymLWkyYu_Ji~<Q_^)2&g1o?Lye`GMMro`B$P;6w9{9Z^cn1JEVGCc(D-H4%DH>0wE8$3oW3QaarjNDGb8<a$P;sN-7&dCp)ZsJ$tf@Vlnn~wU&mHX;y6lQqd3J40s;p(@ObZ~x99H*Q;WOk^sgue&{0p}lRA>$;r>FxL5f~HD+OqDQqcEQ;KDE+ni{K+7VJfSZSRu&I!2+)}##jb#HRc<rt`zrEGVBP(HJ9jMMTBpnL-tp{7R>Bg{{G$COQo35v1&Z8$uG_Rs%w9Qfmm0E&Ax7CpB8gfgF8q+Wq60b>IOx-YU5h>UOpI0CwEc6f3J=GYi_FG3B`#}@*3g~iI~}BvhFU~;*O|w`;PP1t+T46>Ko#1!(yLGt?31F8{HQ*i!_Ui8~QYKl1Twpf1ryQu6t}A89Yc7F3hfg|MQn0K6haPTtRQuyGZ+obMzV`K+}+ekE6}}HKPLn^<P?Oxc}SKwztrLBd-{R9$v=<P@ngnlfsMzpeb`AOZTPQMgvx{+!L}1!q~uR;vuE6RohpEgZqvN?|=ZH<~70oKrSraX)}mXpwJzg{}3j}=MsH9cm9!Is?3tuY)c-e*6HpsuB5)yV>>}IL}u?R99ii2S^F7B*2QaSW{He%83^!~zLoMs-O1&Sl)zkf*r*ANUVy0oy%9vqMQ2+`%;jCzJbJ+*Q!k+72!;4NqYu>%6!@ybCl>pj%#ZrUM>ZqI-bpnXWrdY40Aq$^eRaDPNDUAEQkxg0gToXhKs}-;M5zMcnx%g!ksthY!9@PVK%5@A=pW*~50YS#!cx|(%1_LVxmOu^g~;AhXX-X4(X;tu4!u1hn<+ZJAN`T$Kk97#-<Yk}S2TH*4-h^viP80(^#asX?h2m_E7g-NqA9ObPom*kRbNCB7hUxp8H;O;cG5&Qg*mK!rD);1bqG2bEHbI9>fRb`IdRDo{B>~a&6g;q_59Vn5Izxv2|W=CpCkp?0oA$AmHoQ}2{Fm&IY@~?+@m3srUjvdwSG4X90cV3?H1iyP!<z5Y1TXWc4npUJMUXPKiGMJ=I_2@-a_h-y|<31yDNFXx1{w#$?Mn__8^uKcMm|fs+B=jxUA$4q=s!4u8upQOcNm;reiXP_#R{_3FZ<b6SHDer5Y6`hHR4H4)SryGC30f#nwd8G6DQG_#3BalMn*097gcLd6PLlTx}&?U~VtrBPpIou4r*FqP+o;Tv*t6MTie^(^iWwaOuHBDdl}gc;0MaihSZst4mY2*;78&h5LjMg}w2vIRnkoJVe*x6VG(^h=9d2MSdVQYEPnUdA0OJGnB|>N!3Tz8z7g#nf!aK0*$lahUS-v7n$0ZwohDF7I7P3<)rK{WSk>>+!;Q*oJo>GmF+}m^;DXTEj--LuuW@a719fXEvX8E^+wevdRpKLDYUK=WXaZvHBWu-F1Y@F-1?TQ;k=T|e@;etowuCz0OQKgKHiw9i$vUuRqJoj9^5!RCs(xd9o8ZL`K&#znnbqih#=JKVlGa8<G#LfKvSV5X{l}G9Aa3k7gp`Nh6|Z~+D6UB9M@^aVke>+j6OXWuEk{%>-qoPuCZ`a;_k^>13874&;R7%mwWh=^Z9i@{K*;q$r=918UD$`4|({LQ*q~E{AwP?FY)&BMP4mm%VGb1AAUno#7_q5H+XK#SNB=v@8)wGzwmqWs}H}>d;jh^u`&F<9>%ZeVfo;PBzvpAXAjp$rHAvY;R`(6{2e~%Z&Yivt4@D>$nVDAb@$1;ufF?ty#L#zCT7e^vWIj9us_Tz!2kC5no@<sM{a+bxDp38v#*Cnq?zcYCX@OwqD~ZwnfWXXu%dgX0kvOL*Plxo5&^R(XH_ogWQfQUn)z=sh}=0Xx$R#L?v}Oum_^^h9^jKFGo5n=ewa<HmN&lp;UWsM+F<=qt~((to0)D?ShktJ$ogB%JGX7Z;sR<#Nw3V?Njr-9+cg`9x8=ty+Jdo`ZjZBFj&uHkvo)9<tsh>a67GE3w}<N9r_J&$(&~V-+3p3=vQ|eJ<M!dcxp~QCRMw8{v00r-!N<3U5#RI7=HcoiI3SbhvX~FCQDOy|(mY^<{Kc)&r-f)vh(>vHW5mQ#pyO|w`5F5iSFgt98N*Sf=zoNlzisNf_mU}1te@{!Z;Y?L@$ResE$oB@Kgi7=asAbr?e`@N=Yx;-9fx%H*xq@}ukAd({C3NgO82hRyI#$!SHp6Z=RfX_ig{Q5Fls;AiTyFWvb_+0&HQ_PNcTsYU#XkpzkBUoxsLZ=%6C3}eKyvA-=5FA`%lgNlh$q@h8G*Wcm{01G<(9Zd>%xkU4WiT+j-O4`<(@C@CPVg@%Wm90c^4pAgO5~3P=HD104ub?7ND^D;`7h*hffW@$c3N4ZR7)5$MR59`uq#etVcBk=jU=tIb>R1&^)|Q%~k&W1=C~Wdr-@wDJ}M$YA2a-ed_BJxvBI=!qMUK2zJ<F-XT`zfU=tp4`;S)_}wk8eR3oD<ukCeL_hz;ZEVeo6%<;>YDimF7tL^Y>yArAFWTyQ!H#&gY_TxpHHjb(cKI>^&$WGJKgD$yAVf%QjnX%=I!1=&U-qVnVK=XlU!ioB-e}gD};Oy^ND&Abh8#9TfSN}2N>l%mx$7x<zFOpLtu9?$v<9NLg;`e<NnuzFcP1kdz|EJ_|w}ql3tLMf;r4(*Q?<HP~dN+9y8hHl2k*^^Qnk3jFK-M&S=-9#iNdc2y!&+_nHt*V2977by|8L5Um8@cp=Y2dNnPbu*z>XzZoV$=%0DAA0eAoBxu%{<exRv2Z#@q2U?s9jCTRkKh3e|p1O1)b$S&(XnMx<Oaa1&wsCAbQ-(?Mb-e%wMy+a#OM3<x1jEBmaHLSdcmxKEe*@juW3r}PGfsdkjUc^<Edf9W`+bZ?`L9n7gNP^~c#I6X`@*rFOsW?R!$kb7l;^Bjw`yYslNBTHny}MMF;4%KWt$*5N|O2_#VyU|Om7D)5cG=<RGhXI*OBt+Y4H+UBL9IKv`%}TglY$XV^^Q~w?9C0=u7Ew2yruQ^*Cl7tzoNI*E)OX1(<L_<p5SkV9p3Agb43pg~|zz$`OBZ5#tD8X%HMP14-S$!bKRyzDUC5C4f+Z`R<5DwAX!kjv`>Z3%<XU=SVKk0i0>O@&sLJb0mY_kOhFgI4vt(i390c8y{H)sqgP(p1r2E@OGU+6m@L19bhNtd<Rh<<sK^Ap{*?_&=miZjf)dg%ul`|L+FW+nRHLr*WI8$RN9wW$Jz>dBk)V^`K=Z73Z|T;f#2UTgl-#`5hNUDmie7A%DK5GHANs_A2tHNQ3-*o`wDe0X}WfcPLAPqz?N~v;SwDIk}sOHl1r1gsb6`wKXf)P_9y^Oh(5Bk?sUy+0>Tt&uv0gOhBlMy7}k62bOX630)(R8RC+N9stv#^e0g-e4a{30*FUzX&3-rZZ|<;=r^1+T4<n*FeSjxNuw*^JV?B&Bror)16LNFhLwz-y`c@JtY%*9o<PA<ch?(zQRN~^IkzKvX&%oUdMuP;#=X`1QW(AhIHeTT!LWO~PZEGyG*ZPGE@j2ghyugkS0(d>pP7u5Z@iaC29R(IaVu=Sy=JRMzw4E<GxU8vV&@}l3Xh{5AL5JdlSt*vAv-q!l6<9cSZ#L-hFO7wxGUyD48*Z_1?Tm$Euy_XxCm*29ja`N(2?gg4K;hN_XeAd%pm@i+!%Q*|!(gBqNpRzhM4*=A-|QBJ3DE7_?jEJI^8^Jb8SZKg1s{eW`})4PeBl7)Tlrr_66@+noS<{Wa1A%xV#RVzn8VkuKgW7Jzq~<Tx9`h`&QvWuQL~yk;u?S*=iktd;EHK5>4uYM7I`mn%#8|ysSjO**UA(<YC_HKKBalv<I22k!j`i!8^wh2497xt8k{RAM8{VTE#CE5Bj;0m#?^)#Z5CsW8Oifx!El%B2C#M{X4}%Bal&SkCq1VFg+d;&M$|jC?_*mKLrrJw6G9}kg-hujB-3>U^Lg{%ewCy$+*yAIkjmPbR2G@ReGsoqTtcUojql)<HS{UyNm$LC$XS>UGbEWvyS&F(Z>gtpviuQ(Qkm+DHRK;OXJBO|yR3kg44TH8S_TR3c%^o;(rvBHAHBjcGcS&XW`<e0{O!Rs`}{RnY`;Ro_Ozw`P7V1WW?$EmiJ8o*RY0A;B4>AL?prB>I{FS}Oi~++$;6+cEfLUJXrw!DQL5m{frLWp@7QNGvvK1}$jr0p;>=uYewgwKw`@&$%^vdYy~zpqM<f$R46d_Chhwe}(XJuJx0J<HqDYHM-hzgeNW{(lP4tafVXzN!Z|fHym%OHLx!(+4-NbM9MTDd`9rD>mhpL(8$m}OAZ2`11xO4-HHCuRdFJ9G?#Juls;jEketo)soHZ2$H)lc8<Gj1(2Z$DR}Z_75bH0BD#d*|4q8&&Ju%_k?WfBPF(`iD{SaKRk4d_O)^=Hav$aJubtFx5{o$^Yd=-tq?@7EY-u@^aFrTCXONyjyWOQPLruv)s#*Bpz3%wS(K2iOf=9(z7KMY-ucOfgIL*$mx)km8w~YW?E&-u90)lniNbcO0-}l#xp+!x*G!&H@cOXoH5}KB+F4CO9Jc{_{m}I>8Y<D?ld<yKLOx((^~K0U9-u4ce|IXw3z?#oMgsc7eCPtEbq<#^#|m=UrK{{&CTs34>-rh^^I=Ktfl;AC8QAgKdu(;9=p14$xO4Z^1_l?{@!Kf$IN1~Nm^;WmMBW;mEIz#d%+XI<$`LisNh_D-ICe-n8SSKCAVU?mL<1wo!qL??1ZFerbqSs)I6+y3#pxTEhY1g92a%jKI0BNkoGbVH8zN&!Kid3?Lk^gv-|P`^)e*qE9#ONFn3TDc<VL-vj=mc6IcA^J(&NCzf(qE;pmGmMqhh7`rb42@@nYy>!Fvw{J87iG48@USa2@}UF_(K^>WZ%e8kBSN7^BWn-PbA*aqG8?x3UVcefsK(>FfQ{*^DI3^j0`Ki_D}hqU8V|3bgbYP&C3;>nevM%P#F_PhhNHnHVzcBhhX<MLE|97!>%hhwmdLvbk&ag%b`B30}nW9;`Tc{VdCCrK`n<22Fr87wf_ArwnyK-+F;97@X6z@7=Lz~qW4u?h*uWW^C`%{I~GU+b$4o$TmH!7!(sSc9q|#VJZSx45!5x<=>b69G105UT|XXCs|i>WSvV9Zb7Alz+DQ7emcBrkcl1DZXLLszcuiA5wo#DRwjGEnnok_mnTx#WiTek;Qpx)#hi`icZ|Dbvr(kyQm`RGMvbhuU3EPdAY{32+Rh$p}0OCepct7E6bfM4UP5QJ6R*@=NSt?`{1hdGpTthX^QR<Z-18N0eAIrfV?To3+aG6GSLPKFMYbg9F;d#qC-ykC^DWxo1npn!F3fLO8H$HX=Owy9@{>yclZ>NTkJ9ANDzm$v^bS>qROgiTEt&@zYA7j+w7?+JulG&N38Ub*`d_0R&N(5L69AukH~#7$MT3C>sR3hK4>_wj&<@)(&&vGXNLoNVnX@gy$36XOBc7E;5TwC;mLcFv&sSH^Qt5k-@cWZedNalXzkT+_L(V-iptC}9sL<ZV9RIKvHK}YrP6-kt3i~**;eT@>34+84~@lRe!3dc^z(qIE-+(<u<4Pyt}KJ9zJ25~zo_YedBovwETOmx8(-mas^Gj`Evl=!Old7dZ&6%-k5~rkGJRrpyQ;{nS?3aQhF-?f;z~CSjrAIfn*BmQm+Z1Wx-~Lz!>;{oz@!^EO15fUnh~zAWpyUF@DKRl!dbOepefWURxuBuzFbYS*pCa-9CO4WP##F8OBl$VtnPD^I~sNI5%wSFx)1!7SSpQDDTT8BOKXhBRdr^!CZ4yq!M_r?-7Ld7QzyT5v5eowG)~Lv@&~clmI0@ve@N*7A>=|~U=B3Y$A#SlM&PIld^D=EJE)mpUx8X5RSj+KGU>oc^0|^~;(H&_2AY_2Q45uAd?>VX93@GVQnt75_QXlJn7=PR{U~Dqb8zLtMjNh!RAh3=26KE8URdv%qEEKDRjZ%gck~T2BV3A4g>;ma1{KjYX6swDlU<a;nw)Ik)cx;b-(pu|hjtVj1^T#PB`p%nX&?z9-#XyOU7a8}%%31c`bO`{)cz)qI#Pc))2_CD*2rPg7jxwpbmv`pvvP?X|B6jO1M8ykTX4HD*^70VAbzOZMZV*9!3ikL|9Fq}x3(8anyQ;NyV+i}@36h-j7u+a^gFui$%GC1ZEL*^wlZI>8R6|0-bqmk(<$V|#X-t*i|vIu#`P=D3xS2UwFa}jh~60OH<bmAks^o=XV`1kP(qXOjJl%Pn(cY(f06&h9f%V~u}cmRTd3#_t~ou!qhz?Dq<Vb|J5g%f2lLc%=veERIb4$~uZg3FSjy%7Iq^|jFLj*u?79#G)z)>tW6f1I^*jyrCLCz4Fjq`%Z>(fa1eyn$`bDKlnLA8;iRVyCtiltqNk(BzRq7@414NZvC2Zr&i!Q?+b?Mk=R|PsmD`Cp##=vb7u_1D5Hnt(mKDjIBA_2{3dK1wxv#&nd+aXzx)dVH1zX12zpR=0y^n(EHrenrHJg+GF0+XGaWQq(5Bjp^2o;p^!QNr`Egg{Gi<aF0kPTFhY0NqJWvvA{VTJ@7AVLC?RJ~5AxKvseEP>Q=qW2QYDyr`E6Bqc)YCr0VRDzMimXC=C0nsucBP@T&8i6T8<%S&T>;5y#u#<*}jlFwanH0VT(3L1fcR7Qp0Y-w>7ki5c}1E<rv1e^t%0K9-1j~sF6Mj`QQQ#|Ft0-#2=2f&sg7#WN44!&$hHMKqtLb+P>9HbXl_jzSbKFX!wOrubZ*hz5{&uWhzDNRctZ&Uw4F6#ejzEDf0H>4tN-MX06RBWIJ-{bq5EWD1&lTx>75Jbvrq`CdhU|`DLuxczYmbPr)F8vhZH>}oO)W?bPapHG(QF&ts5Z_kZM?I!Z1I3SIX;o;S$@VFWkEM+=Zy&wVe)AEGSq0tNZm&{r*u0%$qVFv4&uto)5sQ{<sBbd&1*}1Xp7o~J(5#p_`d#F6%`K(H;T@A~Z7ejr7D<p<7-ZGO$g^-qeQz;2kq}m&E-@D0VQamW5a!=29b<b*S%L4iU4ONWma5_ZqV2?X?%-nAtJY7Bf3S|5zy3`WBVSm%uVa=)rZT*0@IG#}1s8+&S7j<&Mk@-J<GLzo4uE%*DvJPu7N?Ssww0+A3Ty@lQZpvMrcuf7n1oY#kL+Lxi#O)t-_9}?0#F2NX_zhC`BGWS#>6;81!pNrqdeZ|QW|z_3NGpfrAn;0d5wCAYu(GpZE8G_YB)9=@cckCiW-F-()KOUJmC`DzVVE_PMLE_Dk(xb?BDwG(8Dh}=w8!CeN`AWlKs@kPSQi<mbYTID9ntL6dbn}8E*&LDmZ2(#v|jjMI{BhlS$R1@~8`Q3Hi{8w1@bipWB&HvX+FTwk~?Q@`{7@+c1aA3cDCk5sVrPJ`rU60grJ(!@HoWT49%UbR{FiC!HC>(IB*$b}!_->d2}WsE@&J3-@M9vg^RT7FNBu@aI0%7Or>lh&#j8eGt{cC&#cThe;+Hc%J4!H@IG8z9F9KP1Kof%gPN--BT_%I!RG+KIYGdnmg9uYez>1Vuyo~ULuVIvavDg4-ukVs)A^rm%iy>9fyIFyLlZEbwB}NR8>UE=u+SNL|Dxph8P{8EDWQ?Q;G6&3oTZEY?IBpicz7_8p)wWa9H@>j+Mar6*}fDtdz&>i1t>)f8f%_g{l62COk3o%oHMsYi`q$xgbw9BJAlN6HyO}hET-Lk42(k^k>#}7e?<t`POsgnhOkHHdij&T>0qEkm&}A&iuGt*+SCt=hhiA-x0BOh%xipKAW`Pi$odce+bPY0(i$Ia-AzT=>-gZu{)euSDRefuGnsE5lQ<4L#f<Nn&toQQ^N+c-ffI-qLSuqV(r$EmObAJ|NY+|8mD}(>HE-KLzv(O*$s<;DCS1=wPe4vLawqSfR8E|BS=YP5JE>HY0kE~^)l0xfO2UO#Tt|$ocU$Ev^0pv7ox=?sk);}cm}bqV$<m^%C{w6>L_|^E3HS+;v`<=fyoNnVF_4NCb+LK8l3;zu0%$qtG%buQSSzi%D_#j@UB!cQRSosH#}^k0!wvY_DE03=qU?OHp!U8yufsx>vwsSu``Ec?(Zun*U2tLmnQ8UI_t{GNiNC-sqTz9GnrC$KBQE-+bWgzH5h0&5O%D&8V2bbuL}S9<~Ks=-E-p~3{yQ@pKwse{QLv-{nB+spR^yaex4WyYgk3NsGv;0`q!lSp{&5->UkF^E;9I)<|Kw0jq4Yz7jbUMGDoGN#T?jTur!*hZqjT;TZ}80s$?c+t#KB?Q=zbTddO^Y@YU~R-H4e^!fbi=&FqK#vpIZ^j-<=>teP;&7V=uO&c;HF#)OXR8vXa?JP|O|8cid9SNZQ`ZcmYD+1`=bKg=}$(SEq)8`WJ>nAmnI=KB%k308;}s5iyuyd9??x98Pwu~_9$<$1Ig*+Y;$TP}auX19ZDJ$zMM96-E8aJ&^vw%+|qbQ#ydQC2<R$JK$k5lk*&DITu{leO|jB1ZeAU>wwug?6d4aD?9!Mw`G88a{CwWnT9U0(keD&F##;$!08DY-NnAnTt7B3VW8KB$%vPa`uTSvCCDwxIv>XlN2qM(Y(sD$t!wIAiX9vTZ$ijOt&PP-WWEj$6(wIv<WMFjK@}Wv3lk9oH0vNXQK2^e_;~LGq^9qgo1vbi1@kGfdh(3x=7Ks@wN^hK60UnFn2|8F~!{u^B#m~Pw}C3HS0QR>c;1IDWp+xeW~|XJ)OskFtP@F-sN~b1$vYsv8thPYYu$Ip2=9E<B#g;d4oJ<BtJ#3_Kn5pqEOV!_1VPEWQ4r57%=TMOpXwv=nIbODK~Zu@+&>Z1H48sQPy#KHGS>`yZL5T4GGDjAubl{nfbr}x{4!6Rlic4AUz&mfeJ=j-|nCVDJ+Z#XGU!~<eT*o6}cJptuceMn)%kl!>|O2)|Xu~W4Ek6BKTGj(m%Twd3w#XBe*#$5F&lbqtEti19mQA4jfmebc9jf*r7-KicqDCa*bnoxW$tLdqw0SA+DWKgjWZ2v8Hzi(?v4xw}<Ka<LFErL-`DaWF!b@B84)|%pQC&a$b0Db4wD@_{_UP?btnUtzIWJ_0MTv@0qirsI;r+X$odB)})$1gDNERw`hvq6RfS`_d%?|HJRv9Y&jyY|7Z2d$Hou~GCkL31@s?c!vORWPWY!0w&i*Nu;+7eiNaK#IYj)}ysl$}g)Ksow>&Tm=TrQs{yjCy;8~dl|8B?RyOrtCsnLy{&D9lSa6F(Kt1@#DHsFD`5O&LO0P`lk;G{kC$vp5raJTopvgb}%i!}YGOCjUOnCr%?x$$8Vdw{)bnP+U;@2ZhrzZ#9w5JaGbFsW4l13G{yE}~du6gcWFJtSt0&E)#v#Z6<_1EL+^82bxcOL})d?!8RNJV>RDTo>Dmzg-?Ubwvl=jQgi7g7gv4rnk3~1w)%)P(#tNOlE(F&<!-?^uT)2Ag^0an@Fk#tNs@>Lg*~q7^Z8Y&WWmU0>}swP{&|a*Ca_p16{Mi;&)Hc`!=}^C3A<+fjQor(1TiOE+No0Ez<`Xa~6yw<sckHjGmF)7j+Xs;gLgz&R7jdgwV;!)b$Vak-=h4Gy?iP!7>y{t<;ltVQHl1cP(>mXiy<&N8{wgSf&(KUaVF^Mv9^agR~(JdH$O>Mtp%cyf8av$9Lr)Mc_yuT#mGf9ci$DfAjf~H$4r}^B~ovrOs>Q(nxp+O?wnTS@(x#m^jL|QI|p26OlGglFCyi+9Gju#Aj|FCn7uMdGZ^C<n;W%P2P($Lu*&mmD+hQ6OK41reVcA%7&`6;)ap5B7J#LWZf-tX|!%?v1SQSXOtWk4I_y~PppP?#A^mQ5GhQ+%pTQJg|xr>qu@++oEdE`;}7d$@(jEX?G>ct&TH&U78zkCL2tNfVX|(OmuH(Fvkz5Ph&iw6tn!Ul`3lybW84ug5Tpw)&Q(3J#L^vj$K=74yex>uz1~riRlSNj#kalO2l#c8@%EB#IMhFDBrBI47$O;3YtL9Ex}i+n?ZJjTcPsZoP5{4a@zgoQ?|c|>W};@u%K+-As>28HkU6!zlZxCKS>|0-<Xc;gVE&c2ROH!{qXxdosmN-yI~%!;_uEPJQ0WdF1TCHk$?+Y8<n%frnL<J0B(oP9gByWTw_v6vTajfHCwW~}Y2zas3!T8p2f|BGCJ$q<3>)j_4povXX}aLcnp^#*YM1~0uPJ~obet{k2%winPn*hJ$&sG0^nMjU5Aggp$J`tG)Rt)DNX($tdyBYpL1L0O9R;EV(WZ~xONtFI#onmC(R{9CZRz3iEGID=E6T+f2%CH6Kk<c@gnKcfWR3xoa6W^4MVBnhiV@^;Cjm1BI21h#Spk4^@mQRL#o`!3PDf>4R;Wzc0R<l&_;$OfA{)Z7HSUr{S1gE%Lvj25=EiaU_v6?j9a0UDUaP=6cnc8CxkFuO&!L1BdtsoS!B&dq9<wef9>J9yy>^=yJZ^l!tm|gPf;H}gOs(@kavit<gxf~2ID(<zuyQ@sZ+*0C{(kmzBC{?@NG89JRyR07dGVA%T{n8A9uf2Sf?U@E@We{}t)ff~8^SL^E$YV%C_kFjqOwBFdSidKj(~5}q8^&^Og2iyRfS7;z^enJl-`i6P2W*0bc8`Pn28sMK*PnWZcktnFWvX*t6lvYNSxAQv(IYI-6BBjBCPe~-HcI~>q9E?9BIFotfNt5dwMLzmVmAL{Lo{;><H3T4a$DluQN1UFm4FKAI21Q7BJaWk%l|CNY_=jmH)Ej@8sl!TaP~jmTvRBmC<jugawy;7j6ui<(T~B>BdEHGTkt!4v9`2IwOK)nqXTRk{Cb$y)=vXn(J_XOvxTn>@K)PUj2E)d(8csaex!6oM9UUMg@zkw8<t|dZp1?q^hfBL4~~AVjt4Q&M<FDZpFHbgt-xBFnQ#+*dMQ&Q7Oz3<Wjv0X7ntO5I5fABRcc0qo<wCCX&dtirxwZh3C<W<CMW~WOJ#arMP%W<6_n+r)$lnPtK2ei{DgkZ=LO3Y{+B(lat0d1XLx(e6)agoada1#dC{0T#gU?F0Gvtp5zGBbW!8E&|8yZFqwc6wI-~Zq^yUHgE==yK2O<6mc$YkBNY0h=^H1;ptBfj@8Ga(CQ0?Oa<Q{rshsX-_7vv1G7>$Qi|?vkB48B>g@}m9q=p0ma*avq{_9AcQYdd~Zf_Vv4AnCVqKJQYzz?YYUZ0x6Qa33{KXszEMoY<n*dsa+m8xb{$~u4@OyhGpFAl4WmQN6Poa&i>pd*-4l_D@dK_XClNz*f~K;bFMQG^=QTSjupYTD9H>>M){Ik4YwWpq(DJkVBf<SE*#n9kNtA=n^td!BMkg}Zj6O$ULz$PMV11s3_V?&GT8K{39@tWA^4UTTQBVl|MB2Bk?e(k!&4KF>I)<AOiJ6P4GkK97=J`+y_d@d!r_|FW~`MDCsuVko9qnf4-Gkt-G$n=`i@oA|@}$A9$u1r@xjM%yvJ>0clUlvWZ^bTE28PXJfla04f5g-=-!MLk<5X?9!Yn0OcTo*6!osate`0F<`yZPEArOZ5GmYaq5#TE_F!e)AZ7Yn}At28Q4E??DuFuObQ{0x-ky*W!1E$G-*RW5oU8jUv{EP-EYfi5}`QBgI0@FT+i5tpw%*0yeTzTfg+07u$sXnekjbwa<3Q<r%Gw8VvQ9_*`&Cp(u8)w^KMZ@p6T4ax2`4XtK|k40|#C&R8|-G;s;+%RFN)t?$a`_%Ye2694Y`Jci5;b%AJI8~*+aUtaNZhZ|<2_&K7!o96P^R`FAs4g$sJUiCa;=N~Xfbrv-`M{}0@EXF#Yf@cp(@&^RHV`g2GClV;{DC|7TwJIf_5Gi)3cSGp)BFy+??Jt%6P^)8M@>0j&iE54%7=?8or5|0*6ONkl<~wm_BeabzRSd?hFetgP(d2Mfa-Vm9FxiQ!>pEnFfyB8?xc+HV42z(Q_4ilNBq4v~)VCBQU4l-&${sKRlk9D=Kl%RKBk|tg`f1GZXT~MTiqT81Ugx-7BS0a>H4z&%D%lZ9gIlHd>nyRHWWp`=e2qC2Wag^F@!sHVgH`|3SYau$Tu0$nup_UHvSq3EB57la#x}GN+%ZXEs7I5MhT;JFfiMWnFs8~L!85A*bzEQr7QXk&)e58dK8Z5RiZcT0A*0*cOX8A%n}cvgINul@8uhVJ*BGFdHpfRWx3wiM*T~C=J@-(BM)j_Ve?O@z^({g%*4c0eow(psz!X2N>zXduCm}xIwYSf_A3u3<*~a>6o<7BSK?^^kN>KlP8^hZ%yv<@ohqsIe-_C!t!my*7A%v56n78U%o(gJc7A$vs3&Ox~Kr#^D=EyzZcd#BJFtCA(J}znzl6!-Nsk`kABu~wv4(GSNW%7GL`yo?kE~2_NCbP9689<R(J-lRC@ZcT+^_EZi&0-%x%%a~HL4;iXXip`&-gJs^)1NqK57|Nf(N{Qvuv~A-oNRVFfzl~Ltk|exXV8AGb3IL9kJ+epZ@JsIN_vTqa``6qgLpinw&8->>oU!SIi0j#la8^4W!r0eX5+HVr_OXx2;FixpvV*#<5LD{o0&o(Gk}Scq^dsZtHkJp3j&P_e|KEK<&WBKBtvicw+=@9dSO=GZ{KRiKe;l(le7{U8S+M%zK<T)*eU-s;rLI1Y07EmNGL&s*lFpaa0bRo1J51cKm;h)#`w2JSR3kuQt$C-ssIMjGjQ*$T-dP_)e>$y!R~&cycI{l^i=5<%6uew82j0o!eS=$;SHv>%xoDoLG3{xDS``-q1S=h5fTMqAlCOgc0b#Uob%`~u_W+M3B&vhN(y9@*FEfc$8@3V>-|x89*&6&WLGZ#gyOP&{a&5j0W(qN-XH7Vn}^Z=F29Fms@{6Pz-f!$rG3!#WMMfma|@Xi5NB9kGxX5GM9$RJ<_Z&WsqF$jGqi+oY$%Q!*p)CIJsEGpca_ZIPV>B|-W_cdvS&e^=AAmTu>I=DSr*+GK=8AksQ8bG>(~%0WN5bKp4U$&`9X1<%mu|bl$;S*O!3phq^*9h!KhP~hU-3z+?BSJ!X{pw%$P{rZ54qf;Vx;sxH|oK8rB1=JqIIw+rzjRJ0w@<vDGTCerg1<50oL*ra>CBR`f~+=;~Rr#!K~z)JXK-w9w=uhBcR07dxS%TEwx4vU3o|<1JIVx9w)7<3z`Z-V|6cOb5Q@h_`U1YxTx(FarTlS@?si`j*${En%u}BXQ(|L~|u=emfmu%Uu|G7rkW;*>jmI1fLC>v>{%`4NPYR2PpxXUb?e2pBUI4=L%J0|2-|a-!h#W*!+*m8#$-+TF!*tYmgjj;{*E@^=o1hDi$<$j5AcW(LD85Ogf)I1~n)Xo*!9+ZK)ISRvYtdAGNNfaQykEe`@L)a=M24xu<9Ty)&vxUV&D7Q0<Yms048$qWbhF?kM0~5TYCA>?5@V=TSfya?Mxj;hn?2#xHDOVK#cg@W!=#Y(&?R(-wcDTof6o*0FH)WES|DOOh0KbcEqawJFHN#9}(%X?Vm}KPuG-vdu90mWwchPvq#DdJdFsW__2*1Tlb7!6kkq&YN;A+#W||2lHUv#+8K4vL9sDk6y?LPScc1j%sc8=@`iML!qQ&>3<rZu-l`5BGRXaAYoV=I}}73A6Tg8jS?x8lY;B}*N6Yv0)`m?8AOzcZjEz$9vV<&L*OaoPsvQca@VpnJs0B+c~ZYG)T<|29(OXDC|G7~zMOa^)f0yBvCT2{nYLr8HjpJ#Br_2y?4$)V0)E5N_Q+-y_HadLXtAPz5QXAGS)x#Y`HnoQ)|zoa%`6lfP%m?Av|37CeJSzlG}cwB!!yl@6!OIgaTzI&uN@NhAB-^@***?9Y@+i~4U!s$Y718HAs=NR+E*)sW?ps*qEd7<*g94fiSvmACwD<)gHsymn^EsN<V+nTds!JSBoqQE#8nJ8Srph3I}m~=QvsO$MZByMWFSsD0KIvl{KyCj66S?g3w}MMHi~eeL@gvQ=?l_9RA={VnEdM$@IxY=AH(!Wf$N@ge!WD``PqsOp=P7gGx5O>=#5+&!{cH#LsFM00+qVLyj-G2Ax&*~=;Kf8L~#}T)U;u72&ap+2o!IN8vFxA0g7FcC8FrHur!tc(QhPkjSY6F8>*XgIdRHiyHI)eGe}yE<r?cGh|9S8LlX-jWzLg{Yr_VV`|r4`dP`hq_9kzNI+5^1noHur9n*AmnEmF<%n^lTr{o=QZ(n&Ir4h$G3D<tX__<EVZ^0P+y*tttPsm3K(PFqs13PiZu?bUtR$q_Op!KJ2Nj!cxA!#ZsMbyhNu|`m2#KrrczojW*y!nI#oFWfJUnZC+U`K6|HuO6Y)}ufx7Jjr4)iM7Zk>j<ic4k$o3Q3<2I06NU#YfH^tUnodzZGc8RV*}<>Lo6@rf#l4hb#(LqNtaL%RW~H3)-UzTr_4DDKQP(`69*)e;(gPUBz~>{c#a@1KWq>AI)t-^8Q)LrtF4qVbC2(CI`%GNnR61RFv^iu~t}9{@MoaNU~aT#3Saw>kGsq;&7mpas6AiSWaOwfFeiffNV4&El-#;r`V!0*Kqs#JKFqtpu&bDBnSMC{JU<S`hx0S7RQU)ftXK#b!0|BLr%?y8G(Z}m-?W(Xz)@kmK790lSy6??g)PNRMz4}h%rajpE5xpNG+v|#R5minRyB<5#fACdI2%5Xc_L#cp@8X#LGqOvq$(9jroa|LQ<2#R0g#$5fH+OzR{`?R5$>{F+evD>j=mkfgONEC}3dkf=VcylcOy|qskK<oi6%Vf_;(5{uC+^gF30Kw^_EIrX;*Qp-<XI6;hkPn?<Y2Z7rXP%<6xw`OVN$TVu*7PPRYb`n=B)ufja_7<SLN6auzQSKLPB$e~0&PhBm`9_z`DNIzIBFkLTPVbI>(ONmaRhSmrb;bi2DS4J{|+38jKEtXy!avg&d*vW*5v!1+f1W?Bm+zKPb=j-+d?BRg8ASqO0^$B3nNV_Nib9e%tub{+JqY_u|Q<d<p)}lA-R!Ot46_a-8oaq=8x7Ev4qpCRBPDU3yNy(Hc(<!)tOLTM1P?t-OS!>X&wFzt47=rt8l6v^d3xwn2(0>Si1F)qq3c^t@$Rk(ar$%>LeZId2i)_Gbi262lenyp`Zu0=bivbrRL@Em+U!VkqIH><VMmMc~T%1~)X|d-M=emR}I$U`R^=NXf89TwXFB3eO5L{$y<2M3}2GjP&lwa?P;SilmkGZTPNSQYUPEJn7$%QBwVo<B2w`>S>Jg^?+;;;q_1ojgWw@C*De2px5rP0D3d@R3yo7sM$w06#E*UhOj*A~xX>k&M89vg=j8ElXys}fhwS{WqQZ#F(~9<#Xu*Zl21s9YN|b5R@dsq9f*MTDFo1!?&wH3&WVtZAom&L!cjv(UuIcEUbW-(w=-R2JSMMI@Mw6Fp|CLJUKRQg3^k)PzL7T8JPZ-G$RMiG@e8AM2hU+~_DRGG1bRoMmprnnPyYwBE0%nRV1e|J7Ty&rfV|!<7+ext_cZazN!0C|MT<I!Q?fw%#G&#T*)GO4g$*N5<)q(CG&<<pAp>KdpYh)><G4{c}(q8|Re}o3X=Y$n+BO>)=+mfcVu{drG2c=e+CcTaG*UzhR+kxf}ua8LqsNQZcA2=d|<v^zo-SUeva$=eA~NeYEVY*T*$x0@9nyF4BTSTTdj_o7k+t#x&K^VMzWVdtq4(%({mYz3I%YH*)`H9vDw!KXQpa+Cn|?Zp7LD^LE2Lanb(38wP5utV!;+x5^$%D{hIl8T#$5(pgV~cZ;H6R(cF|>Y@Q1A%uR<41E{@-v}3$(l3_mA?|&<<1OE<N;n<5nyTwhXnPS7t~&?GArkQYigX1CG0((=HHUldS+*gTfLLOp5>-RvS)ANV15fTLTZ*v|I?+=TKb=kUUE-dzDd(yd+0RZ0i#-C?^|zc7dC_85V4>Et4AFb?Jk|$?m61Y-XHKLzB-U6azX_506eM=m$G6`!T;YO<Gv9I46r9HCKVL#nV*Jy0aV+&Br&*{=M%85<f}*@Ik@9QkxCviZ!Q`$U_%0a<d5YtXT$`u`P$Y{8m&F|tl6vD=VFBxX_JU}vcO<)%K_xtm+TsZph7=bi#bB!X$&evR?JZfQZ?t3Pol_5Nuan9Wg#EsWT9E+=8;tzBV<e1-EQq#?!1VzlAVU^JIWm9^^u4pV(Q34b-3f-2=v_o`UJ~OiPO5<O3im|_5zJ?^`?%047?J8Jh8<f$xd;wsCFs`Y5h2+!q2>DAz#-`ds|_)LNSx}qLRa<_yB4y^Et6?gUAlT(XN90Tt5oK+qebM}bu1mAy#qb(ngb2&dn@~F?GCmI!^BnWi5SJ_KVT@!6W@*?1L4jsAohx~0;6!1N%=1?sSjzZ4#0e1Xfc?WOYj&a?Ces{&uzLL6cx08#fs%~qhClmvH^o68Rp#x;G=(N!AsRQx>Q!W>9Y9094sqVAtIPM`TW)+;%%;I>Y~&uF*dHH=8+HMn@$A>fiPXlWHw|;#2yg28;2R5sq5x7=d1%54C)wN!KyQVnIQ6%jz5_k@eKKtn1o53h!(`u1jUlU*qYGEq2CzCeloePNCHNuw;*N17cU+A6;W&`;!C5=gQ1!0t$cg2&P-hJq%qIBaC61Gu{&-le;cIAyCOm$^V%s$rI#(B!{S%j1x_~I#%6BH_|L3v*UmvHhGy{?)v&SX>bOiuG7K-%N?d}p+8e709KVb!BKueRYWCZ;8#Ts93EIe6%t$*XUQ!oTF`?3|-Nyl+EhbL!&#u*>z)`$3QWC-aa<oa@Q<5hA0EZ8M(K_@x&W`m8PhpWwLK+cGh?YE<QM5*43pIrlQq~I-sZ$GpN7@lO!a84KUjlfNBq9f(8Z}y_G_2U~XvI!Jg#cLjSzeXIMZrs)BN;t0OgeX{3GGfy?3i3|PSm89be|Hn+OX}5=1s;Lgcly=$sJsNszaXxN=OIkLJ=F3lSv$iy3OB5dJys|$|V#u>LihKn*Y@!?>IJuT9qJkKAU7z=SmesPP^h<2yc!x_Cy?Y<f0G5je)IX-m9YttjPQuVfUpz{N)c7H+TfA0I}6$*eCX93o97sI)93}W8$kd8tSR~L3C+aS`$b&DWp?RNgFTqx{(R}Q{J3xeg3Zx$43^rqxEq50Y;s5f_Sbw+=r<%$Q<=5La&a^J|1XH_(pZD#z}G7|09upG@D13#4z)upwHSnxTz;})#8ZzhD%c2A#oDACF<qs$;mFTR>H38Gj&(+e{X|%8St1}eLCGxrAwD?dXRtmLz5cHpKg;H<egXo6lAdkt)wQ+NliUZ^%(Z@38a28O*N3<B+?!`DbZrGM2<74sgi1raIhL4QZcmFd)M!E3{PYe<1(m`tP-U`cPMd2NQtjIQ#Lg&8FAR{B!U1pc-q<9vs8Kgy(p^;a%rwfC!+h02kU_oZAQH)R#$7Be%h&$&$|&^_jm><7=uVc_OZA!E@?hcNHE1VMMDtzE0YihNiuVZ-Jh{-T17WG?$zw1J)(V<aE94vgy;zV5tP<ymia?sFni{pSC&v_gOCKmc74b6OyYNx=0q5d%*-<2d>CXObKR>yhoI_OOAIr_iU?%*UPhda#GcN4mtBPL?Hs4_`FdCntH!@HH?x^-hh&f|VvZD;Oi<c;M)b$fk-848z!@=L2nD=Oa@d1XU8ZyDt_HPJ_>>B}2>W`2hECLBRr#95J%)y0nA57dZ@N<>-Nkl96pPDc1w0Jo)G|W-BhBw}A^LH1NdP<&U`~YabIQ+X`J!k0%p18!5p%Mvi@n?@+~x(erKlz1#QyN*8OmV2`n^*`r-ChInIvI@t4%N2y3p!%+dd1bj<#`4m?M>?3$Me+4eziE$bj{<eIK`CNS8)U-J(4l5qY%|a30xs;b%#}8H}<zu^$>);~M=$t@6i4Oh8R>`1_2|`e@!Re(*BTkYXRlG~RnPcxwJ9QD^+Qt$B(=i+%2Ic0DJbCobfL@g!S7KmynEaWtfBy^&E5IR}>+3%Ynk0R7U`L+eL+Q8C7wU`iH-qG^Y^{-#^tCCdu{8w2qeEu;E+0f)W1N;YLp1brVn6}m9!@r;rC0>Q~JMgSt8`T2g2i+@d!xU9?JWo&AUf_l!S2Ip9SpIEc)BC%fqx8e{{sh#R?#XZtC^Mv_SPwlRrdVq1JdYSf?8>77QOJ92x7q#$s2<~QqDlX^jW2Eq$$~mz<PfwS6YoL8yO6=izJd+1jKMZKOARw4{I;uZm8B!~w;L#HrlF$p4S?kE^>I}^;L9c)~k~7h>6N|b8DraV0tH@g70MgYCR-j7aM<h$L5FHgG?4u66vpG$^6jJz$f2R2j92yFIr%;|#`}bJ-7M0YUF)qX0PRzD?6=(x$(y!BJp1gw+IArUqSHQK?56<W!of@`gmhc+kLVeKhRUeGHzv>imG5E13U>0}tGh=gTIGGRtn){8YRknr>25Z|W3!b50FMjvIbcGw~2+T}0rvDIWl8{w8XHKzA{It)XA8}6KfG*vPInC|_7s(_{iN>)(V#d<!{yf7^WauSbglC2;>bmuY`b9qg+fQ%isU(Gjt|t>wwIZvBQ3+j%$NfL_v1*~r;?ODoQ(t(Rs>^!IIIT`o16jsLbu8aKO+}j~2T?jkj9tu8tWUJ8)|O#2N5y51LWOZ+g^`9Qtn|H@scPW9o~Bw&Q(i;dlMP#^@G1IaRgmWpB2G{VJBq-g%X=BLa=urjT#7i>Ama(hQJB@h?=8j46<2BJh5+2&=B}y3l6)R<%`v(;cO}hT&jx0HQ^yN&WS=6Od}m?+9AE05Mdo6X)f;RXzo}*PHWN=nJY9H+_~Vx8Xu@Q;`*#N1UZ8)2V0x?r8xU*mo#+QQ60z9q8JmhM2J3z3A7UyY`;z)i7j*pWGTs3IuF!u&T6J6;Tn}=@9v69^1Z*_t*4}xuQ=>MFYRIUR+4YZthdTzaZnkt~P)}YkfFwao#thKZi*M?B1ob?}Bd|920Dul`*ZH5=q0v-)V())qY?)_xyRhws0VIb*Egz;DZ&`%tS=|}LZsEqoPMQIU-<tkqDueoNK|+sj{aY-!_^=u?guosdwkx(ga8CTBF@?D4#v^=XL{;yhF`MMUv`8KRk~5>-`)^2BG^OtZcc{m|k3YCcQeIR!ADV?)H!a@uVb)6YntfRRKCCPU_ISpcDyVJ?)ME9_K=|zXH=(q4W63ZLJ(d`5|9Q*hE#}*Lob)j<QaOp$!K&qNo7;dR5TtMIOD@|}Fs-8UB033-^VFG9wQ*cF-kL_wzccJQmb;CL5146IDBBRMW1}i!H^0~1yKi>uCDde2Jlzh3@pm5crV0HLQ*S?Qw*}qL%FypY=&z`jY1M>nx0^{x^xo&*J<hz@CiLBQ98Ts)P*P~Ub^E@3zT@gFzh9o5RY6>qaYv<KSfY@J|JCMS4f_Lgni|;t*lMtCAsjJyQF6B`?WWBi4v)8JRe|B~9R#5D8&X09!wM+W9+UkknQ24rh01b#394>bqiY1z&ZXC2hNF|fLEzv~@DOvW$A(Bd5XVL4lu|5E4NMX+HHqsQgEbj%TtD))Z!8!zr~~^oR=E~}ji{LVncuf}F{FwnOO%+Ts&r##fTdU>S@O>crNd87(P;hp2!74@{pa`$b$k{{S@4;XNdcQ3lzWyXr-?<!RmQ=Pld^g-rljOkC}Wh!N)yqY4%}=GXeSK-98}n6&}yz!QY6)nh^k3Azp#Fz9U&zve%SnfA8IcIcanG83!UYr1|Gh-@`+;Fn=cN-a=t2BQs<P><S$8!&GjyTuO1pXOil$W7@)<HPH1cdpp??$`7*!J1_9i9`}tk%#%^bO@B0NHRfW6qizFGEm7C6N^FzxbmLQV<K})e<E~JY;P}o`)*+(b;ILFt<?cq7^2K-P#cumACuJO1l*Pq4IN9~`a5F^a~KwBrF)n=j&ZVifNTcfl*OtM%IFn6&sYHW1~tK&)9t?rp-F%w#j*1uhzyHM^Y6rA-lA5U7Ti#X0$5)9MquB4sM#xHa0YeD_#i$J9gapJEve+u=M_HFZALyUtNrsYDsA1XuOa=_Hb>66CF;95u3UO<P$ov7JL7D2z6E5lUAI?l3%*3`{1y+hT-On~e8c|`pT=V_9N6Wq_5!PWMx{lwW1&6Oi19;|@O<?*CrlOn1#Lu}9VhXnDjWhT(7=yiq^Q4+!9Or=avMBL%6zDnOSK_aH3h~6k5?@(HUXi<sw>W;^Q&+3%f6FEWa>v$$IytOXmpu%30r&BOR|3;u*(aJLwdgJgPHXb7azWCi&=-#|s&5HCb#k2!$X<CURPzuNOeJ~R;tAg><T7`?|nmwn;o#x8|Ev^V7U6Yx<vCu6vS}1Fy1qlr{*3~j&j-V0b4p5YDr2Hj-c|A!Tn%#N=d-~}1;%#H*xyWen#g@2@icd1kE#j@ZWScPOfu6-O3Lkk=cU+fcP#=>!uofkuP;)>RG6AA75|%NNk5pJo6`eej7R)e_!<_TNV4@F6;-T{o8;wmrgzlxF7fcb<eAH|bc3BRJO-V1J{8>OFQROS&YWhw5^zLtLbR2KT%OdEPOcaEph9U(U)wZ)StFjTQa2egjDT%#yBU%sn@s?^nW!2G>Y%Jw9G+5dj3l~IAHd1IJ7)AUUqv6|3CYx6eeHym?=vpbdr9pB9)ahj!IS(94L}%}go8>Ymt<DEg;vj0t_X@6*%~>{$YF@RbG|yQqiMg#Rr;?XCrVe#bOawToCTUg<rjGqllTc^LaMD!?6D;~f{dR89p`FrDKnFEqRnH{Bf`j3^lHC(VdOa(2H$g+9C7ofGR+8BdHljTVUWsKBQ|V&agPE<ckMzx|X8-RtU@rk$3GW`TkdT|Fxp}}oxI)lt16H+l&JL?F`#g_XDNW7h1eANUIc_y_Z_S6mATVhH(K+bM%3&)CpO4&ZUa$sae~N~w2s6HHLgc&|wjM@xLUT0pm{rWhVN0)hAGwV(-F-cH$0~{bO}(-8u%$FsK(Wb9eSj{|LhM7>tVptiDw8bh&<^ZVP?aY^*4b3kv}K!ZvK!`s9LyNahBLbkSDSk{qB$+r70jkWp0@)tzqji;&QiqD2#u%iTQ&>FP4mBe>r*XML7Oiz+mb^4%2eCk&a>%@%(L0%S*~*Ln`*;6)wX7>_sUe8G}UIL+S{Qj`wH|{cP)o%XVAZnz8W192IROjoq9RX4wCa4Y@U5!-BpV|CYYKybvDE1?F@T;_YAvCuUY!+NjD#LTEE#z_W$_FQ2nZg>h9|ps#Jy+oZ?H2*5ae}s?oZi$w(ZknooVSKD=YJwk9CsW42dFFv}4OUHOfV-1<fT>_&X}bwRk6BXpxb?4wl`9cc4%n-`W#J4FJtr%>-PtWq7o{SPFLx;|Vvdfe*D!)3kVOL>@`?CiFGh4zl?tVRQ{UP!QysXS~(wya@9DQcSRaO$lf7WWveOhnsgOeZ>#^7<gB52!}k^<kw1u4_eAw{ucoZOHGf&dwNAbZ&1HiD_6OgHBWW8^`x1E#@G&&RdQeO8@VTokGkmrTSzD+H~f3VNJsPYUw^63|9+B%q;X+Ms5wL<B&@>-3gNH6XiQy@`_|{y802MIdCc@kFyW%<mLtoVX&S`%dd_j+($+Ai>R&(>>`?Kv<KOyB%K4IZZ`$)JR^T;22XljY)v&H$rrlaGw$Oe60GoKGPSD8^|M|bD>wBsAGpole6-E2dV6u8QEJs~GJB!o!qKuTvwtPK?0x(QU29o|&(7rZR^*C?b23<A!|j?RjLKs&o+?iz8Gc7K{(8;YLMo^gXj)v}tXe?XzHCTZu@TPNgw0$@L-nU!J>bcFFtdAc5Yoo0prh>;4@ImQa410ghw7bVNO(!EHECl;?$TD^gqIuFQ*NYq>I0wzp_S1(GG!00Ehh~2)+n$%;9qHe3-FxjN37p|hAwL!IIa_995Jb(=#{{^g@=6t8mM(%4CQVIX^<Vn)=E3Nz_K2g`YQ-`JL#I8twNhl@iTrEV`Ll=ub()&dtVJrId}33F#80bW|)rQJ}(4igMo|koEm=s9dz+WQit}jRtH9n(R=oshrVtP{9qJr8ePDK_G~n%;*%qV>nSnNJWs-FOU#*)Dw8UoW+n7AdxOU2`2oZ2nW*f-Y5UaKf;G`}$a(;Mb0)>NFFs`I!{2!|ELz1xn6Orh%aP)lFBTU7YU+x4N^+3ytqH?X)zT;;n~gdf5cP|jje6bH9??w_Un$7u)XmiEt0PO-^-TAjW)`e6iH_3rc}Z;jq#%8R+&r>D&Ugb;G(w~_dyppDLecz%<~G70k@4Y;9jsiyKMp}+*pf%*t<>UT=45*5q5(>Qrhdc-1>;23Rq-l_4ONkTM_@XNL+ZES)q#yCoT3XdO>_O5@GRX?=yV)ROb<%3dr920*cWfjXl+XR$5G6#XZ#N}Q*5SsxgP5(P{&rCEpj<=KwMQ+4zxO8u$U+TbWILMX0(4aO=T1hqn2EZQ5f=3h6uOH8H1!yc<-r(bPrhP(G26Qgle=ojsvPgLq0$-#|b(~C;-QNNw$ijC`t{~tQMRs@3Bpo6|^TqvSN)GpZJivBmD!+N?JZ&p56KHnG&v7vl2`^-*gtk9`Mo|)#=lC1m^)7#V*qXD#U-eVR*ce=*>GCVFdy*kgO*`3l;OW#-i};m2*=N96X9PgRhk(-cIfMAPPvb5XWr4xx={Qy`Vcvs?0|ke5xU3s|VqBTmf3J10!MV2EDUB6fxX2m`J;*#gN>CIFx0b5k<$juA-yMjtrCGcW7Aw=k4A)JG}r+<cqWhx=R!u#x(V*A|8PM6K)T>Ow9{Bz0^>RWZ0JWYCZ3<O?EV_)+^kyMy!I}E>*6D&Cqcs!|a<0lfn>eH@Dd2sbf?t_viFgOY3>EK9Tdb>Q-GeQviLbdKjZ=SDKQ))L7Ja5$aRV$l*&V6@1xiQo~b}ffTLFV@8{VN1FhlWW~)}9V4f(PhXGosRcRD#yi63%e@JiUa6v(lsg`)$+YXji-7-?x}Qik{VMpMOMgj;DL`YrMAvCVFed`D|92rtslBcEt<r%k6&nEmEE$b+Y7orOU7BZei7#39nVh#ZN%d)<R5zoUl?OSUc@V}CctChARBl^4U320f>R)NxB%_s`W$dt~Bw4yhRJkNqCfeo>hkVC(98PzhJ0M+t;X581r3|d^ZRh#D=J{X$0u-4yZdoeQzwn-*$b?oNdzoPABgHvdOoRQ!c>h@}2m2f6yB}R0pYeHY#d;<cCJ{oGjUR&|#*P+rHm{K6l?=BI_3)9^Q#xMNJM&OneS|IPTsR@KzM%W_GAsQj-yw2SK+!p$vRIHwT`QaxQatR)6X7A%{Bkm|v>(#I^*nQRGn5tHOKx-QXwgH<d(wt>;9Vl<o?_buqg<-sO_A0-NHHm-zqr^YfA7`MicP=|3awh#a+i_Am%NRoKEqulNE<NQ=MA;KlL7Vw-qY@9s^IrYMSS9{nXvQ>zuLU6F9qGngVG=vGBL5I2TSk9Vw9vK$i1Bl^wL?e@{uCB7W{n1L{yL}9U<22qt1lnD^o&h34|%DC~v_$=j^7Pjrv5X7Hhw^yI0N`#I!Zi*?}4&&qYtp8hy1f2uu<nE;lU$GKycIB80ZN3A&U<<i7mBeqeK_+->e${P{0ldOU%Fm&$5rywcgp@9ym6_jY#FL-FR$;R`i)NamEJ>#NNj8#QhJuAUB_86+n(8w4}X@4r+}M{`Zlp36;7C++8kjuAlOLw<ix=kZ-Vohi&5&{OlbL0jjSK9ur$rgw2p-P7WS{qRWRvKlJUVWwWa%OlG~baz1M<D$fsCnh0Mtl{cuVEkVL$Fr2*qA+)*nKh_Y(uLK;6Ot&4pQbbP&fy$1fMoYHup1fEspd(&<VG#mHGe?eL;Lu%5N@f*hF6b`@_$VnBB6mA+>J;;zMs-mzsAHR&pO07lIfUeh8N$!MTUU$6Gl3zv#4%Q1Nq+O7=m?sbFzQ^i}@IQLV(84m?bVo+d0SqxIAhhXr>8_ZZ;Q0d5!~#-QyK=+9?VV6HL-6(Q79l%Z(?1pR8_?W`{P+hq|{2uIJrbntoztM#XN|SVk{7a^3;XmLN;Y3PK*Y9^u%Vcw9)bYN79SUG;V})h3xlF6T7eL+&WHNjLoe+`Y+<b!na+^v-9v=MHh>-uNQF94afjswihwHAN%0j7W(!8+OPN{{SGoz%49jF&VJEaSJe*?glp?VH;%JU>PuzSRi=?5+GSZ&}_UymRR5o_JR$(&-47=Gu(*yrp(GJITebG?+)jld(J!jhG#IV*ZPmqj7!r5YXWv?9Lo&`fs=m*>7g?JBE6)~t^r%g#DOiOwf+e_N@oI{gv;#dFON0uk3C7DIc{j-j@bJSo(F(Gi4|}4N-uL7kocH9*Xw}^d$IobWYk7KwTPilgi+D#4P2YVbdyJ$82;5<_s*bM#!TS50HFGmXfDe~d1MgasbJd6d5nLvaw9BRnvTYO#zA6|KUlcOjTxG`b+S)KE<NyU>o%AvKcj7OITP5yyFqHgcVwssN*+ol%At-o84X?FVUT$y1(Y2CQsM;hpZNQ}zU5$w$$n0?>)*fr-Ye35L=X$yi5t$5fwpCyfoj0?_>QMDMS-*~UCd*M$_YeyaiKW$svZ~t=X7T_nIh`)GC+F|?k><ql*<=}*Zp3}IV2P&+P^$>2yxH#<F00XJvjMgF%X%;_jg!f>Jkd(EwQH$5N($KI1tn2z6~^j9V3yuyL(4ouJZi)u9)xOXO+Vo2`S6vMF2Un-gEua`ed7R$@$qAHM~RAk{VWW9k|@FsQV6qi}mtI^1X>&f?^lqo`t83@1CP((aWMh<j=%0t01PVgP1f&Fh0(hyOGj*{!Jj2Y=!Wb1De}*YV2N$X1F~npeYJyn(F>-Oyf-1Li4SD{cEHAFOiK?QIc;DB5^2h3)TiPR;Fu>V*_Y5k1TJwZtJ}+SQglA$=$&Euz(xPp%2J)OZ4-xML$r|f>OgA{p`qGVAOSg6a9?vqWqQvAXEqc!p4dN4CJQ&c$F0g*BVZOx)Drw2`Gt^Y>bmBLd#Sot(*t!cd$y4aF%jAZoZY0L6Mtf2Fr`g1$*WE8g%mde*Iqa!kf_ZBb$p0eqvgC9C$$D<9gHZT|nGD{EejBf=|gN^&9qi{Vp*DU^PWrTax`V>1tRFBe&LGKAh1$Mf+`l_%7Ik(cC*(ka4EcA86nqR|?Q^`H3@FzAR5crD{kxvO(Q5Rn54FPknokX9B^kUUfb`$YRkrzl<uJgG>YY6#yY8wt-IK@$mmySk|GJ_V(p3(m3sA`RgeG{(*Vh3Y7OQc^eGU-Ys=&$vlC_Qek9qj;YZ$Z^Qj5%I$BKJSU^gRrbaeq|<16e!UYkuda79bs3dvcDJ`{pX5fY1VB)<^<kmFzK_r2NPwPVxz<bKf!eWSB6nn7`)uKh*_O7Z<dnng$vRuTE~}pEPHa!Dp(lZ)XIb1gpo*NZl@UbX6L{l3zRCF{-#ha$$$6@u(nYO+zW~YKou9EL$F~gsR*AN;zu->Ru9a?E#i|b;EZxPx@18Nho`-+Q@383?gQT?DG`c`<n*ptIq4vbOLcN*+vVAK|E+wh{-0r_%sCr?jY&N`Q>klTL-eS`9Qe8vkY?;`HyY%cl;H7BbeWq+rw*EH!m%29R0lE6b#3bXZ+-~~Iz?V20<C|6xpNWw1mgm@vbyh`iLyIv&Xi9nXcvF>RT_SNt2uSNHNqoWW`xju+q<{BA0|q4<Phtl9(O%Ej1jU52#kDhCDeRbTN}C8FE)jzLbi8#3h6l+ubo`98U>-SxDXBSc_Y0k_MKw!opf?u#bQIJ2t0a){&rf(0axbWdy{0CoJuKE(oG{~Z-0;_UZ|oImqz&UuMtce>&=>7nnogLR)TL^M)1NHA5!0%l!gXMWvPX{EYp+*C)HRTb;fkL8A+wM6Q-gu@M=cl#G<f*pjqbf2*FoHTv_BU7-H8r~WFE=7qudeFvAbRMgug4aP);l49ir>=vc^Se<sELpcc~GJ@YQ>><*j!Bg4BZ<@`~msy>_IK6D2*$O#hC<NF6KH@jIl7Jr#Y?Lu0o<^y3Fc=h1XQ8#yRbifIxJg9=S!xb|G0IDsK}&z|UIc1o;~&-i?gtJi+?8w&&MCvT>Ip<`boCZxy-Dgiuj^x}Tq(-Q^h@)CS;4UBo+7LD*Dfc6*zn?h!4S!|OdlVaWq#z6=Ij`Cmu=^MiRaoJ*ef;$YCYyGQM6NhY{>D(skN^f?PaayAxz2SI=*%diThF63Kbe22vlLu3<@T_t77cWkoSo1T$wHHbM-Wu^hMqI)*nUf+8MQmCTRd`mC=))Zk-Stua8<8`=UW(}tZM<((mBMeMoKI6y!KHs7wyR#qS84Z(EY*5muavxm_yELK{fbu>peAZRAJ5uMKqUM^b**~zd#Jp6MX@ek&U_ceUv_uWj;z^Jd^m{!YAJFS0sMmP{Zd!sSL7r<U=P{RRE)(*v@-|cMZAr03MQe}_+682sOOKZ{Yb!FjV|cGiWohlt&be5d5I9`_LRFP_>bLS`A$0OoTWld-w)$mhXy)H38q%Kp{bk+M&L5srwswS(UP6vD@4O~Lhwn<kB@h=d~Be0FG^BT66p%o86m+dm1LJjt~MU8S-l7V*~GdVu^Bhlc-qbkyu5ilt=v=f5q?(gkSl>-K1<hi#T*W4rIHYCR3UiwB$nIfrkU)$%F#FUY&|ZGVY0hjQ_o#K@#R0vh2A6tm&b|u+Xx$PKdZTu8xwo}j^XyknW^d18`{T4nQn*mH-9Xe7b{g1GWPXeyOOITghp1Mj~tpaDiOHzjeGt#u12GmFAug;n*WgFmo&L${IGnHn{QzZ@b)-0N!u0M-qZD{Xwd9sP_e&TV~y!QwMeecgD*J+zu>8iXbjNS6TU2wur<Jt4rv5^pss*y^s!jMxJwW{Xc!8t!XyH$TfoXX?5Z?QBP@v>^&*)fC=L<z=FO1>xGwC=hM^0lsqVDJC^tC~vl=Fu@5n|^HzNub9%Keh({6LoHse0npdDCzD@5cYvXGQzfPO)=o|ps;D9a6}QM~@an=YA9UifxLGq4dJS+(cF^X#%V%B0P7Z14Sno|?3#;`sRIfsQgV^a|}90sxBj6dv^z1meMqEsdhvwv*|!eUTH?n_%l@ik^{47T=<V977(nbw`*6+EbD2Kt0HR@W$T#3c>LfR;Gfs+qzGAQ_<(yiqDfGw;3k90f^Pg+i6wXHWZekjHeJR%VqOSw^Rz7W|Dc_^*+qmY9|moDC^9k85hh+YC~J?;7=c}VFR)ny=kh`ri`d+e%z9JvdkP;*eV2$Y_B84hujV>_>Q!J*eI^(C3Q|xAB0@bsiC>It{LNqhW<r(cS<Po@2B%}Zt900Gcm478z)%(Upb>lIRO=%CMbUK)9UwwCyfn?sW&gqUB(7lIt)iebr(P*2}UD7Lcb^I=hX$JO>cC@=@2SUd8{>nLnNZ=bbs!VlCW9VGk0LRK63O)iWch?WOCroQaZp>@UFTto$$vI()b*ZS6rJNgThyWJSb(PaUF<MnSLq92v4Rg;hYGL0s93tV9zH&ChECe?&Kwf7hD6nM>Xg_aYqNhfml;rmdu{scy9||`Zpm{Sx@v=&@(!onXyi|y9+0|e%C$jFqY*#5Lh%W00Bw8r!uB;sQ1bo(}+_`({3)fx?)h#dK?qYrxBPbQ`H!n?IxtS1IT}n5k+EYwx}k$F(RJArOlTH3T4dYo8VZ-NUrmyqwCp1tU-G=6>juJ5s{51uI1H#i_z+wkwVOn&%kj6QkB~pWfYRsnIUb@D-Eb9Kkh&vq<Ti6*z=6g`;F$CB}A44PdK1W2r0}y%kaEwYR3}(n7moEsQX4}TqE>Q_u)SJe*(h8^;>@K%GsSCA&3?4pgKGefsMuI(F+1Zj=7Z&Ih{;?WRj^S3^8$qJ{IwAlA@0Zo*<Xv3$)wxJsE1FLTl0@ky(U~q|jH#)&X;<Cv2f+s$-otN0a1JB2d5a=k;;4UMUrA!ic!r<5l;hRrOAeuGD@eh`@354uf8q-1y*9qX`E3k@oupNtSHAZ%eseIUS)V9z9usDx^Q_e#>Wu8gN(s6pKiHjh!LO{^Uy9!VWjQSYsbkC=5{~uL(w$sFl%tiEzXboUcUft+ST~j70+&<Av%h7`3=~y@ucb`*T2@SX68uBqD$r5FZjg6p;Z(pTtIFO$oq!W?x`uJk{VO_aS#%ay5YRKyi~mYwes^q47BNNtkPx6<&SgXZ+1Y4>$|C{M5v;-*bla;oix*#WmmvW>MXaXrNv<axYEuUZKDN6_H8yl^yEy33)Z}F(}IoE||{*qv_1^q1Pi2o(U0yqA2u=#7bn|S(oK$K@B-G8rUK2mEu=Y&s{6X-?DgO;D!CpJC)YEwWLkc5N&!k1f#UJk`>qse{$<Asl*cCha5YB>L3OVy!cZ+n*e{_g^c`E(gyWwLmvpyqDXJllFRCPFII9-PhL~C!KP%hWpv~P1>Jvz9huTUvnV_8-#1dAE0G%!I0nl6wn`OFBT^i_7oHQ@xOK50Un-FsB8vt_5(6Ej*s&pxM2y2Ilqt9ey>X^d5+8$A%R6eYBrB&#`^hyo5du&d#B@@`;VL{Zj8m)P5>(_jEgW${*M!p4Z}5WUN$;p%^^WW<jsm6m7o&Id+uuUK92)R>E|^AfS)PlTkyouMr={CQ%fUkB^uD2TelAYVZwZq3-a6){I>LdOyH$ithrla^4(s_X;ju$6mdkC+z=g%?wh^)q7lII4Y-~fRizco#$Ho8ymN!;i|N7U0E#H4QW_hO$^}Dsd%TvXK@`mOgy~&^6<OS;!$KlyNUyxW@->({bCZ*VVdy8<A-ATLiW!=eJHTih|mrh=^Hr`HcwgDATYv93%Lp?kxkhXC_ea*qY+_z)XPT*w&=p@klgweSfBZuc&)r)j+#LzDJ7otgxT=P#t_xwjRL4IVScBMwS_DV!OD*<$Q2wY74+_D2O{%Xp@@pY)zn=(Vbxj!;{qK67`c8AcR@D5yPf38;-SKYkrkb!wKWi4iZGMxz|Omq>bZ#mM<li=0BKuHZH4B-=|;xVD=kSW_)kVm55h2aMy9w$}PCX5-)P1DmG$O}4UY5~DF8VYH8J~o^1`6rp-TMi9bXUe{tS9+1wx&Dsw%h|CBZY{?+?p*PUO&%80;;|wFEoVXm{SVxqG6?NgnBYhb?wL&sKU)XwiC^-*u~28%O)kuP23KS+b8o)0bzowbkFA%myEon2_O&%B>F{xcUQG#xq8%TR<bn`dZ@>YeZj#cqg!0I{2D$NqwRt3NSe=z|$M!hm)yakV<8TiW%$DlVAA*2KskAd0nmpt{Om4l1C!HY$bUU@rj`reAueOmd?(e)EKSF{rv~#=6SXwhU)r%bg=AksQHv+GdS!gAt>H!~}=+r_I1BCMdhTkv5rFzGAPLRRqf4~3JLG{nXMEL0Al;Av1t31<v-!XHX(0_3ClKuW3Mec#^{fWua#7KGyega^z2CgV+?qjU?bIQzA;5=?y%J=8sKzubK-s?!I$>dijHuAE3XObL#>!6~nKE$_^Nn;2j5xx=-lQSZ!qJvo!rb0c)2wPM#)c^u3FvE<bl;gG@$T`d=+!?(r-JMuuzGyXNjROTt;7h|4CDp*hJ;;$IQhb|(sHZbY#sa2-t%&YGCvoDi>4p4eqI`Et)zO74@M2+?EwBTOv;%wFp)S>4HC4!ZNCerNM?4d0MzBM&R%4I8e$8^E+W~{^yGT8p5RT?4g}<#l;;kboM<dGNr?1%V)JL2YQDd!$rcP0pQsS)`()(QiKll|(tDm7gpS~Kyk!1JDsXb~MoSG{#ug*pXi@!n~y@_m-^V>5F_U0T^SD5rG=CI05UK$lv`-jiOVDJ*0O8ve+gsed1w&rw0)pfg<n<o+oIG9{mK{iPjsxu$hE2F$N4)|3hATFk_EUSXD$V6|@udD`P!ui~+qIRwHv)BOt>Y@cSF^PNwB4K6<mu>n;CF`e(sHIU1%PM6wiXn`q;Y#;Z|8!(<=BXB%l`l%piOUV9)<7KfoHY`xpvU@_a(hWRwy><X@<c!@o`?c2b3!m!nZGxc4eL47f!wW3h%-ypq3NQwy@5>(w56@O7O9<|TB$<Z{F7^GWieBn0k8~k2ZcDS%Xc|q=Wl8+mWpNJDtbmvFnHnBW+1z4!m0)M%}<icapd6L>eTcS36Bd|m|_j2qU0w+L$lnFx?!|5w+>nTg45z-g3#?>{h2^3s8cj>1eNUwigaU;!RAIm_hcc5j367ULOvrNeIs)~6lZCvGR!JdGr&U7heFR6GZofPY&M~@<k^IEwhpTqW0B0T$J6mdFbfS09QNQy6Bf(@l2o)Wap9WGu(W=$8EGMnFcO9Yv!E#rF%|>JqNwnyF}226+^sPdH7M-h-%I*i?EmfeBa3miXZiuhdnJb`C}Zjh?ZwQ)_Y$v1v45B9XF6FzsMIC#%DO<8K1#EnF+~`>A&x<MJ3xNA{@t0(k^yop2tm}#@(vpvv29G&zeQk$4NJf_%|Pvso~2v6w`6-CNd)j5I5INi&S8=+^|tg>z}RznO7wV)YJ;+tj=p8{aD~NsZ{?TN<jJA|&L|}z;vk0%Co{it1pJ*LG`qZ<sP@CXFChul7ld|9Hi{V$Y>9QjgEwH*AOFCKSI?{8PCS-D=8T%4S~6+2b8qBSiJE(IrdnZ|tU_XdCSuE;$24ING&Mn6q8F7xn{uJexA#Xgr5VaJA`~2==?5Fy>|)X($#kyQI3_~ON8gPr5L3UIU3o?@^{!7V_!1mC;`Gm3s`9Ju@qzi(D{WuwJf&2Qv3$gw#VYD(N1UU{=5T#SXOQ1srC*Tbh9sU0GnYGzD{9EGwLIxkiHlBSAeiAILIwWp5-GCI1%%YVLYbnW3H97l*#^=6(ImWh1k&6B07<8N`6B5Pbu#8jpb!0i{gj$~V(Q_utn+wh^7dHal`hrSbf%Ct@*oUTo!l13y&5B&=zS3Ty1vEQ{~W*4p+`==vvw!bj+PJqWpqEji~a)|AQ1sdIMc+d-nAXKv5ty&R7|S(A$-*2C^GR3J0u`<GKC!*l9-ODa!g5~rFcb?&=JO<3ChG7$=BRJkd`+(dof~&dhnB@u9zDw?KA$d+9`)X(=Egqu=OYnm=P&HnC3JT-du?nLnc%~%{3OKM7Cv2bTCbSGBCp#8&8Bs83WzA03LX@!JGCqE2OAP#~^GxrE0oR7JX5OVWlIE&`X5gDZPqHvXIA|41@6*i)tutTyQ9QLbC|V&WSJFI|g&03)bssf7Dqs5xx$7F#&VQc>DEnRp3JF<PesJ?o*U3txz0+pJGUOUZ0=59}I3H`E+(2xw^2m9EoAJ;3FQZGd9!8Z={)x1alfGlI`!DYQK|r%@1VlI<gR{3<jsa32V#Eq}+@qcnh#ccJyeXA2w~nbg!s9wsi;zD=57@%-WF+cSSo$vo~4c*g~59G?M8>>3oPvy8VciAqG`0!(w|9{1YpZXy+52buOAwT!dkTCl(?r7mjB4A>*{TSkH5udNI#ekgwUuab+#Cscg+UiJAm*j9iWoZee-rKi0qf%0z{eKHMVDLTG+0b_B&a^RxU${<&w(OZcrPvp$m*$Zzd}a{Hw=Uu0`6vjTTM`RLhqWo<-5TNNS*zj)I`>}(cx&1VvGkq@dqsb~F+O+9gT5(<f@t_GV>-3M)o5X8pGJK_4M(gMgF24hXZGz2u{iyVE5RRu4U+_IVK%wXzsmdCA*BZCRe!feD>wopR$vtt}-7;H>ZgAg&x&c&Z1qjky@kt|X&*r2D4E*rf~^ytIvI%D(RoBE_T#WZd(?c?U@YsOYggv<^F>0NvbA#AOT1odbxs?SVEl68$xV#{0e?^(^8tsPGD3bN@NXV)b=ejCO1ciiT$4Ogk&U4yoU=Gdk>^K8|#_zB$%+hq;o81(jDF@NG}@}a`AAd}_Ps8-kl*2NYhFktg8a@#NKpUxZS8)H1l;>XU!q~%UfpmS6UjjTyYUiHb8n!&?Ov}$IV1Y5&o4Ha1ki{JT6w=OpyP}5OLkfSW^7nhsKzyLQjot_zaC{GJI&$a$X&n!mk`=*HF7a5>v7Hw{+;57aUGqqO1@vVZBW{Jmwpg<{y$~RrGY=NBtOlSH;GM^@JOWc%E?Ed(Cy=E4hdk6?)&D1$NIn)L<>v1<QC5fe9Rc*>`jb`)HZ&+-8Wo0whXejjgJZ<gd-q?Koa|@g7%eL&knN3E{bv%hL)@DB2)8UqWZl$nB);6|vbc^2Yta=+8zijB&<gztQd-J#sn9_zs2JsMQ46n3ikTD1Bkq;)u1I90F^mEoz`RNjpoUSC7CHI<b64t+y&VAybIG)(3p_xo+WcKTj<a;$WZu_~P@kyx${ykxa6WJw42XxZ(h_Jlx!)G&(Y>%XMs4wnj-?L|y55oYpKW5qM^&d_7l7f^>8p=O&TiJPBMY#MyJCpd7PCF)i&#`oLXD{Js4q{gx*<r5(?;aAF>I#h?HOU69jkv%kC$a0&;HJ9jX-~2k?}L7P&q}9nOuh$8?t4x=jFgjg4S}0`g_P!3*<wR;?20T!ITffj4;Gr$fBv#gW=oW@?VzO!kQ`+~eK5|2Ib=6SZHbhlHnjYp(Gw(>TjPO;E5^9hkB-d5|F&J}<4bESCsk@|Y+YcFh@g9j*kYOO*T}1eXegV~xmPJv3&I4I#5#Cb<_;PYhE8W83q#<*^(qHL+p&ujZ7r?KdFKSLLipad1)0fOqR3GnoBYwdEc@oKXGjN8q?nP%&^MMTstvIvEm0PS_R7?nUyBc*LaG?GIuN|1+P$?X6`Gu)?fYtocs<1ple9~d9IypEnHZ=ymD(Wh)KfH7+t57W;taUb+D;R*y(&R~a#_n%I#G3wFzX8sW|_$q6>X-dNOuR-X(KFmtlFk%k;<iK%XBaiAT(?zp?uXjqChk0$@D+rjZ4H5?L29;G~_dU1U?tqwmrZRDqw#b5Ul@avF@y^!$&Vh?W^?#BONsiKIK=>`ZcdCw#Rz~K&XrPJp>f$vmF!Cj?Ip_Jf!&qb#}~EIhBe30Vm|4Y4@wE?6Vk+k?!3FD#g_EHl_F29)Vsao+4gWwwy#>x0ImgAB8|4irQo3O~%jpDbsTbQj-y4J`R$73{7xfv2}~uiNBqEBY?Hf_1>cOG_pzS;vw5uo}Del)Ybv(&3_E`1#y{ov6w2HZT^}lX`TAXZ*y8KJr%hcUdS1)T)9d}b9fR36<H;r&NA-#l}Vo!b+bVA$zJ<WKU4l@)QK>x9fOLw<~`Raf-q^Azo+2l&k8o7o5d(Qx-0pC*)hWVwk|%gJ2pIr*+<um?tfoAGL(=$82Tp!XVgKaqN;Y)**WqS5bH+Noh&U3z1AEqFtmjNWZ^(S6rex}{pA1%v?VCnR++V;fmh3pJ8xvQ34J*^_e8oJ-*`)>Aim2&sgwC<6JVl>w=xUVsFG1asN)<KJ;Qa<mq|RZ{35cB5|<9A^qPs>4r&WTo<=f;n6Mu~IY5(+V=>wi9N8~7scZDVFgONV?FA%iKN9%Ydd(bHabMpeBl8|WuCf|pJM9@phnAgR+LJk^`N1jrxc1u~?CnuaU|4JL0^Z}Zut)Z7ZVlwZ5EPQ+fpV<b3)(#R?kE<67?uQ=m)$hs)Mz-JNG5hhHBkQnobdnXZL!3n3J{d6K`FuVwZx{*GnS-?A_VJ#{Nzd=0QeKMf1WhpBZcLatc|QE4+k5<VR7Z*8aioh^3A=PY5~EU2pC8jiUjN?kX^_&Cb96VObw)VrD^a{NHH7uF_;uIi%luF0Z1rjG^jZft|Umdlcs$l2m~oxjvb?&#O4EfU=-=JAk)vtCKkXItI(t=_cb8(R-#W3V>PSdXv{DP^Xy0JJJ2XXMT3zJD)oc<5-!Q&H(D@1Z!X&Zk9OPlJfk;6k?#t?K!WR+cqe+3ZKpU4C2BW7{;fl;Vfi~iGv6D_Kk$5<PpfP`H59bez9nX(PM^dBR%1j$yF_gSn<Sm>`>65L)xw5}_=8G0W`9vnNmlJHGaiFI2QEiV{<RZ^p=s@>*gjf;VT%fbqQVvuPDT`<(yxb{U~k1UcjQh%$d@31tsSB6aOV~4owS(Vg9J-=Taf55X%XCz48z7AHyeg^TR*(mn8{``Rxe=jBVDw<;!h7&3ED@Y(SmT@eht9Z9}`yn(F|-&Ci&{pXY=AR16%JIpi!AP?oHIau;q^#bpg#IT|#$HL;C<+4B$CP)?B%R1=0cQ9+mQIdJU8ac!dOf)qCjb{l15Urrq<7*7cv&yS;Nmf<i-J7WPoD*<Da1RTqWt6BZ5u5cElKdk5&i5eE=Bdx~OzzP=SgS3i!^76E#qt+$NBk@WJ0cLEC3ufxcq27Or_Qb4Q$JRFe5;`muZ=5M`I>bIG+&#v2K+`NH(V+(j=qG}mmv2RdzdmHrz5o))Yu|#en*^9nS+D#SCym0C_EnaeTZJo!3jtbIFHjObweJ>M*?PO-;08KKR&*Ff$MH}US)qGZxyIT2W9}-!(Df8m5`5Y|JOmlppl3fgGZdqF7wM^+@Go_8NgROzfQc>HQsj=oKPZ-~fUxfc-h{PNk{I*Um1ad~N+e9D}oRFL@nYvrt8zNpMo{ePXnt;=VOEIKRaK8YE_+S6<h2!3lXSiK5?mfw$E@D;_%>IaEs@nmX+p(%LKA=qd-Fo@&16wi<J#A2D!{Lk=abhf$bLc>K4c!PN$%UZYd7ekMKBr7jI>~p-Q%D%_=^evNJ)VaqDHik=A%;Zd=RXS;8kxW;QEF+%+;QOx7E>oajtrhl9%XdrZV<f(Q6a2D=JPWn@*2GS8Q22VukjP27L;DU5?xtYb)A#E()abpD*M)*_6<!SL$6+qVsEM}Ju=Q@6)j=<X(~mXZdA94wW^Eun9!3VufS5SU}h=&T{qwk7oNHaoG?<C0MJVbT+8H0a_R9nMH$HCiJWY_#KBIOFCbGk32QeapGFd7wEXHElJbbePv?iKZiy*r=_4D_^<9K~^7~pJ4KbyaAD6x{b-z@;wWK^X=~I=;a(hiQ0IAFNU0B&~->dKibZPcQ92~Zcu|NOb`)?30v|zZTJRjA~79Kam%uH*i=xbB~`GI6r!7^)4sVdkuh&ab{GQZ-=i5|^5o@3o~7@E@OdPj(+6NcWzfU!1nIg_R0G|OvJou-SwO#%8Kz0ZcVmF_jtHSP%3>h@)ZQgUx%M^lP&Vzrx{r|=D7_Bjj&n4kB8yxt4uVrg_slPyPeyX!_d6qSeDv!T7l6Udh$`FPu=jOwVWQ??G?00riHm4GE&K4@wBtb2WEe&Y3yD$<i9P=5dy#om2jI1?LISm1N!#PJU>q@wYI!CI$(2#fhIyXmv%way1=ohOi=aL+#i`(EhVa-xLXfdN86jxed6SrhCoOeww&zz~K#&W^FGFK4VT2OrPWKB@ndVOx>$*B#cH1OLXe0`jG(`+w%Mdvf^{L}plr0$(3rVcKK(T+ugu{R(dZvi8p2`%vTQFXH82s}nCDDIvhjrp_pAKE1$W%iO~s699NwlfF+GA_1{8_j&AQ(CL<-4CT!cBAk)Omc(32hQUoA0gQF3vmMb9!o-uE)Z7I7jzIl#dE_GxUd8U#%}-WpKeIzsRu6gscKGa70LB>~1mBqOr5J^~`b~{=|C($N;MjVC)yNeYIb**d^&&pN1rhn&2?#(bL$mJT>kUa0J_Rkzfa5@QkbKM|<!O6SEIPB4Or6R4AYeL5nMf`H{z%1&4)>50dRkf%r^5j2H|x;MV%{MvKmeY<3;F&ynqCLS=m|CG3>uv)uO03~W*dk5aye)lF~GWCKxNL*KU^@vPR_I(j&rdJItL6jrQ#9Ia#+1cZ@H)#X0($$m?Uto#fqh|!Y`!awJL>@E*4MVta8P`+p-Ja6Sa$PsmIEb&n7d1JM+Cp{Ho*LPqFRQ^2)^#`ryo&@+8wVR!HizRR8>u#V39|kZpy^A7J3&S_8;PB?8YdmUB3uoLDc#xxPO7GYMXP?@LWAy)-(=lYro2xKrhFq}@W6)QWMx!e9J$YgZULFiI-V)vjQ#yGeAS5}jf+?Xaj@GRx^T6_+}eH!CWpHCWCFGhOOfvmZmNV_8lU>Dy{MSlA{s1|H0GvJx?1PG~xkmbhhgf-6UDVpNFWFeLh*)v+XhS>%Gj<cx7{628aH$qJ!19g!s(TuM+>fsK^!vP!5WEAXcYjlr9cqoDr-L#hQMeTlbqEcMFzfBEf>;&B`0)U5Sx+xzq`Zn5XHqE%dD&r5r8gP+Hz*z=jbePrV>EJTl}UgP_q&RMN(6pt0^JUUA^W8MJIRb<)=cs>~Fyi@6Dvd&Q78TMROL|BjRrMc|W17cvkWk;94`aia+S4K}$vyC_GdF-z&KK;#~f7mI`{m&%woCP|U4u6R+MV?+VAi;_!TFIrAipoP1n7<7;t@xZ88To0zNzTYZ@tO@IqeZ+5IQwnD>9+xAzvyg-F%wEe6rn+hSheYbp9w$)QlGobELKhQ8I^l!qEoHas09zs*wv#5jAj75(ZtSAox>;s#EvuN!QIch3h@uWouy>jHmgy5*(@v8yq0prX!gp9J&=)uogTF^ee|07TupGd!&$VXSr{tTptLVe?nt{w`94uq?Gd<)*Whm>5<Zls{&eu;7|z#lP$jGe<B#-gI)~2+cr@c9=l{+RU3gvMbO)tWz`m|npYxx152GUJD#Y$pv(&4PT`By*F7bGe2|1`Ld_g1fz|A5ZrKjOV&<K%1BR$lnn)VQEHQvEhLyKf$KLc5K_Tv;TSRvvu`)R5xo})#!Yv?45u-7MQ1Q4Rr1G>W^{l%M+kZB^A$Nd*|jlCLR4%kIV9s@JcH{4z(3nCJNaoQQNeNaF73QFCXR>9`Wmcum3|C_<86erQ&z+UGWzGyX(n1-;v2gFi>*92=3-3-m2CAzY1*Tce??Y4Z!^bEQZ<*^!8ZDdP|hucbeN|9x_D8ZUWl11zF23=WJ<XGpYv^4BQcAd<MsNpI}i#_NT=|d?Pe*>)~>D$RzG4Xbvf-Re*!eT|=;3}K-ax+CStuz8Y$pM_+8C@BD9mpGiWrCo*S39y{EbEh(rx;7hHjmB_O^J=}8noBINWNnIC*O?7GFT_@bH2>N%A?8eK1VZY42!r>B+yBl5iH^6HH5PVgK_gUB%XM=BwCSc%@HUof#5}0SyZdFwC?uEe6e-w^&4ju7ZHA+j1-`ANO3LP+|-;K65TJV&Gr!r%TpsD3(C;@MfvyUTP%?7mH4ub-%vNEKphmf-+Z;?*LupK2}au+cg_eJVflg$%EC>u7)GD!%&XTdP_jnNXcQHtrO%KxR)Ws!w^Q~AHR|U-D9tZpVpCSq#*5bT`a&(=mG~bf*=vNoKtZtq_v4IQ<>!W%*fFY@uMq9e{L$)O?5a+G>^-cgFH&~$9oz-TyS%d;p)imt%<A)j2>A>)VxaF?5uXuGQ=tara(PZWx39x?AhHIeHNM`5Q#W(ZaGew1SeL4E7aQz^udh>CAWLe(2wqT(qKN&p9<2u|QHIlAO|k^&NH`T)W&{GTxiIi*zV3v3K?cc_any0*#A23djRzEDuy5`MSt`rIjjjr!DQ5B!_5m6j*p98;=%xEQ62-%$BiFa+pR94DzhYb7#83J<Ti!u>k1rAmHd|goVBdo9RTA+AT0vGQ+Y$$+>zmwRCKTLe4YnEOCeXHlsQ~UJJ%}e+gDeoWWIwG@Qy+DFTAeQDF-)-ThFqX@ASxZmjiEDZqFcpyBPwr+h6Gm=L%hI@0Iu+>jKFVxn~VHp+gyp;t*}!%Kyf!`HuT{oiou`y5a;+4d-=)d3qx@hxTr$LAfkhmCw@A2*r8LO>DeH7x^k~XnFy`h;7NB#%j@G%j*~LCgs%vpj?gt%D?sfilT_dpm6ECaL!tDPn)ero90P(>?3hy>bj$AZC|~)J@vhQwzWp--(TYIX?eY5QkD^Cwb5#8=nc<iY`02>BQfVkF6u?8M>*h^@y*RTFOVV<yhaF^c3k!L;J}_Ma4rD|=lGtdL;5t=DgQ<(wgZ(exSg`;_%J(c5c=Z#!v|;O-NzpOjk7l9yvPQArlnip5ZMrrk10iak;EzlRM)d+29JIQ?2By~P1*xHs!pkV6+)zlv7KPMzRydd;NV!3fN`p0RAxNuE)f-SqvV>;fRtHA?XI<vUE^1dwy&6toFk58%LD}tTYsvt^gf$ThGBM$*S7HFT*{8fPk<{gyD2G(v_tj{yOzwE$kRz&UT11k+NKFx4s5%^VaNLMLP=Eiw-y&v4UOa}GiGvA!HrR{}y8dm*8C3qa$QduJ8{sZ5A!ib6%JE5u^t8f8BE{O2m7Q!}b1O!Uo8s~<V5VEC5#8V<Z_qLvdRAZFKxI}2xbFs-F{}HBK1#Szy^<h>D{t-xR*4QIlB|o-&cHKM1JCTkZB^QeS6S|L+`D%efZfXVHM~(&@@||<)jwwl4L<Zs_lMnYfps^1Y08q4C4hhrG2~~(Oau90`=<8qsY6k3r*OBTdT1s<3IYn^Nr($5e`ACV$;{C9T6=Y;&$!l~MF|XsbfINHj7>G%MuXPd!iv;mG@z1+(cEioL6rk<yx=1KDtD)FZBOB&J(;cel<z1!_F{)c1`g&3Q0TWoGx+dveOE`5>l$sQC=+Udbi*s0VO`A5YRdvU!rhO3Q!I4<9NZO>pZ0J}2(Q@Y?XV&y$x)tQmpIc=&iIfxK4^tuyf21W9cDXG!6@1?Hw_snp<Ec7?+KI4ks6Z|3r;njgUW~KrL?SSqAB5X*0)dBP?kU|j)-`|kJ(QGoS;sUv(YL>>-Rx!zU`mk2dv)p7q+E+++U1-DRqu8dl0ZoY>tTsL@-4s|A4w+Pmd^wW)$j_`F1{6*MKZ62R?v4IVQ^lsf%g4Kf}G=MGD}jer8Jir0JyAb@VI+BxCxZlNoh!lPZ7=c#{>=bBeok&QOyt&9DvgL5v<w4JnBUGVi<AqVj8_z35ebmnaA%UL<9_=72O_1ahXRIMA;Th2a@j^&zM3HA&u~k?`AF(9<AN6wB@WDfFuh=I|=R&*&PF!|rYrG17G5Y;iTuVtM-L6RAgRWY13)f_GfR6OzfziEZT567`3${4GoxRV9sIkwlV>?7nj&Xq0j(4A}RQV#=I`H#WYQIMT$E6p4!Jg3Gmcu`1BVFf%li7|D$jo&$|FAsh&%x-m{@F<9ctBvG6VZ>~Gu6bbCBm9XIN^wH7X*lUF~--kyq;Q*-hvhp)UDP!7~?RZ(@c7TONz+|Q)`B|FJnWTcJ<{5re+H~`A?6RPx!)Tu>IE>g2jvA`I_?Gbf(={rZYSQ>)I>lVHgh4Jq47n+{)Vd>~?Nxew#4JHT@L(#F*bC3B{Y0ve?yy>Z21o;F4B&YZzb6P0bWKUHm8b%4k#~C{)9W#>5$ax$>)OFF0iW0dDHrRfXD{aQiI;++5W!%3#aK2Usl3md(22=?j1S7F^-pM)Vbh@$sXHAb0R~ZWvbe5ih6nUnIMfk$P+=t=dWq?y^1Gke$KKs}pvwJ42A;8h)T-z1d*ex~mtOwa_h_U5h!VSpmZrLRPsOwYus|}#ikB<fCdm76Jy^+iVh(kTh?FtF#HbH7eZAaK@mdBB5j~1>LS5&2SGQ2AUNzeX^dk1*(hKxO8$vpKXvO68Gob^NzW3ov>Ne|@^%M@57@PW_sZV?4fy}zGf;`;O)Fc@_GD}F7!Y2{}*^PQvGzIYxcSFb-+~MqFvn|2+emof<c9t#KL_z<<Cf<KZ^F6LSpSQ*o-J6Xm>d$fI{QNALg<fYyX1VD?uQlIq$t)a9%@4H|MQ10HFq&re#u5t=F5~JxEew}_R;vrvMUe!2X|3tmp`w4ALj|(R(h5ri(U!%Y0zMMN3B=yyr?@CT<5S@kx7BZ2z_>tC$J~#ER_}HUo;}^om^a2DvjdZ6<Rcm3gewjZ9baC<BFqZUsM=zTb#<GvPjQQOT+-1nV<eGe7HEAA2$U>4t-r7QJs4nuk<0sQdL5o~w7iq?!Pd?))l<GTUi6c77-DC_%Io%v>=A7#4yODXgQ;bNU`nLCeT%7O+?rYz>5@2=a+k(Pw#LhivtiRXRqv(s1m@#UO#^KG5$wI(HeTlL$HqL7)YaZ^T1IN=h(BHO8~QCze+PLf%)&lY1bXtJPg*Y48wqM_v|d4H-{_goUD_9J@gYsCrbKws@mPL8b;HEop}sKA-mS0aeCxN8T5F}Q=$r1Bpatza#`V{E`um9`rDxqoH~rRna&F{GBiTHggK9i8Q@ANRNf%-A1a{8SMpQ-$>z>S;dNs>P3lw912TiZ?j+$N+U%@PltxHO!L(Ci&&@%%E5fmi!<-L={BEEbMvoGkV#y+n*dYO~8`ihBciIUvzRFqQ{2KXZ{7bQbbhsUU=mqS3C6R%`vNSe!v5F}&QUVwI>O|=oRL15b8vN^Kh$R|H*MMrvWNI6XRmfzO08HD|$5JI&JVkA4Q4a?i5HE}0U?W#q$_F~<{#O8L}bg)u0l8y0nGa<rydM&dY@h(BI7cZ*!Jp8%48ZOH>qhKHA8PHbEU`b{3j5BouK1&gSpL+R7%sI(CjUv&3_F~n_a%;`k|4nJzbX;1$N@Jp>Rdr3Bhrgy&bg2mhsLW}CXl7g<W+~{6#cTU}mhXuy)3pl{!$0+5wTd&DbZNE_8Bi}IU>-iv7~N;%s4FEo5m^+d?%NN3I3T1xTulD62K}EfJvl)2SIakw7N%Uzb>VyV0x!n1x;oQCkdE%>diEo9OzUAwyBM$SR>Z@DA$aQNj@KX$3}m(QYJPy(WZjvDixrrpA{2!6d5E)58`M?neY$t4nep+(G2OGa5v*8?o$t?sHl?M94B2?)0(5DYEx<VlLY{#7toUmBfw)4V1P@o4qQ|5C9szitc!u4Dp<;coV~1>vV<c=z{DPX>5o2F+oQj0_pp?4rmC?Xz37|Tmw+TWSd8v-1M4*&XWAP!D!WfOTrgAVXPlffpRb(){&QU!alle?L30{UI<(0_Q$_tMiy~Xjs2qtP7^#=@xp19znR?^&bI*pV<bwq}uEH{G*lcRc8p`S=T-a#1{(R6gZtV7OV2SCR*!gHv8UwS7%)`>`6)+fbTsBcFRUjZpln5g1(fugS>HPDlV;4wcp`dA-7{jOycg<P8NycuZx=8R(7gATYFYsB$4kwvUh2trO|50-A6bhl|kYF)|OoFU_>?ro_;c{Wv`{UAwFOcI`E2uTfSle(_QyiPdPo|?cun|{$mzmje1*|?M9C(vzIVLDaQ5%h<vmwOdl>dHH{n~7^in2ug^+V-09Eq?QPwq#V7d09>iV7$~9s`<dlsd~w!A=O1e_7JFC*Ux|DY}aKH)!pefVzV7Ndr}XQq-LG$d`xMVl{xVqC(+T#3K3)=@cK>MPKv0Eyw#<>9=MP}uUD@JZ<>Jc)jrPxIIA8C@hx0Vjq6PL?9vR~6}D#T*=zfe5F43o`b{)PnXT5vM<B9X^iG2?=scY%=n{tFqbc_$og4p-rW{M$0Rc=&q)GwHSY*z<n|g#`+<$Q$utxudTMXqlJ(JTGO_F37@l@6#f8YcTbKXzOzIpbVxgTtMIf3Icd(+!yuejemHQX1^h_a;ksm<Qha9HcvJ8)0FYLO=yMN_v^Op{1ZRmr*BOjk^~O!P@^Kc3KxdFl$7Kv*I<B3?olRt!qr0-CI!c-OyCkMd8yX##sAJ<oF(18YoxQ$$KJ^<bMP-tBa!teQ$ZkG2>A);nq15Ua`Lx$js3<;<xwIdeXDg{0y7bqjZCvB2c{*P=fZO*>)%2se;PsKz=b{3JG(e&cRWe2OgRz!T$^2sI$%G^-qM8ohwD@(i0)Wp0Yw!RVAYhup21%KRN|x}qQ&CE;xcxuG>9PEM{TQqm@8G6`D|mNH4q;xUu55oS#;+5E~_K;Z_4(ZBRHl>wgB6G8inm8Jew9pc0cv25L6<!6A)@X*9W{8%^MaJj>I4LrO0&+mKs^kwiKsUrf3oxnA@4{ca?u3NGz493pOIt(54`qeWF<Z3@;m9Ra1NhAO+nt#&)&=K<T2-QOzRZ9kMDUlhs;wwbrrX@WF`GQ1|(##X1$Oopq)f%Z=9kn^I<cP&ZO>dfO{q8Lw?-xE2itn?Kmc=D?YwnxPSo^INQ!J$YY86F|{+WgJ*)V93$m2-HH9?SCONSN)t-P141sD4#0g$rZc?mU5gRtA8?#8XiZ)#ysZ!u6qFl-mnNek((S?}nF4)M*&_b2pVfh>TwoVAR~V|s=8CbQTyog#U#es^&nN%`~B*zL(FWg+G7tHJvjl$g;kGQL<#cM4Rwq|`5b3U>iW(nAjWiH$B=aHJu8(QDK)cOkn5L$a^gLkLP@*?q3xi$W*>!(N2;4wgn@eUt2dj1c>%%kgM}b3i@7zb78^T-gfwpyp`6Ir*Tbrf+m-31pOH>S1Z7O?SGV?hXf}izyl1;Ws{9LboulpX9AUBF%#(x$yzjez9wW3jpOW%FC8H9-R1?S;0h9)e+hQ%EYB!p<|QW^<sU66R)2Nvi$*0hNX!*F6CN19!-HN&JWhuIO)h?vV1&z20ArQ!y7DUBqri;U;xnoB2&AlkM)f@z5qK1tIafRZ~H^kCo^=Z?>*=#`>kGCIc^?Q6j>CmU6IYEBfk4%G_Sw%hd<;lQBJpeh_XL{<<^zRyw)KTe{+0j(#LU8IUdCHk{;qEi1dQDT&2!{7aRz^^%oLU+^VYa!1R_B7k|%885<fJrcf3PGt<BB5vKJZzh~UcEB^kwC1UIvIBRc`%h3>{P2nU_^`%}CxHIzH>NmbnR=5tC2aggFukuFgI5BRlXZyeYOq+Ij^6Iy|*tE;I8@Z@Kv1~7WYUa#p)Vt=u&Ap|VeLQ!{2E!{S>%*CIC4<&^KPjyh$I&+LCym$7$n8Y#q`aoNu^_7TgTd!|+UBWgQ(8NHFN?Ok?!6(nR{IUnPs1f*dkOM_r?CKyEU}B4lAXXYP4AVvO-)+Wr&`;=YpY59YM%i(u(3W9?79n4f-~{6JWKraaX#BS(;NnH?oJ!gw}zejOK%*29~#!6Zp_oa&Y=v;kHa>ODYp^KD2>^AZAR_&O<^KfqM&xL7oULif-DSjYTQD_F^Adzn?kU%sxfa>0|Yl5IE_^)KibthFeuY!x0hpK$F6>7n)6&v8>uR`uB4WOnd#H<E@zB5d=_1wfe|o`*C^l(TMaP+snQ2gK{`YE;85}@XYa=bU0}CY&jPZ@W(5S_gAKh*F9k(xRO_{j@$~M+o`2N+hs+g!=->qW5idhc+wR@)2xa|=!*P711>7q$g;lK;ZBXFw5bf}4Ay_`qI-oA~lBDcV`l&0w!631`KM-cY9IQBlqhIhiR&08KV~zL-HBXBqqz_=8Sb;CTLwmP=?&r9%;H5tB^z@+@rsU|8$-9l)d&1u2FUE?cHrxaDncif0X)cS?uzA=&0J`*XUD57cpCRW`E@^6dfAKdVY+M(dSM`1p|6HfXom_E!+Q|(Z18_2<WL3oRlVdzi%oN#xfE-RFJV(gMG1Z3-HO!=|X8k0fVyHb<|31-rp<V%W{jq{_d9RE14uGQ*y*)y2I$=5TDMo!G`;`;C=CHCKw2%3Cs5!*MP^M{vd0Gmb`LaCAMzfoB3h<RKvxiJJoioawp>r_S3}C|Wzlw$v>E}~N&`uyh#}rIXLB_=^?9u}pGsb%gbVkZ^gaJ3v%&}}_Qx3<q6n=#M5ki=WTTE>0i1deJ%QKB+AjUJ^I4~P{UDFj<boOeiM&#O<M;B+}oRp&8abX;E59=U$<n<1Gmq!B@|2)C;cJOMK1^>WQzA)AX_nTG9I{o(yXlewP5sWuix8|Y*r6jJ3ry6rg6vpQJWI~MWh{|H;3=Pn_w2nEP32O)Wg;mY22{QzUAQFv1W#9S_I%B&8J2S4CTwwJ<J2gMsN;2!T<8~cTDCoRjRd<Ps>Djl_s_rSqz_-_gpq^Dpq4^7ug{Ky?BhrFrF89GiO=^Ck9Uof7k=S`@Tockkx-+&JtnFwKv4l?@_;RN;*{8qpPH~lq8GH~PDuDX_6c05^g$7B5k_&J7dt4+r%JccVln)rO9jMB0`(Cp&cnJ*Ea{1G<NGJoAD2g(5w)X`?MZe1KS$^&pJQRxVy-Z`g+PBYwp-fp-+AKABt{W^PFt$3J<+OPwE?d5jlkA?2!^)~;TBi|p*(DX-kK78$VfdI4kEasoC{vX!jp4qpVI20gpT7*~Z+-}`4@$t~^<fQmk!0LbS7s@`9UUFdd_S^|+98qva3gxv1Ooe$!Sq-VFb66fWB1<iQe`@o=&~ROrfO0$5Wc0>*<0T}GMpNPf%m!h@>C$BHx+4g^Fgd~b*m?NkAa9?_&^F@Y>ocU7S}QXyBMD_`hsRglGsb6ZoO5_39`m4{7&c1ql~4ev<uT<jwe<g^8j3)X?$6~VXsO7w`Wb1I*y`g-V=X6gx5rY1R988t=V}kpfb}0xA@<JBHoV~0;psCU9{$+ur}G}?D|J^g6j4?Tonie(JHZslqAPl=2##P7YfV~euh<p+R3<hS-|EbL<ZK^)1t)2w+jqT3>JA9M1oL>CC$bViPC7EVm5tfXj2p%4*Xh#2ZXTKXPF5QYdi?=i1Dk7EUL^STWP&4kNMsU3K_a%kvK*wfI%#+MoLL*D6+0A{C=2UVieac@63P_$m;s+J-rMu5Wp~I>`(2Uli)&zZK=6qUF)+q_$cH8?>Jsro0?#P9P4_f$UQf#3K8{S%lPK%juG_RsJQ>Au`aCQUgr`w2v)tPIXzOvos5wzomi0KIb2?Gzj!6M@NAUi;?acmM0>>IeGGjsxGM#3G7Ixc0=W=kBb~6ioxKr%yo{)KUh2;^Y}!*-PSz{w6gukS)v>haC1DJMS&eN!d)?kXP>QaGK9kgFd9OGPwB1B7z``zLXYQ!<)-&F*F9P};hIY@d){)Dv=wtClBmgkZ_#hXlu@x2Rgqhip7h%n4F2L*Kc*(^Ca$D*U>L9b`G6^4obxEr!iUf0r<^=nP-W!E}58QnZP=y;FtbRA0>2$!d!{vx5w!Yy0Dh+xBYDBLwC6bU2Fe99+Ar5x|5jz3r16;+S?(>+a62$fDbQg}She;x+-ipT&>G6p*$^K5fKNdGRTc&;ZeSJJcs};g)I+$8dr?buBH7x7nh4HKIWF7s(KAgY_!C^C3H?$Txna@qgaZd_TzS)}ovc*yzYdAlHD#0^S1P<)-^v(5;<8y6~8D+K&mDF|I7@)ry1LD>ENb=5Fy2z9wz(>EKi)?Q%t@%+<G)S$N92pylDrL4}<=J-f91JZT<xEC+(vG@9fTwPQ1i{iq`J(k}f>jA#ZYuxd7!=7*KXhdW3|Oyhi6~MKE%)j!$NqxAWqLp(k?=QMDzECG2S#t`Tvso`NuYQ~2MJ~j#T_tn(MK8BP?=~~_jwX9PzW1z>Oc!4-{@0n40fDI{y<@)0I(iiO(oV)gFV(dqp{H=Gz-};c_8A;hwt*R=*krlyztMvSCQhl!Ji#0?e^h3x_j!uoL({Ay+%dCN3Qnul3&%!F^yS@O>(QjY5&LQ$R{Q_zt6${<2#@!)>t_1fgzu)rXIO!#~S6ZR=|M3qodUPg|y)LmdvKouxaRd^dz=IM3mF7G>wK}p4nJ5Mp0RuBrJ@c%=UC$t$KNBQ;1d78jRYV@ve#)-bS;f!=OmHram0;p>;|)T-lT_G&ulbNXQ#D0a!qeTsB7{<~*mtficiY2J3rn<Dn4+gT5eYHegl-<6}u?A_}ow7wJRzoG&1pMld1N`0A7;e!v7N>T;7waU$n6{9W`<H;O+Qve<P4k%LlFKZT2)ZLGOqWMPmMp&6A;kcjkZh8qW?MyZzrGS<KUTu)yShQ$^P_S4jJ7G?JI$u+~`0DuXL4|lw%*7xMk1)|N_Sn__NEmI_Tp*N`rt{-&{Oz5VN-pb&hXGvif&aK^xNOr);5`nJXG=&$3_IfPH#RftluBzUsdbK81G9gK=;=P$z6U3o5lb1Fmz|=t+ma0E!%~HP}%TpqzE03!V@cf@Z06jO9M)Y5aka;_8gPTVNng${8CLZL?Lu2(utcu!c8r-f(5zSNlti%QEU4(Y0o*_RW@6~dP{y+ORHq57JflkImFYlTBHle&gz?#2wS(sSD+1%`+K&7W!AQmbKhR%`oM35j(XhnvE9rDF36l*~z4ILr*!WusSm>|1mrY?7bq2!)f@5D~3y-}N|=jIuL?VKp4K;(M6bLz4riO;Y1PkdaBGdH_pM@GRdejqp4z<Q5mmE*4d537O`&AR`KKWh};({YjBWn6p{SiJD{uz2xhEM9sCEM9y8i&wr;ES}$D@%$4kUV0gem)>8vi6HwV1}btC{*Dw}L!BAFRbdz)VM>;a)<Z&I%PvT)ktUdNX1Ggpsb{`NnNEnWn)+X|8c*McS(!r1P8cOH6b^$K0fE#+S>&WD4k{wd;sEZq01I%u4BJHoGSpC_ViGKVqu)^>ZvI?Wi5`l?;Mqiz&Q6rqXAKH;*O|5_i#}H6qOc#05kDUjV793l2JoI+*S}XM39L-CmwRb&@C<jM>lkVU$b|xf@qd2ZV)6vf#&@hI_b;^S`!~$wcjMP?AYn!!w(@`2mXyaQdD2o+&N`nZRmyU1dB2h}o9^U8r>$_)4aIh3G>)LQe}-Hu@L0!w-?Y?|4T75l4!{odOd~&gi+4*|!Nwptg<}@7dkfR<`k+*{Xi0SI6t{Rvk-Jf+;8$$+dQ)>&C0T9$Z>yO6x8JtWd~G)P3*C=*+IQa60D1d>eRBhZV8%C%)}B=G@?PB!-nC^{%Int0EfsvTJ-skmFC=|<q&(7|LiF<D$bG*1(Q<ybPWZh5gc`_dhRhngD6iQ5wUH%HH|P{5P#a0!EqnZK@yPzUwMsCn{>XddqA#pnk}12!Mfb!-14dG_r;{;33i}D+RT$4^U@|=5kK;hSv^rjfuzL)b1Ch^lGudO*Ore3|*}Q;n%03ui+{+LVAE$d22!w|BxNqWf^#ye`Y@Wku_Bfk=WJ6SNoQ`C4rj2v82Y!@Z!kHU~X4WU^m8>%xym>2T8KRklzu9La6siyZ-nZ34T?`jXqAKKj8ZN%Pf^3$L^1|{lzT7|UQ51A?p<OQ@>z!^yk>%MH#1s+t_y}7*(3*U%ZMy7ktyL;9IB1cq_O<d3`&uGxyAIgnCW_V4gWhP|Md>lCZNAZWYfHeco(c3^oxbDGf42XZ?%yE522zy1e4ieFCldy&-?FbGv&L$D>&#@<&FZs{)=`f#HmnERqgm<6yp=JKV(8p++-0j3pgPp~0UsfMYNFA71AawQ1r16HjFTQD!!=2SDEeX=FXmeiMcER0M8rcKFjIGJHpdomMomVVQkcAI6Hz)fceB3JJu&35<e8$Wd)V4xjZ>x&!KAP_mQ(WqU?*?pm`O%{G_hQ1mmoBYs$7}ub#qcoL1N2@k1mvLb+B*FGTg>`BnV#ksHR01SaQu$Io7f1OiEk7zeuv$NYj~#N9JmgOc=;Fv`;n|6@ho^bk_6vzkYGTbiE~ft!1l;fRGyVVUfDu#y;H#Me1Y#kh`932ITyV7|y^5D7Q#muC+zRTnvB0Dp=pWXRvNgVhnl0yr>n>8wCfPOm-Hr5?M1=nT&0L%O+rna{q0}-kCdgUgDacN7VigxIeSllYjTk&R#G2uf*Aa94W85#BGe`s4BPWg}V$zj*`v3#|9|z9#DTiFL>M`fplLa^er95#2Qhd%6E$}7GsNgWBR7-tp>GF-?PLwD)`{&$=~T93Xz%`s;w^;Pk}1)9E){)3?ZRQh67&3_iz$9!%A|tm5>FWdt8BDf@I;1b`>D!STQFkR3^qUHV-J&(|1oI;kn=kk3}tvw>6)0J(J(tuqNJH^cg<fkzwk_UgyNHi70qmg7)N5q$usuLac>1M=1kcd+k#Rsc+J=DNve8rV`64M5wk2?ov1!m<imN98P=8YXekR`_e!_=2o!sGbwGmBLl#6)Xal)Woc5_Wr{0J91*SnG=!oX7QlxlOJs2VuGx}B_D4v3XXVb4wsPd^#6CIS>&{dN_u5zEZ0Hn@9H+0_d(m&{*ZR2i$mSp)X&;X)Dz)H=C;S;#7@6xt?QDiE16DX@HnO%k6IzD5Z#j?()9<-iRrDWZS??n6Rpm+QAg0tbL{0ptP)yV(6N7ZHK=X7^QKLGk621cltl;vR2nOvAlE210tB0C`huM?+&O}40Mz|Fd6%xCJV(79I2yhpof#bofNC*aj_<HAzl$&Nj(A04HK`9P~{)w9s;M{bb$zw3El?B5|+MGS*2}Wm9oi#7)xq=Le{Mni#S%m&Njc6sM%(`x1DJ5n)PaJM6XR3L1V5?dpkU+~YihAX(`bY^C^K7A(suV+;pP|}NS<*RPS)PghFx#Viiz#uMm}nGMZdMpIz08=+kw`jK*>(<|Z9R=Hn&0-y;8RqIy*SvuiFA%8(y7HMNPc>!0YFjuX5oQ<UUhnGoz@5cb>QR**_1t3x-92dOWM!%2bqZ5O_56^?Zl|(SWmd$(b%r;L86ff`W~TqJjfgNzU7pGk0<HefI;VzDK3k_e;_Xfk^0nhb|{Gp;u=nXcy2x})th|e+dGK(sIpAMQAkIWgTdoIYgY~_#sx#AE_UDJMaBBg%N!4kFnqoLZZ8q&xr5*M>2){^6nM?l3Cga)svJy`Mw7h*0hLWwl1%D(+;NQyZfD}Lkz`0A$Z`L3<RI;-kZc}eg#86#2I7((ax6QML(5-V1b}|*>a5O$?#8D61EKA1!wDoQwuTRi)@i94C`VlX*jcoK<m`ahj|&H4yP`QGiR6(18+Q|8)T|p@f~n(T3?HbQBt$wJEjU?}?mcyR@a*6%WR>-6+OZ;#O(*C`4AjTK5x^{Z6jGUrEWM7F<t0Lhs8^K{moG-C2*L9K#4jB%V-^>dl4CS`OOk(TWUB~;YQ{o2w)lukjGOFY(tmxBC8H@*c|W_jX<2g6B#3N|CCIS$=unb?&lRMwNm97=kIc!uZ$dR(Y5S~oy(To&Dq@MMXFgq{;v*^WlebUrWRu!8<&y|4%DTB7c-@Krb84p3I{^!~K@nmSMgzUKfd}ACij+(my*t*&C%<Uhc%Pdhw34my4+?99pYPQy4b*Fs?afWsop7V_5!HGhA@*96f};xr&7sm-2l|!ad`F*{Zh&MyHi9NAc6Lgt-T4we_08JLHBbV*o<|1OC!&(5b`#(VZ2A<;!0!<v4QKyji7tBo-MY;8Asr)C_0#ktjLJPBN!=^|OON<t_sV}%@BbsXqT?QGk;w*o{{=&H`2hMx)jM$w`1ozEK=qN`HjaFnCM2c_6J40cjp;7{1x$m{%v&c2)-?_Qk;nzl`@I?gL~Nwqm07}-U1QphhQ4<jbFbxZ>DO8MYI*5sLVubbvDGD%BWSTo9R|}JN9K)3gMnndiLNcyc;wHZ{A0chF<50TnDc^2qw<o51jdnHD%vnfFZuz=YMUrC+2l#1XZ8bXJMbQJsnJDO35A&Qyj)g|ga7)yRBGVJE^8Seq&s95@xT5CGK;4p0*;8S!!VDCXy!48vK<lfcl4`q(TB0bB&!%$q4=JO3Cj-6wIi>6WlaIej-yeKL+Opk(}(pCm?JzVamvE}iEPf7fj|bmtYW%(IK*WjteiSb8Lv1KfNN$QzW2{N#Q3d8huOo-TDt{qR8Z5USX((rus5)*$VR+GeZ3y11}{>uICLn6m|Cy--pL8ZoEcAbqp4ST55_yUolxI00R~+I6hB4F5L<4_9hSrGQh)xa`)x#8`Bzn5cGIKp?;-Is)mQxhUvWSvCq%j#N$yV=Ic9-y;udOgGSj{sx;yblgKk3J&nkJ?Y|WO4YFO7RTPQLkQFU(w(@!^6ht+)R4HX|}SD?b!wTE@JniY*3v7_i06@mtDP!E}L;P{C|)U$@3=hljEp_=Ak_NGC#kLi_Jv*4Uhm^Wbf6<m|aH6q2Mp>e}qdwYHFLm(&|FT<dFL;)hO5^6H1<|6O>zw+LG-6sd5lBe@Cu=usxqJ7$mT^6(MXPvqiBL8q=>b^L28y=Q^I!dbNdX71Dk96cSr*5?C4b{{24#mfnQ+FWdxL+EkUPdTK*>oo!Kbl$hETdIUBFvfv^GRCEt;T|dx4v|!u{~9@C*FC%toU(pw^VF)&R<T<uIbl}9_|IX2$YfjotdgzqvpsG0dkAGm~Pp+yc<slyATYS6vrkSrLv?fwr*DgF=USzrZq6T5}X<0KFo&eZn%d6O1?O0tDHhJT$lGmf}mtioscOL0n7UnSVO@q%FwtSX*~r;;ZY2CAbidYz|JG~G)O%%ALDx|YK4H0s#Jb4=&a-SB%5vsWV<HfZ2MsmiUu){?~0@@Ou9Tvc$_e|dV}xS>li6F7eywvZU(MuJ@BA1Kd7T|SFh2fJswR&18yqO$pJGGwV7ME+bk%&WuZAr>A7C3U#`#m4YzViNi0U8)bK!+hYL%{LLD#R5&xi%lOJRW6j{uSL^3*L=PYY@Mz3kFT7JUdQ%PaR8hmgpXoAZtiRrkQWB6qH;nXKiD+>{Rgf(KKKv;kyr3P*uEKg6ulQpcnVo_%bg>GZgGGkX;v&Y;>l<#wBT3tZEYkx5FkYw09lhgI{?<P5Kt|qhPX|M<;GWQ3L%-~wyyV+RFPKoHm1y>ua#NoW;*4tAZ$reV~7KK6vZP5VVsz*ip9nJ$*DGtm;Rv9vUiH2YUHXt-dN?hcO^?f6K0>kWcn^p#`Ms5eIDACfwn@3mFrK6%1PJ0}<lPB3S*p7`5$(sy=H#J5zDsb`38Fymh4%MqX`A0rLsyN72i2)+=v`J`lg8V*W2zAAH|AdkZlgx=`U!4;tdEjdr9Q_3IqnIATLK+m!T2MP@zkfQHChnU#ji>a^#RLH^Pz5)Kt4Awhcz<t)J?oLHv5;pZ{0~$jdcYBC>Qg=<6Q1=pd!!x&%FDv3Q$tUO6&X_L>&b=2SDW>VA;9zBynA?zN(mDDG=0J<K~GN0N3JwtzOYpJj`j9yATkyCWHH|@(dvX_V3Zhd<xP+hhj66C6swyals}m}1e1~n0kc;I4H=l8Q{qnBX@P*^Gj(-VNXrz8EJFC;DVU#us&GhoOPj{Dhu#sC#H~FVo#z5T5F-Mqt<y=9NKKkw)J(`(+T%=IyxY}e0Z5|Vtj7;J8ZN~}bwFHvH_jjfw!v4tYl2k(LqVyomB+pRxgZQ0Vt>cp_{Z;QxZCmPrF074$d#uV6?89FnfAIBr)=p4qP@19XFJ&XGji<=ttXc(yApkL>B*(mlM6P8HVrudba5LumWPVx<Pb|(0U`pwbmo#(=1501r}>s_W5k=&yo9ALtd&bjTD};CFG#b|Q}ay_EvxPVeZN@FCkCfCeY>>$fn}?EhU?Y@ce#h|AcS*^)ej;XJyFC#DeljIEx2~J)}8PHGJ`?ob?-#EGC?ioO5<e8SCI<k?784JA~nsnwMN<-p$FPF#$p0<WNby*6Ts6Yx+dd2mlwhPMu^|Bh}RD!MPR!lTpR4+kc6oayM~4K!buybg<X&R2?~xl@}v^J*OH5EPQaBf>E5Qu!fYe3j)X4+7l~p6hvqlNl70w3>|7&uxDjP0$d`~7jF?hB0(lCb6`6H=LLxx_KbJ6j#_AJ27tOp2pVP{hHAHhVWK+fUDl!j20E-l@fujheUcPtqx#_8o+c)0~Qv0EOKhR9$>STp7-~19x;3X6j$Vp9QHg>LgKCIo|%_E0~lxA{MpX!;POM9vqT8~=u%3@3-8W+2$WF@&=N#x3f!?z|vGLi&DU{v5|Q?1tv;^ILsHK64<+(*L7_}(`K+@`}zy-Dd(hxJ?9F=O*bnN8o?@w3j;KH6S9U!1w*CW@G>s6&gA34WX%bebm(`-{szS4J`o8D$Wp<&|>nUA<VwAnKE-jlG=S>cu)4s~yX5V?O>12e;JL`3AfsHq387XoEXg-WXTr7<qkeVmhqfm8@yUGMBU0r&$JZF^Z}W|4N-S|H9my!{{rmKiB(oq@z=qWe|{fqnc0%4?+issWWW@q8284^kR`!@F$_8i!tZZ14|V|@${mYo)}67Gv6NQ&Rcergb%7#85RveEmw`np|O_^wou|XSAH1Q9zi&rvfMckk9<}iyff9Z(P8-`UJWk}lBt89L-<k@(3Q;NYi9=S;bM9lCIEd<;|-n9`hqTnt|!v+HJ7=mZbPX5-BAH<BxgmY5=FzCH+k@lCj3_{7&){g?!Dp>1+UKrBL{g}wqT?utw}3XPv-|@wgBhYHgp3Gnk&4cnpkXi*Sis+vZY|eteGkBFbv#=QuAe&6-qR3Zm5<F+X}yg@0~3l7KYLfsB6h<&sF`zYCmgDxRyj+NIRE-1KWoL0X5)|3scXwAFEI1fY}0*F_XNSgV}AG(^r%$Pgr%oJu@cK!Jw1DZWne_<atS{J?4rP{I%oohsJrUnm=@imueM>QrH-3U|>4LP5LlAiz)hRKa<KoF-2DS?@V^06&KMfY^hLueq0pV_KvOck939x>T>PoE63b`i#^HTmh3QKZP-P>afnyhpW8c2Eo$tHd@q$)eVPZws`(>KLuL#^Il|Z({Mu7A*X+vGW1lMybCEwkW5kUZw5~gk9i%B|x3Mz<RAxh{%W&$jHq>WSioN6xjZj4FPzm>p&Q#jmP>BSUFyz54n<&m~B8Gtj`H0^(K=IdZ6@Z^xkBF{q!|k%d(yqoDs;wTzgSa;9cH`icN6b)J=rP~PP<Dk!guxM@aK3rHk48^s@w&%=RfTP6!%AHPoXlXpA1ThcgAu;)0%+->Cv##wUyna>zj*AVCymiJLJ5<b)GK7hDh2hg>TvLfCM;Cn^12A&foI1n%TuaZ7nkH<+2fqYzmw-PE_}ys!gfmMHl>qx#nqIagWdR~rJI{AFtsDFFt&*;3qG6M$Z>3LtCYCu;f34jZ3lnkG3&L`c2-Z|%*VmWNdy$y#18j}BTQ_GfCWtKqb7DVUX^@l?-f=Em;c<v{&~^_SFSMU_pf?99e2!qIlZ6MJBCgB`1!Enog2qdwO@6O)6z1|tzRttNei%8;CL0FV{1L)wpko>=OyNlSL!|e(iiS5C|vc0bL#~MvCrF<1cz22wTjY;XwDXtbZu}j>ikC5y}$(<opdu(6D5^u2z#53>F=tpk%*RGRW#~xcFe8z^+WsCA4#s&aS3#1C(yL<RzXDiZTDL~e;<9!!fG78?swUB*&(DiC=<tQI7g9MXsjuK5_YrU%%GaB6I`*8Q6s$_M=96PI}G!142BVt28l`Lu}59cc5p@EzLVA+BTH3P6>pDW@hNQzZ#1y2^O&i7#>^REj3o(TY5ziC6?5;9g4wI_#z;sL+lH(r*cNeVXxo9h!=D5LWzoQpg^vJHlR+uWIZei4K~d|fNuE%B?I{+9vNz}RXB;W`;#bo;mT+-XH1!m>4WDvpqh2Tw<)b%MGvcdwKsrh9)I_L%o#`H3|M{QTG|puEe*I~z?Ssy8F`9ow-ARLAO=ghyTc+^RlxEuJ*E<OPOEp-QWFak@6574PN}MaG1J5#1XyxxEd7806Gpu}$2!#lmThh(LvgDikrHNwqPZ2@hDwM>9gSAq(fZU@r-_0xo>cBGvK<FOSBPuU*4T?d@JB5S$Ez6*L6Y=)+*1X_%7JTN9pgcIlR=j$>s$8L99m^-`iaOMq_gpT{^1gJ(dPAV|1kYeRF~Be+b%ygMYd{+vL$RDBEGb(JT-Pq_uyclUy}&zyK5IT4&Eh913*^$xsM|}s68`bM*(G6OnyDzkVC)5w%@)<d7<hy;3T}j<%6uu(bQZ!yNi<)rRBDu99|`K1)G>%R=vnHPGVq=p#fhacC_VzaObM`AC8oq)L&NK`7n3i@ppUZRNb*s7=uLc@feeS|!Adk;rbCp~zA)GWK`ot^h_M{$y`N~P5*^V!A^%x7mn6SrN%C`Qt%7Xj!ja~sKAr2e+(TA#EK-2=4Xclv(0PLuOFq?NL5IX@a7j3Ff|8Bi14A1|O5_cia=RoS<HSEw()w&b9eLjGP`SoZX>#6L?Lnap1fC?XiUW}X<~50LJm~MMs4DFFbE}*rd^ZU{F9k;2nMZ*m>oB=@)B<Bc#m{wT9<aU#7#Hvn$X;{e;eq6BbZQkui94VKXta2g@G<Uv+^W!zJetm^+<dwIllN0h+l9z>Pb_XH`6voeYCkW8G1<6o?N8tIFz@9n%VNa;@qP%;_bmI|qWYu`M;!C+rJ7G@LJd#LKHRC7bbzgR-Qi&{CQna?hTGy#PbH@)#nUje7E+okKSCT~F{cO1a|lnqvtRj5`EJ#Z3I^%AS<i<hVr!Kj2u-21DVTg(V84zF`SVauas?5jM%AEKfKOF&ZZMx^4&&zf4^t!+0yYfnRUxRchUOf>WQD%Hw&<_d7_lx*)0YeoUlEv4zx27GuIotLQ?+()19M7Ttm~=@Cs4+J^<sX4it5p^CWiY||5=9yrbH$}HgiOLkD-r@z5~IHY&%#LxJ+2*553#dn4>TxuJ8KcNRz8mIFpZdhRLw&dj?@iXkWh4bK!>W1#U>@Ae!tTl&P-y9|CxmVp~T@KXt%%lswzB(KIDtS@3vGI!?*fnvs@8?7YO*9ElCS?T4k~0Naejt*CxdO^y}(hyQ-fu2>r@BWJ({?t5oMEo^Ry&hGV+ck*SoHq>OMtbRNa=j75uJx$oLlJvx%!BOMCUVvgbIY`e)`CXEQ!vV$F(VAC0Z|F9eih|A|S)@&V1EL2vwBzICk1KoSVmx3GV&ouRc-1Z>pO1WHPECJer%qI)nHgd8-Z&g2FyMeXnIsCb<Q)>lF}+C!oyj<ZJVw9)Svw|wN_0lSY^5FQ&841W7i9Zh+8aRNVC}#vkc}y(iaBOMN3b4+6+4p1u?+1TE%OL!0$U`A@Xrg2#i9>!@9p?<CPcLgrFf7bdSY3rWJhp>RqBBt>wLWP!2cH3n#BPUSZimBk74-Fzg8mf1{4Fgk9cTV{a|)$;aR>wq!OxsJ|k$ZQtVT!m^b>~Yv%j7$_RYR2*T1qV45H}1CL2|#sZ7kA{q$z4x5Z%0X4`;mtj)L3p-#hWu67jpyX$h4$O##hv0Izz!@aDLP#iyCI)J7yGYJl+aq#(BN@5hi1rwYVRSxj(*DajQ!t5HA7216!1?2!d{-sxD>8yv2D^r=!vs!P9UyVvaL>Fbr}|wXdW)AG2`H}r=!AEz|D3`Bl<|1JYf7%PBcN{pIY)Qlbr;W2U8q4U%ZC)?+wH?8M+2JYI1b^VCtN}~lc~lE=MA>Z-=k02hmjT4X5tQ?rtblf5g+QpM?f|;QR6g(?@dl@z@Bb|-N_oGUUY^WKCeT3pwM12@Tr2f&Gz^wQ9t<+k|8cWuKbc80QjKB|AVny8TWGA<nEnXBpgaoQjg;B$OdbW@^6?R`5h=+sRf_)8x^j-0rG5_HOL+7Ep-I$MUs&|AC~AzT>Ucv?S=xe;?se(1w@7{Bd}qsa3s-IzHahPt8RVQ*{iOaYMh8<p`I3<hq5;jb2zz?O}>X_cTh5%O>q$4n^1fRog*--_h^rB;DPch7`Skqm7^mUm?PG}gA+D2`d2*j*|TA2oodzwY@KqlQ1CQ-v;t20pMEBFb(Gd$tgBBVi+vMy_3)&w9=_>5S=jc;$~Vv_Qx)9}bDu1}y-D`K)!|*6WO1$BfvxGbL-y?#(r-PQBcbQBr1Py~#4PDN<HhdHObR>9K=BEcZtCI&%)AsHIJbL3H%B&AO3h1K;r$rY-yS$=d%(mvU7SfxsjGeFd`4h*r!*dq)O$G4=`lwWx;x8?w0=5U`G}>CTnkvih2YqP!i#Tq$xWQu<?$_I8;LIi`KNQ`nHLy}byr`x7hI0WLvsDK)J7oIh`gspBiA58jQ%mq_Q2pdF<*JmM%N~JA{{xq8l#m{0_U8S*j?xAREIe(i%l56T5Wm&^^PnOBdFU^);u*{QaybxQ}r#MJtCdE&s=o&7<A0?!jJ1Hc!jHb#twy!;g2K7g)^M|)E@to+f3LS>CLyg_X%oUtT!Y9fpK_1zmKTW;p28;-_^fK3ZgVc5t@@zu@`EI!A<Ba@=y2n6-W@`(D>_r$M+xos{c5<<jyU~@X~7egjE`)Ko!-0v`XyUg3PNHWPz-PwIH9;2-A}mWLmW#gIbUzMnu*MIutT(@$}-I6f-JB{Uk@@nRekC49(<QYqGxbOmP9}u%ssZnAZ);Cj55Opv>!am10|6{?=F5|LwL-`6e~ft)kcQ3I1U2QJ%K)rP3TMG;5Ae0NFRiFi6B~0oj9RmMdthRyoFGE2*x&Hz)2U)x~?m$9t+7FOH?rYG54~y}Tl~ij{NXT^eju2A+=>1;E79$@izWzx6Q>=6}j`XQfLTSNnEH6{XT6Z*6o?S?1z9PUd_~%xqB{xEP^!vtXB#BMq~?(RWRbbdnq?+Xw1qnm60J`n5J@V^1?$4GifNhauB@5(K($ksyFC{s-Nk<G}fQ-Q%P0AKmm*tn+y0F@`qK2DRi|Iv@QMxgSLpfEcUSb@L!8E?j^kuX=cdTPJ#gCrL73p;5Jr$47XCXFIs9pHKvI0@BuX;gfp6ff^Ut9|?N7+!HZMVDIY(r>4g=SU%dx57ukv!t2kkxGjT(<LC$xPFFwBxe<f%0mY479jEuCkJMxQd+r7y{h5qPSt>8Ydt#v?<ww!aA)N!X8F7VL^%8qTM7opCL7@L=kSekS<b~$lv2n-@w$02xXXIr)n-!5lPJp1w*`&$&FxR1{j)PJ~pCq0dCBs9(DO%l;R$sHNp3+*qH}S>?RfB4*Hd>V{NZW#`3==z3r;hxTlQpi{;)Y^?6}ORoU4a#u5b`BKv}+KX?(lWEW}7>SBr{mDU~_^){1Q~?^2bKDnq;|hG3#A6VHlVM%Fct7)fm!pzBm~@>B`XrZ?-;2nE_W0{kb3wd@TO|?P6m~-qnlTSklB_=Ej0TDSE8Gp~re|BP{idgIU_%S+(A4iH0A`4uTrs$)-j-?c{db5bUAxOj$0hbLx;APIpIkLTIlcMch;6{@{TFhDCi0VaA`UnM|wMlNzm2tWhU!W}#r-ROkdPbK33O$HhJuWrwl?!wYF|T-wPV4}{zkV;>*b)(p);diw(NvyM@*Mu=>NsxlfuE9SF3x{7)VWf`u<>4L+Ko#5AA*`fL&YmqH|E--e%DEB<Rks(DTpwwwiFVKN&oLnT^2q^xhdx<TvZa4?hYyp7XvL&#;@b5!B?GRa-KG<ZA#WEd*i1H9EtBAtXA~cLpO)~4FnIw^t8M>!VjE6u0yeM@KpPGj;alpZDyAf#&2ZDgkA~qjQttT`p!`=uEBu_L}1nue!JI~f0O(vW%IoQ+23@@xL?!D2nM3gYz1M6FU#VSbi-^onI)h?Vl0g>h6g@usJ=@IhJbLk0V%1Fa~Xs=0TewbUOK-I(9y?kbY6S8JiSG+#9Stasplnqj7A%_npDQ#5T_NA8U?fhGv{9Mp`*?!{uM-Uf0tVZHOhG;5hrX;iZWBu%luQYPT%|8EszeD@=<y7bm9oRhw;Tn6tZo-1S0~`C{9Xqh$<@RfI$H7F*`rhud6^>Y7^~2J8&CXVShJ%q>i&iFp@|06i&q{z?;2_AILyJ4n{uK7!$fZK;WUdZHCZIt;It_PzuORNb-T6!xD1i%RSbk!#0yAM*_o!u*EJZR;Nus^FnX}Gmnw`kPb3MVfU>#G6$I)QL(w2>)k`-(BajlfJRt@O_Er6V{y4lx9w0&L0to^K+9nrKcZkETN^QNDZX7=xzEJAFkk*lc?KqsI3_0-1lbQh<)glm3Mab7eEQgL~g{N^`g0!@6!j%eB_J)U!yS??f84k?A*@=9_$VebgQ4mGFGdM^Pwb$9?!gaDH2U2UN>6rheq+J7ckfbZfFQr*^5kh7SxEjUxY{JQ76qTvf5^1k=->?(A7x^{s63Bn^ha<@5tIQEX5DLh;B6#LY%owH1i_4azj`;#NCrM}aRgk>__2_M;O5K{EXUFw+(E*-i0ClIlRU89EC;x(^g&;9Y-@3{JnLh66_wGh4?#`JnQTdU8?gF8LZpxH@5IJh+-epT6F>iooRYL=T_w*dPY6lkR8c}1H^&DQ!X{S7%D>t^;17sx2N-pp=GaGq4rhEg0kLOY}0NueT3I#m82&K$3`#^J;uR_%v%9jD;45<vt5U(*c|6r&-vP>RkVqh4xAko$tdBg(qHmG%2%avw=F`kt{qhtO_beTon>UZH}7*V$rj@0}0wj&>b(5!eR$FMvd#o(jsPis>E+D~Ky?#{dmSq;-uUM^dv5x5Q`lpo|nfb>S4j>qcR>pXg?dj(0G@G;<1stU#RUcS0oy9S*btR%Uz3BoqbgXK2AdsAGGAA|)1#WWbgHRhY~RRIwFnfJr+7Mnva>MaqkSzU&Fr{_rHJ;`p|vX#Hm#7xlL_M`*~>J}C2tucYV!!3&WAju~!B*`5f`+@8vbO>ODMFpx~Pv;{kw{>j&8V*Y{&5KD(bpg5D!K|Pb#HnU({m=Z)v`7qIv10G@+=uODf4qw(wHms;3`d@uG%HZ9(iO+%5#v}){_W`MmTVmn{q4okdaRpC{4W1@rgxuh1-2LchYxsgKNNt7~P-&oN|Kb*6aDz~bE0jUM;wI8Iy`K8e0BA*8pq=-NZo-R_gm(TMaq$MH_C%PlzX7SWA1q|FGb&A(5OeXqm4RPE9Q@UH1tXuLzh{R9BAL__h*1s0j$8<ak*07A&`^Xj)(lcU2&9|=P|rIf>KRTMISa3Zc=J+xvdd;dNlCdc+3Am=ZLNfc6SBoQkfkr^)HD$!gCzzjV{_sJ8$nTB%$9nbr3-z8#oRan8Z3-!M|p*bZ|V4<_a}g?C*67_K|2j(w$Z60gnQYA*KlECP!EfzIfT_~qC{RyOEsAqm7p>{sfT3>&?wVkbf;Osw;7x;K@J$p(sY+#xfeMahl@EyOVg70`Kc2Mlh;V`i*QzJy1(8M8A7t8!QFvc*M)Xp^%J{Dg=((alQj4Kk#_>G)DiT^+5Qph{;CRinmjq`X;5Fg5OOytAsTU8CP@87_&g34dK`5RX&IY#VT|xE#+EKGD3%T28huw^jHgrvuE7jM@Cxf}yz@yf2yX9T`+g|l-p}BF+}V6WvVM?Gb-gyPn$60<uNUbWB(K_iczBFcokVpH`{QpkI(d$Vsa8n$ELTfSkl3%;n1vF3j)A)R1uH4R@vP8I);exDI=17;s|iNMEUo1MQKOZP;B>$~nHPgtBVKkB1nBCtJW-ZAHeXl-v3rAJ)uAyq4tKP;2RmWU#Ue9YA5tTEGdyazdcqu{v!rm=h}R!|G%c0~?dfjhrh1*gdy<n&IzmY=$&yk~p1Sm%8CTV4>`yFV_D|kT-m$R%|6F4#w#F2BFB{6uDE}r?cqIRDEAoiSMVLFL>`DYGBrFWs7Ew3uy`W~ZX$*u{JCm#?pkP6h6i3&k-6HikX>p4<+AQ_hN8{B<*bz5moTVOV(TWne?8uhX{iIH<AfQk)$JX7A;mT$@CX8s^yM--tp(jTt%hlL|+bc+$7?{8Lb)8mUZKZn>-~bb14%!+LuT*!xezpjTc3Y&S(rbI^4AzhpSqtNsLyxW+-Z)UEmLaa>g~JJMG^n&l|2n9y%|NstSZ>r7$4Ra?Cb8K>EYoJ@xQk}#0!i^GJV=>`=;SV#7A>&aK78JZb<J{%VwXOgJ5gCEzvQV+%&+!K9ZtC46Fx>$4K-fWmFhelfmSB6+I|bI81rPLSA2yXf}z9#Q*#CUgT7nFCaOpLoz1*@7eAb*^Gf06QA4${+1An*T=8l&d+^QKo)BK)J?GgK`L5V{z8K8|>fyLQ%_OC+8@*ap&~8&vwS|{$0n9yt&+W)bS%vZ2o$Rt8hUpFVqNp+~R5muAoNQA~1}71=0JvU~iUu}PWT(KZQc{|j)cS7=BgIi=r5Y?zQ7WUGOEg~W)PW+7RIV^TloGBKwF@V6lH4=xz&K-juyo;q>noii4%MeLwO_ZpT0drl#QBFA9a(His&T*D+|06Qm)mXhtJ|2*OXVT5wHp|Fq;?PUs`B6)9WgW$>vC)i<0LqR$+MSfaWl%T`)x+|sHkFiQ}hmN4+a5n&*<&ejkk`zx>b&9(o(iR(cv50a7{Ay;o7(6`M}(aeX5Hz%`WD3{(Knz8+NhpeE9V1O(9Ftn8K||-I_VwvvY<(m)>VATvoG{vjUzN8K=i4?Z6Bju;WhNE;3`3vAi}b2A2}}iJC1IZYoLWh%j6xOvCM{L?n`CSi22Vg{Gd&$+ekNWGNnGI1YQp18_LWa5ypvlf4u^vrBNhBPWd0V}gn{&}6}+nr6WEpk`YnTne6n;qJtHQFxb{Sf%O@@0C+`T(4e2?qku#?>D5?Z^61eqxa)Ww=suW(&~gLj@ehM)~z#ZIvLKTy42jGZi!!3Bt>Rj*2w)e_iL^CWkkN_(910Qh6+~ZL_2t~hgSlHOtfqGzRt2O79g%J&XuyT&WjH&Y?JPgyIU%lpQ&K6o_Wi!>vaI>-LlgSm*2QwFJk#ow)-8RO@G9S%;W5QE2t^P#Vy*jG^nYpn$DZZrc6@nid`^!dC>o3Gg@jj1_%PMDJ^6JR-1dwSk*|z2I)wYe5#v3p?o1j_@Gt?2I<Zf0~UcwFO_&Xu^<X$40&dazpk-%dL#!WlO4v335E@5AIscsYAUTON#XXN>Y2cZ&~k*t>>G4y<T=QD$NcABhOcs+K{Xd;S=00Ls~2#~2Anz<R2y)Hg;|$3(?xHs?WmNyUN{YtU48xkd}FSIQF!q*q1l-0+|wGV{_)_cwQw{hbNyptt*7T(;-1xL_UVBkMafdqer*ZxjW{I+)xfa|IxO-^+u!zpZ-{zDJ{>lATi!{)r>_@;#Lnvj!dwCOu>b$rd$V6zvOPU0))*@yBZr+k_ug5js?M#hd)>aiJ*s855FCsDfENTp;>C#BfEd&*By5C{u`m{c+HTY|f_5VtgJmN>&=L|hGGPA!SO^42wh$mBB*Y63JYliE@B6KY$lSU2Ij3&btwz2_yRveKjLeK!vDR<+2Ky{;@)A_ME!vF2`HigL56(*F8>N)u&_<&pK*GHk!YmNG0_l6X^0M+FcCT;?>a^3k#!a?T@Gs%C2pYue!^?(?U=B`6sZ&tMZc~uZCEY;1{CJL-FT#UVpL@+UiY$ae?i#$aljeM*{^8(w@pJ+?9Vom&`lq*k4x)^b?4o3~84aO9jJLi+DZALu47z|u$W#}8F0h|4egZ`YGV4_EojQY_wyrnb$&LIG&cAe>8@;jhMRNykpIU*uNRiq~)cv8=s(GhIeh>AiKN)i`BEct}w_b0Ujk^a~bMC0j!Xifv7W8n(Yx@Y*Y7Et#`pl31k-8p7PJsE*o;SiSjA2=`3*?j5#Dx>ku^!W%EaOlw#V0!Gwo4?Oj@cMrpV!-+HBN-gVC~y~sjSHOGa@3%loEh1Fx7VE$2GG}Aok?LR3{d_i|tg^Z2i9r?Zo2pPnz&&ej`P1DYV+mtZTTAV_^L!c+a948zF%OEl&cP16321ACBb9V!DP7IL)%8MmX6rJ33P%%1uS2X4<=?q|Sb>V4jw4F;4}ZlKI=4#)ZZDl?WgUL>?jmm&-4)Ku|b9QuqCODh?2_{sH4;1{Bz*G*1X+Q-hRE_h<$mfx=I-ab_>AP;Mr4y&{634^oSj=&hr$PHnfmW%aO=f@iaBX5cQM01J!EKRf2cJIMl~Qdx9-BJhZ;yz{*q=B^#Bx`IIAoVWk&m#!9FD!5v*R^u)|avnQ_&hbz$!^bem*4MXg@pg4pC^eYKZ7^<|H+Uo`!|}2CqBN^h%#)9}S`L2h{<vA9(l9cPvX{=BNeaiy&Y4{7S>7;Grii+A^z_4&dlGSSe(7M$w`Dfdd5G&j0}4N&luI1GUtWbChnTKdQ>3+V`SuXZ;W##rFE|{9Y$X(Fo7(eX7g)pLQWc-ya!aR)#=SKqwwV9MH|oLKv-0T_T93*<8RIWq@D^87lb42p9q%%kxN3y&UY5oobbRiAOE@Jf^ZZE1)q^#<G0ROt&@s?;vr|?yt?=1>H(Yxp%?+$){03QR#kC(R<#Up0Z5m%z_N?+|omJ&I@&&_@J?kbIg2L(YzBXnxPlZ4cId<1EVVO5;lbyeEWzC6wk~pJv*3_{dEl%fuUzF$bD`Kx-iGd>%=(OVDtV_zU>b{hGeND*8k8q28rscG-ab{cSOD(6H#6>nsW;rLC<k;u-RtD?LTPUL#vL)4^$o@$!f)#^N#vDnWoxN1GI1zLxM@J6f+-!l1JfsE3STJYHAT4_{V03;#m@UTAvd3b-AabQ>NHW+|M%O$?fnt_)4j$LoyDsRZsXo;&<eTU08cY_~V6yar)pYnUIL9|SX1~|{FRyl>mcbfqu!;(>BIe9P_CW8}rX?Wu)tY5no;edj2qPMM%vAe0-{*^7$SsnNQ(F(kUjK|n*3TU)gbx=mqj7d4+g#JggteS$Wa0!&C@8;ZOPD0V?JfKgbu2XMSm9!e94<5v@CW$Nt*N)D2JUc>Dc(j{pV(tCjHUckRN@u#o)3xLE#iK$VlhZulU?PJS&O;82{Oy^N{>#k$MytB*{BtDjI3;D)v~ME^+!t``(xLNwdV_eTFZ43y?!;s9wA^cCX0%gIMp%RnPvCr#vzzjQJn*JO+8&|1kPk;<Ad~Ln1v$ySvDK33o4a*C!3T3af3haxb7F^J>$+?0_tKVcUIprWaM2(WH3{MSBb4lH+X-_F7L45HxL3KP54SXixK6o8QVT(Ej?O((_Az8TUud!X}8LKG228J%1B-fx~qy2D8SA<X;e3pn4&2u%w;INSGL59xE`5*^o9%41TXh#K=vVk0L_#ms4Mq0S;lz_Y0K4Yzz<@w5=OHz3e$tBBbYu7?T2;`Es&NE8VrfF89UG%%@f1&f+Jd!Qatq3+*6A>+Vj?@EAj*81uwa;>8WmjkLbBgG7N~24s?7ZDq#1dZ&kk%pI2Vbj~LHkSO4ISR)3Cu3&$N3B+r*hefUqo(6Odczq^|X-5dv~vrs*gJp*vbg8#&9{kYl%X=^6BT>CSjCwFynwsi<~mpx>_4$7t?H`_zI&3O62N%s$3m^1ik+5=d7k#C_=zgikK;fPkPw-6McRS$4BXbUQa_W-*TzBitY>V|#dcXRNeYk~bAwEtj>G*0r4d03$emBU<T=W6TN+BKO`3Ya>uW9xj#Ogrv)G=kvxF8<}E?jBwSQ-oWK*lSoe4lnl}INM5d?XvDpN3*NadsxBQ!X=z763*rtcGR!x?(_z^0R1b<k|wg1+ZV+g?_WZ+sT<9>zTpm6N}8Z0Q~z~UaW}=>e65}%{>9Mr*W?iT@z6FR<|x>t`UWPU=S6q*q*u2CSM0SA8({tPZni!R8bvkGKxsvb)&5o)Uhze_5ZtV*M81h}^8wjfANtP-a|>abaIsNKSF9axAS`}ton*?6ZCAg7woO)d!$gsoH=36q`o5lqL4n;e2&;g<+eraZ)+U2__cg~6R_Bs8CvnwZ>Z$uoTswi;OumoQk7mI_j9H}A7C!eo@-k61un;opjVQo63%*oI$g;{EC|Sb3C3>w90#-u@1Y?0!HjL$g)|Du4%56o3F2n24b+pUIO%m(X45TF!1-nL1+K_Adu|2@LVcQ8&07ao5nXngo=`bsV2k~xeXrBJ7|DR0?jS1vGXkKV!pxaXeb|RV9uP`-a0gV-oe%R~~+w71owY9EHIm}Qqnzq(Q&kpGl^7?FE*u{%UA+II{Z?<6}Hu(ObVZad64kXN6HQnp;zyC@ShE2L?y(+{sZ74l&(%oYoK?2K~6S|ZSoLNvq#)2FUe#~Ic`6E=Xfb}qS9$y}~Jr7ttIbYO0!&=l2YNRyltzq(C?z*9%RCA>3i~}wQ(dfiVec^E}v<j7PpgL$?m)qc!umfI43PWrLgHdF#9{Fz+Iz}|sNZD0#tFS#t$P)CU&PAqY>xKi+L2%#w<z;G}g8KrK1|dTM9z<^S*ZN}f;XG_2qR}XFGG{E$nrC2ZakAf0&>o6eZ8BmNoHpQ;g=wUOk-US+u2^-rP+)XSSsm?oYj^<-dVEZ%S8}WaB_R$}`vxl0k(z}-Pt;TcA6Fwx>6A?(n2yj6t{3enOcK4jP(;nDTgVKMK_Cx(R)dTW^N8nbOgI5OY<)U4{!kMf@X~>tgNbT|IkQ<7C<n}?ur4|yA#EdN2s6#V%y<r2s3YXnajxdbq5%EGX=@}|Cd%27ew|o}hOketKPc)t2@A0`o<*cY*O{aOPxfGa<DSiDpkCChG!_O{_1=S(T@S{_qk)LA(;&%3Q@5(eypoG`V#E1=UAqE1YFyRpuooKo2^H8WwMvC#O(A5>!J<i8!)HgQ2`=eCSS60Rdb~5L7AkMS(%NY=X;zruD!><FvDP;XUd#?^*oZSMb^u2%fQ)`4c?G73fzI^?QWZHC{^w@nrAAwDGgC|*bVjrT3kA501p)7vmm2nZcf^HiK?i!p0Zn(pw4$8dm^TJ`G#bN3?tgv(S~RwBb8r(MjjL5Nk8VUxg65*;ZhF>l_%l(&D_z?Rur%V+<QLBljnu*gHfKh<?9(?J0L?|A$><xv-8u%=HweqQaG@P@EsjP2FrtLLz2}w%2u;oE0tqMcT9#Uh1s9Gw<D~0Q&$94Uw!exg04;~8sZ@pjXp$UJiWhaU`?ViYxB*th%XVM=s!f5?*Nfps9$hY%Q3iEQ^G;Mqh84~)O^Ng@lu$1s&mdP2y0$d=$y19OdfR?{@OPB1kYaYWR#V6)9Q@Qq4L+idwS%y^$SmWm#30^C?B=W|xCX98UyiHydgY%@xwP!F2$P#H7pU}?kj6m{x_{#vFNrqV<!dEToyHHYhx%3zy)CPCT@PK9wL&Z8kBbPQj;<1{Yh|s8<j|L7wVbM=3{sz~X-%`kQhco>`b>?`2Ftm=@#v&I?ORE7$8(ng*G|vEXuqn8W=gsFRXr3UOjP<<ilI$HV69L1ycpVawEVZIPxvR^PZ(LxFE1c&>nt|yIh&MgIX5`_1i;=hJF#_%o-hnh5TsUBovKh4c4A;SKjZp*)47!VSf<b7D6n(^WmoKP!}W0fwPoL?lHi-C&qP$fsWC?g`81I>jGY3WNa+;PGZUeCa_S}6g?<>xS8aY_fD^@?lkf{=J}7C!q$YP0(S#dKvWYkYIQfDD<Ww{(#E5iWj?T&^24>F)A@?TUb0@Xy%MwFrC59{ahwr++2XqL-aDWB;(W018c5w_f=pZWUF7Eh!ifc?^wOzIL#b{(t(pJkBv08nu=tXiy2z7%7ZUTqF6$Uv7O2x$~QU+Vx+z)19g!FOu;5G(FVIyBwyR3=EQN>egEvi22to0@x^!VtMM?mPS{xDSRf?OWP<~I!6jwHy3->6ovWPlKBSu;FPUDhU!2Y5zs8ijy`9~4PQ%uM_=`jFKhybCHSu*bs1h*5}olvw%iFth~@DF<G_jD3ip0Q0@RT)&%EUJn@w3lL0VNd=d`{y~dHc;8C#isIrkfswhgAmy72sP;!`jMPxvU0OVJZeAd)xWM)0dEGH|%Nk)~BNUHbR~Ztk4B>f|f$Gd@g#eaDs+&>2h9q$=T*H5@++eh5>5#bIz3d9-<x+)(GB1S&>T(nP><}V5FQ`W_D$UZcB_h1$dNnd4B=71a{UJkiIP6||Fwz8GbJ4H14DHt2m|`~J4%*E4<hr!^&r5Tv?kWre@!!6oeW^kw+U4JN;eU?7oAuHU+^;g*BO)rmQU{6SM0>4(FN-4l$Rg4N^Xu;9<L@c3x>j{>0(;4Ah;!N0__D{fTbT83u|Ob)ni$e(>8V5hcg$;$C|Q(nOp(qA2R0p`8|KIqC87@#wLqHwcUx*eu@dGOzt~$>UT9|WOo0EJpf}7EKlpdJzVKT_dwu6nZYi{a+Yy+O48L!=l?>vzw_rOIXuPji2@)}tPH2{H<RH`rN?i&t9lq<_+~H9<b7X3P>#Y73gcV-vU<eAD-6;?=Pt<ClVY@(5JBaj&Tp4X#M-5>X*`oh4nrK*|z*BNUT>$?@P^y<cREo-^%|?$E9<~NK^<|^|ItjCIzQ&<=N9T!&B{&%Ec~oo)7A(MF-;EG*pA_-&u&{{DHeDZnfl*UzrQE~>c98jX>NMVRiof9Cj`^uffSf54@bd5v!I`Wb>1A~$_`dJ99SNAuaJYmC!BVIGoI{PsbZxk9QuH@;R5g%14}!IK$bvhCmNlPy*N{$IPY_Y4F_bMiWeL!N!mIL4L~8%r50ynsD<a6D*)Y7mJPe#$#o?K&&d)N3e3dygSp{1a0{g#irPdNJ#HS7h{xP0Zyi_eO#vm||{FR+sS-XLPx84!v)9jy}xvrJ8NS`tR4GkD#I{6m{Z?*=s4tQGwF63MSy4Zs;xf*OuwqMTFGzO)gHJIs*TrcJvlUFtyB!k7n4)ouiev(|478AJ9Z^eS*_5F^;1CBeV{_SR^FjeGf&dlxGMFHWW`2%R*bCS)!C<74(>UxdHYTmqq8xTU*2p0zrY8E@eB6Rkq@#ZbVwTzNJgQzCgkp}Yl9d;tO6M<vX(Rdg#OO|ykW`!ZrWDAgL^JXV9BHh&k@9*ij80ncav0g4I&VAkCxg#VC7PWD!K&AeI&Ttdi>?`V(m(J!q&(HIuV~ZV(2p-82)dx390~~8JBJCw~<$8YBz*M(BfL&~X7MXAy{kf}eOl;KSND_M_8LUV|2|;SX{Y#4_lPCX&K~OlYESUy+;cThaQy*sHq)=z1{wQnp{v3vrcq!Jq51R4o0F8v}-dhf(&eR5$_w`jb29pAo>Q{~W6?RRC+MsZS_?ulPLfF0R`Jj&)h>foo^A2+05@)QJ;2T=F3b&onZlGlG$uQg{V(K|FW5ySo7<)uRnHN6e8jN44aY}VSinPu#xxu1~xymU7r$(I&-brOG_C|DnCzg1iL6$h2%%cpKJ>LGGFKvkvHT%g1nXQ`c>X>8WCZZ?d4s3#2muJ)XSt$sTQfKJAlVOwV2lXCU^2T)P<`!I(*%JsVMs#g|bj=vN^gt1Fld=*ZX+egJ>x^bM7=A_atJ0O&%M-+eILuNcX6rg&Xhc%9*ioo6k!4ts2Av{0kaIkWGaniS1f@T<lRK8?qr?PQ?dCfZ`zw(FI>j?H5&LKl2Aql>od#z4S<O9e(_4eKZo8px_Gs~O-Iz6Xz^KDmgU>z7`~e=Rfsh|u&>>id#)UIW2>59maREDXu#5&e1>6)pdza{gs{LpgmAMR>ajEVHi{n_BR`IYX)J~>h#hm{C_&V2fXHBT<C4Ie~M;zTluKD*1v|RSbE!RWu=|W&XyX%F0)WSYB)z9lyy{32=qy+shWxzC37+T%eOD{F^`s~8)Qi<&l<(J4+oyDLMn;)~JMJY9DtGe?q!q8t|(j5nv#_ZLq9u{>nM2fL3>|(`-&PqRRg`e6Ae^{^ZYj}F70jt*{1w!-TQt_Org^8Ze%loF)gZys;kZ=9afAH(?VV~;!?*%^T&wf0JROQQNw#+t~;G2P~RS*0kmgY^@)8Y9iw!CDx0#6&ZOtP1IG_PcysKKexUoXl&QDv0*b)VGbX+Di!_HUGPQKG~V-QRVl^_{wAIc;2DwVXKfa#Z&0=F~y`M?YASr(Tk4IkcdveK<-+Bm{q<$`jYBJoS<;tWc-tMD36zYtWg5$FMiQr05N1l*5Gx%t(BG;j%V^^Alkj@|H0>g49_Tk(FJrx10RSpq+r}G83<<#*muYwDfp-tHtB8-vLx#hw{*qvM6oV)VeW|vk5Q7_*m08O!z%Vf1NFkjH_m&fI55in2lMh@~H2IL<QLFq{^cjUHT8e-uledw@+`c#G@{KBgpZ`Y55F?9A@U}a<aW+|7U~IyzhBJ24o&P($s-)jjWH{Oqfn)1S!FGQGF0?lKxU~q@4-UZb9-HgEW$w+M2@-w}vUl%(-wNcEEH7qSaW=#F5Y>T)*zB8xp{o-ZMFGvThroX;Cg=j3@e}r~DwD=2>g10amkcV7_vPt7S_OdjY{mo5Z-}?pA2;CiOpDB+uW-WcBW^f4h8y$?C)(%}02p|K@M?-~4O+w}q1MvHdr{>c8b@{kP2z-GA#Z`fq5yxz6M|Ug^J0t^YQ*{@ZZTfBVqp+qc<y`!%=(eo1O=>W~lbg1@JO1)Dr|R>ka757#G6w~3DAD2YW`Z?h9!2gaV>3-m(u($w2fskZN=UI3Fm2~BJq>+guDqlqU*Ye0}&>ya9=l`o#W{A>qw2^d|m)zaDbsTrTti3lwex7YCNT(Bj0h%P^I*`DkuS;SHTFJYFf?>x|9z2Wl7x5f%C2UVcX_AHKqrHg9_cHXIzJ|TKqH6|K`?DX6bDSZLQ5_lO^v2C~XPn0AxnrZCck{6Dj!(Km&#e-E4JVmT<dw^756r{=VfXgnVzVttSyYtJUX7s@`OVP|SUQa9KMVgbP+&AYGzf35cO<3`I561~srwhT!ue$k}D?)kM9_tpn2??AWxXxrZty}pEyNQzsh)a_M<(|zWrZ4~6RC52~R5Ckphq@Y4vj+XcAN8E_`|Dt=D^C7?2VdudLmM(t(LJzIz?u(eOZQOvJs$#x9t&x|3vR&^&p%D#+~(xZf|>2);uK0|G)6hlPuN*f+og`3r^L(_u?qZQ6%q@{cRVx|6pEW9A`<JRGj{IS@?jNT+@Z#8+M&TJ3j$&$Wm$d#A)ZXp4_)#{79*Z;nD5EEtk2Z5d)MyQk4ls5T6pB)Eay&oyBcewdVp?A_r37Tx6+zdtr}0JLI=U?k>61gIwNT}GZghCFd{TV^F-l_8j9^Pj@4)ysj&jT8Uicff8k<-T|wdmpG!R)W|EX0kr0u06ONKUz@bYtST@rm9$L%Z$urs%Tn#+viIMUqZfN4#q+DNV7cGAXJiBaCu!g2XQgx4Z9K~ip4UbBFhzGCvR!@Fwq?o_^tKSHsZDL{0$w>HBHLEKu+xyV-g}v<f3_5QOZnyd;FBB%E1(hu7mt6}+v$airfnvchD_doR?tNUfwpn+bC(qoR_^h?<WTGG#y%+g7JVVkaBI!#*(z}MF_cM|n-`MCi;bSrMP}2&6>87=EG;?5YbquK=Nh)vw(~X>fnWQy(4Ip*YP8Ep|pDyjXC1scqFq5YJ|7Q__-2KpSiT1IfCB}1CjEgXWm1{o(CvMH<3apy>^ClVE`m1%Ak%(2)1hTzUbtpHy4J^o4ui33g$AvAr24OI&{4DZNcm=3u7N5zc?I`(aAS+I4sIjG$+5^|;tp=B6=KR|JeQFQaZ8KZ0g;IaYmzt9;3y>jQk&Xbb)W}4jZ)<q5TD^gs!^^T<ZoBHGZ5yv%EAUI+g3UWUOFj0tL$U2QKD>f-1Ecpsw-@96QXA7+z5Yd&)4Y<$9P0VqtoVk2HUtTH6>6`ATN0;~Yiv>vts-oA2W#@q#vCMuM0#GZy-RQC*4yQ**}&#Ydp9h-T@E5NwfGU7EvZ>POP_XhK_&}Z)m{>=Q@ZHhid2C8Z^PcVF8PChFv=;rfICiPeuWKYH&zNFi~jH>Hh9vx{Uzh;zN2;Ikxq#G5M$~-a`J*JPjeRugumT+<WIuTk&Y|0HLtqG?hv9;r{*3g3iBN{^Xy%I2ee{5Io?@yfF`530-wM^HXJnGbrem8SqU#ua34=~yg2FVK;Ekky*s9W+0pR06Ltv7TvMEiL&GPyq(!g`n+JU29p{M9+Ues7ryVu62LzM5mJOLi#~wDAWfs1}W;no;TJbwa$N<rQOmq6*TC9%b{d{`W>gXV&BJhN8T@}70$RQ1n{9<)vWfo_|_)zZ2Uyh+P2e`n^lq8J_`R5cH5h~i{L9-4sl38r^NUSU}mJ5s7ke;XG7DybCHUuKo>m_IKA$!+E1t!<ot#5SC5-&WA#2lqeSho#OJZ<k?cFQA5sBOfDUcKF!`!zL)_+G#IMAvR1*Bad+YH7pA6j5`6t79RGY0ht7a3T<8+?S@0fRzzjj+^(HAKi38YU_nsb-cDi{*Bqw5}LZRr{$KW8!KB&o&B4hmUU!DAg1b|$50|iOQxqZU&K)Xm*)5&rvdiEv|v*64W{)cb}IGc$dsEdlpAq*4yZXGWy#i9knsW<zLNGXo^V(18!M=ewG)XxTP}BLT%0Nanhh+-V4urd(!5~GSto>&7Ga0xE!l37poJZ9nrNpcnRaeNPsqhqNpw&V!5S$vIl%__KJ-=>bGQdxIV6I0Rp~Hy%@Xz)q|{<*k*MeV=Q!}4aY=wDoCLn5UbTRvKT(hIzrWVZylTa-H8Yns6(si<9VQ~C(SfIwI%b=Cc|%()s-H{^R6<xgWvUEiJE@uFJLy=mQSXuMnIxvthhR#Z0o{L3*CdRTOs(yr2-TT9W|pIb-4D~gy*Gf|7lY}iwe~(oU!W9xUsrvIs_7Zb&wHMK6IH^oFB@?KwbTP9pfTtqrwoBoR517wyFGlVW=U}60}(Qm8Tee^LPL@Q)4SEKdQqXQh?Hg9cmOzKGO0`q6=tYGaXE6(zDq^x7YXd9DPne2<rlg?^g*5<^*s+bYW-6ajksfHC8MDRbwqOY>W86&#)tw7MhzGXbr+cjC`|GV8duNd78*7H{nRb%`miMoLr%Sqb^8bFX9&-Dr0KvolZk;GtZ(#>gEBxTj%<JwAN)TiW*(Squyg-iLGA^WzoX$3GP<S~<-^F$PNXSK4-G%W%J66sE+L(|hQoK#<MqOjOyUcMn#1)BP!yHnr|m<-%gAg6_b<ZIKiK^`;s1X-=F4M^TOQ<J%p&eNM7bnTiGE_k2p{{z<|tLt>#*53jTwDY)Oz<OM}pWc@uzIfe^+3)DM=U_CAj|HEStsg99UpZ4Y4YL(IexfdJ*Td>9OE+u_?wvHIBD8jU0X%)~7vTDfrQMn(0kp#5aWz=#_ZWKla|Fk)%&s&xIC33J9>5*PAp6xa&_=voG37&)o730b@`AbI;+HntAx1jy<8dCjaZ*Z@QeC%Xm+9=AVGH<fzR@{smS;?rVUKx#1v9$43huiQmT|JW|Z&e6&m|NzKzyW~x4aqN1&d+}Ooejyz7$GG%#qcsq@_zhfF(uW$Ak6j|A|3(VbpXR^-Dke9q3=oE31u&Sl28W$(#Ct*-N-V$@2v^#whVFSsa<hk{GT;79uhMRg}cxZbtI4C|ELe^XA-0=h^+djlCW(4KJYzerzR3mw#8W>NkH=D%Li7w(zhZfS)f8;Bgi$v-4AcUp(w@b&)bpD~9j&&C4+XSz2eAclIrWqxv+>J|rQER6YNSwb?<eI@I);JrJAl<`DJBeoyyMnn`oep$R{9$TsiB9GiG53aBA89KRsT1zFJ!Zm9YhXA_7|2=n+rd<FlXkxG$Ej1QAT~l~&wJb`6T}9<IZ5A96e|792^R^l15fgHWh&(<km-pl6lg$-xO+GAy?>fLoJj2Zi6zpb*rPN-q3#wJ5TM_&a77i{2yUy-C$hl-B8lwM#Taa%a5Z5l_=qG8A)!eW%ZPmtn`N4*YTLuGVUg>q&PsYat-7Q}w0fx*@{;m_&`Yr{iKjq969x2>iX#l!Ro<23Eh=xEFoPZ%P2ScGglS~T@nm|o8O7hnrXv@u*5c)1%QOQM#ezmOQ4X(N5I5dD8zD`A#RnRuG9sf%+MtGk1ec|mpw4G&U@KAPH?yxaIjbrby|s(=YEKYS2%-gT%zRzmH_eFM3>*27ZVtwlC*bEUg&^(PIGfSVStNgp+FNmUpC&Se1hOC+xqfnKTyY+4KU)HbsZKnh<tOpNiCX?X_TFH%<%M}pSI97b3L65(u8-~HvP|Z5x=AvDXupiXn@oT{Hz+%@&J?e+gGlL4dguP%fJAjh3n_6P1a?aX!SwT^%Mj)=vQCKOE)<mTtkgo_J|@NevAGQOl8zyR1y{8y&E4?8xatui<&s{C%8p=KfhkO?Vh6gVMIxhXDDjylJ5LWjz7ezm*1wB4yVgxX>_6=wW_{#Kbv?@#fl-C*KFGSWh79JF!dT!884X4}G#EUa_8VRjVA$=b1W(kSr+g|?Fw8;yTt$RIwrVGAX6cQkxjE4rKr5*)YA$f0@ouj1ON0**TQS$bXlAE%?lIA2-|(Y5mfJslZ}EFo`QEd{mtHdPwdH+jqJUOG6G-p$F6Ftq*~8b%Bgzx<zQ#F`;pkbe@Bp5ffUz@NwweTN?*aX#{`BlbChw0zjSQr&t~rqr@lmARFTXh7se3K3rYXc;;i8Dttdq_iLujw4E?x*5mrkW6tmiwYyx$6dDpb-CeW_=A*?yahwToN)y3t!KGj^sczGbhdA?fK9X|s%7^X#u8K9VF#Vecc44PO<^Gi-`x5;8PN<3M=!0v>&?7Q3!zXXl!vm#W(F+p22+(-^$IRplK08J`x_6^adW@J5c`1B!8&Zn#k8J;$KrD$guDQ6@DX!HF0jbl3?eNmya)zz{s(4aoLnN4BC;fB+yUx-P3$K?q#ka#*(E{0tJaJ;Q~qJ<mmml+`cU+`!)+gJMKMnGd%OBhmR!>iNC{#f<}yADu8o0rp6;$$?F}z;iLE!}tX3DJ)@Bp`pD+xi{dvCLsT>XfDV<`$|LAuK!T4{}Tq#jf=lNoUi#BWzku1n<U(>HIM~*;&Lgz4=!TDMD2TFOb)QDgxF}Z$yt{{&y`1YzxwshK$jBbNz1!K?}{wX5V>OQt>@@F<~s-e{vj~z_jG=)`ybg>rAw*yQ#ac?J;Qzgy>wl%%m~b2*uyv}<iR=Dn^2R4<k^MgxJOf*g7n$<8IY_xaonA-9%X<9*gOiH+aD$N1!2h%9d0DmVwdLs%Vy>S3wB>YwY$IJ+H@r?zXk)Pjfok6;~?}o5zULi8Sv@i$2r#`04vSP-YuJV%j8MEbS#157pe2zsgiBhZSvY`1aCDPDF0ywyEx3n<ONAu<sGU1c7}G%-U!CA1%C_~(6w<CsFX88kO&AvsJUIKe#-1^(4^%%D--Hl5u#d}>~=lRTRL9rilx>Ms+YZHa(qvhO}Qh~gX~G(CQRBtvMkvvX<{%id2{fCJZez>hc~8Z8c1s?`jeaGlPU2%8gqLqDSA%Yf>;glQinb<c)9FA0=ZSJyF~j})01rz?AJ}@`)fb!SpFzQ0#c<RK9ruR&Qo4u>8aP?0(n}asL-U^kg{GvTI{ALU*d{&s(R@RmR+e3r0#-sx>$~3?O2mdgKwOa1tZJsz)=R*(EltMq-1EC&}synCKlDoV3gDMbj`EWm9B&W7@b2O0DeH825jQa(LL2)OA3g2UWeF#63KH>0^c^1K$w{7m<fi&9o~>Bus1@cAR<PCWI=3*5#=46OQb|vrxsH@nD-EyHLBzToGA+q&$PKec^R8O2eoI^Q|QseiE@WXG|5SNtWzYZJPwT6k@hk@7cwr<PS$czqt2ZCy|uKdRDt~`<AdONd2*Xm7ZXaFnY2zH814p+N-Q_ZqO5Sm1l*Jg*O4we^fr;q8uq+X%`F%SiFyGbPE7PUaa0TsrnnZIuro-6NtO?SO!$Wru7>1n!s->F957GevOCdgH<}|3rV`D|<m`)zREOS4&>NEC>N*E1s^#Te`<5J0W@pF|Wp~3wY!*>J@+@UCQ^Ev+MIC8Y^<XDw_LOHU(IL^8%;AVnTIz#0%7;BFbK>Pl{^*{mlgfKf^5taX(GDuZ4Z|d}#3)v<KbuICpdZ1Ka3=pvttU8Bp{f6lN&!#se~$ATk^ZV)fGfKvtY*tszmL+OG<jtVL2D!`S3@`0bK+wM4&`jma(yJU4}qaZN=-3?HHzswbZF*H`9SqN{2XGlc?A~UqF@ml-h=bzudY;x6Epd_|Am!q)%<e2mIm;k*H7l{EWqJnAEzyiN000=Qp>mb#BqXZDwODIZ5g7gi%dO4mwjGXitKb~dQYu)PV2u7OG#EJQxl!(H4!RO>jm|To*puZL*SMTv=$Vw6h$|&p+8mWDs=mntcuiwH4}1Ug*6iUiv&5a95%btTS@KeHXG$ovi+3vvJBq@gp11Ooq4XYDu^XvO2%_;{(<vu+g~dac@Tny7_e5o%23|a8#^gQ`!+Tek*UI-<^HVi<8^URW_`2Tp}8G;-&`}V+vob`iLi#IHSHJWNAI6mV4}m#qN;D78#z-CagETreMn7EnqBBk`ye;J6qX`eT7Pc){@I|99WAWg_)q*$T*Y%^DJJBds)^=%D`CLZfOgw;#BGk~cWo!12Py>AVR-guauuPOIbvN%8z_wo!GFG|GNkLKLXtBpjg&G32(;{sZyHTt6JZC}0!m0k#_PU4IkZwf>k%B_9m{kS4!Xy9OnR{Cta|BG^CnB2ZnrSwY^GYgh<y@{o=KByR>4Q-Kl?Bj`vcINx5Ov8a&c+RS3*?!9aOd1`AZ9XV<v}I#$(KPAQZW4F7}$?MedLz7L~%ay_cRa?TYH6P{PW{o^vVG)LC&P<c#$qia`o*R^M6D%E+E{Omx$kr4J(}NTbq`20BXaVR8mZYx1S~+jb`KgbLz_a#oG8!nV%kEbmaLeOlYupBTloGLCBwDo|G6z+Ozg_TlfiJ=+I>ub<EM_1J#`=-)EokIRIw3!s|>b*Z<LumtuHvd+{AqS6&6@Cnv+Ozd2D-<AUqZ>62d389SPutbuC8CWKYcC;feV04DgPj2x_cE-q!lH05Y^>=W>Ctt>C&L50kFQfsl&xwly6=ps6JZsb{qi7e2T`EA^cuNpNu^>;cl2sK{Dew$vPfk)RHcNY%IGcm3)$r%Hx7(m9!wjejA`ypKIoAxMo$=YjqJ+Di>bZiWBhwQ)q}{pD=D<K$K^T;kTE5;fFVRXdZ)}T;3I4TbWJfYIV`Ey5&PlVyw!E+N$bR$ula-}LTMcz&Y;m0Do#lYI`PbQ(QBh9EA%x?yTWtCHd>on^<h-P^bJ)IQoOizZ#Au`ueNgfyCA_>8XIjW&uBF3eQc+@rF+pEez0ejQo;kN(3NQLNs}@hwTt<E3uXQh7vTqD+Hc=N6Ia$BD7ExY-oQo&RBhy?*0hCuA*_p#AvuXfdmGbm#^-OifL|&<b7NTFOi3;dzT!!<Xg}(6;^M;@`lctr#x;YEfRcTAxA)WJJeKw0?nx?TCg%=vXlX2kY^C{k9?^b@5T>smBB*8`9Si4sA-3<h+f|R{i*F<b%hj)4fK8&!n<skjf-i;0M#^;%uEpc4?rLMKpB9RZ}>Vxbjh;^|wKS3AguVGjA{Dtka!t&l{+b|{_bb*H1(sPDZT8`;j@2(B8(B$dD`U<!x>-?pqa}-`N7F^YI<b-vhPVkbrwEDHL@o>f{S(uM8mS4$D`YU7kLCDj!1j))+zFe1h)Ofl!md}fYMeJ6pVpqoUZ7ND^BUsyr#pV)c8U#ba;97v;1Z)_>%EE#%<JwZ*Us%e&mw{sk9K&brDnGkev<Q1KmY*)PCVLA0O-;@ki|)NCjC^v-)Mlc${MA(TT?dr~@oMDWQ|QLU4zanlgIX8I0Y>XMI|Qw;Y6>(sxtx*m;}{$gD?mcq<0`Zf=as<|3OBei5Fc)0v?z1rEhjib*uf<ph!qGjcv29(7vz%m0YP-SW;ErY7$l&I6cwawQ`0R@``##`p0HdT;3T;y6rm+bg8_0_QJ={j1J!?Y^YYf%G8#eBsKHLY060m0Q#9=*ZX-A39Zi*)lO9am9?@6hH_)dCm^UdK((laQZRmvCi3|<7S;PH>h5@Wk-s6%wFc!hP{sGJdb?Sb`7(FUl9O&(Eh{w9zJm55YqiO)~;x+)|rnlYaCydG6MBq`z&xNpL>K^VfS=HlyxI^~;)2VwKWpZf<B+i+5?=;|w`Vuw{Xd%H5p+Ki;9Ibc9;~h|4I6_bCQx(%-^9?w<yAOwlZtLtS6?x3F`g^GF-GeZpS=T}S5p6@rY(1gaHE6<2D(+Z8hr}!6v6VjwFmW9^+2!A9L%$?0L@b!q({%Q6+Mz-+MKbYEoTo(jB*nfE>5G%M0l^-r%0WN|Ng(;0xPlMz5#gj^!5IfPCH};5FH9~4NgLJ2&z%X^1J`P)wXNh^FZx%sf$rqKS7^yfrT{=qMmy0p(4?CUseUIZ`#Na6^aRjt3s%cQ_9;k!m)$zyUI4RcRqo_wpaQqtPV0op*pz<kjdB;7I5Tt+B{<5~A<OFijW=?eKpgnH^E;xGaev3nh}Tf)Py8BpShKdR>YJSz6pmo>jh#7wqbB!Tc6xt?N(_p?o|a^%p~SnMG#uiDW4?n7H(v!Z2C@c{zNU`2>|o?0fumcR#p3Ed194WgqD+|V$pN5Q-%ol5X-C~=EUZ?mc@ag`#qrw+nB>hu1=VCHGj!F^h)@Z0v!T--hzTbK%hT0|+^C%GJMa_R8>Q<JZRoX2%ZcNeoM|n@R>hvnu8Cd86z!#?lh%o>z^l~Hd*Bz2v=!m{>II+XC8TYvb7-awPH<dr1RFOqZP<Tf<wub0AWJ%Pdq`2A<;l8n{KSrm5_(wE9OeZCm1uFn$NiO$j+XM*7AmbgzrL<esS%fZGXi`mPEsG&P%oFE(yYV%N~m;$rffOAnX`nZ!!1l_UPVrQi=2GpD~DUoU&gNg@R*6eYj_?uAt<|!oc5QIQ-mELC&yLHgq1D{4@Omb4pYcZ-J&cXSsc<(3gj#MuMHbu1Ij@$ed((9hC#bxEnE2Q$;XIGr{K!h8}O~c3>l2_Igm-Q76H68^_~mX&ne6N@t6@HEY>K?q(<6UE6v?|h6Fs9`Ry;nM1rtV{$;*$x#TN{AA+x3&+y}Lo3AYWR>{O?{i1S95KtqohHIMq+(iZ7cURA}`*{%x^sR5&Q-f?qe{C+k!qYAE*Y#g8^vX)O<Xb|5{fBF#%<$9=H;ppuAwL92+c&j=tm^khQ4g^k%qD^f8yRN1ZdKpAN8bU8db?o0nS0jab#B!M0Xap$S~k{@OQ|L%Nq40K-oN#YNmy6pfn~|gku#6Nee5J$gOp~X3PdC@G_?9pO;6n3$DXi9;#`R?3{km;Ic;0z?Oxtg=8}h|b)??FL~8?;o@#<5k1iP04|J#klm!5FX}EeB1nYp{xT4cV-f9gV9N9NaQ>MtPB+jU5D!&VUjHD1nqZk5xu%ya|XaWS_Kyy;3L0!MtUC?~(;OxfHs-$KscE|r~>uJvb#(%A#62bsc{G2C2p^p7p(;Q0vwDsfj@dnpjGoYsoDma<V@IjVNb%*K3JV?+|3D)#=bPRhgi3&j`A%R7?^-`Nm&A6>;qq2HNvyfu&lV!ENng?Sse|fhOI-kuh#@3%yd-Hnwqsij?W<bVgY8!IU^{wGHG=VKKqb=;Unb9;HA=f}4AX^veG~S*Z8G<#P)XtySpLJ<90~Ul3zP}VqoyE`@r8wW_zQi1ZAgwWe`$`V+KkNRu6H5etf2XrT>ODl9b6Ciz)At};>@NO<VFMh4mP0d-+^H1a;1i-&Fap{@&#AYTFr^H_WjUS>^g{FrFpx(8CzV%<>EWn_CPd^6RE|xkSB_~S&#-}p&@Njm-DzbvPeLAED_;7BG>SypL=7m+VnxODU_OM}EZTx-Lk#hHhOF2wHmsu;=7ET#h&hMwJW!Lqrxi0%zB^zDzp1kb1ot31UmxxaF@l1$x2wc{f|$-;okDLIA9W_^M%5bIb~^Zc&mg?HAofD4L<8(tJB0TG6$M%^3X8FR9S-BK+x&Rv{O7M`8vV<5T$&B{Dg(bP_0fNT&PPGhV96!gOn0I1;bkPW7WruM9yL7SJb3N$w^E{svx$$*XgpftKct4H3(&8Yxu+yAN>p;fzi9NG8`>T_(Rj?3;Yd^#jUG8ajsSZE6ZT*V5&iw$>?kkcn2WeSDlcYiRWcVlw?zEzGU9iC&`u`eZs)%Iis#efqdNkBH`fw?n{<hk49l5J$7h<NyQ`DAgzuDZm%fk@u=3s_^&Bq*h2Y>wso$MI3)J?n3#E#(js<b#r=A@w9A@+7M36EfMP<PlXQP)(7L-yO(K@0R{!ol}JA~y7oK#Rd*|c?2R|QA?k9|Y<wECB3eA<B%Lc@1~6*4hf?Tl#zzJa2TJqlAp(}lw5-dhq>kKbM&@rW7sAZRz+&!S*knA4d`KczJU05WDO=)syHz26$~jg@!XvH^xV@ujsTp$BXRhZc!wW5YawPN?&2p_>t5vo)rqO$iSJmL`Fb?YZ*;UQ{UpQP<0ZaD3*_g~Iq&!TXa};tbaH<aJVBS7wO7Crr*H%kY;NghgWu*rFH-#_oOn1%q1~BXp)S%48Jd!ujRTYO7qC_l%flU4<kLz~%PyANmgZpqOX)LA~8{hFDnC7_b)QhHbMg(@NN(K6CIAY8b4{L6hi_Ul;@l(|JHGap0%q&h{MXHCV66iMx&Zfl$bflrKd{WEfop2*AQH3lHl5NRxqeQy};DouHBR!uE?2h1ZZAM)r0E0P_|gcxe#*CkS*R&v3o{y@AD1{_PM@#tpRg{RT|)dSz&2(}&OzeGM0d`pkF9+8-J)RQ|bH-F_~@lksaAxsjmfF8&zgXTwda0cE#5Ar|OJ64AFiTX*bKs_*0oDZ;k;6w+9eFiy5ONp4uH+YKW&V>_4zo|7=61asKD?HewGbAp-Ly%7boBjZ2fNBx|&E4x(09AuOW<B#@smNqBpGh;60tQZ(b7ynaKej2C+Jo6>|-ncxj0Ts7V>;<a-NV>5zB_MEWsT$tM8-B4l7IR~c3zZg!rQPp;--TkqBXtvgp6Ui?3UTxl)iX>yz-4tr9FNZQ7rY2`5($Xsx>DSkmIQS2d&mG}9kWc>FheY|Lfe{#{reFfB1GguDS?UzC-gG1H=dwq(r4&;b<r|#z8z$86q4-Kdy-te*m*1~-vydxV}tt#YicQt!({a2>^_}j7&e>EaJ(0gCHVhg3HH81CQJu_m&<`FF<+X1)CBlS3G*uNt;=_hQf3+mhNtaKmX$Gtqt}LyuCBFvnLH;7Qb;sd4NWG&SPU&1r1H2NKw9!i2M|YPLX08^V6ymMRQmEvbmiF0qz=V|MBjOq@przZyPOUZOFxIs(%sy>uiED=%T<pSKRjBASseT#H3b=X;%hKXq2qL8aCSHH*x(XXi#*G6MgxKeibK(Shp*bt){5Y6;?A7Pis80q0u{tPZlrTkn6uW`ct2m^zKg&1(P_uniHP~qxXbHE_2ogQGJZ|K<`Fk?#HBXk!m|;V)+5fpZ@4uS+iPPj&I9e^M;Ymn2m$j4k0VLeDblD9$9dHF2jDVpjuaH&Hq_^GSL0&Kla)JYZ~a~GksnDNY&PH2Qx|q{QLYJIDA2SHHEf%tGoGn<bq5=k1H;jc$R!7sohC;!XPRe|d`r=2M?EDlI}fyah7?o;S-))ju1=v8#+$$?^haj9nD!@ECgKZd3t1jGDe$w<H=7I?1vR+H=eHE4V!s#wvVZM^bum|&)gBY(GGy6CG7aG*14E-T1o%p|fm>|U4(`%fWpH`8OtF+-$;$fDRz-@g3Ef^L%SLC196H#uU2wCl3i<1Zh1ebDGjdj;<d-W{4@-(mdb++uW7|gdG@H2!JyPJTVsz;-N`@QP85=<>L1>QGGz3|!JP3?T?$8msBM5*_O8kl0VW`0#3-ld4XkxNhk^SHw=zarsxVH8mcnQ>>_$iiQ=^N!oMpAePIZ3FX-LsL0g&$^VD$Qk%u<&S9kK9C?^gPs!b_j$wCS(K%LV`-q;^`Ko0(IY+QFLcG;+^8gfi63YokB1WLmcQ@=OuQ6mo^NS@DkM%L}d0XB+A=Hl+j7@Dl+{O%$<A>&+wvmi;&Tvq>i#k-m<$UEA?Qu@CK4;)(GiQJZOAeI*J63ZJ?%H-~K=UP+ZN|^|jNB?$NvSVGZh6e51pvHC--Shb$!AB5G1aR9-@@HQl3TfMAxDaukxl9j6+dIpU!CtN6_uj)E0S4`D_Zn|qz`RnkAq#0_|=QQ82UBL)c-Hx<mGGnSJWE~DI}n(Cw?!{}Q*Q2INH89bWO>`0jYgK_V?359AH!@~%*1mGmBFO8Ym5IYZ7lE!nDYTHZ*y59z3#((t#M(BEYwy`-8{qzcncyl=_d#;o((1*jljYmw*n9y5AjLNzgjN3LCTOT`xHWIfOi6i?fD{Hx#EL_({N*k!885YyJKKeNoY<A=lN-}w@vgA>cgkrKvgJ%fo#CgyKegV$pvbT(8=cUm^pK#acZ!4u*#;A&5Dd5gV>TF9#POP*8X_L$$)|~0~vq(E2ZyHAw6!}(L$MGL}l_q>^{Xbo+-duR9T^Xv)^O|I!*9G!}fq-Y4@NmZ18BoojqTN&XsX-PoOunRq5xxV1z%T02x<@cFF&%YJ);Kw04_LYMe0b{4T+$ED#GC61a%9(_e#9_w0A_#8sv)wVan~Jr!fUi-i&S=rGnW6KK4NtkBM#?JcW>QNflfS5y@ufv*gi?~bGpzBcXMc;tvZ@0eqZDEgQVX9pQlZWE*o)vC`@Ko9fJ%<T_p)=c}ZAMVnUO@0!ZU_QeMSSC8`4o6mLUw)pdwgtFoDvZr-kuOq_AMotiZ`N`v$zte>?97R@;JYEf8w9&IvR<SJQ-YlO^MfH_{YQhPGUns$HmCOrsT&4vvRadn89Ws9tfGLOXa*W}FDH|{$r7gAWO$x4{$_G&GtpP8S@O8j<M3*x`p{VJUsSjZLr-G86o@v%k?YK<CCZP8tJLLs-my>(=8TVk#U?GqEMGI}R$wNO<;o%%^K!{)Mw+ho<f>}7iZbr^$%azaL;b6gQ)vh6u-SR!)Pl80Wv&c-{R(Jc$Jlx^NNd>hZ0Rd+K7c(%8AAWmgn+_2~dj7t!P)W_+zZR7oko!CUGrS!UNZ?vm@;_X>DVzt=ODi5^74C=<TB*>(M>VE#7Z+uc6uJyv^mZQz3b;zDEr{!jUtx2`chc$Qp^5}u+Vf<WwKt!mI>)~)VHBr9TpN~kG>XCR`_wZD2QSvKK1ai4%osC(VGz$84bG8ruzx$y|ayP*#bCP+uh4&m7E2txzG{SBJQm&mNnUmebp~NdwUX`W|gwmRO6A6>e%_}$Qlaa(E`KIQz^hvtarp?U>h=A=ptDhuu<X!r;PRObT^K>%8@d~7GVNa}&8`phYZye>Lpnr}?9CHYf6}9zo^Qw>Aulu;H_i%bdg-Pa=^-vU2N>1Hx14P_koJ|YT57@zZ#kAldOxp-K+bx?Y#MW%etYhiPDT=;Fn$kQ81j&s)b*DhxNNU#<%UlQ#3uXf+KBm0hwf_n7X8r;BJX{1tlb6=)fh7*gw-aB_w-mm5sKHHpDe~iYl<O!D+AaBX4MV<{nM6mc0Kr4p5v{LIR^pI_EIH5(2t##o=|7p&k45ji?d4|A#Sqel#CwaQT1O_07HD9urZTt0cu3B4ex=^BqO~^CC{>_p`X%223C&3lt^+@JA}Yk0(&6npGkMS7xbLiP*>3&JVCyUr!Sw!bLE_-2xOko~e9OqnXyw0~5(gu@-A^`8VfH!Ej=4TO2^?%o3J;#EYpmJNCR<A<LIX4D>$xe9jM57kx#fUMI?4Tyz`u!=+p+am1C7nd!J?co+|IB)b@74eQ2;bX@kW58s5_Ce7;0uCWW1n$u3uDWJXQ>J9*8|CaByxi8w|^E6pQtobs}P1bU46S8PG>d>~t4HLW0pPVg-DNirV>TL9gKE2)PTz)8^GRjg)ofZtEfH|N9?miJ4w*`834O0)AYtGX2LdF&>Duk6&WeUO%r{zrTp_W>nl$kG$?n{#0dcKg-2sgKOXt3G^DATe?bIP43n}Mbl~`-q)2igxj~iPL|kOTUln5B10j(8d|~}Opx<>m2uGd$;GP7rTex^F~9lJlrecVV=vtf*HebWxVxA#wk)B7i!N#}C{daSN|Vh)d;y;&7PsypM5YZkvtfcJ3%ZLB&3O}~L<~BAl-Sn9m{~xJIst{yZ>)urk=USr&W$0SB~mA_B15R(Q0*MH-=#!s@-^mR;b(bgah;d~N=Lf6={++T>$2vBKn!l%n|p3WraE#AHcq{T+%8=2P;(Tb#YA0u>$RIfV`_g=zsZt>mzpqUg5V9Wz{CD!_irvK|Jx6Sp4Axn?pZ^RjiFee=)6ZP?{=B-vK;4w76%k~!w_Ib$$nP>=}};FOdYzwvk+%RC`!4=HS8eQ)It~<%U)eH4w?}|O#T-EUyDc~(Y~0=0?cRGpoa~uS$H&STW41Cb)>Ky*IIVX6fT=83AK5d5KN8SQFj<P7ez9|)QE@)psV}PE`LT#{iajzN8e<le%%IFw~ko-{2TP@KYHD`dt>KES0Zi;^R7o|62UqB4H82GyYTDpX`zei&!cIo$F>yU;nA#~IJIzuJXyfAsAhH-mQnMq!i+)OYB*U4J&ek_yMo<NB3r&Kaww{^A6#G^n}MAK#GTN4ad{(>XatatngY2>IKnQl2eymM3nij2_@Ie}1zP|}SLhZIEdhffpfQ3#J%X~WRuC)warq09|KqC}Pne}vJ?NA4VgFt;)tw#0BCe<yWf;Q0H0wv<DlbqMk55klomW^Cxap~TI)}Y8AwdFK1u2G2^~U=**bE1_E`Fb|Z{aqW`Ra+=)ttAk!y8Jc*Ptw^CgI<rP1lW(qQR9DkrGjC^s!?(5$?xzmVHvSyMB7$r{8r4?{@`3R9#)a%cc78)Tsu8<9LtcD%c_<4}oy_(~DKseK1XtW|ievR#{#e!|}FTR-WXbAX#V3hwSG<R}R59t_(W5xf&5-su_TEvI$yqG3=HpjyIme5i}_8T=UGLkV!pf6WqZY#A)LZJ5k~r$lwr86pxEk2n>QfI=ES};^((z)^-6MNNYR&aUe#M;X2^egy%TJldeZpi>tm!56+B{m~2Wzw`=n47=K5ZH}sxSFy<H4+&3;v22Z0(VK85<0$Xy?T*XS_agYWSBV3j`YY-JS6o*Xh>(z*7+INyAA}z8eiPU43!23XEEw!eDWSn?;e^Gz@UwMtG;29Xy6S%3P3ghfl-}Q+5x)?K|hWNl!cLvnG)4>L!8!D9|C@jJ_A>%8XL5qh#mzrp<ot+0_zF0lu`iyVY-E}s<njwX^zKPh!rUiX4SY9BBE6XG|2&vd0i?fs*&w1nmJbDuyu$G;v`T5yLV||~qzZB=l|MPL<Ap_al*M_G|^d<l<oT|F*=q^&tSLEgIwqiAqi#o}XG6oHH9`&%XZeTD)N^M|-DqNs+I6zm6Z5~5}4rp_1x%?+kDaB78q{|lt9$0Qgre&iN7bymevJEneOt87#@$)k>2=ka_g86rJ=~v#5(fDxXIB(_z*UE9dGh>*fOZvUCaTMS4YuPx{iN>-*%JU)~NAjvT`eQHN{7N}48l`J^uWTIG=%ySe%^JE0IRnySk{X1QN5y|2SYv~4xl)m9jOJNLF1T(@a|V%lKuczW%)Eg(O1E!va+_yzavN2P=~c!M-{t?bn|aEIkL0_*LeA4MKD7Gh4SF)8N)nT=;RMQ0v(en)mhM*4&pj!QiC#5V%!WBHPXt+91e`&AC1iFa2hCo})RkUh&Ny3_gl5jYHcwWIhv3*KFNs0yV-bg0pH$5=UHNb~X0bOnoqmRlB_p->?L=)<<ctfCIL8-#j~jRRnm7!U@z$mx`9y5`OO7z78_Ay>C<GK0spb}@{@EK^8D~a9;X++7sZS6De(2%}ac7^Qo6#TmyP9>4O{T!`158!dJyXfh$tf5Yg|vk@a4hs#z!NPAaq&~<6yYc*dCGBu-LO+OM}Z5jlT9Nm81fGRP-N3TQ9uJ;lukOxlHHgnjTWOhmQd8d?wA!j*Aa<e_}Q6L_ZY1TahNDQy%Miz_ak5O{1npig6ULr{6^{rY9^P3gcIUxt%DKUKEs7dhKYrlR@%g0!Fs7ehR~vVFh!$WJxPM*nFlH$x*VGVEq)Y-`G0Big7k*{$4?Efh!+5bb*nofw}sR!*PjbwNbddB8rJNzE=i|0L6EiF%?k0$ypTBnlklQy*6|u%k=UFv+uPa%^n3KWlA{4oZ51f0ID4rQ3?@m?CJrYCTU!NcJTK2**DS(Jdcc_)ajO;?CEd4>%7P;-D`i}!46#6rJ8(H)#O2OHwp~jG0BzeXnxt^K9xgUe2S9nX<dttQv;MuW=#Gatwb|s|x5AUG@j|OiZ_ObtQ*UjiQ^%coNSk|IA@P*Rt`f*Omap6ZOfk5n?Tv1B)`MP(KV&W1G$EWNRf_SjP+1+N!qhzPGNpe3>p-n4I=R^f;yWp9Q}bKGmmO8u!`kF7^AksN$Al(Q;PbuzY-}JwHybL-Wy{~g)}-5L^+W>Yr-@eL+W7{xvq)Q6&sIqhL!8hbMp9<I=)Ek#q)&xC?}`~eVnQEG`%Da0pdJ6uuiYf#HMbM?l9ixRH$B+OMuqCd^Mo^k36n;7uF0&C2q_u!ndKa33Nh8pubAjuN)fvjQ25rDS-GH4?@S3O<A~N-T{KRD(Po;foec0SV1_ddVJWLgM4Fh2EVO1nbE(qAv^7%+Ll+}<$g3)NB3X<IJf1KR@iyrrCvOw~z({1T0uclYIx!kK*U02VbD|S7leX9kKYt{Pa5VEpwrZnjiS)u_sdKYJqsXc;uBi>EX8OG}C>Y*<n-%f@_D5=U(%`eJ745Pm^Adt~Z2g#LJ|}KgMtyE|l4!}Z>i3Hc<628by$veI&W#zOOIB-Ky3n0y4r<BeMH+k2omjg5{!$t9{jxhosWgRnzcw?$Xc|<iD9?OOu3bv#NdgG}rQyl4LloR>%Q^?-TgEBu0>PYQSV>E%BoJkgLZKJxKC-SKf-YN3+3j*<t9I7CeiV|FOZGb+rTpjn&d@(7SwotbYq;IHdj7``zuLneAJ1?4;g65-kB{(=kMNHle#pZgABr0f{nzu*e}%W_k9jqJBVYT6efT4aB7Qtje}u<2e|?{o|5iS>{-fU;Uw!yd@BLfnz<T#XJ@jAG!~DSyAy(h~r1Wt8t@Lny)qTXni~H__?nk+ekq>FTiud1k?OivYy!q<OxBm96)XMy<;u`FsmvfUa!2$ua`|Z7?9)%_ye$}B%-GUo7RNq0kaP1&Sl4)`Bp~O<o29J=1L$9ueyqS_*eda&8Rkhl(C>wK)+UcS0TSYfG`!g{%*$Q0znP!gfmWR=Nnb(_j-pbU=8()8zuiw7Bw6Xf2ec{Uw(wAR<^Q#>SHx~Tjq-6(Z!vfVt+&}49rS;LfFyG4E^32uO>&0s9u6~rYXjWg($l&Wk-QMC?KguMOF2A!7Z}!boBPvEeyMMJa-d#N0b}#;r>*K5nxINRY4)y$_<|E&%6Wom-+rD-?&Jycy)>oo(%mz{{|26ZTHV=4{J=GAJRZua*v?q0ceXA}&3{8(V*u&u0uX+=ZXwR>2`NLm)sR`e$UW&Ije*YW&^0kS@dH!>}kxbL|&$M^hczfYP-OC@^j>i0|zxAu%^L8)5{MGXUn_T}u`@;F=&s?3m=PyP3E%WJK-`AhM=UOUP)L{HB-L4O2yx3AtK7ZzFhs{RJj@9#TeseV1tG=y_&ra@3Z|U-DM``)2xIBOJ_;fFPv71lEAos-ihZ9qNb-3Kc#kdT!%O~e&X1lvfD_NmFbn7pBF#qu^3kkc{M69h_42vUVAt5^1FE|qq*hw9Vn}#-(I3!nW*jWy=TZ(2Z5vhfU;`@e_N7t2=CS)>sLB2GZ@FQ@Vd(fG(<P*1%6n1~4D&tYToI}X4^P<?hpj}&RjE;;G=@?yI?F8<iV6i|HF$?SmM5W)FKIBX^k}VkIfa)GLoEU|9hBy<2v<~&Ru%Cpc&WQGmppSA-HgC=7sp6@h<F$VYLV9u660X)j-}ca>qn82U10s4S5?YU|xv<?8=^8U|#p|hu2B)9;-45p4h(WP)u@Ri>-hym8H|VkyO1=xG;>~Lw->Uz^YQ5#3{Tc*v0p%XAHF9^aXyn4beqkS{7A-jl{}J*-0t!jh4OQSM24i};QUD}iW4{KF$^FP(>E#wSKf~P79nk0868(d5S_kZC*tI)yjW8BQmkPvkg^lrYSG+f6sj)L@6CF{1GU;NcX6&VQZWz&Y1qVrr#rHNZQ)ZEO{;}@Q@K}DAazOQ%eL_30`t=^VLh;5r$xr8yADY8-2Qc1NQcMRmC#fPVt;H^$sk?ZFBrJGUO2fYZi=g>cx9&JPV~>7ESnZeGAe*5kUj0%Z@jxF(JGB0LpawVRJMH1Y)8h@t>0WQChiHl>PEV3MXii6h#+m+P0@6$x%oYni^T1}gSj>?&TLU=a7=74(6emG-WB-p|^91gN<FgSw$xsb&(NIqD=|B=AB2bV7Jf~lG?7kz!95}n23JxY9@km09yF)Mb2%tZwgPlA~6@iA&*n>o3aX?P+lfeBWOgr_4xc-UYsmBk@ODX<$as&%;`It=yEKI;NoH*6=_d)9Ob@Y5*40w)7rf<d>ozaTJeSj#+qiK;Oh(>kCM~EBMgLlC5g2s1`Ang*!4Os*D6ToGGlFfUU-%>=YUil{~I<%SoNuBqpn@T-4@IMuF+7LpKupTj#4h&MUXH#kh1Zx1mOu{;2=~5OF$Wy17&0K;Vem;h>XDl8CzVP*cz2SvJ`{WLvxPh9pI_HI&qqs<W<{P{QOY=x;f+qN$`>9Uh{*i%Bkp?~G?KYh~lL@2#Yz#Ch4fVJkS3zFB4{~%B&bR)q(wpBK(bgci96T=SuxS|`{f!6NLlpG*vp`u4zyYi4r6k60I2i6@qeQfyb0<?Ci+|I=5zLpqPH+T4e_?or`%{xYH-)kF<V|&g1@Tw>n3x&G1_`d)3`ARD0agy%fD*C!UquQ0-7qS`YD)B<JkPQ%x==MtD<ON3Y_KAF!u{lA)sFoNC^3*s<IVn861hs@R%}+YE5hj#Lm;~5f^`X$@R#l!i5Cx;cSfgl0wK-XlWT)4LB)J?BaSO`;<Pfz$~YrPFo(sOqZ8Xa5_0u|SCRdt89&%x;s=Y_6~!BNMZ^OYQCcqEbtzm%hll~v6F*X=ntv8jhQ;Nd@4x~2#7V(0w#6`>Ib8;s^_l_{mYpMkHJNj1T?X%{u+7b$$blUp7f8)xj<u6i_;=mjTXW+~jgm}09R!RqNThJwsjT%@q>o1~!W0Smd8$O^VA@i+Po?o415s*Qcch8y;xO?X6Fdg<U#xzBvasj7PRf5;qI0w7vN>)dgpPno%9~O#xx>*IA|)W0zhWoN=FK-QrvD3H4GBs^N}KZ+Bq(5@PE?po0Zy#I(!8XBWi%X)qmEU(pXsvKH(Pb?VVEd*ESF+=i;%621CWSACslQ)3BN8A&@-p{MHauy-Vzl<LK;)+zmy78B8ilLgSL6okn&$l;;E{Vr>cnmLKG<1NC;j;XA_?wRmgwFd7?M<OS5fM()6|n&?}QWXPh3rH#D>9Iy4AB4~C~#u?BnVX@LN*Iv%Jfe-|o3V~*f(Gg79vLqtS*jcfe5w_O>RNFe9>mK|q5TX0!N;L7X%Z1+LdcpnEX&ny0NzLea#)_8l#0xyxl7cb!CMe=2rWD^s9>gTjTo_EdLE|8MkP@z5=6113oC(O$Fm*M2D`Q*BE0VK~2NDijpY;SjoCGY*Edz}EFxsza6Pi|A3R=ko<e06t=@!qC=ve0@Yiu`Wems{~l`u>*p92tueZQ(_X8qKCY^M~x@*X8VYeVFEy^kmEP46sq2FJz}E?Fu5!%~L)5-8iYKLVRGSq-T-vjZDuNJk9#O(kLNys+e#=)9=N_qsXaO?kCw97E`xwCD>OWq+$ZoJ=g#FnjGYtf;T39`uPBY;e+Cly1_9>n7w}W$H^8W%&n9EG&HUk4~3<Cq{boKEPlI@PA??K(G>a<-LFI7FG&zW6Y>fCk=dAvbMkybn81+<0=VNRj6C<e<Pi$7SkhxB#Jh7=tO)^K_#mPtVj}s@iOM}*TXJ&Ch%n&#<=fIUx*(3m$VnKsdpv$8HAsRedv!!&-a0$8U^8h=aW}V6<=b-(JP<2S8z8TLS|JbG+no(@(kuDQ#@%t%eM@$BU34hnreNFM%lDCgjv}xp{?c%7zU4b?hS78{R<_K{L0xuJuyo!;hP@0^y>v+!O(4a{X5!+aA@Z5RSv4s5|KgjNIW0Jc_s)uxGbkZ2KE*tXE)ZrCE?=BW>7?gfn@C3|0>YIak(>R9u1GoDTcY>jJdv(=IkRmj!jKo|QfKIMFO#zLoR?#oV=mmDPG@S)qo|Ad$`#Z|S^bKd0|M}LX#n~<cduNq_AGv$9Y5C;oY(z5U+3cdec!CoUxC=OT*2crbFsD3-_Rz*;cTMbj(2MG>mKnz6ICtWuEhQxpSmMY*IRD+*&`!!QAHT>?mOh|lGyeS{%wE)AkO6j_eKNNfpiwk9{<9HUsUGwpC}}?r(aYP;XwVN1MxkWaTF(kkqe$0Vk@&K5Nz&DB&CLkEX0xH7s+2HPjKMj`5sk=vnmqx93?LslE4riUwg+xNaEns8ErY9s888JS0ff$LuD)rN4{m07yAKaMj6UbDwLlkublb?@1lqxU$!S_{fv6`OwuIp5e!r8i66=+jtX;K9LYZP%oQFx%ASDR91l+VPzfwch*l)9lDgD)%Gvy<?pGJjS5(y>n&&Id>dN*N(Q(Y5*Ii;bcq$}Bx9W+@R$R{Ib<^Iskyw<v7T1dinv^Sec^?PX%8kj>G_<({p>k7#WlbVvN(O}zP@Tw-Qh9Qw@5Sam*qQ9x2IKP=HlPb7@Ul7Gv;H29SEKv_b5}6^v*0bKHi};JQ<pM17jLdSUVc&9zU?rqtvJnLJ^RK5wGXu|XD*XBDTL*r+O=VJC1&a0OxC@9729~eV<g_^&x>d-Ug5>7W*Vh>*xX23?&#m@VYqy$Ynh5sURslGetGrA`G<#Afib<9<$&lrm>H$riuvlh3%$Sj3;0*Qv+W@?5^v+>T<vEa7?TCul+(2C_(f9Z!YbNzE8A#Rd+SJ>{*+DTYM2dQDG=CwSQJn~^w<5B6lubGtHpvK?~0M@XhYc6{Qa7U+hLvcs>a2ch}%h^D>pmPNaFTP#9iDZrR(fxvkW>l1$xthH#hT?W|9&Wo}#gETVW5m?p$)i%x=p*i*1;-x!UU>cT#JYi?Ts%A{%6dE@Dy4ZQ0342fFhQsB6h%n37S&OYsAB`cqT3jka2V9n~oKbrpAide#TcKWMY(OZuR9VY;Ie>0P9fmPy5zXm+Y@bxR}@EAw*Snl(hDtk8mtqwD&}S$Yu}wRc6E)bcDc%H{^R=@AQZXhwr|ZIxQd7Q*%v<7GxrH<*$>1<g!6Y5oe`iEkglRj+S>OHQ6ZRfdIJu=mdUFD6#%CEhah$j>Awlk9`K&pLe^4d&npfw-!@ia+e6zVUn3K`0El_Bd_c<bvz{L4L9F37=Jg5Ey{5y0NU-o2cj29lKrqbq3KRZ&HmV|1Vo>^k-yM4YfX4B*ytlhUirN9?)Lf<31NdF6<8otsq5sR@{ihe>keEfP$cV;`8<Tzw;8#eZy>{h9Oz?B4!~6iMj{nMmSVIS$_o8rO(m&ZZHoR)hF>^IvB;UqSi4>GiKg0p`q#EzvoO47MEg=D=i^K<5bzUU*5u%?j%Xnu#y|=&0m-c<l>2^f)g~@rSEo6>lHEoY<-md+l=coX`8}AW;VlE*|2#3=eiFLSp24*3ey5Z@KUb;%Cxw<_G>gxDqhuj?kMHm<aahrA<&q-+26~>l<Y^GG04rB6X6h>PzE`_^;h3fkWX;G!l?=UslnE|URjcI6!Z|=_Kea?=)^LPd}(nI<)S&TJD$WlH{IrExl3Db@r~pxJ_B%ca=h|euM?#M+|LlpdE>GYb5o^C+81qMv@0zbd=F7uQ-R}!&g0|Nf3(|r-FhmD(H{|I$X=3X?d$0;a-}G&fKN0J{Kfja{+q9d9em#fcbnth6Duco&>H7TJ7!FF=F6o|J&u@q(h$WZmM>rUP+<%W#uRoJnmA0YId)Q%weqFs?{t-26Ee6q|Mkx}>xyq?2tjC)gH#wt)6=WDMUX>(O;UeoLEB&;iiM%h_hPw;NyTxp(jzK4b@y+)i0Lw!XvB1~(jS~r(!=bI5Uv08j&sY~MoEt{U1)stkeE431pM3Nqx<Rqwh`A8HRHe5t}7ewH(2ReDiBn9XJKdOF5ErxwYFBP?F>#m)}^*{>G4F7ty{Xm;X*XHF4QSr*oS+1Wcb&lgUyEFy40gkELpEZF4j$*-ny<=>hzSsv0F>-x(_0(FT%oQVVP%Dgqrfz>^>e}(HZWW$S^#iRyxB$YEDhfUM+pgTi0sC&HkwiW{e`Kh15w;vkz2V{MLP-zTf@UD;ChPSwLU>O_bRTZN%@QiIX?@@Z=1Eh&If`#vcO<fEfY}<m;K<AW^{jDRB<!GwKiL_2@KBp$=Gw;D%zbsDX21x>CaLV89M@Z*t{`VYr8h0_OA#b9sxMOs?$;E0rr!!j;Bsq%Dcc8O?}~ilp<N-5MpGRT$ndjnL}o3}+Xlze)3CT{9?NC21~N1{39X3xzr}+!RbN+s@7YAs)P)0*-H@2-&dp?7AYTr+$fcvXVWIQq|%$ZIO}ZyQGxI%dQXls&qT!7ovPJ%OD13$9y!oF#VDl2Y&(8>Ek1J`ADgsGfXEZgtewV8J}22><q?ymNU+&xgiGkIJ+m+S06i7!sch_(u>){%3Tj;4+9q_o`lb}B|Xv0(8)D;$Id!H0K5j#r?2_K4#RoqW_|?Hg-2H7>i^`zhBuz1fkN0*4_p$Yq&mG<uz9=@J2_k7B~$q`?yZsQW;^(MwUlrr4bppWexdcSNcP3-;7@WNX0G}#&MC$89ao-Ki%HEG2i>U|2uqyjfWjqxc4|a~_POwGa+)}zGC+IRptZc7*E-3S1YwJdKNdHw2;kfs+0JrF-tFC%U2j$61`ko#i6j0_g9%YCM$|A$iWRuidPcUvP3ncg)7*cjXc2G|(|-y3Bq^-HE0Zn~ojZ_zF>N@J_eeP4G?APXgONXP5IsOJ#any!p<deq*D@CHh?=GSVBNe<G|7zzMy@q4rS)t*yPv-C{f>^|kj-+RAq{fVZ+3s26VwR@+}EL8CtYFyV_xMDy0di_MukOgQrEo7F!71M{)})g)j$hIZSJ5MoW(L;hAmAhjGhim%&~5UbZEs*b_KW0Unvep4er<wLcvMjaML8kl+vODac}aXK~i>HM8n1;S2s-|)i)nrbwr<7jZOS5JN*zD*Q?xyP=*((<e7(#Z}dZ<J|p-117QD%AZYdtcFS3%UVcA_5H56|0aI~|!lndiJJW%J#TZtFrpyJSZ~QAhpST%(LZ~d|W#djy0xK7)`bPQCnRnL<`1MDioclyn&=Uvs&*Op_PH~F$5XQIh;$$*(#~1JGy8jblJIycQWKsjng_YnSgq2ngC90d^0;iU3NLKZe@WyGW)3~NYZ+4bDUT@;&C<RiK6@z^Qh1TaZ%pXfgi)+2VqmWg!?}NEZlYQm^Pv`(s`iwsI@6MQ<>-gL=@SEysna~B_ifq{X&+2C1gPa;{1p)0;MGfaBD@@_<4O9^J4E9~$K<D}++D0fI&jE{*^AC6b4me%u_jcz!FRUYLWN=T4`AhV+KsRWlRf2VvJ2ezVzXz~oAMd*5^we>`^IGT5#BT6mCxVCw0wHmVsLO_osU~UvB4j=&m~9C(jL11FMa#AQw3o98rnQNp^T(~jyg-MqI@#1OGXxdrIE5aFh0ycs{nyJ<drr{L8-UziIi@jGn(#b&i8Vz)%=nMM7vg6wMd+Is#N7Sg6ymb#;`S+$xD*K<aBdtKux{Ok_9r$t6d}|Txj{_AWR`2q1})XZC36}aLud5{ojR$A+4jJ`O<n;W>>y0~pBDzM(>s9kcUb?r2D5jvkJ#=!Jj&?^Tk7IKgcS^exvbWpxxd4mfwq6_L;K^2Eg)X$nO@fxc=LzU!(6zy?t6sTlw&3g{h#~LW9HgeJ$Lzy`cUo270@IC6{9yr!gFSfX9sUW{67g_JRd(DJUYx=9Y2+u5l9{{4&iVz?M^KtlXAdz6el9!bQJj#fvNRC7FZ?Ld3VnP>2)CMO9zzyd(*ad`w8*MBi33?T-@fw8J0Gy@qi=xX){LvYk*z^h4aZ&kL$ft0SKjt=1KnvBgkVny}b-qntt?@IULWf#)fr&@7TnxzwTYS%zE$0OzeRIe#h$OBk;vRN!dHX;C2WW=D0;?0E%OXUWyQe^D#!6TSFRX&w7!4aP_^Lm<Av~ru;DLnf2{8C>puA*4#sU5~|v>#}RSBin3T#sIXGk@3m8TBDWZZhoM)srG6+~x`H@I0lAG+14yN3E=!}N<$F_(R=1GBf%Tp0)9)xCo-~vRXMPu9WgDU>LR>uqY}+M>)~{d)oM#Y@%4aw-k3<YXPx^WmfW`h(9|-l_u&^pX`@jo4-<h8brttdwp6g0-^zU|g@3Q1UJ#(w0k!z7(^a$3aq+gmzFG}mli9J0Ac#trN;{wxsw<0B5;Svo+I0Qtn%w#%LkIk|7GAlE`$}U)X#$Y)$-vkc;mmr#R<FjoU%xB?EoJEL@J>*uol7~#YlP+sf+@k_#=jP4Sk~$V~%V%CLeohL@HuhP`+<j$&q5V!A^0YS!txkahh1DR{7&&MSjx`Z3s7woqW;Ea8kCU^|Xrrq=xc|EQ6(=Jlf<jzS6!aNZ8b^6+r$~h{;ix3nnYXc{z-wKMK7VrbE<=i`;-)oS&y6vhJ3-kFb>PCJ3)Awz_?N_Z9CE`r9N1Tt>t?hDw4llAt-BUDE%zx1iz@}mOo);UHA6Pj`W9crgxmSXdN?=omtlO+WCG3OyWWgECsBPc>2=QiNOj%3nG?)?>PQemEFsyRBiAB`vYTjjtO>vx`9u5>`&a65B=rV3Q6Id~5WsC?cMhgDfH3<IX1f>n3EDcyQjxtzW~?>-$jE<@S{r1-+WkFw3WFLb4Q>?GPGtLT?xzL&?Yfo2uTHw$8WykKx|`w8)i@ea#m}KETd(<1)rZdo$KlEeDi52WcSabu5+=`ln207kBGt&uk7HiZLTjGO$bcic@y$1m8t`UbfR&5Izg~T3Z(mJmMjTM!@VQ}hFyXWBGn$z4O#C$8c&>7^*;oJqquD)SCs1bf4IqH?Y$CJ_X=lg)70$^NKoYtW2-^w0B2KNzhSzyvzi53j<r7~Y7ZZMLJxtQZzzhzKg<h(`+$_k!NZ5iGH#K6FiAS3en46PK#-eV8S!=V&>IetMnffvE8?QO_1F?1<ZAN^74Lv>UR?WQXQ;zf_sx9x{xBi3kv*%@2&-UKjdXbGV9F^;1-eKAIERF@x>}ZAKLB$!_(vJ`u$9%a_eNv={d(=;NjG{70`!&i9w#buGt4#2K;zS8{x^|=+VB-lvZ~d7&ZzA+&BfXKq6()IyC>oOR6a{GgbTI&Uv=iqJ1%;;Uq2<EHluLFWqh?^J*c%(q$r`l&u6}0=6UK<nUY#DJibkCops@i6*u~cLgXM~;lJW@=MHgkENj2i>Z+_glB6t?z8tld_6ni)FmTtgun|!yvodY;lI3h!wgy)e(zEc=CXb(7QJJHD9vpN*fCkW=?Z0H3~oSqe^xtSYx++jq;ipc;QQ(RyN)`{N%S9$Rz>#rXuyKJuIZN3E)c8joY%P`?x1DaYC$fM8pM{BGl^hA<ArHMhm6NhVOS!m|uIdxVdi0nt;$a9?+Frm&z1@WBhZQ$(mPTTO9tK0sL-|$_-O&M1=<5M^G5@Ne|^qV2U8sn?q)bJY1dREBDVQ#xJ=10hr6|mKbu#dJMWqS_o%e-R@-HW7j0s=z3qpQBgq946gBf}|4`PSMQ<u;hHK69c5{JMt$iRGC4b~RA1fGssckc+OzJ8XCiL?34hA|)qo8BGpTG4P%1)ZP&C3%5IV5gaO_c;h5%9Juqr;(RwdL^&{N5&vZlRjUlJ{ZMnktx@%pjLvJ;GuYhWX4{U=h9O-Fy&zF&Wf#}P)%8*h-`$hJ+gmiZfa$y$JGC{gLEacp#OB-)8`yBh0M57ma)-G!7@yttASTD$BF^?!Cfu@ZP{G3ZQ7uSWxhyocm@UfvGxTEbJGXKQw!`Hv|26zzo>k?wQM^PN8my{Y??1`d`4T#Gx$_oSX+Ld;SzaWq$m`dkxBX82-e!v0VGW33ZbNm3tkhE14vrH2QGE&4GzrHK<)7^SBR74)g}7e%PikFv6M2*6(T4oA<=CV<ri?x7ti5|g8zHiNwqswXW}i%3P(v94YG4NtA7$$YqD<UkB`B*_@qr2j(OZ<atuxDG7ft8{@A~YKp&8Ih7{zC{XKE}&Cn1G<xHM}VJdH4VG}14dD<dW&EB~I@BJz)ZCI+KS^`MT6^^?#vDhk;!`W{-pY7)(O#4fbDOyX9a)ED#qpGWrm2DrfK_uN`fKc(?{bf|TmnnnThVEnrSgk&07=_o8c(fbky-uvm^5djJCIEos<5)vhvajU|S>6oAy_{Q&Pvwk8P7$u`k-A_l#LYHK^6C1x+mnu`C!Vso7Gscc?Ws2pj7;kJ#mQzt;s;33EW?tO7(KAMh268U)S8;}O@{;gMZb-f_@Z7A|<(T}j9?^U98iU&a$A(77z`c!`gLvyo&nD+T)BPDY{X%zsa$*qVFHjN160J5PY!Vme4MqW?`qr4A_9F#lJSpkl^Ax^4fFM4}{ah#e!MyI(ivz`IkN!~%Mpae8tOkk5L{K|tEfSq6|2?vL#h<;GO-N?W;$0i8Dopq<cbzy?2R;Ab$jI>HJueS{9j)Q*>9*-t6>q=<&{wo>2PvtzARU<iHS5XA9jx;~tUZ{+<iU6Dv5vVT0)EFMQ)dL?R8!L)b3f<=)XSe=PE>^cDMY}Ol&u2^AWLWsa13xDmg2@Diu#RGlW@}1SYJxXV2hec{roA>Rt&qHpK0}o_D}C6x6hd>)m(kBeRlKXxScgH+Rpv@zB9?SRtC77q**i9zv5P^g3MFoDs#2{j23ka-H}1YW%Ad`Z?J(YUJy+@Sb^aNH8RNTxJ5GEV3>?uSu2f2MC5A89Igt4pkmrsUMn&h+75}J3!DHI7wc~M{y--P*K9bQWGk=%EbxH8K`kg17+S3zh@5f68#un%F$6)Bd1TBSa?{Q9fVMb;!XqTJ@hj|@FL)#Tc;Y@&({@~jVK*yPX}EUtvZ*P|*@R`vk3<U*Mc$MhYFwOkh~r9#!IQLDzt3J*r(WVO`sJB*Br;2W<jlSkXVD0kARbNKu&sw5RXt%|>c9b!I(5TY&NmKfJghLL0e?1u)5L2(v6Vqk!5a@&Q|`%4ZQ6oRdtuQLu^@W+m^dEmb-zc``cTILNUBVrDPh9(q8aFpz)F7R(A=ElE14pJGgx@phryJup6YD48!$y<RoE0KqD?(An@5R}U|t)dc>K7(;i%4hW6@OC8KeW$>>}?syXNRxYPjY2D`?C7G;y|XFsl<(q(Zl?qU@;=E_cr|K|Nc9AK^$p@Zx{$6sFYY%c-7A9G*ISG2z2N311NJazrBp`A`8=kh<2EZk<e(`y5xunnKqUhgAdr1|p4)CS{IBV2Yvfn;Nxn^~e8W@=pRj4joMKfN|;snE)#xDE4+@-Z)YRV0$<7A6n3xeR~+qoux=4u2F3IAZY-&Z_2M+tRpd*WO<SsG9ajW(&k&#9tEQ=n&gNv)lgz>bC4PsD~Bv)aL<3?Bl?dIR{u|ABBQcL=g_><rwV0?SD^saKkKNOg*jHM{oIs{nm>I#nFDJeiAbj%%?UHHh9jS}L4g<n6@-Eso{4H4>dD!HWo(@`wb{mQ-!o?7cV2bcC=;`T{g~n*APZ}hHNg_7&XFe|rc4efofw~S&KVB4jC*{XT5c2st7BphgjG*M%*d{Rp$4<@c+i2n%B$z3dPMWI&|T^pCP>XZiIx56v{(MH4TsNb9Cm?`S$m?R?e~OVk1ppU6*f*hz)!diN5)TPReo@1XW`3^sL<I6JVTHQMRIrTO>QCU<l25t)&iQe6UN8bNx?H5Tyv3^``KD8b@I<xW|y~KX${A06z6+RUne{-t>(o&{n>4e?H&Oxweq26;Z48+ArBD(!&<%V)xzS1eAzF3+|B)X{`-9vAwM)#p+S~+UHCamatvDViOWyMQw0>4$;_4qj}6uuzQ(slOx{y+<f+E#5w9Md<zojBO3<hU(4(toOlN@M@d4U*^^GdX;i?M=h{+_ee5~;K!xIv-p8GsJ;lOOvx4Soe+N?PCWTo3dqB>8UwCeMB4STBv_Q>g78o{4nZ|%LUC{b^J*+k5~!!;+f6m%r`A~fG@4&RNmE2eImVmd>o0Wg;h01{|FJzDHB%22v-W*P^=>gZ}jiAiqAA7{wIH|u5sYx7y<T%fVB-k%8v76OHnG44D?v`~e5dvoek3n9`5x;~#wt`umUMW&0Zjt=@pqn2=qpDZmO_PV?U0rj&7YF&;@DczAHg0KKz&(A%Q;&4XyX53qZ1_`Qc#TX2Yty7)(iK~n1%%7oF^;%n?PQ)rT?*i#js5Iue;Eeg651&_?>rvbX;Z{`a_3LW0Km)0jnwi&Km6`(#zQmkBX_xRvmtQV8XBC`*TK59po}Lw);|CO+y^s|uIJ0+|S2gD(K_Ege>IvBzlY{2f@v7h)a$W$GBiZM%U5%>c=2l$MZ)}ofD4Xv;py15TExrkoC6tRn2Z;t;Xq9KPP*WZb2&(IZTHx>`-BnzzcPyy!Kv^vR&Q{cV>e<`(mLR^T7L7m{=NdphYMa)j;nUa4(W$Eu#P}k*UPY<ET=$z@GdJ~n{&_5$KZU?QsqS`S9@Tf5t5E1n(ZDX30lJikfmt>}Kr8Up9d)b%OWBgguAy&DStbl>B7s}RXd9Rr<=7+1U=N9~gNXGbH3l&*f*GzMK`;xI11lat8;uH~*@(bPJ-t<lj3){Z+^xj;IcommkIHmj$6!f<%qz1*o+*GPOk#=1k7mJ28^zG7*;fTs62ZWO!T$h>adJ-$!qKwVpTZn4hX&rLKbxQyin4e@oaTLszBO-If7J*(Kyvq*Fgs?KV1j8E1>R2DfrJ_o`AiQ+gy>D?T?GyP^bmjQHJydJR$O)`>R3Rodexw)@0en?3WP-9=1zsP4hGK^3c!1>1yM5&a$$Ovmavr7l^RDx>#SE0*|Qvd9!zOS4YN{y*V+Wp%*)vm4bfEPA<L<he=a6WTtABI{7Oba%}vy*Rmldn$0iz#5*0^GAKwZNPW(a>TkA~XA&JDHT6iel&#)hz(pg!+^@ilg4VCR1nDvH?LbN)D?Z-7qg}Gqg`VxK)(bjqjmv@?2fW0>wY}d8kg}>-#%t{#s5EIbeVB|im+Am?%bus;j`A$1-EquHXS(ravia+!BR7JEi2*|}96KiPQ9+tGdTa+eD-6poCM3@DI1$3TI%1VE{6?x{ukxsNaruK}V8zbIKKbN;ZFZB6~(qhXl2-*tq@5e;^vmbz5OjKIlHzJ;EO~E^`FX~FP%hW6008nxa5d4IAOo1fP*dx!A-eDcZc>~pzU4RH`4X+3k=78N(+9)vx4Q>QtiV3Jk*&_1cF`+YFh*Q`=#N6+4_vwgF+!5rJC&UH=gst2_Ez7#Aq0|JLa6>j1Kr<T1<{?d`Ca;e*bGc_mS?BS;`$Bi<y$9w*xt#qoBqws_hT%*d$v60+c3?Dc?=0XFTocXhGa|Leots9#J6qfQvj_hLB>+ZBM^BJp_Pe7$F*b!f!4d5O-LLyRWYL3sWIdm9Lrxfhy5)&`03Cn8K|*Pu9@>GE-7j~)MvXP!O;iDLpW+OKUAL)I?jv9r;RK)~c2*w>yF_u;RB-0%Wtnp%oh?#e+_EAy6AFhNTS}O4iZP(-Qjg+Bzx5KRG=zJ*a`T<3ma>6>2>&?Mq!FQ8G)+i9O=N=yqj!(gH}=Ly@y9#BhzhCQgcSQD=teRn!h}9{s@VItM-XfaD0uMPW%=d*WA9ylW!dudpjeMs@yN*M&b@cub5Gs6T~%Fm-R`!_ZIC^<vc!ae<q7`)L*$7Y29`}3fkmS>w#CbKqlR{aFkob1AuJ0CG2qp}#0Vh-5&|LY0m4E;Oc4?T*7tqCUqoc?+~=Ho>pohzj#5XtGb1A-BUY^SdwdW3iqj*ihtt_`CY@CCpX2xWL%L`6B8ag&5zZ%Em7`WAELeW)il|@D@u#6zS!m3hgHcvJ4TyMv*2-L`57c;M+{4p}GYB9TebN#AaA3s^8iOUzjMPYSD~dzyV5RpyncyWq3Xz4DGuTX?rmRM+`EW6jIle;Gq1;<nD>IuovG0QR5{ZF;QY57+Y9K9FK+U9hl503?`6+aibSRB!iR$*O_g^}*bB8UN7;ix)l{UsnRB4JPoT9dmZ-S}4B{F(YR^qOD$|Z$EkOq-~q$ELUbvAzcWUR;NebG2dYz0H7P5Km0vJK=UoLWPR0&h+IAxrxLj_1SCU<(>t(Y^3N?Tc*B=UVkwf^xo2x_j3Mqt-I>n%oq_ien`ZR-8|8yh{EGlRvf@3~*#&UlQzywTo90!6lHP<+YT=KW9>SqK@H-Mc3QZkc0FpJLHA31W|U{N`_P<4pz8e@t@^Fw!iLSl!9D$^n0U8L19wZ%;{qwaGgY4)!@4u_|gi;UWj9Vkxe>sz}9ansxw*|eMMJtMx`LM7v7s+2A80fzG%<RQ#8OS`rD*VVza$IMZCD+PLI)G^U64T$DVv17SwQS?BCc~l8yPu4*)@Go$2}+NdImaRO2miUOQB5r$)`HDLF=rXL90izhA)Ja#|Ge)+G#z=VdcCs{f`6xYIxM#a8<stfCjIJuBO*)jqCPdrGIF7u&ZBGlNS#{{MbGXBWanz?a0B`t(E?CmUdg7(Y3)s>?YSfc!1$bqpD}bFHD2gFTILI>l27-6PO0MN{Mh*1HP{?E8cDpUQu;u-ln<wWr3!*k{R@=qI3FrJo}sArQEHP;%f8pOun%lx6#$_2$r#`^>A2oIIls0QsylesLkX8&(M|rD=N$2b7<6!2!E<JY}BLW~Nih+k$Xtg2Q7Yez8e?xB^S8vt)}d6&fj^A~q1xEGRlz*)%NywPi3VDO8rpodn`?rp-is{b5ERNsV6}=LWpeY>G3~<rR$Cy~CKoH`$uExF<VmEtY0BjKkvIDeFcX(a=%J^glGI3G<JsA?t(LGYln{(P#o`PBgK!r)W)V%L%&1+Flf*upleDv|hBC4doCLii0?~y3X>0!*aMu=mzyoZ^nPL-XWK@lZOnolEVM^B|y@MsQU$US!dfjYvLMji$n(0%&Vo46oxg}_GS6ACI_F3ImMN<mqN|mB~NQyZ)@D#OS@X#dKtFdt9^=Nl>u=g-0?M}Ed_4Cg%-@#6H$U~m7Kq}V5PeYmP<4CUiBPc$YGFMWzp|jp)eJfNmKDm*9zk`@b)px0)e4~I4|9Sz*~Xzv<xv`P+fLi1SOzh7f&5rBRbceYde)ouM8QmnyB&;NU|}QtpLT5vN#3=-=DnclfzGs|3-jT2Nd0+?hi&6ASC$vHZ*%N9;a8!@m~V}Z41Gq#_<=#f5&V5cYcBY&W*`N+~B{dV*PFiIJcoLOt?jXTWNk;p}^CJp}-UAu|k1M)nW|+ALNZxXF7*~4-NtEt|OYUp6YFg4tISo{+oSjpxg3;iD;C2(l#$3;8s~Wu2JBFwHBm*;@re<B<lHhzXXH<16;CQ13)#H^Y;!w6NKUT0>6-r2jvh3)&NGJs|>$T!_(r(1%?iz+DwLAz_>nsdDwyzgm)1>NX#_1TXceOTc;Ve5ZbBfO4yifXY5AE9Xy5lplubG-jk3EJKR|H`P6ZeI$)aF1k*Tr<Y~^-tUuVivqZfcUecZb%5PWQDE}8r^fy9epsh3QmO8+}g!LtFbefCr8;I=6AS|#|%sz$K6$lA>>Ozev!Jw?3=I3UzW{QLa$^4->5$MT7T?+G_y0F?qX8py`fuhb9AcbUhKq&yuCL^Q<7?YwnLx00iuY7$y525#}Wba0Vrevgrby7T)ILc}oXsF?VO_{<L0_H3>Vi+)*pmNzj?5cNu=4ALqswD`KgAy1~g^9}Osyd}KvKJ%FYR?6_-^M!31kDK@qvvEa#E#{tjB$i|{fSOibzjUPQU?LxB=jMyA)}$5I)t;BVoqFnbH_e?u}Ta<`>duk`9$>;<dUE~N2*Ry2A0b5V&`p0OI9%4k|Zj3mUdly=Y&OzHUxW@e;@U%y5o;hKBPohJk)vX8Z)qHQXiu^c~M!wRD5h$B|Q?{?+PVBp@)`R%{UyP=)!clWqXZMzD+s<iZ5}}LO@EuqU=o{!j0<as#gH+4^3uyic4M&c9D*O(FzI9CePA9;#0KaoJ@9)no&}WX;CyvT_FpwZzw0FI#CpLPnLf5BV%igp4=lKf*uHNXceU5R7?t_JsW1Ak0!^fKXt(~b1gLv`rhBl{^U%vN){OF>{Dl}R@sgrfs&Kv$eSZGF0ioP@fcb+HP3KN;FDg23AS%Q1LYpX+0Oikr!r<nz5@E<x65!hrS=z^|L&`ip?s+bNRu3s1MGkjUnxAJY*I|NG~IX0DHt-Q??hd|zE8q-WNtRLzCckWzw{FSTZ~kYkWUL`H3=>%aZUynz2ujBntIGZ(xUb!aUc5O5jI~BwKI>kK*4EXvG+}o*6@wUbL)D35zA)Eu1A>_2JxKK__D@l((rvGHzz}(I#?%{2y3I4)a!W!`C#iYGw*qn&rThol8k1!bl}$AG~t1)UX%H0?EKeEw~lhfRmp-IEodQqlWW?qnjG5?n>x*(K0<e=E>PtSwAi-%@`)q~8j+a<P9G=<b;h5Q`VM?uwxGSt&^+>x92=a_p4ijYHZ((fbky{TUU&UIP)Emb!(%k%o--)!jS8!r=n$G5WUct5P%uuu@u!j@-O}BHbeH0`W{Bs9=*@0e8}!5_(}TiZM9$344_Fb=^y~7xhY_|}SlP^5)LcSwBo9HB4Z+hXoV1f+nv>P*sUuO3;$b#Mbz8wd^r5~9;u-el-b3j`O!H-sx-u-;q{~G&Gy2ucmI@3b%vE9T<+7HOtz2(QK`&flXRTmjc+?CJ=C>xDUzPqF>4+x@ln{iokl$#D6Q!?YE$&qtIf#=XL>pjaSXd;!$aR@lRjxRK`KwF6?%c*`D&5k(Azw+lRpDL>eI^BXH#-`r-#O5?A6fC@?immWO`Y;fH-S9YyRK~o)+9jTUEcM<#bE2sXT9z`+YrR;v<x?un49xS_43rrQfDm3i$t=5sz%#q%vUZ9S4_xzM`b={FAm8qA&~vs9?}gm);7LlB(bnGSDq2s{UGAX9%A*8m8!zc(XKSFeR`dL?CQ77w9G3E#R_HMRY7%tesf`a<c2-nCLdYCInrIZSdREy1Bn*0fxw2=#DOc0T2Yzhs#Z#moFlr6JUZ%>C8Gga;nJ*ya6F@~pl}E<f)vI8(=76#VRDw})miWMH}#7y=DGD&PO%N!aXCnIs?WA2%5*gJi$j3xr{Pm(0MJvzh^4BX6m4gXwY=US$;tg3$*3f{)ZQ(~3m#x*<2#=}t4G1>v>HtQI=xJ@;w^9#>PpZOZwgA`8Onf}ZoxFO!tlpWJK;D6s%o?*3`6wSi21X~LpK9zVImUs68|*>V$s!W<qL|gz2uCPMFE};0lBBl)rwB_A`vnPlP<he_^H&6)_*zRpaw07M+*uEZ{U<5$LWT_8n0Mb5qUGve?`{e9j!3-7>=LN=^_xwsKU1vM-1-5VU_K+4~%yZ!S;HQ_g=DVjzG!mBdw~QSF_UGPDq>uC6lTN#neG&a5?jpmQpoDEvT#QcTN{RVYy7|kz#~N^ZZ%<L8+P1IFhbUvoJ{qM0raDEgQ>{xNOYqb_|H-hS_t4G9;jGvA;*U(Ik;`b}4W_W?SE*RQ>9n|EndvA6SXJFqT2)v}hRjr-uI3^`tW>Z#g15@)}zV4HGaH6t1JvN@tG1?CivHaFYNTSus&m0A=o`o95(}0QuP#?#xu2ik}{E34xqhx}&m8*#g!(D4*vPC27Je3Sid9EkdAtH-pi7c6QW~r4KKOpV3J+ss*t0&<dDn;=y7(@#9PwbTjv?CO~Q{&Q{JCYn?ttjn@_u1|^$M7`wKOpE0dp_-vxUk&&2^NRpK4h>Q*C1cAXylLNb$)G->hw~i;O!zmif911B1Z9H)vTKxp_4r%>JtumI~B7vun2P#@6Q;oYi-n#>3{cvwF5Z3w0saXL{=~c$8V|bSqcJEr))2diBX%MYMBoJuETxKlp1jo5Seu`lkM@oP(c6PCUtd}u*RcA4nC~OM2Ff`yN^u<yDm2_c;WuFFxL>VVB2XIrYUa6?<ihE0q!r!vdV5A37MtUrOOugDY$p$vEqzcb#(MNOVn-$+ohf{)X7~shV9Y2UH5347|yD3%Far=V&H_khW>K_wA98@f5sB}gcK*T|2lNtp=)aBu^%!LhZMAd@i+>s=R)UsX&+;UR;u713=FG7s~WrBjNqmHA2b}J&yFY@yoL|G^Nk7J=B0lNGE0+>aU(xHA2;`>vfmemuB%g=z#Oi#1k9ZMyjQ4<U&FV$i4o%&UKOsxmbDRs$xQ>V&9azcLGafr4oS)ElkFNUkENB1#=2+{^@nv|t|lp!vrTaiGObP8Y`g~=kMxrdreKn*1+Djnjw3=)lPjOon^1gb8mP}CFn;L3#wtM@0t<dVWMO26vR7?L`j6cMEFp2%5#3QzU9)5klD4k<3C;HXZ!b+rDsuexX6C6&Cpq!Q2q`h0w$JK0k)os$fTYQtgx@_Dy%A|?Up^SQi2>%NzM#9P4}(34Ro$|&UBmEi)zC+SgAgssnt;qj@@qg;~IHw8PikeSV@C#^qPR8c8{1*Uk%qRDKpRlpNLOKR(pv%IrX+jL=eSkO6?!vYrz;K&;(4}VTf{*b`F`P`89^iT+NM9hoRStzbgl5~0-J<XJ@>vWR26Eu&R^00kJt4+_UXQ%7zQg!CJ%q;Kouzt9CJ!`Q8??p-idez32OGjn}6MZqH+83-A$OG;`Z%Z9&G_3Zb7=mE#PeYElg!b=iw1!WYfQmy4{sl_qmqZC)Ba75a`B*2jeMAGN{?0wd$X?h(HZmhtx!CQ=O^ftXP1GXUVX_@WyPDnG%~X;AEzS-fU$6nFo<}KpVsBs>@>bs~Mm$T%4nO=LWxPYAY6wuM6zsN&kJnK0>4ZC6Cm7;*k0uk!9DxVV?I%ItBzJOQElY<{bddOp{J<n5vEy(dCKc^ZzSya9l!VU7Dv>Az$fg81kuAuTk(|F@Yi1zfFTG-Unyzne(PGx+(iK`T9oT`X@2{Q3b+F>H%bsdwg_jTJ8Yd*3YNfbDdu!{@j?)VGGg%dpRbn~9j;b2%V==TPzoK=c@rJ;W&5Bvfa~6mk$+v#DkfsJHj~yNcCD_R$r^md9HcBu@J2Sg(*_^2hPzTXsjI7}dJGO)pW~#}WbYTZd$A!@%?IS${S*c0=Iq_FeFXVqPD}v)!W^l81RT}s^ZfxHRD_7-Jw?dz3g9zV?rBbA&Qdv*4*^An8Rq7W<8(Au4w^WL^mP)b~Xw<$UD&>WxQm{_Gfsy2%QGB`Mgp=LHrdMgZnZ0a`&!1l@b3-LJh1u-*QTg)*r!>K0+*}Ncu67SuMj5Mvd~=Ai9<7;<qaD?xE#`%d@D$#$->k8TV9AleWGp%B*!SO7qxR3;=I|GezSGKH4-RgenWa;F%57o_b>CsnD%vQHQ)3Mk>Wi7|Vd6OAetYw5h24$p=~{cM-q@c$NrH@4LTc|12CxZ4CGL2saVwoo_E90XriN&OTut22-cs4J8`zqm<HmiqLYPVC5@C?sBmiw#^I0-zB^Zio3^Q%MsARW`E@KqsIiSu(UMg@goKQ+gjd9r!&QC<kNsNGbZA($+8ZZ+3?e*^Z<Nl(})#ni3e3(6Tjg1HS6yCr`-F@tOB8bI|;C9vzC7_fh)#GeZ&EmWO%k|H3qFVxgBD5Fk9Gg%pXi0bJcm+COFL=+h7c|HViszsud(PB5<4POXby7YFZskMqJi_u*+{Rs-q##T|Gl=I>1k?Oq9gfcsr-cWVZ0_XvJerv?_rTN&78_^2a%7TGOv_4(b4@X%PA0sFKt#qYjB=~OoRfQ7SK5w4o>v~1`m-<Jq+ruKGrYr}N6O~1^>DXCQOe4{G#G^RMQ=jLOI3O?LznCJL^cgz_9hllKokFUkv<lxTEhz_mm_3Kq;_qTWu&;Qu1hv|CFGPcw;|;A>OJ!-Zk*_7*OW5vAj~b8yPUt<5_fU~`o=P?s}92T2UljzhS$AqHzc=dUUxJW+vTN5zLfNxq^KoIb+~ZT0g0#!FO7`U%-;yYaC~vVH!jRq1%G=Y<oj|Y)>8<pw!%$6!gUo_zS3dd$@*s+4e{mctM1Qo5?<Iz>;HHoBDrcb#PyY3jfZf}Rt&2y)%<@><)3eU17H#GzO|MSFP6?M69lu0twX5W+5|e)u#6t?L^hzd*PcU{)8^dlqABLf=vSZ#$=NeTWC<|Lo<J<|6J)(7QC?jDTNmn7b+8s}Yag@*OM<4H>hQQxE-d3_*`bQ&5Uo{()49j(Ym-!oyDW?lYrBbyV0Lfg74<Zm(<o-B^;;)NsuL35o3o1nt0D1GM-8UP@KMGS5c=wq2gJLyr6#hfOS0ISY>H&lp~eRzp(@dO5G-9Znq|zP>tC~_Z4=`6-|5lay`F|>X`_i_D#U_qe06J?@H2J46XP~Sa2!)BBMW$ELE*xDLQ(BwT-(V)h(WFD^vRq=>BwzjpS_sqa)q3&8F>Owgz+2%x+N{k^{o~=hOop|Gk6sin~pb7w<14mw5et!U1@}uD-PAT-s)V2t9~2v7aNkeGJ67tWQinT*R@w|%Rv#xX6?n^Su$mbOwCiu$*2O_|Ir#msoyf4Z3Wl?Y%%|1i{hBtK`uI`EasDS8F$uPNalHn-W&0d<&3BVndJlXk-(*A!`uP7U{H=J8}e{>yi2?IgxC~UfG+IuO??X-6KMPO1K@6v?@oztHOMK)9?x4P^K=N5=?zNO8Ko7t17Pq%*t1LOy5JOcdC~upqJ7W%24!;*MuJO&u@R6SH4E?+>Hv^a4x&nQl)nlUaSy0{PI{f#xZi62LQsLK{Qd@Y`VFg}ZOG3J8f?!Pm^sN}9kW0j8slpQv(`+iRBU8(m|?|&0y)zWvKyyC4O5mfq$9!Ld5g0RZ;UpXYDiQQjy({%Ynkg)CRx)RppvsQl@8#R7#POo<lkZrdT2y!BBd?rY`n8(4(-2?0*r}TpmkdAa2ss&TY4(IHs;~O|1%pG4FkV4>hPZIXX2f`we%<6PMbv4eeRH0Bhoi%nw;ex&KqpPPVkLWG>QJrL!)f9PKGen$dm)8b`<urv4$_9k4ZgtK^gO-;ijSzmf!x$(|*l|5YUPDd~KzuLG`{3t%<HCMid2B`F~CR3#L#c|F||x{@qMj3*q9Y%+jhAuZ?K9lmKM!R>+LHg0``m*&Dje$^>1HsWK-w0!mDt0!4Xdj9Y7(mVIkfTU8KJOT$gIUo6U!fNN}rsC{O(+(NRVkj65W_aU^SsUmyGYgn1U&Z$~fEpBh`hpOl5d8eETX;p5fR)HmkL=B+&$&we+$)>Ym{*rW}w)h&@FXrNrq!X+ZCrQ-k_)|E(roDdOLRMKR8DFMxQd22YV5i*-TI+d|-bp8#at?huB=glN!8|4OFrQyW&UKo_>R0Hylj*StP+&~68HReb?0Zqx95>G)n8c}xlrTdX!m61olr!fM+GsK7@0jh)yG>H|VZu^abg=zM;)WWbCYTx#9iWvSXXWH1$f`_;7?etq!wsS&-K_ZE4k?>=v%J{jg0otSoiJN5fL53z|21spr7}mF5m3RJyk0oS&H95Y)D7zfQ8S%oc_B43%;^=Slg87Q`FXnflLpE|SnLi>T_!FPDax3lf7cqr?MFzQZ?cI`6JqKeNwxYF#E<g$r`zAy%MY5H4bjf3Dbr=$e>bObarV;r>)n)xgCXty?oS0F?iq>Pg%BU^&Ah;-W7@63mUyDK_~D2GicPztq4Q7{=lCzzF5>m4?+4Rd?)xhX@t&X!cr%-SIA*l$0?pa|Au}(mF#(G(2ZX1)g?NfIKaY+p=Dol+=UjPh+7zvTMp%T0uoi=w8tTe6+^ewueB~dmLTpgg88B(rd<BQb2NDyU?D=<>1h~RxU2x~{2DiMhqUwFEoWpTK9_H2-OUk{Qhu=)Z;}w^DnSZ~1&+z}lhV3rM@a&b5`^AUtYcWHYtjs;f3?DLhSq*x1{1W*z+!?}bAt=M@Uk>3_z`(@kJ>xgOZ}5h>Z6GsEwaez7!FvtwuLo>|+;?eBx7ebHAjyR0T2)Q^wBj0Lb{tZ#A>1t^H+PcWTqSGk@hcxf);42fCu;LDoG@F$dHgD(xf;Cjn;E>n35X9Zx9f<Q6s54*fe2)dPjW8q5Sk|>A+b04>CCRf?8ZySc%ai!iP2!p=IK($L(9y)a0UrItJjo=hWkrU$Vt3mBH}tXt~Q{uB$IeX2yog>&NNMWzWx;L<)aNB8l;CfA0(V3%$I@HTGWt|_pNLj)|gbCAvuQjRvk5M=*^Y0>Z|^B*(`JUXLPsfNF<?|6epMj@C0fz*M6J-SLwA~Hp7F~0<&ak153`x9=V-ui6yaNC)>ZD*kn}C(vLp4IU&{8n?~hP05?>PkiO5I38_WSGfrMw$mOKAq}AL3qhbeKl)82ExMxqY&&IM5?iVe-L9i%PIz+A!6`@-RQa=hX(9<x4AYNdSIc03?sU1|HL1nCE7BN_n8xeE;r6<<8yP{$?Z{ZF5haWYtz3b64uK%Bs?tip2x|9^0)_b(?<6)C{Kd1CZ>dBr;Xg_E0o#8S7mHY{L=ntOr<s#b@q~P%q`^TnEzZYG&i?M*?b3GzD^+iZUKQzc};|0HR5(eP{yaUWr@FL*P=@Bwdnyg0lZUmaGTgs#=!372u!SzWe&0v2q>qUPuHj>y%=_#qigwxU`>`|(bb)ouOUl+6MonhG*%Z5Se#gb88rosayJFM{jp2$p4vdBed)&P}A)DXOgNP9)vDFp)i2%3&pjIZdhU*tVAw4ued3T%LuFgL_4sS#fILzcK=6;19-Kq+&jh_2#+{R1P(2;Y<fBO7E~v<6~CzzDsu<8W`#fpOLVjN`Rs2Q1+u?7EZxsg*LU9x<iS_a<q67Ls<D64M_HH{Y1bpZO}WF9#vv?_gg>dF7Z%nHrYLeb)$>nJ0+aR3_-CG}pkFUSiS<@MQ+LpuySA@E1<=jy`$`f8pfD69&bo8UB)_@&vQ;YxqkL{N*fXM8m!ae~)$pHFB-ANZ`vT1Vksq{9=oICgSwS3)uBW872IM-2wG{{#f&q6h8wH15?c<g`Y!+bLknGT!^u{=n4BId*Cd<&+mbR0-tb5a60DpEuX_x{0REU$84u`^oV;q@K)&(YQ88{;CPR~VPm4}>YRelQh%?3M)I2`b8jH`p(N6in^?yMUo;q3pN}{goSTUuR@dhf_ADkr{VweJ<a>sTt?hvmG7oY_w+u%%lRHcS8;~Z_IAC?{&6_CI!Sb#U>n}I-8p1I8-43A^ALNm>okZ_-PM*^-^~W5a*|=!3Nz!I>2exjq|DUBt*5v4l`ZME&tp?k}^BzN(&*v7@?cPN4gLQ1eQZqOIRXXS~YccNQ#3k-cy4FwaC9S}3si*uqy~R;|tFMM~MsK{0dIgbeoF38Ce)4D_I7<<7?>%&L56~|r&9PT8r)eP{5w`f?>LYD@NDP)}BDQVo1qu84BXyK*ylfKQ_r&Wq^Pfos4wjXK7sb!|&t665e)M6m+>VdCOCs~Vv~xk3dnun`#J+6Gm#$O3+o}ae#D}DO=_^V3LSwdztE?}0*4HZcQ=~6{8Lo%D5EemTp;e|QY}ie*x6bt9lIFE&F3A=9I>BSx@+QaYnB(PDjyH-K<=r@-$+}fi=Z@2n-MDbwjSIiB_|AX#9b!Z>`AO+PFw)c!LyA`U7UjMELUi306IV_K5X@&%1aJWp+Jy{P`(s^95Iq)E53QmOn9bB7A_f>S$J3$l4Jhc<!fdJS)G#4cE<mG;=C5jW#$TZB|FnU;Bd|<o=vdI+2Up^Zb|81&L#{>j;<~irCYX?Q83L=J&-j*CyI|-|$?$&|#YgeZ$k>z8{d$7^C$C!89}+zXjdl0l%j{rY#|^u81q~s4&Qq7wp~Y-dniqgsc7}VXGB9q4rgxdB+)xxT;9d&~GHEGSZy3&qbGU$BO_=6jlC43Z83v3B1q#5!k4}c%km;hnOqwg_d~A6GP&kh<#1q^N>R0SHHlXWwoew4;k-T!d^=PIpUZ+1{i19y&<mYq={gLaK=mPc0?^@vEi9&QoAcIriu{k&+#@TJ42!Gt|E!~T9<<7kPJEXjAFlA%1qad_bmlUL^iAw%VSdhN$t<@|jh?Y>J2-c7612NDThG^a&nY4;ypM(RCy9;%x>hbS|1}D7Kg9&_U&vHnl>5aBL&KvO0C;EP9|MTnG?Oy(AvM*=q6X|0pzK{B|53{Lh%Kx|x?tO^g{jhAF<-{+a&0hhIzkEX93W*a~{rP~L{-m6q8_zktfux(Ow0`ike#6R0UEu5OeN;|gH#>>c5yCUF4kq-()J&exPl)dT>LA@VKX@wt4}Z{<{8ABJYBUe>i4BJI8?eA@8iqts5A_%Pni@F{E(NO5PqwM+qEj>T<f7;Z#?o|@D7rWa==$TFN#<LI)Y>36+Zrt#<F3SqFxzV3p4{;iN?NzZmII^jevgr|FD{C{MX~;AY=&K$&emwvWkh)XgAWBx_H1DGnRY38BA6NywaF2bY-57vn%K!Kpq5(GDbbRE{Ix4UWgVKug>?k|Ia13ZT8}ZSOxzis;pCl0BcX6Y?FILuO+pCX)kH4?+qBEB<RwRt&|0b?xkv+N?SVbdt&j=9Wf;<`TWIQ`f<Q0LLr&AKEnybbF~r%+%X@A_hxlgc6osR8r;6yXzAGGGSb>e~NP7OdVjm<2z;z>L5ewpHXO#j)jP^5U#AR3q`ys47rY&@f{w{RgntM6~{zz$7GKja{7`JxS3kGxc-HfwJ1p1-|6lc|exSG_b1vI+YWJfoZwu21j`l-vOuI!ALoN=c83XgexVncGQyCDGGo_lWXMneY9ozJ-ZG{4FXiMgs+FqD-+$>ndFveq*s(M?wCh!_|*+$ISdaaT>NOsH}~lO2?XyorRRQAdl}v68U_!%0HL(o#EVhKDp>tnV<*C}j6wM^I1x)+qJ>YR1&;i{8p(#avzd$dG))tWl(86}u&(QP+-Rkbw-F#I4lofo7^dX>zgkVEWk1Z3(0t2?}UMuB#K=y8j*5X<Jh9J*?{NI7|(<2!6H1K04-&sabC}SG%;6(5kkdfbQc=AgjqVw!~59)kA%Hv2F~1!2hFq;fWIFQW+*mJDcK`j&>t&+$@*^FhOl0%qjxYh}ro+{JPqVQ*gD$S98u?`@V#;Cnxk?&Kd8u8FfGO*EYh@t>y3LpJ{HhB&)=(lh2+$lhHHJ_9pXejJ^=s#o!yf>+76TFp|u@Wiv%Zs@V!dv`#gndkwm=!kujMMPHG?ix=%gD2#xPv2G!jWQIbj*=@9{dE46*GSV&569Rbu$`Z&(=JR7C>0^M1D^#yQ$5`gf!*}U|bfhETgUtvC6O&Y{%>S(r=TOYVB=K4&m<197)e1UT|8Frqd$8K^Vn<=@dM&3`6KsmkyBGa023Z6fW@p!HwvX9_lv3*=AUIX6p=?oZh*a_5c#qj|pgWJQMOx={ATMNDoTnDaQJhATf9jaHX4YUYBN_Ao!kGMR7_M(NN#y;wiM?*uqMkQm&2~a08hb^nCfEV@bNTyi7`4?H1D)MOV^<tc*AwB1NCU!$X|#1DD-#wl`+sfzRh;|Yhf?_?I9J;Mp~sk9$R+tgP@jA^gkw|QB4m#eVh4N7%O1r{QV`%I!+wdMsx=Ccvr2(c$Ze`VYasx3j0oUl9ob1h9)`aXMHJa<WK>kNxMr48YEs2zC>is_(#vS-afogO?P}Gfh@g43<|oZ9qw5Ka=8X)SR#_;_s}d^Lh>*kL`H?&pi`gk?(Kycv-98rmoAo_Izu_lSQ9H!pWNz9;3O%k-k=Z8OgJD>Qs-)-<JRVH}!f<t}9v*-VM}fQ}1`z`E02e@PS*oZ9S%o#(gtJw>&8B!I#iLG19DxKx-N~|;sB5mLeQKoEnRbmxm9`pYqdwIA55Y~3Wqky24U!Ni=K%?yXgwUl%brj}J$l)t@g)2MhLin0AC{GBu6c=yRaUxANoT<UnVrR$z1RZC{89cb&VggWX~<@)eL;^Db7Omn<&vf!r|E)91?vl#u=@JSLz7WFNC-E+*Zfth&S%PB)g0n2mP1T?#|)z+*m2j)jId?gxSUGs_iY5?)ai838{Eolg=FFjwSs053MHq*Is}&X8h9j=UE{Uuu{2Wuf&DWK9%vVGA#5-~WLUa-p={z;7&==F1$`sRDyF33tPU0YC%IInM2f6BMTzRh1h3Y8o}?_|T)6<~!rKTiwa!mHtS8LuHF|4yjV^GS66Id&#3?hL#_;hVgK|p?DOf=0MkQX5UY)cDei6CHjVgP%ReQ;36QzL?PAWalVGv)Pv<{J43e|HdV8JP~i>D0UNxi!y#AJBK#&oN2GQan(RJOdp<;KNzu!RYsiQ3%q0q02k5yQJ%p>PLRvC+-Mxt2OliUr6<5z8cqm6s8gv@<j}&gxT)B3Uf^Bv`Kdk#<Xk(*Y9z=9NNINk>{5D0iSYoyp%Upj=^SsWhJ`uhPjsa!GXxr@$HgyVB6%mPWD?U2%3wY~=1Emu9Syd2SV5=TYmgaIZYk4@{t?TXAU8lI7}>PQfy+u%waALi$@V=~}k%V{|^vjHkVM%rD+*71A<Z9N>PHvPR*17Y3h!om{~yI#l@1{%!0hI~bysTKhTf>+zZqq8Ak6S|l*K4rE@w+DL!1XrZen&WERQwWPB0ABqkqcyY0!X`WdItKPq7v(3EnJ^hK>DD;i345!&3y)e0bLM;tar_W7#ZcdVNe@dE(23p63ha{yjiulkN;)!LxBmk{H25fNR>{CvN4MhWkInk4`(dp$afi6mLP1KuVXuq?PEd9;oUxvBT_IZ%QR9+t7HL7CF+wn|=S))3b<~1L^X&#dKNJG^H^R+yL2O*>`$FO|7CaE>ZGes$X;HTB2{X3QrZiDg1zFN`cNpXS^DB=x3hng<seR36ZD>AtHGFAk@|F6)eb-Jdfz${mB4b$<GvP1>qO0+_gg=j9FOEN3xHt7n6y?45iR-?g!(mM4w8V%5Ng4O~S(FH8xD*_hXTBjLJ2@`&PLe-yXFv`@Z!%_>1(iOP8=A0MV99Xv;Cw_ggN-o53W<cp07TsUNqT6+T_^ta5{LwGg=R7fyudCCs8Bn`S<-uBi5I%cQAlLXhnSh|sb*2H{(ARhz`IWkz#l3KpXF?ov+w60E>QXmgBG_+8*@4(u4Pj~+8K2mz?E3gH$w$RB<IpYK#vk@cNQT0&lW`O7^|yy+pV*Y3<cti=5~^r8!a?%ciTCyahA<E?BH;~&ArII&73Hr_-e0nNyPmwaKV4UIryQG@sGECuFp;W0N%6&sI$7|iiIiHle?Wgdh?B^haOwT9R%2}t2<VIT;vG(+^ZI5?qUNM!25kw5>T%X#O^LWPi2w${|K3<+<~m1}R~22=^PD_*VY6PHPgaB3bs2Nq2n3LWBE~$gW8VBsp;=dGkfws}-E06gVlR|GZElC6zkhZe0^YHMG9t)oC%BS_=0Q!Y-~RG&$?rQb<iUigEOtCLEj**R#IBmt^~g#a-VplixSs`+TW6U%;96O!O4XX9APf?f2vam)%);0%(p^^ck=+JX=f<RB{wqX5Y01?AK8nI^NbO~3!R3nxq{8gAliF^qnKG>IXll-Ye=<dpVJ^36u}$#toUTNId;_n<&e{hAp~NRh{?Eh|iTlD-CerC~0#YJwa<lJ&gG995qaO=<vwH6Z2>|1GMi$o?<YDLEohR5Q0ng%tq4eo76;r>p+4XCkJky_je+b2UZ>W>!8I_*lBW5L!@Bo+|E$NBUae8VVc>C28^T{(_+09X?R=-KrcEo(&(@L(w%$XJ700rd!rr@nOpNZy<%k>C9DKY{=xHOi7W-LcQKu;%Bqz>A$F`1@#=JUuQ77bc9{~tXJqTW<ApH|@mSSHEB!a;rtKP0oYn)B*GQpt3G&!(5+PJHGzoS&5FFJFPH-@s6`Xv+J^`@8b#MfLso3SbrE^cr$9_y+LSejntdPGNgSJTEoc=mH|BszRtFu;>j)m5PkP?7m`|$nw>k>^RjdV#f-5QZNzKWtKJ7k@s-#8f_-f7K4j~0iH_Dimo2gsm`v%$PnZL@8VURdxG65=BB#yWBuaCF#V$o&;IveZY*0&t^G-i6#oB-{A+pg)51Y_we&z8zFbf3E;>sVOj=P`DVL>UsT>nFkYeqKMJx*GfokzO52Gno5O7|fw)F}l!X(n9o-I}&x6(4Qyl%>7TXr~N4{b8>pdHM4m{3ioHQZy-HH(%JWuFi>G#{YpXWea`?z(K3aeuK4a8sxFfp=~f(ZXvXtbjUZjk140-funl$Gi~+=>Pq?IF?^6Sxp**;<%4aaQAcp8^2Drd>y%{5|WX^yGAH_M3S8(ni~sWIuk*P>NFpc1%bg*2RTb)EovR!pCwliIR8Y8REFShHF8Cz7#(rpMYN)@;;UtO5UnIb7Mf*}S!cbdoioGU&9|HtCsAi~Rccj8ZlA;zJJ=xtV_pcE8^Yh2c;BP41wR>#ATukTsWtLk=lr(Re5(}AU%fMlNC@`3XoMv)k7}p_;@@6NjjH9CB{9-57jXK>4ACTEtg<hEH=aN8!ny~A4Nnz1du^O~>lm_FrGV(z{=*g!Mpl&A(Wa2ODROi%4+a9ED`ZqvN?Hl02YM3(QHe3FXt@KYfR^^c7Hzl=mkWJvv;k$^@g1@Z%LeYP8$2IT?v~)jR>6FoWk#>zQPATpceSm%+M~-+Puk&vTWu>$zyq5rkF#L~PDT6A0W+9Lm<q%Uf<cg{&!`C8xM^pLp?264Ki0=~N7EcHdSaaAcmkddpwqn7<Y~PUH;zl$=41c{P8T+7z~zc+nhcGZ&>O_mvPvKg;l_AUhm)tgH4mUH5tOj{3RLOiMjPimd#9twzqdomE|H&fw5>ty%U&^@YrVC+RgMN-%<~~}fgS8C7`{Y5=H;{?&7xTYmcPfwT-vhKVm98<Qxi}yH3IoG7ujG5rY?h)?0^5QSb0rS_WmMPUQpNxD=IVHyeNoz<L33EjP%0Lt6Ld*<+Y&~lcblPUUBjCVrt*q@$?$5JiUYmy45>%*7C~JtNy4_D0WmHB@m9YB~PzWbyo`b!_5oR^??>9g(_w&h{Rn{!iQgr`7p|%l(h)fs0;ueUw88Y_~aWm^!g{>pY%Li@=<#0aO=<Q1%4MNO34E;vE$(3Xu?I_Nr4X!8Mw-`ez1E9L2#MXzUmp=1rvjcwj~`~<LTM9>9tL<4R&D`#z(bzbVo6*?MQ%H1fa1?SqjzKzHYpWGa>jy-5gXpwx(;}suP@az~NC=qV;TSnXhJa%GqRxMic(z0dE_2N9&%uRH%RlsB4SD)kd394QZ$D;Q!NnA#~?=>b!t)#Mmeihh}0ZYs_XWwn3)3LF#4zAp2e<0?eRGD)S&Q!#VCO)G%pFq6MTflh)dWf@yI-L4uXuno7a-UnxwR=^9H<i_9y`4U+52I^Vmflg`r|XPpckb9U*r?3mD%@09O6%)o<S&h#@V(gBD1I(`?e)UN~?;|ec%Bb%a$L*7c!;e>U~KZg+Gi=E6?RoRd-YdOe8(K5OeCO=Z{x?7oB<f2&^P1k1ma|ZG)o89xuif+>oM4G(g85VCOCR1E#R?ey+FZ*^<h+OFX?!vR`w@F;(m+Ou4e;ID!fm6(F>h6o$oV{}y#iF+7ozcD~=<QU@IqTsesmCr<gYhC*HQI%l(d_UB?IEpHzDL73n9BEF0#uTUGZXKT^$Hr9UeQxoGr{)~cVLR&#!zk1U+$x4oSbne7KzO|h&j9Bmx+F(;d#JY(E2(B)5MN)5iMqgnpjZmX{;b6Xk!4FRDxN|D7c(gJ<X(#29ic2t50kP`D!>u6%kBtUJd0Ss3{>G{c>lReXkg~9pGp@lOuqlNJiYab(3d!JQV4I%gxjT{o_@3(_YJiYd{q;mNIx#i|$PRmXezEzkCzC{I9}s^|df9y$I97Don#=>5zBKk(z5}5S42XYYIuPg0&RyAwb=OmA-7!teWFBBjqb(W06WB+Z`f)yrVTE8&-~j4otjW3Uo;nWw=ElaN~I<@Uv-KlCm*k!S!t|c3YfSA8ukdQu5LZC)V`Bi8aiz+d%z$lV1F0Be*~RC5bd{phQ?$%_-4!-4*bPYsgyzy;DLZZ6GMUlrVOvh8TIP<;XP_4F?)y<P3oWr_=N%=!x00aDHh;tqG&#vqM9x6B2CTVJ`@$teI`jwJ}~JwHDKE9ksg{HpSpR)EYwM{c+K!<WFMHxp3oG>^1~1wL)sC`^5OMaQ*Oav|_EBnGf`htw%fb=#`^F*gAWM8t+5fthQ&8%K+vng-HzzqEpkK{KAy7mY1lzQ@p;#@7(~!7ik!h--g+@!VG}o&XV1@;*<576c#d>uUr}M7=S3R$z&6=xtU2Op43&r8e}rUa2a#okjXYpd^&`#!|6e`Ro^`TD2Lzmgo|8n__}0_C;}LVtbXZvqN_Tu-qF}QTmpLD4E3jdLxwKfD?^u1zJ#X>S5cg^!<DFoVm~u<q4K=9Zdp2=<t*4;UOEM@8oJ<HAjMO!RTpN_3^Q~gtzqc6p1aXJWtQOPQbrRG&Cs<7Z&q$D$$bmVm7Il8UK3P4vvFPUk^Fytt%fe;j-gA9^OBi3+(XDDPRZ@c&}F<fbh)Z}XL+Ky0Evgn{f(lHb=tYgP5Ltm-X6RN-ZyIg&`gnXHl<u?*~~64J4SoiqdnQf<aUYqxN<6_vq7|UZ_QZaLlkWqjSfI%+Lh2?BGF%2PogRaR!|0l`Z>K#l2_&LPBAn_R@+}|4f2QF4gNL@sK$`zn^o{vL!P=!pWmr9_|wa^g?oRVZV)y9+qaAP+9~GyB7m=c_Q6`Ay@r)JQEb*MAeLdJJLo;j`~vnxxoV4M@+ua5=~(nK3bbx76ZyQ#U*uS{W%8m%<_pK7I|DgfM}(~xl?D5fY0+eT5EcXJxR*T^TqD0`Y++oGUldEe27et_NlLy3e`!=Y^2-eEzfJttpZZYz7lhbTx}<F#M~9jPQVZ?@BE);><zPte+nVVZ*u5uNzTFa}0L6v0J;oCqmNPRy*bIiS7b)og=)9`rJvnNl9C0Zk4$0{=mQke0!Q5re1eetl_p#UdG<CL2RX^pQnR}?I$L<j$YjCd&)>&yDy$z3jya@3fu@VVMBm8|Yy@?}&+Ip$qIupvR=&(&kpP5587)p(bcPFi|RA&n>uHIk%ChQv$hxLcqH^i^jz5#bEKpt224GqPl$#42_2M2wT+`<QtVre$<Ar20#mDB(#zjScOAUbvTj2l9GB^A?sxN*Z@`oeTRX-OQ|)I8rK^5Kf{#X^wZY_dxeG@P&vITk=t)YA<8v(~!jY-)%r3g|aL5C@7U;_7s!r+Dd|2gq?;%qk4HYAoi;dlLNviM)tbXOD-$$lF;O;3gPvJE<YkQxX1;pxt2d6(k%+IVD8NC-FXH_Z)V@WU9#Xjy?V!X&)#3rkxKm2_cFZg#MWNNOAyD6l|?5zlenc8liED2KAiLgx|yU|NrE7G-3CJLR9vQH@#aFIKKyE;R;c=3|#_LLi-MRs77o8TKv9OB+3=77j<9=7CAQGX}e)1UY%NFIf{&xz7Tnr?D=;K0q<T20q0j(yzM(#yi+~AKmNs5&T}2HD)Mp?-jggxGmV*M1)4%V{M|A@v20F!caXnykO=G0$L%KVj`6?}?L<NYM))y4wd}t$o*0kdE!Rb1*Fv(b)Q=E(b?h6{a%n8<P6pab-8TMS>H|>V2PL=q6WX&mfsV%C)D0Ye_{?KAmsh*1JF1*~8o`>aJ0G`3sp6RBSyh9(iQfYY#6&pioOQKM{?)6NS6zUAAxs@uQIYMedK?o46`%{a6^D;5)}3rlpwg>hM9f*t&!!QYDMM=6OAd0JsH0@EVamhV;P#8r5J7XRA3NLvu?Ocm)-ej(iYVbs_4g5x7dXVDFq52`+K?T7ZMQ4Lt)m*qBj?weJLaQ{3bE~%W|3qlE`ZBBGHN~5pS=mRHRoA3k1Ix%d&JA9SOc1P;PwOHYVxxIKBDCv6)9z)dRSDnPn)<=Axnas36l$zbb}UKw2wB))F4zB7G8Yc5W1`CgM?41i5p#XV>GQdQ}ZP=O6aEHY<>s0A^*!oh4B}>$N9PnBQJiQP9%BOM}a|fS`-#3ugI_MInl+dw=yWdGXKi(GWXX5#l`S!J6m1~y(J?v?RPQpGaid>r1^>TTQ*Wlq_v=ca($i^PI#ePraKfcsM*E$*ee$qR9fwQj)#7xG6n7mGgX@no|xQ!FPX7gy{`P#**Jn6`8ddqw|Bi_hZLX9uq?FP_~C%OuVx;R_!Sw$;<h3nvKOy>oCR=jBrO9hw4OIO`nSn{QMNiu-iI_`xy`)_0U<6Tj)v!b|MQhq-Tdd>?Nwb<vZZt_|6yC$?>7<el~5<l`gdwaN2g`1_|N@2_|N;0-3M~17eOEzhjxLiG**@ILc_XK4VaM1)IZN>th9wAWx4<eGM(b5kdaE$@2b-{Rnt<Mo|^7CP5;r?ZD>&5ixFL?7p9uDl6@XuRT_yeVi&KIHEvvZKYVfJXTyjpYRPe>`J5Ml%PX0Yb``$lmD=+?fswQdR<Z{x?Mpe!Ias;zE?}GD-5Mk5uExmwB9$Axk@KQA!Z5|fGjFsk;iUaHZ`acABLBq1xW&|p93^rgtxt}$U*}YWGqZylUE0*S3ZuF}1Ob;1!uQ&M7DE*N%3NvD(wLG-PXb7BN^tEZ@YV{Bdw3!Tag-UIXRSi;nIm*_kbSg-7-ttCzpJotg=lgWT2r_nH|Cz!vz>Er^v=XRXSFc)vvZMvz_2l6TS)0KA)5RuHVr}Z)cSnUTr*LG&;-1VyS@{wVMF;ZtmpbUjb_fz0JD^25|`+m8Sl{E5gvNcQ2hiTpe&B4NSq9esx6YLBhiy1^-l80J(T!;Uh|~()rJZg(#c?m1-vP<XHkoG=4vN5NrNH8-y43NpXMT$5J{#f$EoEKmzs}5^Kk<$TP$C&+HHOq^WWb?PI+Q^ZK8W`&($Ao=ME`j-{Mx>raH3I)Ka1W0C}60etw>nlob~MIBG=Icg@EK);e18Ix;2PAR{?39sN8spPEDi>nbUJ-bLA8TPKmohWg!832)gPnqvGsH6vS%1L9Hv5|D$`qb;o`)mpcRZ)u}Rng~i>Oi?5!$+|A;D4Yd4m^DjZLc#5T4wN$R2<%%#y4E>PwUEk)NGr4R107^s#8JF_?nFS4I?rSJi_m7Y0xNHb9pnj2gjsSQfR)BXFVpzFY{k|dmX~bN6B#cpwmm!c+&;c-t-sJwWvf@C!L&(<HrBl*#|FYOT2AFOmCICx6+#7Nl^$~qCeqJGj5abS2@S!?;UYl&@Ly(<V{nidDPY_Dh@g-_wI-kp+RSOB88uEhleXprT+eneWd8>Bq|X4OlQ^U)>`RpWfzpFDtT~$-a-+*ygT9{ln37d~C6W?eFbK73IQhAYwQq$eOf?@#a~H-ddHlw&qZ<3;=70K<aFOq*2*Xkr@5y?e(6$dtC<EE=8o6<v#dUo|DAUra1N9~aG;K4BcoiwWwZb}S)WU~LXmlIpHBQ_F6~e7`z~OGqN_U&N(*u+FV~LQYZoCIZ!<L@hRa?(v5R>$^*4Ly;Z1($~Igzj;iaykT!jhLma5;jfY;cY;VVKK`OHltO!u9AsLg*WN2h^;B%_*bYngtp5rp&!7_Sov=@fb|cwrHB-&&0}Ph)HV;D2nlNiUqht9HNPJc+telCR=LC)f8f5bKq<34Ezfw9{dMzZa@ThAjcvJrk=}>9KhiE!SxzW`-nbi!@>b)7->R~Ps+laWD@qA8#^Y7dxH+i;n^(dnZwv@T<^z=^=v5qZ_`Vj3wh8##HT))$j@1r0-Q_9FKZ=dycdO9;@G*JYxynhOGDfU>dWEAxSE|)iT)m(ED)n`QmXeut_Q}jc7$)V@zKsq7R%kOTqA$TfgUkH7BL(==@_1cM`l5${=E;z0+>niI;#*9lW(^gnp{u+&eug5n^-PvU!((|$YB-jiY=ilJc)G!kqZoQ>;)yZEC7Al><tIE<y*>^dDa*-TeFw8e7#0oG#OBd{;APQXqVBNHCcq0hJ2D4WG>HOb~fZQP2H9vn$i_px5txf-1p)2_96~Aw6tF-62W1{(TSeI>lrA<Hj~2IYf_j3F)H`nX^aPE-GLp9;LI-`CqhXBqAl1+PR#=*Vn>*1T1owg1>@nHY&HIi&2NPE7udldD6af407ni#;yRCIlR48>JvQ0>aL^$c89(8cV6~QX;=-C$(gcwyUe%fbDO^}lQOjVEL@BoM*2)B(6N#0qSB!i9RL9zW>2A+3mD#l!Y7nG-VeUIxvuZN6JMQ5`h`G-fq#)bPjMCsnVW$c#+DzCEg3&{Ki-p;oQAcz?F)@ME$i^7fBo@)$Y%}R#2uG%xF%o2c=BF-OY>fg_kF=%bnFN3XW>@t?F>iTGHt|Pd8P%a$r`HLh2&D^q%p96_IWyLK=)e9(4W$@8*V&|P>GSzh8%pilcN#0V_gt0pY^l8H($w?OHO?&3Ji=XJD)C-c{h~H_CnQJ9RGI%%anmshU(()_t7>d!ttc0M5*QsLdT3EZu-D@?@IJ+XiX&IAo6!{PvLqf@SF`~h(AS^6`3N>^+%?Ko2aD}z2rP&&Gm_j01Jd+>v623ufwOB87ilgfC5rGt9xY!ECxi9#3L))8Do1{?P@jFc1=0TQpk;vbABe-7asGpq09VMbYi*>vAur2W5{++}F3rfVk}M)5?5i;h7vlvQOgQB^OJSUYF*S3Nx--7B33k>Yry)s2s-&_j)!mZOqFhzfl$*tgY#~gS!VT-0?RU+0kxOG-S<KE09A%Rvziu*R5XE{8{AHPR@A75FbY2A6)~_tjgDrx==+*vUi@{hdg~Bmw?WN%!M__rhzhfL~-+rio|Av+8f-+sN;4jxf_d@S5K;J_%PV27Yh9Cei4MPuVnLR{+7dceThJIev$e8%f=O(lo)dn@Eaf~>|J~EB(A!MkyjQ9@I0;)f(v_3%6ih?Eae+k|9Dt5?c#EO35)-ijoyhZu)NrXSL{M-iHr#=!FpKwmiEEE>u3#jrf-Ws1TWHYJjU4M3AOr_af-1I^h${9ECVH?-l78Fu1i-CDuOAHzdOBJoPVn1kuw(;TtZW;h#zCT>jKgN}5d0Ko5;!4OcyY_mvhy9#c%)eD7bH!Dg<=TV$z0XH$`uwvQfmXxpp9<Fo={Nd_@_@4bfQucP%%QXXW|CNJZY|22MLTnbb*fLKQCwq;XC_FW{S{c}@~)bGk)p)z+yeN*0}8x>^~OU3gQm5vXc%})wJYV&Ejy4=hBNs15R5zwvHh@m%sRkKVBiR=RR<TXriw_DM{OY4lVCyuMN$NbMXECu7ERN0QN!v2`=v$3x~3~I%2h~0OunBQ!4Rd7^*zfXgE%bIyrWrK?zP0SEGDL2J-pJV9v*$M><r&UU~`&~Tyr8O7TR=L7#M&ahPH82?~+#Dw;@urqY**=0D>up=bkMH;)GTI!~(fxRIa8TSvegFwn)!d1`Gz&&(^jPq9m~{-u+WGwZIkrC1Q}Cl{bfUMu+&MVzYw&dS-X{UEnHD^@8XYrgAVd_!<zC<x9t-(9qP24iDyHCw)<9ofnNx3h~sBw8?DAGK1*PC?GzTW^ZXNGvY+ibr(kx{sOoe)Q96IU3jdE?3Tg_N#H2xW911K>i5awbV6qzg-SL9W|mQ=-|?sHRoA=kA%iFI39GOZXM+0Yq<x;DZU?4xCLtGETtGM0)3xEGT&!^q`DIcL!{q)Mg&Iacve-3Y-~a#qGI>IM{nE&R=cUVDIXA_Sme7H>7r_a(U^*CX${<Wc9E2kU@i3os&TDg|{&yUypCzQOVlkt(*3tGd5uW>yJ`cy@&FdcD-iUeWq})KLrAn7#9a{t!RuLR41aam7OLk41<Ve#>ySLY^ZLb`~WQ9KU<!3JLTV8n_CshLYI@TlVwSiM6)4YKQd#)_pLy+*T=08l}tyhtXn{YkZGK9kr7SCx6Y32hbH|gDI72r-X1roB>4k)-$zKuC=NzU(86~cM_pUWuDa$z6N$>K`1RaxkSj?%Xso#o%0*O3~X<>#hPOLXQ}W)-8U#r9cK4q=*zOIItI%S9c?6E6k0av7j3(;LY3(#2B^pf=uVYG^*!<E9CXOD!swU|e2@%tdww^Zy;fZpjkl#sr|He5IB-@)q6U3e$;$H-jCT(B=;D#b9dJd<6%MK01}J6gbrNBH0EFHO%TZaF8I^%SUUZrET_4)vtZyUu0{0$ElsmrG<NSuH2aI!z8Ws1ZRdZD-Md~S>6=*u6~4oLNd@4yL1x;nCdxhxjuwEYzX1P>`bAM+<a7b`yYSh0+5K>Sf6^S0U4+P`B5-U@6OAKC?R$bfb65GKek+9&?Iicj$kQbtEEGLenY()TaF~Uf=jW)Djf9^byQp2Q2jApt3PJ9w8p%eL8+THAk`k+u}9ykt34TJ$OIsnKxV2xZcJf!Ci*Ui(aEe<`7E7B>V8@cF<N9mD0#rN+u2yg4P{&QIID~9W5Q>L&LAILBt5N*5IU?O!gdjTWJz;Ec{7Kvc_R4L*;Ijfd{aK+z&T3i&I~__H17hO7Kej+15%d)7&KWwfOo-#_jADl*N$K}PW3!J`-?|Yl&UlNn+vu-NQ(?&Da_QEk^MZ>(Ku1pFmOOyLD=JTjH(LMoqRfH=h=LZ0=06Vg&diyLRw9z_=k1#iS^IuZr57Q2o5ln@j7f^J}mbF?io=a`V?*3%-@CoSr=-D)r(wGwIY}aljjIp*6Sb_Tc~}Aae-kn1O2184w;W1(Cg|D`a{SqQGuzRc!Coy`SK{a0ni;MD1;Ly@=>#SY)+iP;R&*-F_0B0l0nI^=F~fLZx!Uo@XjpfK@dlhf#)s36X=G(BqF|PfuMlf%!aXdz4<3ow>_{*_E0xCHTB|MGMdg1M5bTS2|LWw6VQmP{-*wnjC11pJ)WA2&J-(!`HVAh;47z+PAA;M$4yMz)R%N%7xb+&(XIZ;(T8c`-??JFeh2~O6=#qX+>BK^MVj#xPYmx@A19UtXd1+7^f^HQN9fSf9=a*4t%NdHTH`6NwZ@H%V$e)$Bp0Wfy-<h>v$!~VSg$LKOIEzK_FzY@S8%)lsAMP8gL*Ipaa20;LohN5X-=WPcG|msAoMa%UAC{cS9}z#9qmiw7Yk>dp2F~G%i8PO%orpuB*620^(b=`U9tSheC6w7fC3&EN8+i}9Oy!zWMpJcifK{m%U}Z6q-XoKW}zp7!4jGy!^v!Z3bWZd7Zo~yd|Z#Hhf-g?H$K9VORNnStwug?>+>C3B!$aPV|tncVP+k`JxwMGtz*{O5jj+^UWa-;A)sxewPksv2EHayrcG2m1mKS4FV^vuTFcVOsv;^SNxhv3FqjeBSf{U+q3I0qY~@p+_Py&R)tTtm!}MA)FJOVVaWVNppo@uD8{}MOg^1~8Z4Zdw@`zD>d|_k~W@8f3+FFwX3fVdWh5t*YC5<k>W0oO?r>ZeoJ<=a%CE7;9g$BFt-_$<%)A4D>oTWtJa8}hs&E*8{&t9F`S^z9=#MZ6ogS4!JS&}5*Npy_s%7xNwIc=YvGAewqlXrx<`&pm0z^_Fm$yrZxHUj1U#&NakW1Q=V0k%*sskB&>yG7@0=_zNZxO~O!<Ep?N((F8`TDF%w<tdU@TgH{Tlv`!BrVs@_J6`UW(qJz!yl6MSIg6}pIo(uqma)3>%*=Bp%H7eq?S)flj3%;f2`kNsf@O`-@vqtB(OfJ`p`_GH*&2gkC4>AD(&eA7tI|{#i(h1MNJ|lw;{^RLimqt)G<}+%pBYa!d2?~_cZSw-I6%flLEsNr*bN)T!^v#qcTV6X8zPdVhFkhjXZ4**oF<O6?TI@Z4c5C=-os&j%DRSF22Qe2enzx})qamgJWM!svU}FPVGxk=qac`AtIx_2=GC*49|4OVa@E-dGCb8tY&O9?F!Su9XDHH^l!0-gDHCBPBX6uvvUxp)T{9+A+?!o&%>+l4WnyR16aOn+V;vi+<7Der+LN2tfA;5>`}1e#^XvZeXJ`0lXZUAl_-B9q><oXIKjT;PXZ#W$FJI){^0gfHPy6RL6hi!LpnikrwtRKpRsLQ+xA6;qHox=FFZ9{JcTQ{!Kh>Y{EBdp1@SlXRn3$pdTpyMGoZk&!;Loe);e(#bKT615KKYRU8~@bZ7w^9N`v39%|3vhet*f3`qaw)#%gdFaSr<QTc_IMbUVK@ZY8M41TF2GLS?t}FWW2!6T@=|$m2Y*HJA&(?suwN4A*=kPM@)tvON*_wJu#)X<R;K5ERSgD-4t&h#-%j=x4npl^m?1v%$gIn!8`wK{7>z9{R#ytOk`j_X4_`<JgMHgI{w=o2IDLxL(usvV#)KjK=m`a+4AZft{*D2*+;^QLoMOvIA`-T9i$#Q)a9JdA8+p*t*-f^X=c@1NdZOoYHn^0^5zwE4{tW`AF^Ds<$T7lI_#VOZ?9c==d}(#7=&_&SDwrU@FY0J<yV3$ZiMVVM9?$Q@bG7{=R`rxKem})vH!WH55?sb{<Owm|Et&6|2H50R)2r9n~&TagZ&@u2<=|>pQ8@K_49b=2l~gq@b~incf9rTq}{%oUcMV&{<Qg5yn66AZ}s;#(}T0?^5=Xc_ST@c;(CLtjWw25ugrh0zw7>3x_71Y|9pYg7w+z7@9#OkYYfjXzI^iDW1hcM`(Mt(=<Y}FJUN;ou1?o#Os@4|R!_VSv3_y|;`r+j!$_e#6WK|Xy>gTfZO9v<6fh^VBRWHWlO74(x5#b;d1lr@r4~i*GL2CvX<TQEvpwI0#Va!U|5!ZfD~u99MYQZ)2}OCQ1{}y91^tO&im(^?4AU>wF(kB&g<>jkH+av;e0Pan<TA30aaUG&cH)8b**Zav<h9P$o7f3j)@h8gKsOvZ8af4sDxy=;5oU9_$vu#5JGQp6Lp<Qw%OTKuUn$cX&`e8aRAVogN$S<$BBfHCfDVTd!U|Lt&}~jriY;-VI<QEo;mDm!5Rf7n^=R357fg~hgOBRi{BzB}9NIpVA6jq&%<u!7O$C7APqygbbi1aE?$DJX|I&}Vq?g8;SFvfK>O|yd1`?#DAO(b__<&pruLu<d#6?GUZpfx9Pj#jwP+p=qP?S3zY>eZ_#5@$LJrp7V&Tg*ZC``hJa{MJlcn46ELzK%d5kEM1Nu`jxm`$stknv3By!kC9Z}9<>Bw7%~SoIeDRRM&^@@I->S<Hqs!`2Bz)Rs-<#0Fv83+IYobjp-GKTr~--g%ES@ageciLzyBmjGsz;s@AE72dZ`ZZ9>_R`;2nx*eE|LmeM``(*<EJ&MWn6zAwsLI?fMx~HUJqniiED9IfVE@viCkH&&J2*l;SRK52Td)|0&`Qk-r8-MHIo`5~SbicEcicX!>0Ey<(ivv)j(DEDX6?$m`6d{=}6Z@*u$Ay?Kyw!P6bJ;-ZF|_Tdr*`DKy*Z@=@sH6Me?Cc2H<$ms-VeR73JUoJ62Wk**9970BTxK+AfZf<2piTpJZl1kjA_}$GMJ-*VIoe_-*>^#CnK{{Y>uvs6WI-kE)Sly=U@)7nCZ6=1=w)=Iu<r!M}n9MrMZ@-48WFgj6$U(0%xU`uzZinY6Ny7^L(3u9Gx157GqYxtscgifF(uH8G`J>I!1uR$pi2LyP6THKxV>1`IG>Ql9ptOC<SV#_7ZX+jxTj4q}CF|U>Bq=Q_9F>=2|K3;peoP&;Y<`$aJQhj~Q%5LvI5p9YIAPyqI!sAY4dC)vWKF@`WUiD2kknvz1vl=o}_hNZty)tQbsiCQ3LZ(HaBZ5BO;tmjz4&E##RL^&6N}_n~|jS8uB0<P05`WJ@R;_iM~cCM0Yk{bhm-e9ESF5TpymP$pf79nN(0Vbl=JCQ(!6600Xu*5k$#XVFZzwnn0_m^@`vT?d_f8lzkpGjK@e^w|-;#vAMe8A&Ksi~CV8?`OdTW+9SO0|cxWgsY|asf-_JgG3~_1|NpQTaoc43n4HC-BBcpUWef)nyBjsHkg**a6eM_)to#UrQDgyQ4$eBOFZFF@Q^IT-BRQUV{JO)*x+JguTX(QpE~eF^%QmxGCD~lp^1O`Lsd<mz?vmR24}yMKoTXvv6@XBd9nhn*XEg6eQ`80rf7MnjN(UuWdfnfjbw=%$e13p46KFr#&8&zx28k9NLNTM!EM|f!jz!XRd2;NgpHg4gT-VHOIE4^KM>>4yRw#Y?I+E>XCPsT2WiH0(1dbuv2mF(g6Ojm;3gIfjPM;-$a5xL9F9piXe{G&0}KbC@DGeU>Xw&a%SyjPfNYoXM)ve?eC>k7w-y-mhQBLCyrw{}DK!P?l&-(xKM%ou0;tZcf32(nvXh@zT7DYMR5CDr0pgOP$u?4_<DNahwSLDeKTO<AloUwsMAg<+{I;A@1mBh9aF&E$j7c<RS?vL7>w3dH@)!Dj*hBvw<vyyVy%g^=wE<Q=lZy>gt4*!|BPHul_!&H*D3lrg^IzD>{)LjI4S|9g#>6bwo)IfE`%+d;_R;Rxc#85whT_7W0({6k>;|S)gvzx{o=8tg)W9u`u~I;ks`FS!k&D@-1_FYFclXqxH(Mvne6sMa_eZ~yY9uEL)vDfk#S`pmNQE4Nq{>U?U~KACf{lqwlcZ{#;j&w$BZ=9`fT?5y@&5Q2dByr>zgb|n=d+PlBm>_`qyzd{&4X0IUh%E2`GkopHt8*~!zeE3CS>Rn1#P7N;7H?9Qikak=y}P8tby!K)*40=PJb5XIa(*wJgg_%avE`NE=Q^C856n2uC0uOd%8}0utHPMc-d1CDf9o<VqM$*;CHNE36i?Qt^R{OgXiANx4QWw$b&Fm>Rdzeg8eSci>;<^lDxRC;c^W$u;P-Ks2`EG2*?LX5cRk-@dNkn%8hg+#s?fy;U41Owfp3&GY?wKoenESRH;j^v?LBxx~2>?aNCNG%6u33EE<`}r*S2pHlWFHBP211<JdD;ai-m@B5|M=8Sj}C^DJP3)3%W#pEDXq>7v$)4^!C}3Tn)V9S5HTf9;di4TyEc`4*O1am<%>4w8_>wQW$8cE2e^D<W09!mOpzjNN@jKjPXpXkf54=>~?L@vT*)96$16#3HLMU_HNOX5qiFW)=b}{&PWPNXj17GihEDr+Rn~c?9naGIwGkgM!HlV8`$hb9Ku}cw%S@Ja6p5gQhZ7Mpj9Bg_$ewyuLpMPs{eSROpgj;iJV&W8;}KPum+ygQ>XlD1Qo0vuwIbi9y8B+11t}cS#y?Qj+x2*}50O7!`-08b@xHE{^Ol46VAQVl0{TvqI-D3Osu>Y9NOO-6Au3fOv05S(PBQdmQSt!Qv6T9wPFRt>ALg+9(;t0pn96EFlH*rWPi46^bfS{68gI-l6vzyds>+Z=0}ref;52Cl}gE+Uh;ji`}_Qk@X_8>@CYksdF{t_M-H{LfQc6i!@IfvPpKdo;lY9AFggp#n;|z(i)_G1XqEMX}K=7Xl0teXxw<NH_n*4je+<T1`XCL<lUGTB4d;tXNjLMtUzgJV=YLB$eUtAD{Y5hgfF156D3)hx^xWSPIj#JD7)oXEITZ4g_#Kt&J?6{U@}%RBT-gJTM3J)UI1UtmOnX=9am=k_GXr|NHWwLb)oxarhEhq3a(;dXJKETuiTDNBWu$jH4zE08qLjB=sA;W!s`fBr@bw1k?CxUsqO&f=Lj@@a!Yv=MBZ6%C(ab$8a}dGcFEIoXcM?6I9U%#t8T|z?bAr6C^ULxd?kHt&cl!KI|US(?|F~z5rtjTr#gk^af%N-{5COvMg|pGT7#%X*y63HWb$nM9cu5}WzXJfxZw21FuIT<96ce@*s%_Hcxr_3%F=LU?Fgf<q^Cn8qDoZFvE#Mvr4(YS;`Pm+=M6FBbQqxeW}ZQe@NkLv6OPguhr)Fe%rcR|)PMSQ2`b*zKT{l@T#)KRTw&sstoqu!t^T0>jUUV`LUm72aTbEf6e?W%!OUvvw<>7w^@A}@#Sq-5sJpg=xub%{7$5`_Cdr^|S{xA}S0@n=u;IlNpE{&jh(zgCni(qCBe*OXgw0^Px{^J!j}K4=hq}dJ{^TK#^Sf!#TM_xirk(eR-PS=kWcQXA?@H=u{D@R>hd;9<1;5NyeaCyX#xBo_e(TK%a{#PPJ^h*#&$F7IM@IW4Q;(OzgADKOQRoqyqOtlXZqwl-r(~|39LmfHwu;8J*iv!3e&m6^dfa%)9aJ!7rJhkEB@Iapu2cQ_kfk-Fu?7;1KC(9*#g^4c8l}Zg&&J)O@N2Y;pe9wl)TJ;X*VXsUF}AI(2uE#G$I57eRD)!6PS8QB8+;T|BxhWP<3VDqug)4luA4J8aKmDMv^|?km1<2-|4cLM&He5VOQa7FDY>6WkLD;}Uer?P3Zb=hl}pp>wVd4LRfQCm!KmmWV_nm3H_t__kW8d|6#>oY)y3WDu-nUwxZYsb4!f$5Vm4e{UPWi6y>8|(Ov;>PxJj4y10y8zkq!_Lx?WxDb_1duCCsO2AGFMWb46G^9~eu+;uTA7e?rW!oH_kwb0c>4N$56|`#temru<0_1-7IJ*YQ{{!U3SMmH|iJpoG(b0tt`Js1DK$SL&fSSo2TVO0zRv$m>KbJVFqY_3V@-?z(BF!a@WFWs-d7MJ5ETLS^Zl`81V~f{GD(ZcG*HAVIE{0lD*bcPcwmG_Njk5(6Dr&A%{s9$1lPO*T=BI!b}C56OHej)98E*cj&+_lZp0>YxKosJIO!z6I9}zLSE8wZZ+JP!^>m3#+9tc^FaT*+t2vL-vrtWpw4AK&cGrtW(J)<7ApeK|)(I9n8gA0;w2eztQ|f#3i6{|AQ>y^)(M?_!=yILB{nlu|B`poEUx8Z`cKwd>Z@-?08HYsh*!MOURUzduA))VBEU|8HuoGXNZL)a}ea7EiYw=73EXW_8i&h@L|CeJhXo7K~_sqzov$-?xWGzZFBW}E(J1T?5L{I>1M0bZ|`w3h5H98jjOp*ND5b8A_t$t7BvkeD0PbK)TEK>0(zSGN#E@=H9ypVPtgU5|A1rgk~BR^+#G14K;C6hDGa|W{-P@mB_4na5K(jACEBR`1nkPJBK<p}gu=?!m#w1gzg!h1Es9XL^%JI2FGc9L@{V+u+<sONK;hb?=;6|+<5|^Dh7YZuFgcfg^l`1Z8C$jNG%-nPGp>sy*57(q3rP=FAz>NM3~P71Z>~xu*()=|C>$p<HaEwFZ&4-lC+{zY-`F~}EG%|+hNPUG201(RES2<9RAE2lPWY__+*j{?Q`8!btb|AF5^DkPAu0w5J+?l~^|;@ma@sNy&aKV5ShuruglzT3Ewoh~u2DN5Q);9ahn8;XyC$T|l4*UaJ3mmJAu2H8(oF-fl%>CsO5MvCAJvJNOxx*{=#<97@sXY_nLRvI#s0>JwgSo6#+m+zC)-5?>@=S+QB727vPO%l)&n}znibn*zUhUWZ_0c$P<u#j&2H|4SpBl9L2~VhtSWP+Fy#yaSjz_Wnq9JnZQr^{OkrFguPWF+ryVB_t<Uvx40KNi96^0aeU{j)Qh1Q)QNU4RV(;q2B~%fn?WFMutG?S}T=Y;^g23L;x)5uN_+ppR2`)RRuEF8A)lN8Af;}hmKh&$VL#Yod=0KoBbPN&hYr-G~Ml})(x~vXKB~%m9hP4bf*wvY(hqj7!BwJP{>Og}l3u@3$CysH%*J--A@yVb35|)?560ib{8vn{Q`s_VnWZxlgWOFHn;v`csY|Lom5Dn5h(T#a9{Un69<1xNLhy#D=ZM`fhZMSvd#mYPoZ-l#X8_&H|k7<<2%21x-XB`!z>bO5kgpJ*IbNRvj_SR5*Hu}oBo@rSQz}>b#3l?Nv_R;sF4C&D5_GHb0ck+H8O<j?Hjt;@Tg(&{-S02%~vz)KM$=s80`>E!j&dSLD4?fo^Wnr%+4YxiHNxqydqu)A4TT{j_grCd|H}j*4Oi>eM;#rG`vlhF|F6mzixEifW-6q(boc$Kfl=$ckBuFV(PO}thvgMZ$wT3#Q=I>z5s@SN0%ap&~hqI47K7U|@G|U?9iX+#KZ+0`|@_J9p`Ws49^C0LA`+Yifu56g+njj{f7{(-h#+Ev5*-Kn9dNZlRXi=kZdb414a4#vG;Q=O5Q2TAHVJhvlJ=+sKod&KJXB8r5MeB&RMoSfIc5Kzqu=P28V~g|O{{Kh&?b{C=+pjQc#L$2NPw~cEF;(mOV;*U@Q;Z%G`p!%$*lde+cbWzaQB_x{v$Fk_HdVL^95**TwiJ&eMqK|pA#nT)uL^j+F_`zM4utR1Ui%Zb0l{6A>DkfjrPaApjEx+fLY=M`l?ldE@2GCs=2<wL`ZBTY;w3d_2qmF@ffOAx7t60{?vT~g5E_<ZdOh{c7A+dA5p`g4nBd;Y?sVTJN%Y3&tW>wDVKD#-J;9K@%xNegMLYHyWqgw1j)t1n4sW)}bn|Oaurnv<U|Q(}p9Yno_;96dqFG0ibS)*fteYGpEJ<%WgkGxq^G}={)R}lVWYV-m?TM&?Vhm&0Q36mM5zm^J|N50BaDC_DotD5y*!re}LxZfTlVo71J9+*;tCg1&SFG)UB@K{zv;1w2{k5qun>#X2kR#WNw*Xw=_u6jT7Je;&PiEY8!u8g-#ugs|lAWiDj=yH2BrtvrXGR|0TS{b&)L5<8@|?M)<J_e_+!E`2I6%6aB?bfU2NdB{tk(Tz{_Z#19Bdo3Q*<Pmq$v1@UcwPoA}qVRQd1ioSZEo$_1682G}@~1UN1H5=0@_$CEf4+ADcB{Z>E9q=J=nl)C%7f3SF-zcLfWHrB>Z`P|;=`2lcL5XkK_>4iLhe2xiliMjs}desZ6a1f?goXfR=JQkqTiG>fv6Sgv!#B1J<@8qusD5&N`gf>E_F37VW)B&WkoqmH3Mq>hx#wY1?7tp3ZxW*dLh+JQ0EHfED4IjeyZ*12bdrMNGJHeFYQq3IjXoC;2aht#7#u$lz7x=h|hMB*^Gaq0uxD+%aoXr<q-8jN}$74>rM*c(DNwpYssLQy(6*72_D!)gVg1ZQN$S?fsrX5bos?We+LzB|m>2gA&U*JGSc=#6_ZPM_M*#57Sf9WAs;a!{J1n`sr-MDZ+Dq#&Jiy2cbyKCU%M&6Swu3pCNv6x7|@n-E;dD@jd4i43J_Xd?6@OrF?`kUX5ha)=Jn(3pLC*(IUU>n;?$2w9kwyKp(YjaiQGlGLRBI<S(xd%&dRmU7o7%D^N1BhA0bmFV|3mkZFq@Efa{&L#C1IQStMy(BD5obHSUVH})T?+KajJo1&(1t>(+4!WkL$nW>+^Cxr`Cg$yU>&(u1G+(Ynl#5xWb=Jvy!@W(^3!Xe#`#s#%#DX~XQ-Abe`qKKAsZlVf<{$U)XkVcz?-Q!w1G>kmRL`9ZbbT(_9MRO{$d?BHpOHGtWlhY9y)MEpH^0*S+g!qb+?>R-!kyAgKjtaB2&kIt(tg5Eh21C-4j3XQMQc$fw_YHaD%LF_82Ds9rIXWf-Zs#~lpeSKuNVC=i>U87r}|n^fA;r|&D0vCQD>?j*q&u2t`4LFQ@Hxs&z?0zc^RH@()EpRIQ^QvV+JDn%qHZ(qdGmyO~G>MdTh*}t<;20{A0MV-9oxb93R<wi7=?GXOjqYX$4vp2dm?CI3!ik*TSLifto{1e%SODu5c+6JR<*GUirt&|1$<?#b0aOz{cP0>Mj*>tX|Xx6L~FdHey9~U=UjHG`~<t6K8%Q6X%{Bjm#9Dtv##(c|}8Hj|V6pS%|E^x@YyWC1ODhmAaq(ggvCYKTXF;kVEoA)jreeBOSUU*rzs_$%PEqa10wJ4Tnou#26KWg&N?8ZZhiM#6fX6G**9*;JwK=ys*Q0@nZHyo@^wN561YXK9n4H;WBe%nXC?kOY<1R^knzOgnF#Up<^O!glknp91rU>3NTRbsb}ICcIH%yre!%xh#PnZRxF}ia5xvoNduZeh@3U*K6~1f4UJlw;KyC!>Qj6?I3lz7XY-S>!Zde&%CBa6K!VmI4)2W{zRoqGn$5`1f<dusH0jCwe^w19OknmQmL-|WA1rj8>s;_#w%kAPlz&(y&ftL2*h=;D9gA^-fUN`4HrmD{bHUnOK3Xzy$~0t;EXlQgLkck`C>P=DEPIF@jarqM(t#yYT36TQ`$#+peTYYs)fJBzwTF=fISuaK7z!{(mNQ((0oqG4myL7w7a-d$o7#~+BrJ_!^{;n(VK^+m0qa5`FbINd=fM;iaNs%7{~?H-MJOa|6CH;8NJyp1d4V@owEts!ZrW`3#v{C)5k0iTD5JFhgvA~G^+@<b0MUC(w{d1GDg5oP%iI#Rs+H$pT4O^%mz&&e@IKY1@O~UuxkS%G_*|j_Z3R_(On^P<o&Al&pzES9aU5>iY*BbL`eWnPem&s>OmurS6-0AgX`~0MVW13N2n^_2C({T*6p40_QabPCcpb{kI4+&2!4r%uu58bN-x!jkkgSUU6EhSVLa7LxO2Q?9WuQRthM;=^u69v;SK>n}dSIL}W^%<%QS~Vk#Wyr^68()(P7;_}y1T2R&tyZjs*t|Pa@CJM)Cv#>mdkg*r>kc&a<t~)qCKWfVBT}^7S>YMt@84D8MiznngD?Z_Y*jg3=CBrr+G|it`_sOa<XHN9O=d~?=WhI9L20&6@|29Nk%dc*Q@l(bT3#@tdTQG-w56olgomuc$2ejnO6{8`-*7wEYa3)j3s9{hyE<lb%^Nmp7Qe6jfD5TN=BTuW!SjoS9@@gn&sQC_i5tn#bNSJ+%`kK*Y|M0#G<|VPW;6>ZN?^fu$G#&!uYHEnQa84Bez4o_8e?pDw{7B9)|bMYtKG7dZd*H;{7wZ=&GCZScr>pNxc5}ypu2&lUC~L#Vs0j<RM>uS8$#BB9D*%p!py_+SgZwdv0boezfI7{Ad$5`%-?i@jbQ~ivexAHK1K=GfMM%rq6`|)OeDLtpT<m4COK_q%VWu=yaj7<n`iUs*5V_{{-W9oVu;dGg`n}XQ$Yb-({PDAu!yU!WK7$jh^q<$)oG;S-`RhCuf9%xoE&bBVVWg`PXhCi=P5YpF0-(_HzBA^9+EhdE6oQu4`V4f;Zvjh?pS75QWERxrE|UqsTn51PytJ`eci?CfTS!{+eMquiGPWy*>MnNLvr)IIhc{Noh>v{*6Jk6P%$#eQ~c@9;LJdY)LZ)0|#_M0MFLI4ZwkiJwt^gT^3d(f@MQB8PMb_>+w(F&sM)0$i_D{5;%}z$#n?hsE5ABC0PxZQEg44>WPSN66md{6>q7^5Mgvq6hf1?jr3JG^AqiH1mZEdpaKw1f7T4;TllDfHB~?QaW3Z|n-oPl^>%6}u}C;lVQ7+tA}3FiTh_+|0oCT%F86k$7Gh&uUimjg5vS@ULt=77i&&nyoEnJqL&Y_#f>tk9M-`Y!WfeP;Ivr<&xbai<Zh0b#Jkbng&;8fybD=ldY!N!UwI<gCc(ZM~UiCKEuY4cl7ipA;r4jz7=s9g_C>PQEH%-hI9tGUS5Q8K{3p@)ABdzssv??9IoF7EK;!ma}QZsBYNs?HI2%$KK1=sw?_v06u$t35qSrk)H{DI5rthRK5*O)XT@b33;T+=F|F%<mBC=4n_c=4fkmlJiMXqj*hmhTkK)$~hApE~T#j7V6dXgQ}Tw9!glR9UH)uq?q*Pb>C;E^et)h{1%@VlH1>qQ%r#<{H7}l9CX*#)WnsB|USBwf5vhW7(>EkuZ$93Y6}8i*#-gf?w-CFWJh~x2tq~>8YDsOe?u5Nw#myi#PJ?t(`dta^rYekd)-^zVY_pUv&vqjoPJ-(oHqz<|7t_lH(&~5Ur#$jV!JUE~~G0ZK#DnCJ;&TQdex2U+rGR(k*h|WBa;j@D#VpnUBi<kIg%OZ=A&)mzZngXRLT&YgcNukcocjdTB{RD?0ZQM1+6#EAaf9+Z0T4uROojhF|SHx36pz(R!y8S_hAFt88}zzhE6=?v1V7zVbqVaD-A8zDR$veJu_|2HR-sd9GQdfb!zKh+bU?^~p@CMYwH&HS#EKj6o~$t9L+H?Ij&j!xQPAJhJ@Y{jIpY4mZv+WMT3cZ)1vW{iT1b`Pb|D2<4ZW%Ue{#y(|uO0jI!7yH)y8sBx=A299*3U0{PW5RDBcYY6xr)eT5em-!ShRYq3~ZVH5LV*eyXoIJ5>t<v8QiFGq;VxF7%drzb?<_*ej;?c2^5`X-Fa-OOAJtVi{L}mBWEz<gtwL8@74#2}eKBI;U4^r`%1zw0P7$M{pt>l^HrE8Y5bynFTY8d(JqA9%Plj~{6f9t0W-QQ8rK|Hqt9}Q_P;(dtA9d%K}0Kxd0B!M%qvX{T0(cMT<-dDWt1RyBr&08s_zN?1t&b;pAU`%?+=#0D8y1`{G-wZbTCGbFCG38cT)@69xXRXk<qY$9&o28>(2#Bt0dON(+$}YWPWtVQP>~7m|{~mxm0rw0dzej5*MQJq7Y!i_aX>phPTn=R1NYZr+WTw^aJC#d-h?sctBc}tjv<;wGzuQVGEZjwLt;L<JAzD9RCGT27!R2<_vG*rEGocFE`srDx*ok=^n(X)uK{yK6k!kK5BK5*&J9$nfIkUw$moTs~;tr$aU~&}m85g|e%3rd#U7}m@A%4LJSwfB`EW%$Z)3X?jTgH*ms0q@#_ZPniA8Z*kn_X<eX2n<Ll2#ui#0f|hyvSNS8$GQ%5(fdGxTRO#5rs*WtFRSicakOQUd5=F3{I?V3FR|7hP4oztEoxe5X;5#?MZZKD1J$1j9LODMHRvqoDjs<EgNS6edF*ZO*I*dq3RzK|Li6M+iLyYnM4`iX18{5%j>%DgKRh@2?<v*y!A#2_Q=CSSv~%!-k%d8;vL_u(^HPBbV|O<<~^=w7qU2df@Z%<*&F&WHm8iTZhK%W2i)J(?h}_X)X+D?keI>&8xI99;tcE9#SExlv&CCMp2JLP61-(~XJ#R^kWc_=`)i=O<}ht(-bp<`@R`lOE#yOr-EwE1wrm+a<r9I%6H=%YFSIB<89n@@n1>8Ru1;KZ&(U?AS(OY*hIovR#{JqmgebA|&5SL@N2@#bU~vR^+qTHL7t|5I=<U3=M5~!8&t!`^wU5mjqI71D971o;)<hS9Fh9*w)6Ek-vf0>J>UJpo+pbV{I7i7$2AD~k5QZT!YJ|a9T3^R{(Ubj&oBF^#keH`;^CM41J^6pD`Sma*;vAj6iM#blouN=uxX?@K9+DF+F@+R#<oj)g5oMQ8Ex9B+R39N{v322z%=0IqgxEar{|Tr?Nr{-SUXscLt*8xj+L>yDq)RMx&E)1$OC-3cj3mpQDvqi1L9ps55f2uGn4BS05tbyf3rJ3g!ti-l>@-;w`ye`Bv3W1dSEeV8&>5ZfKT$2on8~)oPTQjz0}-X8AXeK&5r>HjX!uS7W~7iza~##`)-}>#R%vUy)o1I(G0oa3#Oy}iABo83(U*PI>m{!-r09P}nvcg|sb?J3<zsNxqf*efGEooe5C8|5c-rSrnR1KOpw;hak6Z$h`XDL)$~&x=PjWULYFw2s7Yv;8L<!FNZD%JFJjwVIQ|?ENi^Le}FXrI1&E9-;J&K1QZv8>$8guRF{n`RziLrn<Q=tiV^8`^XpcEsc)<a0WXN>ja^*es4&82C4YCd6jj`{XXM{(r*a9n<i##g<i4gOD(Z8Gg<e2Ogi3wCmNg6r=irE=>^F|z7Xf5cu<jHZ31X>42dJ~xG*7(AwCWhynjS?2)^J2yo9<Ysaa*~n=pF+870Ga>iXfI$PNL3BAES<~QDcH*3dq++MxXeQ+Lzbi5*gA%IlBcDir&=GGW$Pp8Ttt>mvM(r7b(QqjzfiClpL107Sav&iQ6aKR`td+TaSJ=Id9dlBSXSj}WKTdJ3b=V2pbIFz3f~&~lg(HrE!UF-ge$+ne8NjVu2d>y=1NF#j7QC)Y)ld99bYxLz-!oi@b;YH>ZcG30j6yCtp2>Ykfz2UgB~ssm<LN})<iJX8JhS^r>Pn3^$Qk6-pe_fPBNLSxg5Z6)^$KdIsHxE*oLWpHR0m4XTAUOq$%T|~o^Yh@I2bg%8YgwgxlVp^M7kA3ZxbOt6R5_rydX$y={KFJ=jU*)OIfDH1uk7j#6c%uJBx`-!w4ICv^=9H2Zw6+47@2DaV89@C$wyY5=4@Y8v+Os(pd+95Y;GUTw8wAzhuz-Xyx4U19Xfb-MJCFoq(oTlhDL(GnpH_vxVs?M)T(XWADvEZCm&Jpz(F1n`1U>u4b>Z@42UL-FvOnt-4iKNx(uj2x1<6O`d)6B?=;9Ul<#rL9huGs|*@DOa-F}fk238P$T#vB%p%WA+gMZf)Bn4B7VQ$@BjbCm~+jw&)(;peNRd5Vcm7tUTe%T#~kBp{>`r;7pFc(sx+}&sG_ST8Z`hGDPFTw0MS;Yz8F%wM4lwm=O8m0xT?pUZCqM6CN*q$9?|z3-h^}y01mPOj%ac=D!}!+hQthm)Sqy021h_8c94WXU5W2ka)${L5WjdNnqi@Mz%0m3so@_p48GS0jRaiju@E^U93*ie^{|s|q<R(TzIVhR;GYGBRI$5`(#MKS#xo}Hl>D%hFdQf{V~6?m?q3b%mpAp;-&5m*+<ym)<RGPDRsaEBKPgeAfM4A!b{f06KL&LjfKa>_uG7Z)$|aK`ptL<gb{ZJqOX-1jG%gdy#jq~?+-@Tg1B9<k$)5k`j4kJA9gc|53BP|nM~;Q~9Fn4`d)Bvqpeh^%RHhOpmb&Zwtntu7qN0kib%`s3ty(_>F|HeTDC$BPsdQy#)rpza=Rqn^tRdWCL79_@$Y%!&;b{<^*vqH9XI#Td1%cry|Dg-5$vS+GL@a*6^rqg_rYS>;2{rs8M3_}2*;B)Xax$yR<j`H{ONJ)$66=(vpSK}!o5ZBHl-^9IyF00(AK}!llxcC;YNU2p9!#|H%q{bIhcysSwOGd`fL!3hk%JwN(3A=9Ob|mIwGT&@W_z!NaRCh?JTm*Lk^RFxmpc{yJI04(v`UTv9!PJPMGnj~M+DOpj_H<qF{tTzr@ScHM2d>_<<WM?@Yg?;E|j$RZc0N*p5)`yp$sz(b<O#b<3^8!_XtFh`v|(+ZH*|YE)&tCNuH_gB#Nw*BZr`h1uOMoC1r+{lo`~b=v_4`6OF?*yqLFU9-kfBhniOsgEy8zP;yt63>#%hPNAd%zaq+%n%B>ejNfx1DA`eMu@jq<1cZ&Uq)<Zj7x&rqeCt3<Mt^&}qQ9;Bk}IbC9Xk=<Cim^Hn&Zi534>0KC*=Kqx#P+4!tMk@_rXadvO7tvH>Z@nNzjXnANUsB_=yK1_vJu=WeYe>?Y(e!kihyV$XJSp!ibwui)br_eYzxuGbzVXW)!Zo1Ou`5le?dc9AAm5S8fzSnu~l@q%SS7Wsqa~4jZXKrBlNPm2M6}()UW|6qE`dX|Dyujh~dyzX<L;I&25bD7n~?d8G?>ptGub>H}^NRg8doVSl3JpoRHV7mVeOpvh`pC!@VwEpu%v?f0tRL7YlqWVCko+EW`hcy6ixB)e3JT9!^)#X)&_Fk*Y_UL|MU@tXg)?llD4+YNlJo_1n9r^@Xju^ayI86X5Jh)s(bbg9feY$gq%04>iJnHHVqpVL{TNQi}n8!rJWE61Tv1f>%1y$R*GsC6~Qrqr{>X*8IGkq3oiE2crMg<#K!ko!fLfosQkAf(!)Q_a~-44xY=*X=qLJq>$eASyD@5Mxmo{@#BW1ZmQu)8r{#q|(}_{2(b<CS+D6CPt}ej)y;~rP*Hf;#5104weOTJHy(N<qs$lZb4d?XKBNb70kkN=AhT6tyC=gEZ)rbPp1Sv7$_|pyC^s$;_8QuBh+i(FIUOG@=ekVPaBTmHNnuJS{DSvS1?}v7ULypk%Llh!YRWQsc<76N41O{iz>Y-b(!=$I;)HQbK=h48^I6@oL60)T{v#2g~j*ofEahPJ2!nAmIhF4iD{A}WGBeYbj2uS+pn;nc4SEu{iGS|^$2Sg%&-g=5t#zeY@^ju4~nu83CH*l>K-Z_ylER=X(W_n)16q>jfNc{)%YNy6YgzOhIX1)ygogP@Sk1962AMj`|(mo*ln7U1<ZoOD;>#n@A&c=clZ)C$YM)2S4#J8z+hQ6fO59pS-9k=DTIZf+0$_3QkRNt)L_09>>^v81FQKx6J}=8;zec<VM0Nc9m%@#pWRu3g?FG0Cm`tzcgzjo{sFD#{F34~;Laf6V$@e}$hdU2Ofca>OYwjFX6OL-P4>tZ^WJqU1}$lqQjvYbdq!@N?^z21NxA)YIY2lxs_lrJ5BpuiPGkz>Ah^F&uMol5a1_fG{8Ot#<ep3J&6goS#W9Y}mQA5sZ%~bpMDY}HDY@7Sx*ij6Ki$Dl*O(|fY;h%3%7bh{cs*xGL_vlrYiD6RC?IbWW;sy6Ue<6&RuK%6vEcuLv#3m~g3;^1*?!_Rm{py=a}7ON;BHa-_^k-T|M?FXl^+jixG6u3Dixp%rTBPktA@zKE5|s_P4XvEd3W?hgj{u7N7UkQ1(nE}XfHrRi8abATw7e`Z({(1K^Mlpb5S3pgj+I7mWDQ~w#8-1vsmgmxYDpndC@$#m|uvLK#6(-A{W_D1gFBNT~JnuJ?c_m)fsw<M~6-FnBZ8F%n1floLMHTaY6aIMAkc#R+1S^k!%Nt>ab#k3RJn{L~-JNVxE|_0>iLZ9eAh&Vedm(3gWka#70L=y?@V#3E{E!fK2y%xk%l)(3gbp9E&b(&{tf6nh>563Wg^n3R{`M^lWWC8rh&5H-HwC!$UM88%oLH2`zgqW_#AUFm_V1#giPQ@x-n*Q4aNKHq^?Xldsl>e7m80v}Z_$isQY)&V>-3qS)7i+t}>6L|SG)cXd}yg?XZQK_ec9%8wHlAk#>zkMG|GOY`#@m2}G&S2AgrltFr-<KcWR+;AsDu64TJQ7mhRrpIyMlbO&iJ+O}o&}e2)=B7;(<d5;um*_o~Kr%Ro^_ZA#ONwfbhchQB6B^$#h7Fhq0J2qGVmLtRCS_UJL0WeljS*HacjNn!YK)tYoM4Q=>c#9J+Z!pnk7+!1R;no`Y=>y1U$8p>L^tqh++kwuI{?lV<jtm1i3o2zw1wIrc6y%UCtjc5{hc4j(%PoE1=W+D2_w(|`2}f9<zVM+rPp~|;RSDN0UJ9Cfoh~JNsDZFTL$MzE5RyA$<oiZQmd5gvS2)BLm{O#Gux83u93ukTCSy6yshkQj_kZGrx%UuOT^m}2KNGayrm1}hUZQOt!{4@)3)}p5}ND^t-G_ri`VxGUq+8|j?xwcoE&p3veG6ceHD0p8wZ@WhpF}Vg3JE;<%RC$8A3y5hwa5*Tw9D``}=U~^4xl33-Y!fg4Cm9Lu_x~XhZ4RB<L^xxq_QRc;zF97lf|{TNm=4K-EjOSG@7UCdDUlp7`&h37I*Yf5fK9_rd_pKJ<p`#e6}m4Ei!>+OTLU7f7_Ru@;P?K^}R&V*^ddk3E`MkJJ#K_l!+7%c-?xJRb#I6PsBwaExjybIWEm#5NieY6RLL7}T5>5cNWlSGd~t?zJHo^+{c1k%Ay2VyGY?gnG1%db4DT->VA}+7T(6jim%c)ux9$y1~k!p~g?iW@GT&aO5Nh)=-^w)I!`TyNlnK9JdtDHBz|JKyzg0Wgr?r&!#XZL>7R1;e=nFqnTDB*Q32>{ajxNNyD&i6th=I-Nc{4fHLQnz1$id05%EJ^`|YK`VMF_%Xh>0`~i}ipYt>AZtdFiEkpNz^j$mqu5F?7E4%i+{5>V3VBm$ktO=bHy_vyfD`}U`H|}_A<E}YW@ECgU24A<gZ#=+#_U)Tio$|++0}JF3BJ%A!38Ia;N8|vlG+u7s^y6B$Z(^uY+rc@C>BqI%$Cn@oeei6{yD6VC;ra*PTLb)<koxSZ($l8mr$JdP-?2z~Ha^5vmG3f)HX_1R7=5QazEIs~6GP9fe7A|A9}Tys&=wNMHVSH3T;K2#_C1J~e+uK!Jqy}c4>)7JSl-0_HcB3$&T`&H$pon%BeV<afMLAGDEZ&1G4UeUjZ}ahRSH+D7|7jyyVFyKkK#QAn^_uwEyNpdFh!KYP&L$_5~YLt4TMRd5Ob;23;Ha`2GE%3d?#CrCOa5~qn=`z;;T}Fo6r;BSJ05gqtN-;Q4**QeRLM|Wy#)CwQG_x*}@?%+%|Gzy~<wF&tPf6u7ngCcEo6B&uZlfClUOl(_z{*g!RaytP=dcV5SEOte_5<tbr+?o0aYq4Y_Fih0*tsm4+UA$t$>H*V^bIWL#EcfuQ-q(Fzb3=e+ex>$QG+R1D&|Kah&ie@ZGw`~*~t^l7LV4<AFth*wmMKmN^Ev2TgrVb4ik(SAkaH}O?3)qP(SxUbZG+p~S2sBh?8{|=V$()Fdj;zoDzrJ`@zir<YcdzVGgkmDXJ-59DU@v6rOYrzA8n9>844vo3V@VvtuBp0rb@7{?Nbshw-MD$1FrbMpEl%r2_WkiR7NY_lH)s?~>V8`yDIw8aUCS`G03BHhUZly=`Cs}%Av@yLpb(z?YkW3BbQfqT^eH_Mtw<hp)5nOdbo6Hj*cqgGvbT=K?vXZKBzlKeBBZ()sKK6;t$mnEDhD4@0o_mvX-m@Amr^$&DAsgAl3nAy>+CJ4v>L4QCb-~M%i87q>;6#X#D1<27LTrUeR$iAYrtrmA+E&bEt~Ogrjegyxu{LfIE>mZT+KO{oWygP_wetV<TT>oKakll@Zc1{pL3<J5ZNfW(v8LpWo23(1n-Ee-ja##(CUb>Qr18btludA)EgPo3@a)Upuc46aMFCx)D2|SJr8zEl#302v%$}hsj|cPy-(&e(Ua_pPtZ~K)MW7}2N{M&YJ0D&*u4!xBw1TnlJNZ&g2O?`<c-KslAUDP~VxBud=(@4DC-^O!{r>uG74i|*fw2($;+|Pxzx_NQ>L9%UeFN{b9aYGeQ>2+dT#iCyXiM*wf~c#sLI?R}^-ph>NE#RVgncJr13kkmD7r)k>N(G2w_6Y$oTLgT>jpt*GWyE(nSAG&z@`#dKc=(^tDf*!Q=5h1NPRv(`-swen(&bWkHEm*M?tI=O(qN$Ekp4;^#askVctJ?GSY&!CUxO(>hIMp3;883DzmgecNxGAAnws);14K0;NTM%)4IavfBb_uD-YCg`AoXbd3l1#(2vk3Oyj^%Z%Kwg4)Ob`qa+Ge^>80$agk*?+pQu@g5ZFe5Uqbz2l{sl{ee2{{wNeM1H&h}GiTj;Z$4wR5+ozOBi@YG^)uQ87##}HaA#(|OAizSrgZ(5(=v4feov9Wn0EJ_%qeSFaW|<gDm&EphC0^u*__Vcas05Zk|%LiF@>J6zN8bSw=R<c4GdHku!*z$6_`6x!7;`E>s1;WL1g)CG&DY`Tu3FDUC^{XnLK3n3aAm%OQVE`P5>T?l@?Bx*J|U1=p=CV98Ody3c-jLYr_Z7JgYWFvxwW&1PKOD&81Wh$|9rD(SZyljL}EtWIWW6E;LZlu<qnf<ZLo8lGv<^$xIiz<Oiod3IBZDn#@U<FN^%KIhBAf^5FI3`_8?qlfXAJLK3LfNO^K-zB4Nbekzr2&4S><Vi_J%Nn9}eJRAK@*{UJ*1#fHy&oMUcnC%PlllOu?12pofgNaq9a710m`Fhw-O{a!OPbyq{Mq6~PdN|1bxEp56LE+!()&Z^r$IX#-f`N(y$%Qd;SnZ{uvIyrd4!vpH#xTA08g@k)2h|7tXD-mRrCUB0N{ivlfjsA&>4ozKe#Uj0?aYuzlgisb^;&i;UOeLt&C$u|buSp{mry5FVWGKKxk051%m2}5FKH%5`Y?5c<`6~LssyyvS-=WdT*A0v%rrMj;F2Uq`88X^Ij*+jg!{41TaO=Ox`-)#sH)M!cJf>U6IyrXU?@(q6d8+iMigQ(vciwJK@NsAv%EiLg9Qt=OW$Dy+;VY_Cv#%=MT%|-`{Z<gjtz~A0WkO)(-Sd}T&h*V*hMernCct7KGB_=I7-$#f4;uWKm5LJrTKB6K_@#u^5H+>Q_gy;pYMJ!aQh&BXFpoMju1RbWypwp!9)B$C=dzF?voiLFd6BdQJsxHsINaGnpEqL0Es$kKx($ON&WpjIMI9hfQX$JpgV=#csF8*B~6=TRz{EqQFklIyE3LHqyUTR4xwv;(Po59%r@0lwbo$ksUPMGE(iOzgyq;?m5A(1s_pBm3!kfXmLzC{2QmKlpGvQFi-!5u^ja^(T1AmOv$U?L`+a(?<-?R(VVFiDPxw%!)|hU}w1%h@23Su#pKGPoSyaKU$p1Sbm7F+Ro=BP6OQ{vzf_Oh@`*4lcsObGm1X{=64FawIQQZQvqF-r>{D`!Q&qBIWbi;~Z+-w2b1s?o2!UI_0&|{t>VDF|l=UNvSFXa6pw}Uh{GsR$lj=}~}JKlSy2;kYQkK-GsfUDOjA|{~)!ULd#WbTT_wc+{s{p7Z6$yjrvu1yLk)`aW&Mto29M!ng&(?Fc!3&IcDNlbfMSOVPvo=wya#}f2rdJz02>sNojN)?V&|L!}JF18bn(oi#QS$n(Qg^%n!38`To4Xe<Ofga!!y^BTzX0%8FF!-&^?B!Ry`dJA;J>&oIwbrj6lh67AxYD@8){S+vm|D%4FL0$4L7*te$j}O_;3cSZA!eLm9Lp2LXfwrP5zOG;SZK0^eR%^dO&<U)E$@ex#*KHmlH<iHb$1q7fZRQ({yH=ZLmWI2)`<cHqI2_rz-eZL$yR+}b^eLOI9kxKJ4XVil_A(`uG6Xp;%|kl$L-p1!b*G;ppSl@9{cg4X>0#OuSaB7*oTdw4IyOL=+bYa5)qd_`;E70`gl<>>#qvE+)@iASPmb8dEWNKrKmW5kj5=sLwzL1-3^V~HU{&n@a7tSCt5DyJO?(RWxR&&z#zP-Y1|%P*SH-iUJDoS$=Qj?WNy!9F(z%Z3$feLrL^CtciWttBkDnEHpM|yuQ}-Uo3>7`sS}A_d`;c<``sVxemg9`+TA~g;kny=f#-VUI2@nTva5SP#(_M*=m&$sJ8FE4HxJTd8<-aEI=bVc{5REK)@MNBB@wPq@|$@|l<P66Ig!3mLftXf9pVpR!GnxW@Gh86n7$1*lloVb54yzaI$wK-L6O?!QHemf5uE|g>@gaQm(}}Gl67oA&o14G5bchvV9C)~GdY`0;uA^?tWF}BD+4TstzKD=`3qmm8|ppW;3Zf?`*m*cp?nxIm}wV+Rfe02RFl`D<qb1kaf9=h6N8Hi!gAJVNN%>%2aypw@0@JQ(Sn6x&>DF#hzBYA!KNh52%|7-&Gfp6(c@LeaEC?%j`Vmf+AOSc5=0iG%*^I%mHH7+$?@E@7^!1m;6&TB&~bkfX$4%jXY9CZJ5{_RgjQt#o(#aP8Mm2k|3vp&5H5p&0#PE%a~SVA5bFB(BW_wM?Pqgsp6^IWWt(cagJOc@90~b?oZI*iY9P0x&#`<v)Jw<|gzLHCQLz%c-ON3^S3Ys{enK{a{z&Dl@s4*o8=_)&*O~C63lV2&H1HZmlP7Sci#tmCc19wpQ+W5_K`hz!XB9DzT7<NFY8<8U9&3EPfcZ@;S*7vp?+EIlMN3D~O6m#sG~=o-A@#qmP}9B4@6;02%}nukKK10BKF#FJFD9q(cQioy2=0C|SL0WwX!I#sUQSWEw5%q|M1;{nXQTHXTYt#B1PMJ3DO@y)`pf2Kxn%IC66L!r(R7h8G!U|@wU_r!W4@!Bm93xj>U=&nW`<Ac-gx4)YJ2Is%(-ofu4@!`5x>=I{g_D17KQ6Z(SQA|IMnQl%Z7ZtipTVk4mE_teSkg9Ww|3>mOJ`Z?&z)G9-70YG$zaz;%3Y8R;`0hgJ+B(470vfIVg@amK5*eAp&n_5`e_C?s`)@k?#x%@m|&lQq<=}Xa0-=<@lnYF`8b66fb|$#f{%EUH#-=KgWD>4~k7+x<(TYcLp!UC%ThfRL9m4?cFSFQhfj_$HKSaGZhnAnloEX+!~@QLYaNsz$Ow`lbHv29YdRNK)fGJxJ4*H$$s?Qax`*@##UZ0u5^}}A*93x8JX6|)sA7ciJlgxtZnyR(C0g5wkTRrO;-9yC~E+ll_Zp2uZfalKMQR}_m-{yJ4dVJ>o-p!gjOU;%oMm$jn)W4OXl1)QnU4-n6V@GmL3qL7U;?u!Z{Wb>a|-J|Eo{6aEzw+d6PIemKUhIFCz|)d*PeEj5SE5MJycCjZKZtf>yh-9WCKg(8lk}7=-;AajINN-|gfi!mCY<m7(MWv><8f>!n0xQ_AcThwbyjl<*_DudKsPJ+(T^`d9yo)7a(qs?e<_0`?n7eNFm7eHc_N7(a*Yt6HOm%)%H>8D(~{4CN0Yb0#xrg8mr%Pp1PmiG|Bzl5<U`DtT!1=J1Et>cKC*0+miL0;s!JFgEo@9kHPG^R*w&XmOKf_zLwS`w%yDc2EsXGSp96VbdzgWKM3?0qItOgGM^ni78lLtNsph$A05|xWP|1vNK8ntKAJ!_#*)G5-?&HZG)no$$H)GWPbq)h$iZZ#V|cgYE47gq<(hvVGb&2GAhY1+D^NbDT;d12`V*rjP($FJxZ@3<xi$e^$iBNUnWa6eI;3{w2`GMUr&~biqva9N+eOz@VTi>l>nZQGF7Bl^(|#8(Ta=V_O4{96j^L#sfc?C*8I&cWT^&*u*|%+npA^FuH|OrN~vloQ}r8Vs`TwDQ~jfs3jZo8S4xH7bTZ88x2bT!fI1$LYt*2ym#eW=0Wj57KH486D!tUe?)N57B4HA&FC}V#+#~U&AsmrBby_aWo8{gsjWMa_DI11HXA#@iHi8|Ym{Tx;a9%KBP0-e(SXNyM-Z&<=35VYU7DRnA<*$UwJTVrC63$EcjuW(4E>1<m%*qvBsK|KIFP|xtU4MQP#CpIid0<C~DIRnb@0dPG)$%{q0?~g2PV)8DJ4zbLdJ&U)!Y>x^@?H{oxdD%KU5i$g+IWKGll6ys!W2TWTMOv+#?34lt&K~%S`BOkjp@4Bdl0QOTBSp+ee(qA4Nj?Sh1+CIF2|aaiF_+Jl{!<f7{P>T>*tv=7rWlHUMDxi1#2IBpWz{+>;T;7&kttJmfX0=y&y`Re(J>VC=}Bv6aTt%Hv#n_q+4a#2Nng)y#o-0b@g~iECnlhotbgu&CKsPHl@g2-|t_#kem#Z+3x{a%ukAq^74j4kHr4w0wu%6yKlHvQ%0D$W5-Rpqq$oEM?}2~>cD^i=6;7zd=UqE5R6VLk5t=bY$xS+OtyR88d7d{icxS{YCCj*lJ!l=!%?e{la!u6``ziD3>@883`Rsr6PZYbsM0%0-m*M3A6R{~dKaHqF=ezgHEOD?$%x*q?{LqUBDnvIAh&cr7W8c3Uq`8o)46=l{1`_bIy!1a;eS=;8;9KU3<T3j`POuh&GYdI8o=eBtdo2cC0(82H^E?Y4`ip78Xw@RKEGv`3F^u<<?VyF+eo&mi)UR!N67(^tOzvtS(;@$?2HSXRC^I#=^jJ&AP@s1=Yb&+TQas#_vEN723Dg^Z0X7YYw}s}pB)rSMb~0~k*~7;inMP5bU77!>qMexDRE#fF-e6_P$g<s7ZpK+q0ojA{Tm!_O-wY{%jnW(K%B)gu#VJGN_9u+?h@0^?3?k=iAzI02GUa4xk93{U%jN?+=9bEp1)(&vfkR6B+&5|GAz|l6KM>GQO*+opgL@yO=>aCX`HZjAOjtMLrTQal@pS%xtRHc!XUNet@oVWdK1!0WWNpm*L^ZUTxsPgv1baB0ro{dwBGVE^A-y1Q$uyjrTLBndCrbJ5H4yrih@85TgZE)I~ErQ#y&>ES436JP=HuevR2rPr$n}pv&jq-QN}?$QqwEAW$?oa7A9`QKz+o>V`6XWcBbu9(6$eyCK<utUoA-*DI61_sU4LH5()XY{+BCG`^Tg#K04B4V`8^{?MPyziCxgM-E%M1#48}tCQ@wsBZG$Z%Sw%WFaBmvRqwhb9$4{E-ZL_)80<GHhVVRjJxM+6&{?Zf|19eprC!S~Zu7Yvka&hY%@gE2<C`<R_xQm{1sYoi6~nDvSTJ#4mew-a?2;rO8=Z#dMB1MPX60I76bk9iS^pjaPWm7QEO7}kuI;+QM0|14#tw54Ijx9?Duq23)p`dF5gyL-pnRcY!oUPePg4NWsC}F3vwDNE@%iE^axME~uqC4DJjhaxL*1cUR+ZM7qmb!risJ%)-&d3jnfTAGYRH`+kZCcXvAH5{g+tKK8qD(<G|vV{2kHyl{Z%fLL54&oOlhluS(3GYvRnAZjhaX_5mdJZfy_=UVQc<uvt45TS!P}m?QoJ|Z?Hq==i$N*dc#BQR;dy$7Gl3Nmt*5S`Aei7xtc;ZaS?xQl&@mC7MXbI*cdl*7twI0!2xPl5*IH-CbkM0*?)*8l@W3mZ;52AEUkF)Ctbjp+G{UgrDk`0agwdD$5#1cd!GENG|2UL6H~GK5N=C-T#Au!c3%B8C|ke%*&CAl#W{nKYi}7r8gOitcu6aUTc_GyWVrm{mN3cn_wAF-x(WXfNbNu70`XZRwKuJc{KeMk^orDe-_-<8b{3$sQzsrVl$N|gk>eemRs(R`+8YjMhtmU~1aW<aOW^iAhi(TrZN?T-SNTV#vmw4A0ct`zgOo>jKJ2zNzSEv05)V!M#2S_JC%j#$$Os|aNtkH^9fqBxe6C0#(e2*b4^$)Ov@S<%LIb4Vc&ZW6QyBq3C)|uS$s(FZqh_#C9n-&Ob*(*@)NinBtA@qPqE;l8Ts-m*Dr#BF7JFRT@W?qyHbUzJC=qpkRm&EhGs(@8;Z9FuuL1Bp?_ZR7(w+6bY<69AV(g6;krS)fbPgGvbfS%k0V7S1!rBBISu+ae#vLDuQ9~vNPy|z6G_SV6ZGC9vDQ~ahn3-m(a5qTS0HT#xxisO1=mTp|C$T+H$|1bVrR~DQ$L*4X8Ck9JS_J4IqprUJQJ=v3IW2=JiHv2lV+KKP(=$Ih!hnHcQXNr4B01QC0@eI$0#~2muLV;UWN3r%q?p|TGfjErwjERUb-r_@i~Z4bwm1uIk(smc(MM_4nm)RAMru5S)VMm(pE2%@*<rMXxX(!`>aa*j<>oQ^7R(T)Z@UJg0&*#QY30>DU#Vfm&E}F^{fmkQLFCa@Mk{GV({N$C$tLM2Y&ZJ$opcjcCB&p_hsBh)-oXTvhpyFb#2U3_T<X$t78Nz5*+XBu0Q-&>20;S3VO<#$tGAMqnB%?yZ8plSxv<#};NT)Kf=f;lMPV@*jnJ$MvyzcI=hr10LNTnoEJaze+{i|b&;+H!0Dpe>hp=2m&s*SJ$k}tx*^o9_X9kIIIr4|XVmj0z5Cl(TfRk>7biZhp+#%G){CvZhTSETF2HK{<c`r(S&8m^3O-w)qB2IKki?kB|-iV!RpvDo_33#(0Z-a)@<LZ@HxIl*myEn3f5`XZflf{>~h6t(dVNs+T78<R@dtbtm<vnx2_B@k`fZG{%Hk?PJR9fb^@>)7;5{{th$?u0bo5)c+0%3~MNHmqgKlSB0LRZZ(#Rabt(32!aFR-+9hsn*GyjLc*Q93zE%-&>9(DG)c(wbwbsfE*>AhA-yZKvbsXlBdZs*hjnk@nK5*scAsqtzXg0=u;83ke~FF4?q0I@FqDN0%6qm{^wGW3am(@7NIABVXHPR~!<_<>=xiW1P6T4&&MlyH_{tfBID2u+u9hE%9R=T3!cwz1N<lf29>J3{Ba#!uvX9qW0?HB8a#Ecd70d8U!;^ZdP%GS&QFph&L605ABKPi*C54=)}Ejf@D0xy^Ef>Gji*CHeoUCcGqq3ZKs>733PHvZ3tnZ!kXk5bGkg?#m^v!6N`gr2>o#jg4X6ZdKEEFli6B|Nxg8B`Zbr9AF1qd$L>~7B7lCVfBLncpZWa{Ut44RAPn_E^`yrgY<TvZ^EJB%OBD14_%1;O2i0v<P;qzJP0s9S3T}fji^6_>j1<;~P+=Gbww{HXacTB+M0RitR-vAQk@F5mfB+)p3!#R4Kyb8lM*fu$AdEQpLM#MtMEk%#zbKxnQwK2`{z-4|_`@aiz08Ys84Nge@F}b3b`EAPnd(qk>OX10vPbN=XaD3gUN%5quvCqplG-g&fd?h~-W`1NDbZ><2z&+hysGK-Bh$i-mVb3BShpqrw|}E87OcgvI(!QW`s!i<qlXKm_62T+!OOZ*toWsvUMv<3xM^vKFBYKjFkk|6BCn8_xcN@(3#A+DY)>Es$14e|=vz0@gA-3RZP$*r22rR@<cxZIb9%WtXp!PFNlUiL@UW~en7n4xRdFrDag&fUb*QZP9&L_ECRS8=p#B0W<NbfO)|;0Uzt_nm8!tW6TjR3uyle{3qYBT74se`f09h|)U8C0`ap;8yM>kXg1hY6@JvR9<7{#oWrKy-+f0;;(OJ+Tb!^xYjyF(T{NS~WUXc_j@gTboCa)aw+f5@uNoz^whM|OyU_$k;cZPjAraZoGCQZH5qiol%{RYs>n%zXDgnBrujP$E>JvebDnfkyi8BL1JbkO8Ta>U24{d8mbbgDTuLCqgc)TwobQB7(%|LYFx7T*2+c3%!;ch<ocKF@6Y48DRQ|B^e$QB^^kA?S%v*h@+1(&!QxtoabmluiRn6%)>F_a7SIktl@(hL%wcj%_&cU9?Xz9J^#PhS%Nh!GRZ6knpO(%*3P2#6G2Ix3hB_b=#Y%#?1&<G%)aBNHI2|zR50HX9hrGU5ELO_+L=axGF^q-qtfdWoOF|Mu9B7sO2W8TM6{<3T;m`?JE`_Z??kKNZg6Sopw+Q_SY<IfYqfeA*h<2^=ZFLVQL45RdJ+g6ISny%rUjW9TrGB5s~y@r4>7z)wV5sCJ$IR)S}e(z<~kn?2`ud$|K5IRe&%eYB&D3J+E|%@k3D&%J2XjWC6}o52cfIvtX+tit|M*`=ia_IP2_Yf4Cx{v7e6TVOtyFhi|?8Hrszu~WgnA4so*v2a@fiR?_4UzWIDRAIltCKKe=EF$<r>8dhn!Yv7PTaiLqthREimArud(KEq2FyV6Svsij8`OQRMshXyCVrVQYPDDfZ!vxzo#E86q~=$DQ3VkTnb5anUB;NxBY;wSJ#%B^r4rdozX)mYcqiD5Q~%NFAo~ifU3H2RjK1A8y8jd$y>vZksqin5Ai^G~0B){JRwlCjpr8gdYjdhi(-g(b5dKv&j|84ZcayjVg=W*^@sos~FwUDel)Ip)9VTRMqN)l<66zSQtMgAno7y1|%&taE=<wuS;5%kJPi|Ln-}*Q0cVMvlNw1#ifssw2UwGELrX~=ce9@jFH{?<jT=ngT(zAvbcY!2@r|hBrQ#T5~YI1fb9*W8z2TDdjr*OnrS^1&94a8nF-Db0o`shObQXc(0A+NU4Nlf8m_cT|Icq67k|aYAGaYspRj=ar8wD{<vPi|b4ORKFR>G?c&S+F3D0LH8qNM09U~`=J_@avn@*IuMv&r9bT&#JjUP6yRs@ZPlhgtgOIpTB2A|7YzJ6#GXztKmklcq*zp8P@)e|b4WM-mx3Mc;<)HgoGAUCK;m}$5q>qBulI?|K+RXFp(`1&IdYgo2UyhZg<nOY2mPqkA_qiy<88kTAv5v>&sN-cjV+>>#m8K^Sq&O3qDqej(GdO#fPZfTG%iTeT;<lRqPMeu8JJO&@j@t&2-hUxeHt`O-xx}TgxMGO7PvZ+UEI5R@wP8SF#tWUWxjzd|N;*vGUtb?><Fn4?3$m*`Ka2Ff14atea5Me!<jTD$pD)DOYVt|;cAp?uv%u2DrNqqYl@eI{nFT!#!93bk8_2xNL-(sf?+F4erUeibo2Mpe{AlN_B7Z`)&;75YACSFHg9V;-R<uHaYO@#Ag$RjOb0h;>kg|Y+^O(-m|_*tmy_sHj5D1;LpaKaOj${ca@D{N{v3QIrrDEr60$=)^`husjWzWmPJZ<Y7Wtf16&<Vew%M08|Ev!Q<6nkoVuIHFyVT}TFOtcXfBSEz6r0vTN>W7nzJ?*bh%MHoOl4S{z)KI=?_*=B7xMV?ZZWNy;+*1`*xenbi3g>YnXG7~Cedy{f1$*l$RU_~Jz3j9T9j!v{j>OY{3QOHqeCoux`%HTf!rLU{VG4Sg)>yyjZ$)i{?H{uJrP3w6Jw*7(Dq>(^@a7pLLE_<b*aM<doi_}FExZ#FChoqN3#DZ`LR@@~=qT3L28ZX&^_7={*(C8@E`6fx8ZOSX9j+4c;l&`!}>WG*6`Ztw2pz#@omM$p+ja$hM=k?rFVkhb9QjGnUe8;~C!?81m%x9c|Z*8QUIcm;qmSaLb1HVn!0Q>Tp;q`NOW^TGX*)BaLhjwuW&_WrdzXN+WVjbj%lufSAii-7#&2LP6u^#gfiHJCf+G+l?2IObIxo6Bu9<Zf!x?!_Be&nYh=z`=$>T+;kd%a$#S3ttCosG&w+wa)7$xa^A3a;ON*RDP?s;bXp!C=SxBHvi*<t36m!&Ah}&{rN(Hs=<~lnSBEB2XP{_1_OhR_CXFGX0=>*pDC0R4@M3ixlI1R>K>onYs*)tP{VO+ZarTOT%GyG16eO`oJl8V41QvIZk4OSYuu^rAPefLZ$j7jWJ<TBr`1!Ip;92faz`|VQG{(_oNwxXXl3=Ml9(sJ!z&@mO91eOvAu;1UeTnACtou7Bwqv8?&p<qG3i?AZO?A#pntU*j)!gH5k?5t~KA9<i0gB@*2(Lh_=J#VG|G0BFKrOH?Z08ohyn}Q+X;7b)Jo1!H&G~t1#1?Vr9xypWbSifzR*l{$Tf;7~9J)utfWeItjMwfjX7iQZP(Y-un*2(k&{u^@k(2u<}6K3)qL<Ox#W#Eb}b*3X6QD6WA0fU5;<v??$#<qY&RCBc;quMg^Zi?Fo$3fz{jZhVB6|D!N|h&K$E6>s!+h-@;O<OFR7aARxfdO*@&?u<IpGhjBf)e6iUvnvzZZ2ng>UJJvNGx@UfW%%n>_ILG(YJs<!hW&aNQ>ij!aU5!*U_TrcQ@F?~ygMmXAW@sacPG}A`QpKiQhtVtw4lpPNmA^?i3Bi5}X(wf5TzuI(!q&x()qh-O^F;=<PP!bksU?;oH@w*7=w|QjGyd>SdxD>rHm5xgEBw;NQ^u}=X(jF;DQD`f3CXvqpYl5;XQFg7h1CQGEgC6bkRAcCOYh+HohsNt>6S$BEzgkDu!_GdXp(;wtPS0|OnOCeGq>hpFI1sv7FvZg5hlwj8i!$w*2A$Xr`c6Y4p>zzf0dyvfP>>0kHzX9I%eox);61JQZ(tj<|u1=hj_&pLw1x_@DJ5BNfZ1NUS=`cAaV&_p{-1~U)Dc+L<UGF*k3?(`|s)g1T+`=A9v@B_<elCR>`lBR`?@*?rw=>SlwxGn&je{nh56;;?uLi>+|x)aEd$VW7HMF;><@?8%|XAp=s&^Ia+r|t_U2k3)b)4KZf2VAYB9<`3=N?Nb8ekVf*XzgXl+LVD4X!ozGZe3y-9gI4=17(8&Wx#fRSgAj_U%p*WOK4UO|X76o(IqPlIr`bQE9^Ur)p5H%h_DkJ;AD0jQM(mi#LbqjoBq_E}aApxJzBYWn{Q)Jadat-30V{hyoIv}>%L<UvJO=J#h8p_%XX^10t2}K31<fe}gN!m(NCqF4kB%#T)1d>Pa?%h#@I4Pzb4A#@TX;x7gna-H}fYv5fQH11naOI=?nlt;<jDpghon-<<2|(@cyJ)e3oyuOautN!IE*3%y6i)#1<-zP~@u`<TXH?Z+auC~N7@q`R!$Lq6?QS%tZSD``N<?-TC+u2%GLRAO#2asE2=+<H+L@1hQ9<sW>sv7_D6MKN85B^gKESunMl`ZeA<J%*1pZ|9=OUv#hm9)o4rPhut~I4;<5E_nnhJjdSF5`&?(R&!x=w&yxJE_BwG@TLwy-cleiX-AwsMuJAzAMl1G(Se+bu38WH4;4N^`RSiP=iNcpSksGqdAJtz=o6-%YT(CIwaU>I;g(hOk^B<p}SXCr8(HX5St}2Gr#VnFobLl!eAe!=2U(>3^%v&+^ONxpd3-AV!joAsaI%_n)K2kd91&>rH%ajzHAm-DU0oJf6ZI2*%L+%)QrxEFGpiIWGeobb%P_-=5gJMl0%0_byTi8PUZeZYmWHk*|6$E3VxX5^KEIjlV32?kUMk!E=sl(ZMld<yjHUK|+Yvk!)B$XN^=c5pPUC{Mu+Y-sN3<beN6w+D1wn^rxr-Od(WGV(2xc>!D2qPi7Uc7U?s~wV9p1AO*jLRh*uC@)3;u7@FCE-D+IQnJ|cYL4%~!gDEdXTW0Y<etRuoe(_-l$rH`|>R7zHcG?_U+OsKUV0S83KPDtD7_F3@l|u9KIkIVaBo!`NxqVVCzYyPQ@`sUmIm-zHLm75)H<pWd{=_w)IME=HLnpoJEf~`LpNOl)Qqr@un&+UsXz6WPp-Ky2BvVP^;)Pc<ho_7x_>`_BW3IjopdwkKg&>ujUO(pwfC+OH-X@rKj21F!H5=FtnPgpa7eek(M&O1#NjaA#W(l26-h&xoCHe{d#kS^RY?ZBGtF1y2qUKA5B4%wNZ`92;=3>InS#3+5m3kY7<jcX8zZgI)C0v_}H5p`;w{r6cQ~~ZXFIJM+%P)mcMnmspi)^^OW5&)hdhY};0%<2^lYX2$Q|{$c#?d|35Pb-}Ds&8hCpxV2L0U1}y;tK}y6Rk=Q)o$uEOoJ^&tB@tOrH};M983_j1qTw1@N{nD#S&teOt|votwM&<E8}GP~BJJd%(CMX#a`!VE*!!A#89h7Ri9RVx=THT<iQ2uEp_0@@>a_urtqVl!fAahlO}9-D|Kcfn@7~Sa0o#fS-|x4oka`2T>VT$ShR20PZ2#o!bWqMY)IK5X~O~>g%(VJ#C8&<47Eh%th%(Jm!4w730iGiL*jUqh*2xbpuV8$XGU`do)0@CDGh941P&gsx1+s2F6*zc_zgOfn{V+mV<2R=}}D?6RhY6C?mu}2+OJ)=D|?<g4|GBgWxGu84_dA5rz9Zo^9k`N9$sulZ$OQ$<x>%vWVQ+v4N0OLAj1$d4151+p2+hvV3}A@+W2#Mun_uj17#NFGFulrrbG41l}I$`QNO|VyPeW=NaktFcCrh0JRUGv=+X1S%AhZvmn6c^-yCeflM&#)ni2mq?^zRi1IWk*#ewQzJ2{Dy#U27odP+IddV}B=MlLV)MCd_3KTze{zCmiX3dnLTU;@Za_xFae52$-AxX+!K<0>`SVuNTYY$tPrzlUh@BT%j8D)EZDuyS1@X8c5IRX5BM-<BTtpP&RX-OQ~M;S_oa>T7>5QGDUXzH>U4zqlx8C0K?Q<9rzGE6373Lua;Zew>C>2?;pEXFjZr%vlcCPIVd{Zc2^)fSeQ9*j06x1Lp0fc!p!^K$9AUSw{Lvkq{*jstDzp@Yl8whPvGqt2qbyMy}n5+<=Sf|?>&Q&g@4|LMv~O2jm!)+ACHaV^QsEzvGu`x1T^AaX-lO5qlrmf37tOBwoQW3HL@Nn|$|pJiZCKUnUQOa{@u2Iujo31pGx(FJz{C&Xo8%6V<F?;OlzOYln<KQTz3y?ZL)17;Bcw9IvO0}E^Ktl0s=R=AOw+ZHtsPNZYPL8uO*Llng~n=E;-7A^-vERA6!sk_cadb!cx1@SWSpb}w?W&p3`T<4t2e*N|H?UO1gR(8||!z2WFi?iY9fT;Ve3nMFW`kR;4NKK*f{YF;Y!>CUp(UPHl@aGy7c6a<(2fg8Qnz@mgwCoVcIKo_8B&kQ&d-JtoDn;2fJko*Qsf<Apw{oK~+p0T~PHFxX<&_TJCjSH(7-h`F1=p~S6i>u%3Ro~R(d=>Zq8nEAJQAE$*cKwPU;xE~*%p>ZR1%T|E3lCZC$S;Ku-xM$SZb*ZCTDV^m{H_Tu2qAQ(+4;T*Y!Fbao-00Ney8^V292?=3)^t6feG03%>fpUx!9h4oiLZOI?RGVK6&Y#>uC8bDT6=H<mpY<fnY57|*h!DAO~i)jeu{;v&9fZn{V@HG2*FXna*v>7GnjzaIRVlvJP8=8L__TtdsJcg2_J^|r^3#^;X?1!U+kNq_Zh2Y=2u<*k;}2dJ<i(0rn_l&VJDaYRh%#gBXJ8c+4D>R{->*=9Q<Pl4d7M0`vVF6e}K>$-s&`%`73Xy=@8!Q8GNI@7b@#bAN>P3YJC$R`iQl*`YB@SOXHFiqVqz=Tl@Vw{uIotj!i#^gaE*FicifY6Q-qrDTpIg6abT0If+^^WejwiihKPzDD@3JxrmgW&(D)j0}Ut3n_=88PuN7AIO8q$D~JKGxGt){OY*`#}|NRPx>qEO6F52;zHeMri-&;`7q&CRR7Ca2T30+RXbm9qM&*9>S-Q=ci80_uQvik|1ek75MMTZQ%~vGI*iH%%^tPtSgV-v%)y*TX&r*j*HY3XKt*_>4WDZt?C8*&K{Z9zE{oM9Lj=*$zRyovX(b>4e{0V?S^h%<Cq$v{Xo)2DLEYaSOXwrgxv!FKNba!;>~wzgwnDAm$9?H1F`PWD8j_v0^x?X^n^wjC{$A357sOi#Nm&|14%wiA^YIYJY})n>0m-|bZ?F30u6k)3>>j>=~bMckeCPtZz1wR;PQb@kdcmHBImNvDg>y4Pjy$+%Mzp6HLm;4pr!1Cz}9|Z^Ocy$q0<;O`=C1HhayH;kkk|I?ricO#)RPESR3oW--XG_vSu9H^WqEpYg)`jC@`=p>!Sk95Auva`KmrL7KXA_>JuZyWSvL^Q-e&r`R+fWP;>li-<r`hL6=$Z9L~?%cGHAj&WNa1RmBiYrd`nC{6bYx=wY*-P8Yt@!-&#+!E(>$dc06xo;OgPep|~(w+k6qcCe6`9-NTGqnhrlVhpTe?4;%t&7MvSh^tzLlZex}i%+zhM&#~=jGfT}qa0#_><_uqt7egI)+}OtByC+?{}Rn$2Q7~mE&qDf2j&!a(HsB3Uj6QHnf@z3A-ge^S~&!6l-FM3#^A>pt{umw8@RE&b#-z9@ZLw|d;P`M@i@LR9>Z468O<c9W7#m|0(YRr82_1Q$}YV$gbv3b0JM+3BQ72ePYDgcOs94lt%Xra{~BnW`KGR8O$;Yf8tcY_g6LpPD^?8mMx7kq<0dv6s^rQ|tZ2l!`AHC}^wSNu-~Iqy*_t14pcNt`KG2u*mePDFHL$uAnAe(;n!r4*`#8O)7<#b_WgNB<n_r5PW<_gbToGAq9o1Tlk=7M~%7hwgIlTZVZbn(!jxs^z@?h(oF=iuJbXx2v(8_F85-%#*X89TU`0BB!)!cVv&RS!rCAeIIXTMs`3T5xr`wr={5DWM<hFDPvmI$U@eQQQ!bi3x;i87a{-BB=tCWRIWcXdQ(f|I6q%;8_`{wR}<`Y3*%!V*5{6LQ3bEW>jRcs^sV;m7Fb^-++KbYNv}oV!{5uTIe@w3hGPqB%(jfCQ+_wtj<K2UBE2ZYMRhK>3SV5JYzx)AWlb4;O~$2H;}6^)4P~GO9sPZF@;mu@Uu<f;cc0@VB;JY%)2J$^07P<o&vu<`Q#eU9V)iHci&egn=TF3|xgMJkB)X^C+@2;t?8dM~$F4(gKS`^8>2{WM31|!?cl?k2)*%+HABxCL5jhzPckkf;2Dm8PiAm4#522k>e2~F_?~dAE)Hk-<dLi7;3mDIq8SSGE7auhZAKI=>1RGmPFH?ZwlPp90#L04qn*}Cdt5Objd%`aZs3U-<!fqO!I}~ASG#TY)sbc(GBWf*^ds~kHqSU?k<2pw5-h?<aYToAo7($Y`mv>IR}Kzi8v_X;BczgS?tsMX5_1bSc5&AxcUl2v|0o-d8e69VKSB0Vqqd)-ao8YeK(qv*A?*!YA=6$n_J--{tO~{^JuJBcf?|`Fuk&jt;Ze#9~5vebKPU%*f`Ju<;<qMvhn&r_Q~qP%0mj}@|KS32~zo_9COXw2aE^;3hCM+kxwdSuzV-rmPr?bFCG9ulGwCVFHH7Fr#%YqhP6i0Jn{mTEm^(AUz~Bk!b;vKCkXL>^))is1mPN)?s1}M&J@1@r9mYUyjFBtKfV*Srsrmk72^T<%d_iy?^I37mQ};vz*{Y*j{QJ<JLDkP;#ak8F+FabM2p1)c^xugl51zH#jb4pKe3rS1k1lZMILm?r8}{Gdw5TLIc_|u7~;K%DXAl1nr-3AIPFBX5zJhNOCxUfYiAa_js_*WoWpGNTe~!L2a+9g@!h^CwE>jpvA#STHJAuRtfN!5T!!jK@ri0kiy`0$nwt5hWvysT9E>F+CEU(cn3;^Mr*J1K7ByPa_Ye(#VE|>O&NGk@owmO^#6|{>LMIyo_aboIMt)!6=aB#A_sRNQ2`Xy@O%nIpeC^qLD}I0q(*<B!>Mm2`Y<oQF)MWG}7hiQbR^dqFMSGRaQI^Y;N=UzCT;k|jxIvuEsdMoUqcx1CH*7EIn`!{LG>dR$Tm4%jZAyv2Ue(&%7PF)lu$Z#0mB?HBz}(c*si|5!e6-%@neygFam(fz;L(sPICKUB3#*o$%c9ciO5>|{hLkPPOo-%nJPj_F7B<Ih^cQU0QSw2Ge8Kz#x3BV_FRnxalxnqJ$h}4n!Ax34NNlNuj~hWhSBu!5vzR+VCv`b-{p<?;Vq&v=aAhrZ!Awp)t;P?7gaNxW*g}~m0!0Sz^}0M@XJEqIYz-Zh*c5bmNf5i!^OfHExa#E=M`BnhJ+6M^CTs52dN1@TjPC6>nW6OGhthSOIlmWX46-2Ytw)<LtXJwk8ItUuflr*M8Pv=0rtXGE)6ve9&mWGqIv3XH^AI2D60vaR)!$5aSc`#4=;L>f?sm_GCUKqW&4)ggJ47+Soz?J7L=9n;4f-uq4rar2Cu33FT-@c6wte}mHNZbe>>ke|{NQ6A?-3Z)BcJP^?vbX|6ea895Z?62T6+zU7Ft>4gOp5FPz69Os6zi)*vPKPAg?udF@MjdK1?(P`er-PYP_Q&%zS}}PewweU+xhl)qmPT26)Sc1CVXWkiyEcM6Q6{<ij|rgUjZ-EebB3Y57Z#GN+B3A;?#v)80gFN<xjfrtDprloelV;_h5<rBIPx2>24#mYNi7T|giko6TM#6)B9S;DMFdl}Muy$7^bt?rQLN*PEs$Mdz?2Eyu0#+y~Plx3x8!u6ytAn3@d9MByp1BzuR?N@_*XcDG7!TECfucq!H-bD8BdUOftp&*1&-%&w}rR+OZL)%%Vb1wo(MFR$|wxa|-@%Q4<`XDn8&FGDsFn4H!DC29&2Ha*p3A3D2XYBKd$)$`}j)XxENBq7Dram-vLSjSy=RG*HecI$6ty;0tNH<|S&qPaKpJN{hues7bt5izm;fh*E6-sgcv9xzujB>vJ!$5hHT-m!Y3_n<SHU_TAW4JNUJj+1FjEwb<;E}}#^Pe5t|f5J7MW!<pjV?@s#5u7bmy&bF_e7sj*k$TxYL*^Mqws3k%7uMT=;I!|`B|B7#!2rn5!8r^p@Ylucurf=NwY%8(J9sUL022xwYekb#xTY_1iMr3#aWUT8MjZb1(Aic-3Q9IzHv8e~_dosTSNrEr@8_rf=TGnOPw((g@9<Cm`O`c6RsI>jnSaKw@bdm+{@Q<%%l^9m{0W5+KOLw)!F$_(bMMvvjeKw8N53||_n$u<v^Q^T3}5S?@f-SQ|H1zxZPe;M$x!L*Rq3DYui+#9dGT}jpr3QE7XOET?{2-M{j&SG6UN)$vuqZcagE7fkb;~$mn*X(*XD~52QLF%e>wM}og99&w2|Go1*#T8_7io1tSTg0hD^)>s2pKMDhpdLsIykx*)OeDC9H@yXG7P1PRX2k?29J8I{50#EPmxL(tf#!t|8Q;|KK3(^{{aJoI2Q!$=%g&@XOtL*<HH$6c-;MTz-V<;_aM5E&^Gw{y@LEWBXvW*CcW58(-}X%f#v8)9r6v<m5NOFU%Z}Y$n>JzIL62eunEOyCb7`^P4N>?Ic;*%Ri|!>|kbpK<g8UChX~IDC;r%?&g!a{*uI=sZX<OC%J{WBcjmtzt>hz=SXRKHnB9Suf(6d!_(=X7vG~FU}J3kCBI95_3D@Ys!2GGSN`hP_SyljzA(Q2LVcX#!RqzLQS<HA$MpN~C0Coi`p5A`>z5sH<1L~&&%F4gcG>OPUi(~Mdcds#pf9a0?Vt9WWT*A-vHdc0aj+xRiS!r7%Zu5b(?+Qe&h2HqIx_Xw*B*5LzE^$d9rH7E;o`{c@3)7&cBzh>yZ-%)+lwiDb!WQp;{FFJ2wnZgugBnkt>M|44dDu@`hRr45tc-6gi8|UpcMwnNbD>0zzxhn`hGbsCXdE;A3AYVFk=^3Uc7Z(y42^&-eU&6sOP#hiLdHTZyP^R)8k*g3t&V*b9<*TsIzPAZTAc8%&8y_VxpLGx1?VB4VSV>Kx}E5;$FvQYG~_s=Y2!jwMeek?H2~&rS)F!YrnxRn00b8I^7^}V>a!uoudts-pIAI`ql{dP-6WKuwh~g55UEumLH5H_yl{syS&&p#s&UCEEMWfXm}n2YEiYJld6{BE^+_HAlmBQ74^v@$e)J@n&oI#)a#es*gFFUU>P3x5}B7sB{;-Gf#fpCv6GsWvMQ50rI1Ll9&|y=l-w|qoPM-$W@C+~{MWxl0!kqPWqMt*{(^uq)6%?i0?LHP_yUu)VV`s_F<FR{21iuZhqK$TPsS_u$rhGH6qlnb?W)+tqkau6Ltd~?$TeF!0}zn+`X2U)X$}jY{X~(NIT}(-1e9e<K#8UyPW(4p-|u6htki(Vc*#VWyHPa;V)ZtB6hOD@s<dy^0NN%zbiX^uD1Yo5a8$T4NMAZCeEA67m@3eivW-nLqvHDqW?sczE=DEU)fc3I4I|(~M`GEIK@32^*2)&@+tDJ+M_d$AFtvfaj;}<hFBceSYxMDPc`<x4hm6b<wu2>IYYT&m^9Sq!-gCvdDb^&SOYaZx;aaJ-e_(T8(zH!&x)?M~MUK2m)5`TG^)Ax{$}sf{&u&>TJa*?4pPs>E06O*!;3#!<__;UTcR?;DU-%I><NVk?(<Kk07U%e!y3Z4hOi4FA4p6-T8-qe)54t`3?tUbp6qA{Hzher2?!C9+71`d0+nT-U2wufjuor(Fd1JT=9BxVV-hio}P0dguz5Pa{H@#5k9dFC?rr`?H3P*<~%)3$LZL4K^j~Fjq0#39T6-N-k8HZ_>#|LGLqJ<}effj(N>nAGi#%`2e_UX%ncK6r3r*C0#`?mmB`9)$q-ZYJTz{9A7^#ZQ4)ySVnYkuQlP{d43pyW{MR`MRRek1T(650)f=}8Vh1~wuGKIMn5ccaEJu1xhTFiYP}i((t>V<yoeDe@h3B<3uOHb$@zb}&&*mtO@45ZK0v+W7>t@FnoS=qYhCidQXgS%iE<mgQ`WMk6BaC+17l^lJrmg4>fP`<{Zj|KH|S_ChRH(xEdE*+9bT=7e)JfLa18JsGBEkuw`+K$(0BX1?*R6PFQ!$bbH88B4v#8uH*m`&ZVG!Ca+2!hqh5rKULu;nXLESsD>Z;(SxHi8RY#7lIU_MWEDiHH+MBO<sfBguC(iMaV@cRb75h(Bx<+FBq;VjJ~jp%&TnKC=NkdBdtpgTpDL0)%h;8VgsOY$8o)+jbu!8cphxDR-((eji>~bPsVlGk?|z-^Ff7(jY+*&>~%(pNNKwJlX0fn_W1ZmzRBPw(4k>>5z`z><2}5LW<tge8TMTE`>mFtoT2K=`>pQ+Gy*JeX<~Fu@arOQp@0|DtR^DH)!vl34sjE>kdz`>*<E(&xh;?Jpp5{!1G7M>#s~)lZt5F3o9f{D6TG40BgHodBf~N-pp;;0Ohp<$Jq*YQ@gVm>zQd`2pqT!-)llOXKTKtEr1r+mhg0X}(Sw*vhS^~?;kM>=PHVu)ASRFjY{asjR@^EWxEnXOYbp|q`SOW*#M3jcQBWYbb!5~(+FvoHYH)ZUBW2|`JD-f|lctq9Qi(s$X6GiM+<UokOQLTz<YsV7PpELVfCXoMiVxAr%8hoC&600-l9_KjX368E@qwgKI&-H#(EUk*rGK@1eh%Yv2T}SC8`P1ytzZ<4w(l*9tB#am$l)y8B}UwbE<ZmRVS{9;+&>!GV8^iIT({o|L#LM_WfzX(Y4T~ObNu4S#~!6riAMxcm8YQLzA%i$Z>RtxY31dK-HrP0kA!2|IdOT@BSuYPw0De-VmO2oErgbdqhr_Aa5RW(`<FzY?IjrZw?iiB@SLY-QicZy>ihSaD?UEs!yQTY&=O^=7LSOG+tPktZ;a%Tjn+xiXqM7*XDD%TEBYpHo=x(lZuTQ`SQVno=_rfhDcE=h!NkDLiTWVfFcZNTaf0vqFQc&DrbR4Cxf*Vsl*44Nc-b|?bMkVY*N1{D8;{Z=7D<2(R3p`}sK*ynAq|qsmftA30V5+A^dl2gtDo=VSg1d>i%*l~ighVFLyi|;1EZ&%F@r-m!7wT;^snvWn=CUE*28$WCAq}AlthgYLkC+&CM7@XXA|nA393Zcg7h{*wrLZL?m?|0>bg(XO;KYt#sA_H)`7GOy&&Kn3M1Q_Ri8Sn1}^Z>93fX#+mS?FmW$*X`x30{LVTe)0=gxnx2QHkT?eoCti_(0*=s$(cB*ojUuT9s{U&AMa5%W+>dwtzUaRherY!>Pv}n4j8*LHtVhFR&E-Yd#*G?VV7e$>2Wr+DwScLwNH}jjjmfuWdapihEH@BADeB;EtKY^8K#KT{Hf10O!7JvUOH=55=K$e|AzFETO5o=0zi|r@*8i5fP#$8vhy*P0W`J18oovoj3afT`p^{wmAQ!}I`!HMQu7Sv@4RO6OlF~Y96$i)LI(Ih!Sqr;hMp1%v`|DNm1gD4MrN-2C-rDKYINbyQ~eA2+LBkXBdyIS?F54}^)K*K~RSdaN^01v-U9E?+Znh^$^lL@0{X=dj*+$ULS?sNgvaypvRFh6Xevh-pS>R<3<oF%11S$^ro2go+ykR1hry$hl;XyP&UPnld4&f|NIrrmE`C~bcoKU1y?h=5yw3N|=Ru=`uYTv~@uXH(oTIpxEq0?e@bIC@4h8t2YLiREoMqJ$$5Lw4&3v;{7ehrrP6<EduOc~u+2C`()sn)*gy>Q|6?kl?Sx!Wc{SljQkYdSh;GL4%6AT?lKuI;iTuc;z<0FZ>9>PReOEt&L#~k0vynYP6Mdu+{#g#t~TFxj(7kh`<Yq+rR%4mEI29(%Yu)*1xQ~J%hR|nVIPs8&`e<cKr8QO<R)barW})dPC_TScKr`6u7;=>3%2?)gaA2O#8+EbPVzN4d{UnT<!5Nsp5B{^LgB-@jv*m1pM{w?map95>!x`zVS4C+v@NH{5VPY{kqk0Gy86>j$jEm76IkpA0l$prolLde3^jvuc(L5%*QPm&$l`sIpi%a<J6ttPvhF?XZt6u$kJH<Dc6Fi04j}#?v!QUXw~{aeaMrJkKJj(b!xvDIyoMwSr$+K@>egkElei1g|-8O@#IyuooRF?Ekv!vmhm)@GCg1yKX23!T0yPeCQrAhD^*{6qAd+^R5O+PL0U(FB<?9B(33KT$}~gSbmU>k9$A1p!KZ1`+LA$G>n)14Viq1qW<5*C#BQY$Z)#qWvBLP8ZKE`+rVXd8h`$KuO;lxW`WMPcie<7`=B~Jk>n>Q9D`7tQ*hF*VAhqo;e)3-BRg5}(utLQAHRK_(9+$+Wtq*w&FPe~BZHSF9gvX_(dH1NG^!>sRHQU~88jM8>5gc(_Z96`S8%@PT_w2llKdBbMa`86!94Tp+E+y^8!4)Fv_A!5|5H$SJ4-(+~`H+9Elg|mnQgip&*gYM%7*SX?pImfvbgYZZ!_tj_xm=Cn$PT~O+LU1&wUtH!kP6d0+%_p|(*G~9$cZDd$(se2{736Fe1@oRw-Av~W(wwss@&y0i|B~`p!*_S0K!Y85hm7diqBK`9e#?%6{P|@nSqq!M`M=8(nB3YqMLVGDe|foff>ljM9X%8MkL|sO@mf>Z=_~Q)=e%aBsZ{R-`fxVJ!6?eTK2bv7ux3iXAt;eLeI>9%sc9GpckpVZ?<?CIn=}-lIjt7-{h`sN#1SxKIU<CbCbk`NgJmoUCLVpnRHeh7Oq8$047UZElv6@zGkaFfofV%heR<=bYHgMc5=<BjU9|)zlom(cQOicP|~%U0AIW2o;4Bw#pZ-8w%OB;D9rjhlA+8ai^ae}C6v)agWgW&f&%_e6^_apIS0aacx_RZY1?bN^<Njw{<v$O)IUB2ucO{5g?_)DDYs`qinZHAt>PMrL1J@`GD%ru&zso?S>uBqO$yD6=CuozpH%iUMEmZyy`7UgUmrGCwLVbSLg_Z=^rBWU$rNN@vHjIVWn;L$lV+-w45-?*Ux#SpT;-kX`=71aM<bYyeG}}hy493iG6faa6+tnazS8Jm6lRTCemj(X8b#|T&Q~4B@XvR@8Okq^%Pz_4AEOrB@9dM%x7Nl;p=~vyUbtRMb^}d-{x0{)gr%`NFI{q{&!mEBPfa~7(~~Um5`8gQZ-?Zw(cC9)H(zvgFo3a>OG=xpbwD*??_pYSOLzx(E%ZI<*$yhZ&|YZ5`7_1sbImM5F;VgqOb@%pvNgHKTJU)?g_yTAFVsn3H`m3tjD>NL=S)mO=Jp-lGIr?;@gWP`UWTkXX$t$W^jO)BQL%D3S-A`qmZiuvAk5VEIUW!t$_8@zlh@{h-!Zjz#7fa__B2q1`eCDY05f$Ns&wgo6XUv0P+jZ#V<=e_Y^b~#$Bt93U=`DIfZ#(vM-e6Jt)2O&dZDMncgYIAWO!++En|tNU1x52(TcvNbkjjt+?Nk&L||M$Fu&0LqPzx~Xt8B?QFnvhq7tEEp6aFWj%|l%#)T?sTSJ72mFYT#_Jd7AsU+B(j9u>&a<*oQ|H)5fzxVE^RuG+p#<I5B@_604_2upNqh3W*3ZwyjM~BRS;3V=>|Cx{OEmJ1%qf*<eD0!Rz_vOR15c@h)pf0wJm;nVCTR)k5%^Ebj%lnITwwJ3;G8@63N$vY}qtm8`oP(K+c-zr3*Bu*<GUkZpu#4QMv|=v3p%-q55=fl5p{Hm)<V)PJmvoEiyY#DSV(K-mZ}gK{@L4YXtu_|#QsRsE7#9;&+UwF%&sYXFEC19tnczOK4E`d!9bU<9ff7h2jX8UE+cV#}N^p@kjfVG_t=I;6R+GXROa+nRIP^=Q-zG7>Dk9(|h(x8W5*d=HrVKkh=+G&Oj22^U64pZWh#~1OF(g*DApT@n#j&ER0$t~|3DNnhf8Bsg+_=Cc(_(wCsCOZ-M1Bh#n|@(+oJ-0pyZHkrSr>$3F5;-5&zAr9brmRIiY?>hZ}74sb@a*&QB-PnZxCiaG@2{?SWLGEXfw-V-h(+~7ur{Zqj#{Se`kiesCTRov`4iUQMhNc>Oi!!fM|tdq`-WxH+^MPbp=X$mN9t30k16$dm&7;J5Vd$R8u#S@<$1IyR%bCj#~4&Rs*hy(FM>oq=JMwG4G8zI+TsW;nb~w`E1?-7Yj!!uei%28r%5FCkWvNS_<u4_1lD2uK~VMorQ;u_P0r|_BB~wVQ_aBFgV$4eR_}ix7}}cP1*4mI3mxXCiP$IYrjeRcj&?QDL+5ZKuNvafPQ~I#=4aKFx3mf!u9SO_+nFM!KXM&oG(cFHNMS^QBCoc$T~JL28RNuqF-<Q59_mp|E%FkkFsa!tn_)HH7$Ia?^q9T$?1CVcPL#BTODWW^}<~}SjXNB8=?r37$vCgJ;3%vk#oL-TZ`TZnzD5fxCe`(C;9^L1$OMXCuI7SbTTyqUiSa)-XqXCZXU?UG<%dEbMBXn{9ph_26ULa&J>|vFij(6lBt?*j?%CzZ2h$+^5{iIbte|yq(w~>>kLwMIa+lB4z1ZFGK;|gJEO*`zfn}NvD!}Nwu4<|Bjvr777uJh)5X^4hO7v<qGEP!$EIB-L%UAkDog(^K2g^SE?2)_kCdEv6TXb889xV;fD9%LDetK(XJ|Xjvp2I?zCOm^wDTlf-(MVmb$)oV^p|IAowFwQ-MPbIw50v|({0Mi;qppCE3(8FuWE1Suf2G81q+uS@Y-rFya?~==lQ!nLXCFEO_*AYLhr9qw1~j2rE7yg9yE0hb=Nzs0<$@^D4k0QZKi@r-D5lw$O7%=zFCA1jLF)ZFwsO4m@QIUrSoA1*Fy%v(2p)|Hpxtp;kRM1JGbP<?&SO}6UPhgZ%)nqP9_H@YM+KA`}%0$kNs-%jYLxFhJLoi%-*_(&XFFRf3ti^`3#q2ONDt9N58N{tAr3%x!ULrj${whHRj`LdYr6-6S~lnzpx!3$@yw*qlI-guj02+MK&+uMZ*Cr2JKcs*Y|&S8QZdI&*JCkb1t+?GO$+j*xjx%nh++^c_j|)uX-^vgvfBaUi)V>o%R@3=g}a4@yk`At!?Y1u`jiZe1UPxO<^&jS;=4CgsZG-qYDs(x^|QL$Uu2)>zv<tf2_^3a>HnJXnVNwDOQ~phow<uyFYfJKmVRxZ9$lkQhxJbw&})8see+Wk)V|O*txa(199!BT+!1m#_!ja`7yGkiYdD=ToK+9@#O&!mKv+nGdw&<z?R~XW?zS(b9^*2*SF?uMGW*Q3UiaKw+`ipck35!d=16+7r*?FFWk=cp9JW=V-NV<SNq}<en*+#cU;3C?vk*hi?6&jOIcV_IoF%_lupEA09tfHl#&NRTbAxk7vEAQ0+HVT{I%SSzSLw!<)wio%nk6mFG0;<09kGpN_qx>^9J2A;#7TWEe3cvgG@$S-u`9ZKdq9@{jw_0vl+<BNHmadW_P|OVl*xY3}A?T%aTkGR|iW>VK0iZ#lTz?nMw5Ov?l>jqLUkQvZ4t~R+xtaD>55Ck9qYz^MqkQ8)tM~teI|dXrg76MaZb=g$iW}rhs-<586{vwl_-|d8ML?r230|VVG7VEd=*uq<K_hk0z9wPGX0X-QYWcW(FWNlS<*yAT>WZ3ebP|b;oA2HMuvw_)FKVaa+OLkziHKxE2nn`O?#*U$b^Rv1uKi7?U|QZv=$5DJdpB+CG_*A<Lp*Yt7#zylT9qI$o52TK&f$LW$a2kv%mLxaAz_b|=x<Az&efHFu|_GtIeWRiBMgUssPw2Qzni^u|hWA6CNbs80uvg`ccsXAP04bQoR-amVUdSyX944EM<4)?X#!L2cO8for^U;Hry6DmNUsz6B=Q54S4h2GER`M$<z`k5*2G9Xe5prWozA<Ei9)r<SY?p1B+M=0{y0(C*G32<O|bRXT%k>;hl5YDh>f1{GTD6U{KgA{xUm$hgXsk=D>d-Smdw+~8d506YW;$YgJVxd=GTd9xa@w{#&0JZ+)P68!wO$}2Tu$Jmet>kG@~!Yp-3tKgC*#9*Lq*|>PSk6A+U%H-$?YOuS57nZ;TFjzb_tVwCtG|fwh@)j7a0%@Csj#;Fco;q6<_|Kx;%xr}ez+&EiriL0nOBpak#aI`x(Nf}UX5B6mWY?4Ye%b(|TzdNgV5^v~g%#J8b~FX5#!M7ELe?XS^>TyocJbn=c}>mI!maK{3lD=|UT6`bwIX}+ooS91!Y12y@u2pq?GJBxx53jK9r>l~;oq(6e(3}JV6#=c;2{8zM*eO9@dQ|r3014QXcGU>iRfF0(@=n&1D+YgOHaB+ce+)+lmP`xTuc|k2hvW9Ccb?%Mo0bK=fVW;SgjZ7hrd5+MXPs;m%kV&8waPmRW74fk%WK!8T~cz%30^87K+$><cNz*GLch(m_}X=`0FotHfufMv7@apfubN?2sMC<tQp{)GX%5G+Blhw2kvS>^w;YE)saT~YrWhNf8`4!={C}z?^)S$GrefINi>K=Jf-J~$!<)-b4E*a!SWm}3`5qs6aC+G$nsxYS!9QA%(=`l)g74NO?G22wXCadoq21DE&86G-9$!NYuiohUcZqxaJuKXrJ1qLm_WU_+~3VNBzhRQ?(#qjsW9I`;~?A4J`h!i?V-cYn7tw{lPT3DAuAvno7Ll61RCVG5o~mTvR@|_b8pn$2j5JonG`e4S|chltlY=<_HxvrnatDGTrZ++^sPx({}ngZX4hYdWKcnyUYMPo>vjD%|3A-FI69QBjGrJ^u|$Q|bHblyOH_u-L?zI0Ym=y~W2B`hapMGRDN6lNvyGQWW+JHeDmj@gCn<%_;Y2x#xmOhN_3_YKi8*>ULVc?6aG8yy%WP!WW+P}@kuJzJ=qH_x{D;@0?~5?Lxxsl|dcsJazl@(AZ@_G?m!$Hcev0qhOfjvC(Iti;NQV+*ZMa4c;8R|((d96n!#ksb(f=u6l$mtJ6lrHh>(l^;Oo9fisggbU&1*H5$jL+^^lGmtMwg3jGDVpzdS$SJGb0~Us8U!{^VP;mW7(Sp@UU06CozZsGrbjdQAw&pv#yN2kOcLkjaJs2H!D=#Rk5Ay%~x>8ASh2TcV%Uo)~x^ZbtmU%!!U*-!$oK=8kk@?<@rEncMTs-251w^a**Fn;S7|}#{jC)x#T^UF!tw>AB_u^dO*|^4g?rC3R}?gfVXFMHj>q`rz1-Ra$6(mc64e_A)pZ$+b3Y@!7AZCPg1<jfcLF){5hhp_VA$YF`9OnTflTgpXb2JT92qC_irRK=68Cjp&8y{7hEZgV_X=cbjIH%_p}i<zP`oOWkqV~G5$?FzE{KC3v*$%aWny+WtH&$H$D*5HPghV533r^c*o%8!CGij(z}J8i=)7MBv<+HO_a6(=nq^dY)TB&4x-|!xnf1}WL0hK#jFYylhaTga-=Ue(^wv`>w3wG>WwDgx?tSR1M1Uw?&%2|Jg@Qd*CT(dIo7XLXVd6VtcG<besA#VHKGG)zy&G9^+Wvm(Z`g95b+?hU>BR4!{$SYyPV^BXYZ2ul4Uj&xE|Wj?!Xj(fGwmWSv9KC1jfUWx9ZogpWa(rLIuXb_nuXN=dOPOENy%P7|vq|%R^e|cby)S8lZJvm%M%v|CV}H%DVOU;!!N(qVNFVYu?1(f1VF`wk!-|8t9ib!w8Sou&FQnl_xxnqoIVM(Xu?@um?Wg?;(a;&ByemUeS?Tce1=78HZb6qZx!gbC!}p1D)9XV8DsVQVFb<;iPdSW3Pm=IzzN0t&Zve_Js}^^b32I+s_>(W9o<ce)!-<bYvrXNvISrdjd&2=;mZW!9TOK$-2<mp`-rEmlSyy2Wvtx)&aI@v_2uT&9FA1*iRne1)V-84@6aio*vr<c#;-p*7umBH?|5Q?sTg`-DiUoXrsuj{V}L*L;y&XwvPHWabv4xsq8q!74X>3&viIjPbxOoNEP&w1fXPq#RhXy2%W9ty~5$5HQkEaFRBUTZRCsQ_SU023L`F|VFPI=vo_N^CbL0|mreD{UecyBrC2JieR97cdaZTQH;wnSJ&8BGt~=PV0lc=&=V(2(6IX}ny2mGZ&a`&rR3eF+{#}0YlJ?-NGScAa*1Dg)z|q>~VO2NcJd0^G`_T*hLiB=B^nUtU3h_ZwCnA+NVV3<6!$$!=7OJ3*4)u7x4f5z4$b)vdvICc>NCP)m-6m~jgU_ux6_#w+sat4|^%Li`4u6Mhybk{8xg_OimA7;OjM&`f701vI4sHw0Xw)cLDXe3*k>Q2^SlUc-)AWrhyL;@J3ZGa>PAJ(7#%*D0b!~J?0kQW!fo=j#R)5ssP?Z(xVXwNfRP8P<pw(34izC;8+>jqqr;j&)Birw-JZnAwo0H?J8-E1~xd}jVkH*{@?Cr9*pY8%a;_u5WV)-4*n|3U*#&0xnpIPN8oAkZgxYPrZXk^%4Db;KIMU-snwnXq(OXBM<r)?6CAnQey=k+`ucx6lFIW3Z$SF^aro4OAYbfB~eKnn(oTT`vh#8!%I0V0WSNoiMbxHd}lGDwfoSDgUVmdke7<neH_mkTQ&*c_#Pz=WPjQx@VT8v~Nn98^0E?Ak%^%Q`&-JC^_*fyrAt5R+o8^0+})?zZU4vZ?rpJH+XJASmTq@AQOEBdEH&Oz|n7@EV`CX#}+7UcwGn3aWV&nU-;SY(vjFiC0GJtTgJMsxgM#6khV$;ue6UkWV|h(RwbbGGZO*75Tb?Y9^l}lg5Ld^D6a}^0}3Ygw^3oFy2yB<wGq5?qv6ODJECHYJ<o#@<<8inx$eaaEv4)7o`4Wk?>#pYE+-JrTSbZhDC{CBl(>DA=7`fP>p91;U|M{fy(ayl21+97lq6{7KM{umB>-4S@;|!4kzjhvVf7S9?^&D!i2(OJX5JLvW5<3$r#@<CG6Gp_bbUd3B_05P94=}RZ?eZ7uOJ%-mEVMX7G$R!yFqF2cNNK4&R?cHlc7StE^`}@ba1<8?J$U#V;lta7M9@#nKYTUC5piW}}0yRH*Mlp$4;Qlm!nnnA|QyQtfqV+lLQo4}2I1;AV%Q3u+Qf?`;worRU2!1pT%{0Fvd}B-n6!T$Q55A;nrz;|&ChHxEEie2EVrGk&X%{G}}fD;sx`d@QoM&#jlh&8xK&RHP8hDq4p#HKmyD3gSWx!3N(_bZ0o#pGb}{2W`*|STpKOrK=c{02q7r9?ZokutT^ont!Dg@mdVB{v1>wNmiL?yHC%CpvA%z<lOFA<rX90<<4bIi*FsE@Q-}C8sn9g4U5xg{atF=U><DcY<g2d%D1c0ms?fr&U+v1uDvK!{m71(t0fzhzt``3lG?D*P@6^pkwk~6@^E$oGcf!%Di1lSIzquhg*-cKPl$0&knnyaiKMP*`QDFw0$S>gbQMutg_ej#D3o*_5duk(6c2XXvzA==csV-4zm7XidOE1SlvC8@1@u-qpx@BKUN=7TdrkMg;Ic*DBc4V9tRLCXOrZY`p{to-%Uip%z#D~x=imhlrjt+Z;>5~M?-0lG;`jN)OUg!|NKO;XW&&lgn!eJ5PQ@tw(QA6$#y4tne0i_}GykgIaZFFw$J+@XU;KXJ@q^Q%c#>p1evZeJowLu;t*PKK&cstBFBw@veNd$%I|i@yPn7+ayKo}$<g5nvk$h1@1)wMv{}gbn)LE#*dZ$eN8Fke9aF&KXhiG{wKM${sRCvu9Q_B}n!3(-Pu1OM^%e-5(lp=+ax{wn-Tu(`oTr9EfNwdRHhK!HNjnq%Pld=#C8`(3k#IYNh7R%9NkhfSN+%?)UAZ=?;k(7b?!3&K80?1&bK;?WUcOV9gnDSWXS%ikHuUPad9pEG!FI4Btk^#$VEs9Q$+?yOu{i%jMB9(N81=l+gPgGZdVz;sViPSSlWLRlT|5V&*JwxK(i}Qjb{Q?k`xY%W)z<<vrBW5#U3;a-sMgQ8j=lW3>7G?n~_jB@psq2SZe&C3&=K6toSj5v&j*v|TclG`-5n$9*Q9>q&=w&n^1$)M_NEVtXWQ!msb3wCPo};vmKO}Y#L9p&b9y0J&)SqV6V3Pt9N-<>9k+_Z*K+h+Wcr;#XOiEIs1YhC_wm(-+AL+vBLu@ph`Qcl4`uKa-yyj<KZ#>se@PvK|p5(#=XHO7SLPdSd6wjR?D_b|-?~L)ZtMLm2NM~-d;*p;_Q|T2Mdqz($J`6bWn7c=m)#CHmJ@-Lb&&ZnaGRB7;7Tf349ry9)riST?Z?y>D*`p#PmcqgHRrRl9HyvqQc#o3DgZG<iG%=mx;!=#}a~HzHgpJ^hIJ9tsq43>F#(ACTcy$IBynZJC>4z1gUYYIE85rJMjOt&=&KKqs$*IAwN!~HJxZU5+^{qEkeXT^%AItjtYP2B6T7gG3wCb@DFcjbB4&LHdz7RpA8bGJMHOX7PAW^$wy<{s)ju+S?_4?T255^iM@Tl*p4nTOo15LOl%MK%f#SDws9$d*M4c^!!U^n(vyU{ZOHi^sFIdR+=rR2nW*greHNBGT`9sk`L()U|Y`b)zWbpJo^{*JFw*zfU@QBpAm#&AlfEWe8Fg~8cEp%{>^-ZMl^>{!avN{J#NW?qHPUQ16V!yzec$#zH=C^pI^2V8O)A&*^xI!IBv^=w-$g#ItVaHHd7eb5UbA8yq_5{p*Mr#yi*Ok6RVL4y>v$sxmsj()(^53NSMp&U7Gc_VHlhP>UbWPP?q2Ms1xZBatJ5IIuO-tW1!-Cn&OyN9c?(dIJrNuw42Z+wun9v?4smA1wFu(C|s8LVsK|Gd&<(r?nr7;6`Bakf<)>c%z1&3R(G?VDQ>@{9MnXrQ(6{NldFSEQt_F59m5^0jFz7WLwWch=zw?U|+<XI^Eo*1_Xn!d`xGBOH6?B_lggXNX*pekOOE=(?~s+)^91C7EJ}q_Wslph~_^bW@7=k1II9VP`Mz3H%?Uoq?Mzq0Xx61_BSwsm92n3h(o1O}6AJiIMu;+11fBxPq$-Wp5a(iyuWX&0&2$>(D3lg<~W+GR1{EZ!o@N*z}I_MhGl!x^tWHxUwaqF-7C6Ye4&f6MobGR2Flw-n5~y8T~JY)#jHj-@i8W)*fB(_OMOR*ttw(`_J43Zmws}UyX*1U_t9b-7IcazIZuT!i#GlL7p>G>G5_^2`0xB!^J8XoB2U*9Q?IM9x0<_vplxNl18|clRYIPzWTfKYZa2iR?PRs{<Qor7IS?k#Cz;0@4gf`S-+!(65dhz;T-@*;T^*t@+$FNKU+aW&J6?)*PVRA3&T?nH#+NBv(WGkNe|4w&heV7336sMt`lW?LO)4e_&N@+hs~pzk-RHXNs9}wlRgM3?}H8lWt&K%(WutAB{C!FT@#D*G0v21+9!P|lxaE95dbt^<GwM!ST;JD2pQ9HiJV1>0e7r1D{H3|KKp^x&7!ZUu-_*xgzvQ8pkd@cQBU8lpQb4maZsG@%-8N2tLOl`ywP@d#UiIH2wDR-5y!alyb!*`ozZs_InEoB7hXFO5_Kn_ntlI-xz*&(pU)vay*@%)0ab(a8CsI>IEUXc<bRjUuBQ#s#F2>H;4Wx*0>I2y9q}rTP-c$rN;t5S)~{m|b8|C1)nmXp&uTNg9GigxfE@^D?}{nt+Sm+c#PSX!lo#eLo_C#OcG#{H%!53^Is;}1h=dczX6D#5kDHiOx*Dj(pi!Cm<T-xv(XgcTWL=>ItD%4q^bV9&%NZh6h4H?1<i5+GENbW-^;z(abiE^?ZjNzB)8G>P-byy8qx|U#>ZoUkP_V^p!$*79&W3x45!l<ryHv%AeDv_MP<a6D8-ZjOE|?D)PPuY+i&TS9?paSe8lX=R5sSw@Y&C?pqc2=NwGaDKzWh`9`ypxeOV;EJF66sxmCRzzk}z7!Q<uI&T|wTw0?%B>^4y1Aw!lMo4^%x$OZKu88M(LYki^y3P7~7AdQKS+&>4%K#z$x&*ZZ_caFNPqNkap~kQyc-8ksZhE=Ho&_jzPpQx0*QvBo`&TrqdBvpS<2i6&;vdmiej*<&zHE)p>iC0(x*>fuWm=r~p%U>TX}CWGslsOWhWKTWHq7OiEvcznbQmw%!AS1@yyeaZ`z^kq6zKa`2#o>Cmv+ssZ!ich@R5m2K8H>3Fg^ke)C&J&2+9=db%ay)CzBb!nAATNs`;uKd%L{t6Jxgrj7Q<mdWcwoNHi;Ym{B1m@^7W8P$x|8#e+3KA&S=9zm5kwwgc<aZ|GU+pKZe8;1%q+XyJ8ryx6dp1t<-7AE6OQ54-iPPZ*{kZbdUTa?7iF+cLw&`gqg_z?;m1GXR13YfPu{w$C(S1S21eeuXrc^OGeQphcWa^UfB6I07xnvR)W-{r{LR<iL36d<Ap{6@?VS-xpA!mAsCv!5^K)dQ+<32HtsV-};c3ratT{=ut$)Xn&9_+A!Oe1JeN`RYy^2@H)u;bL9QT36uJ}0BV@%5eie`6MxCS;j&XV}N3w0@;?yYR`AS1B38%wA=Lb$hUQw3M!m>Ej{x3KtkV5j{pGm*^iPxydp%hw|p(Jo|+IiN0FuMVT9M-8K=<7G{A%3xioKB`g}Sgj8APh)STh%>q(`I$=n1Ut|LL<pZl&7^1`$k{hTP1alR2Ua+kRpbE|Q#ZrYzODm!A#~GcG9{vE!&CV&u=fU6kxcd8o)xEAj=>CgBJmn0K^>orko4KfB&~G6kL?-?Vn>RRQg?*szk3$y3GtTBP+xK{$n7k*^uR6?OQEGDdIS+r?iJCbCI*$sRbh{R8INcV(}4x#XLbjEg*D`!<5-If`+`X&hP-~EtbJg^V*RDb(NVk2(ieQ+QCxcLeu)cVFlBJ{{E;oz+g9YpLl=fD85vbHoc9|I$j8kg_&<fDELO(fv9K4?rr;8S<K2Ye5fN6kCLS=FF`4Cdxg}~bn-&*WBxW;%F~nkFRkCc%h@b^a4%;cOaNnN5iK6mHq7s~3iMsqN4_LAibDPg;BOQ*|D@X{(+NpWL%j@p=E(cx7=nifUt2S3<>ftC$%Pwk7_N82daLuV}9%OPxVsNjvMbo%FS*1*_MA!$YDZvva^KLUDqM>kxI->vVHV(+|jRVvdD8v#1Lr4=1VAGB+l%7nFyuZVs+r|X_M3QsQ78BP@nN=<cIZYuE9__5WW=<tg>6j3<@r-y?;V6rWSOcd$NGQILa*3X>ejYR716)!2ixriaNG_+?!h4v0>_@Ce_iUHe(>}0yFu;i*p6mQSP>lMds5LxcfelZIEl*LeIhm&^p8M`hCH7rib-h7Ur_rv7MRNOkrv=}fsMsdj1v%`D;dcQL<ZbxaWcy72qW31-EsyE%m}3XHRWP9TJSMQa5wA1tnYrPOWIJp+9rc*$^@K*Ir294BK2w`qcFH%>8oyem-^{&Pyr|m|P$n?kpti0j+s(AI=gP5|_pVvwm@+B{@)DJi2u8K0I3qi+ixt@d1(`&sjB?(guQrNZy)W1LWzBewN{RFm{_@C^SSr9w8*6K!#|S-d1X|w_U??dp9$5z|-t^J+xw0v>H4|t~P^Eob<YiHW?mt5k%aA&$Q!rJE5H^qAbC3drU8*H#_SXEp#oKHC#2|a7PWNJ(tN6jXtx!XHVLDDd8<;WWmSdqHxz4AZbU=TCQ|kZuO2sR$3vfkyZ8D`hM;*cy+b0vihO7$^=-p-#*TLH}DUr^LfOUM|G^&Y-2HoP3`9cBxWB8J36w<bYWtwuBPq18iQ5p!wRA0<G7x*hf8v8Vg+i3(JSDO~SBUvZSq|Vf_HQZ|IT{j+83Zno1wRxjr`MrqiH3OOW*2OD_9OmcFTbe*<<5st6F_|JvP!b+^4}o(C$^1A_J3wG_V=6@ZKDhO7yf-wJh=A`<!C5^iADX4CK@R>u_TJ@Jnr=T2s&%PrS6_DT-h20V@j0JQj;&*k9gG8!CBA<FiD4#O!~iKHn8Z#HIF3jNBE*1fFviA_LV_8A7?A%U5)w!-fe=OkSwcYqAte(ANUZ01e!o>!y?ejk`+ipo&a16gy?a+zRadQA>vwrB$#im??`|QP!Z%j3U9zwbtk=%pO1-vwyI$M9U9VMi5w)eq&3m>Sgov*y4I}Gg49g|AzqAomsAn&KyP}Y@I@@}H9kwiyD)#))6(x9+^oeJiX_BnEe$LBsGT3s`oCD|!<({3ADFsAdDncFg0h|M~%JHx_@f;{l`05d9Oxou2>T^BAs0((Es7Y{z;Igz^VQ`V{w$M_RdBkm?#q!3t6J^c+;3oy+4=Wh6yY{MPY>FlnTD%ikdGYvFa1}{$GL;Ejhn7Lj=LEO(?_L|qWjR?K70?pJ`02P*u#uZ`=aOI~x02%2h?`oTl~eh+yHF$-8yo#s6+lo8oU#2e!=pk<W-XPG7B6Bl#NZ2THS4CfI`r_(OnUK6S%Hz0?|O`TQ)Dwp!{*m7@ux8S=B?cP4``w@an9JI8D8SZb0kmlkmrf*@l@t<vl-uIDagCb>jkQbSmNCS18H~*1XiC=?CDe)7(k@iL2buG=(6Eq<9s2}TbL>BWCBX?#VGi~XM!JcDX$+uwwaB)AB?XsX8|3Zw^I^-`_yxkA$K+t-l(`G8>NR}VtHw(I`tzJwo%+c^?zr4h>-S9#Zf+KYSQt0=SIXUr%eQN%#)6nz8A{^bGDs8FhEistXG}ohR}<_OV*w0a1Sz|v8FUu!T&=AY=Au<I0wEER(%cO%D|z|^AW?lT(fK5l$1;@vJd&EOul7cG5Ngm-Ra;+9Tt3uq#sowX59wsri8}272L|ddY~PkKAy6_sP@&qYG%iQ80^g3|9aHTJFYQ;l8aR@)%@&K$ts(^Y%t)7Y9&y<CeZ6NoDr<i7tFl__|v#jM^4QmmK;}qBGQ^Rlvc`Gz*GUrBx+H~-${g*N$8<GOb^V^5_NELlI$U2RNSVF+ja|&krtcns=f#kYq4KPv+>S{ek;>Oq_wbs$=H4b>Jee7>yIZlL-j^}htihLgxMw9bX{CUkX1B-Epz=}jKC;$Qu7W+-;O3lwwY=AXG)0J|K%r{pk@2Jw!D7C1>pQ1#s0dsYGG}+$jk@2So%t8wf|)$eYK3T&^gkFsIH;T?c&O~3lkyw-WH$))1DByv`U$LSsb!K>-UK4L<fFzK}5B=W$CNDezg<|Fas4=u7Ik9Pr;2~%JSE<Wm-=DNVPCN1Y-N)8O@YiH;u-SUE2~F4n-v=Cgwe|EHz8bfK1KOGG(7nrkm7n?U%Avw7oenJ!E{_OhZLryZ@6Lq4087vlLQym@ZQgRbnOe&xNMk<oMIHw1-eCYov9~st~W_uRBHx1pjsvyX+}thZVjo-E$nks|hFL5P*k6+)gv-V&r%jxIJk)6Q2#k6eeq6MH<RNkqsW9u_IC8SO$WW(RLwK4y*(P29Eo|>ZRom`w~^RfIyT*kX}PXoQ)L+wD>kcV3u%O3I_+7$eK<8*?ArPI7ZTnf*X3GKY+lDg&b&=y7?w^m|%`im^nBXVnOQ7z_Cmi(ZwB1p|yl&2VU(wyICjO2Vy9dEM@4C%fK2CeHDE7@mD?oss4jzoWo%zY`R0VpFRbWyeAv9q#oTamgA!fmB7Z&1Ng825_py&XdINUAL0eacc3^aMf(R>ftAaACYrrWwb$HS8IRKK8<oe?jMzFGA4-6g6c6!dhUSQa#sehNgJ#S1mOTUR^HX!>J2Mh}+J{mecJ!k}>&l|4_=%reKC|XX%)lpHXOn2t$7D;7Y#hvuF~pnL-4l><Z?2pnKcq7C#bw@(<Umi*yJnk!Y%5dmsPS55%Cqw?s7!eRa*6L<+Vz@L3Y&t|CNJk9yso=S#NRXHSQnvql=m+}J*vCw_1nN^UadfpauI1g&+=1ih?PEC)v0%!%gCxz@~YGQ0xY@~+mza?PU$_EtpL5Jl3suJ9gOiWHqzQoOh7t^<$}D4HW&$cM#!3f0D2b`a}s~3Vfxun+nm;nll63E<7IjxcZ|t~C#+vTEYIHHFh;C+*q~ge7f>kiPD{=1GVP!0W{h{al4prgepGJh$@+X{<C2wrZ@o{}kB$x3Pp(iuDhc8Nnq7GFDo>k@1drPm;V3dtFZ=tLA1|ZnWpl#u%5OBy5|s|NqOn%>$rZ4gm~M?!UR(E6&UEYQ0QsM5{<CoYh!x5!mZ0{L$vnfjl1-Egv%jLs`oNSGIo}nRyj;1{i!lgb)WtsfRaBiT-uxL6La){l{{dfLC<i*5!&mss-M$XoX7=sNHhVEQdE8H=GJ3@w1BZ;;KT&NBBLJk-@Ud@mXpE6u)@u1YOP+YZ{WLZ!!9I9G$oIsVA9c28n~)tZ8^b?s^YG*QDS}?uYddbO2p$nNAubUh<$!WcnO$aC_>OBp3TJ}@$lGI#m-2$zdxvA#^?2ud=XmYRPx6e*9M6X^byx$-GjMn@uT?R3&t>Bj=5l&3NH~v*)-Unn7}TU~(VqwpeRJF|Hmv;*tTg=0<orEXo@Wtmm)dyA_up)b>`B44HsiZi9-%zE?p3Q_AGrRE<qB=qpF0JxoflZ|cNY`d*qx&6a7wSbiwgE5$XI)^fPxdPsI2e-%TX<WMe|(@zVamJ-ekv9zDIWvi2_MZR{2deS0D~yyeS8hLmNErtqH`f2SB;7ESvRV>8HHeX6!h!;`_B3qpfvD;au~&0z`+i%Q^J#SoC%qFrZZ=yr@Q~CF{#|4ea8n`?i<C-R}d}@$&>BepD@Mv&(GSqlTw#B0I7A)jrajx0jYF%@Z$;meYI@eHJ+?#GzV@@t&fut!xDZ=SpzX?nWbxK;DxP9w$)3sz@pC&Vb|2DL&U=xSU>(sD%g|zL*f-&YW5YGZ_bG<r)Zzi^xt$P!G9t8XA9E5)^x-cEsqY?9vYasP#bbVr=$Y;(8M12h@OrOSW1no(<8oNc=(cYFqc}#lUIAkV6i~Ga#3~J_;Pp27q!Q-!}5l{8UON?|^5DiCD{&sto)#hu&Q|_`O2<l@Gw|JS`eOSdS4d6SH#&$>I;(d0=*EL39h-=~yKMY=@U*V(nG1osu?n(3-BTvrz!nXlR|WSzwPs>!cOzaV7}l*xyAyu3){LyqPia?RS6^Um&InU?Un?GX@}JOQGIe*0t~)%1`X+A$?XY^%Uk8EKWN)gCzoRT&1}M^d^uuij_ku%@|N%clGaNciEMOiSCx&B}aJ?yt-VT1h6z=Q0jy_$qUN8T-p<}3J5m%kP_{Aow6%o)9wYsOM;0m8{C<HA4<=&7a6;i#2zJ-$pho)t2wHOTmv;sf=PSX2p1W02266{Z`GMu+L+NfPrXmM^s_-DWi)JCSe!*nSJ609+3~}&`35dCTgf6hjWFNJGFIwRbhkm@(n>3oF?&tFtgOp>#4ktRiLIpwWvjXvZyZof@h}k%le~VNYxx-ISak{9u(f2ILsk9Y3a(}uS_x|Ye{`i;({QOe<!LRR=qixGoc<(oWG4w*5vx!K0UA~8nkh3LqhHn4;%kO3$?9`mHsu#5=$Z;-=Vfvc$VSuVbsp@>-*EN+nt{nEGSayxra%548``*><3B0;a{72?tVBQ?_pnn>6Ma6Ze_N9IPFQ8>VzYvYp)>}AzRt|dBqV%fgGf|)m~(T_Z5UN-MHfXXG>fI6>z(sW0(o2TL^uavhp39rI)M(m$||1rh64lIcn@G}t6)%jF4Ll;IA>bC9AK`81mPIm3x2FxXJ%EaWk~AgC`^yqlFKEe4=gu55Z?@2WS+pO?hx04`|PVpHoh-AX+cN^V0Z~<JtaV{N11c$<I-(wvEl&xYBFxs&;_S@%9MVm?VR)+OZve=VQxQb{vAth%E0@DH$<h(H61R4D@By#0tr$!PcF9x<{*k<TgQWP#s_FB$UR^qgxHq3*Rmhl>y_Z)U?z@L4v`iY$mph(>q>Q1n_38wSAi+1Md4noF#2-K8QH%HvdS3U8xB2B>hVmAbIKD1rg&G-Qknw=Z>TW^7Jnzf8~X_ds~B#C$M&#?OAY}-zEdtw`vt}*ZV!6vjWV-uJp69++oApGR0dqRcx9e|?c)qXSeAsb`?M3lCehryWM<TJW~C1g=E#yCqb9W8<|Gb4C+X6GX7A7;0?hmjViX_Pfnr~*T=OwZRzYRQHA-$^z<dz_5H=o6AQ1o+^bXe$=o*q`yCe)dgbQ$yDD<e=j=ilk@osmQsLf=KmnnnZ${`7mj5H;THTDW4?Gxw;j^bTH;ua}{$L)2K&omQfYcTa?7e|B?kJPtT{}WiYr=<zVo}s4dG(0tgyGVj5p{RQ{N2sfm>dN36B+rSSlgWi~TF%ypPC8qrUsBYjk;b2s*jV@T<Z(nkV9#hh%#`2n`YKM;j1Q=P8Ow;zH!)Vm!#P|L4V23U<&d)H9d)-%(93E4b0e^*M51Ka6dth<PR(My9Zr(uM8_I`4R&*AV%v~u#RQ;!gs!bdQJ-la7tPPjtj3P6tDanwIQvSrgW*7l^l;qPTyJwdVQo_h$jO3+v7YMsC(%3Z2!Bi~y+^ceEMh9d<Tn=Eu_)((Fg(%(qFsprumXvv0@5=HpyHkYDQfn&nwVHzFOL&f+A<lUoxnJXuP6AW!N>^!ERpEdQK0CEzM|~tu`84=GX;pSF+tY$g{VDz);^)`)I^yBWxCDj!icDyu&AJ&J%|y8lMg#18VAmtp*G#DyvZtJG+VPiY6C!tXv4y%l#$_3FYrLDN(-q#DNqLXGl1A-J*Rz1#zc!?*yUd8eE6pGo+jwXVgg&>D(a(mR_5)VKK66tR%7MGzrLxvm8I#rxkY9mf#)stT54X>q_AXyWK5t6T;w$_6Iwj*b(>VM$p_~yQ%ObYJW+23QwSZ+XF6qxb@@kTx_)$$VDUGnMvT|y6XW5<;aSB-Y&kuf5uJ=Bkfa~v3&{|PdpngW`8jnij&v+vWiJ(u_&uHyP5>oj#i}%qGpryBr>YwqSYrmZ8*Ya2XuoFS#gFP1u-jL5&T2IEAQ+zJCj_MBst)|qn2p1m|Ldi*djSYkhU*<&F()RW!y{a1PR;5T?Fbu!bsZK#tQ%<kmZTK_PeeE%6-{J8q5s*a7Z00<j^|74%Rok0EBZ*eP7^oIk}xYT64gYB5;Y$hiWm0MXyOvoMHg$N1XEJ|tBjyjE!(m3%;lEg@f&zgMoL&oo(CTs;e5p;I?Vu6l&Kikrqy?(jMA*6HMuA=_79%`VrP;(2itPJNp#M%(CA^?n2tjEwCr*t3P{<29@xp8B+UlAMn~_GE*mh&%owo-0F%a(r(FkwzLL#jwkm<a4lZ70WK2;fSx&zsu8E>-<({WGngf*SvY@GuB+w^r5@I;gP}>29Ba9Bh%)@n*ejdn!=o_g5VoVH~gfYx#*k;GaWsXKX)3eh51$)S;`xbuiZaHomA)*il)dC0=ofv|iIKoYTy_T05-BFY~dK6lQ@F5F{qNjQZL}4Gbk~xL3Zw}pH%YPN$!z~>x9~^oML^A;(pgxP25i5A1VSbhlWK^&CqG_5;!lY9<H$pVKjHW%&V&zG~g`9vzFK<52Xd?(Dh*-2GW9*nDJc#(>1iS&loqaQO9OGn=vb~Y=#pTM<t=QF$)z0DH_~4oL8CPg}O4KQ1O7fyvD|I%5QQ4v_#80x3kD3Mng*+zZdbH$W2j@9e^OFPeq!8$PeiC>|Vqs<6T+(2npkfzSooc)jI404f>tDCUhVB2Dk3tpml!@L@zG<{6xBh4nnY2LE#dAs~_GOex95g;MOhx#SOl-;=H(V(T3sWi)-l&ftrsXvxyaCg1#Q%s7|4*YqA4B~9>%`2}D%ZIgr<Wx?;}mTYcGZ5W@jMNdW402eDhEsf=bEi)`*M*EVVkx|mXBAuUAJCL%bu#&dk1KkWEX={R@{W78dm9Cl?-lOGPq=P5ody95igG$-Y$hC+ia}uesQ=6bCIQjgyu(1XqeJWypl*=>Q_>y%`(7&&Bj4`_YC_pSpwtA#+?m!riDl9xJ6NqsZQaCn;GHS!_N)ObeAgcszCD$<+)(gAY9uvLa~9h#UV4R6hM-UHn2)EfT&Ws?GfRwV8+rl-YQzEtMR$;&&_wrRxAho_ujk6fHfH+7LS;IK>?kx!UqlHM~&aKQeKszPiiOG%yIlCOnO}}lq!J%F?EaDYJ$5XSD`MNkpYYe0)s^<Co!|F>ehp+TT}Jl{C)-5u~`h9eiuVRq;JjRUSoMCU@+O_-;2b}MKV`O)!x=ab;?IFlrtcuWtCA4*+(B$uO-N3;_edJMs*^YAj2g-xfOdRRF5KhDW>gs$?<`YT`xgwM$9GArR02?|1Y~~BQM=IF$Xa+x}ApH4oNc+boqHRyY_3EhUj=Qy*&+e+i56i8cLfvsQaKfNSI-B5C6)u&k0A_PCZtjqUkkPMwO@Yo0E>DLa{(kKIyEhS?${E#nDBYCf=HK-f(<D=6oxi&yoJ^o4%BT{<CkjTPaePzZX_A;3EnwOUHGf!6!Xk@MdkgvQV9k+-R!gYydD{IL3+Q4HCzLB5#I8X}-p>rRQbJVh#}fkCuKPT-R6vZVHTg1eaL&fIw}go%Li;^rZi3r=Td7;IHXt&W`(%tsv^?9-`I`3d*`0jrDJXSO;zSYQNF^PH2A&rE9`W4ZA;H0jZ=1B=$#{+st-l=tSf@G#woT*g{Mwn>>(HgWL`!1z>=KW01Mca8k`NX5)`=3N7FGz<A5lE##zxyb1y0h$47mF(KkEaYBwLTxFvlV6*Z(#3R;(tniM$nP*it&XMG51mrUXP|$gFtZM|w1rKUqe?UuRna;BF79be`_*S{%P09Y-E}EviIij;ETb?VrsYZs9)NE6!Od`uMyLl%jtOwRW-2E<S&j+$BWX~CG%i&R!ASvcDs`i@w{m}63<@A)CphLx6uvR&pdN?R+h`3%$+4q)L$L?k=wdvR0A?hl6kUqUcB*Bc)Dw?!}W;O96QHen=L&HwaMfMbN{nW~78B)!hdep_MmMzfYLoyc=`Q?q13Xy>jd0s!{J!oL>26l!atnN{od!NXOrWKlkS#jp;lHu*6t)f^dcK24%Sx_d7ln0&RV<TpJ;ujo$=eFkf5hrNa2B+K-;}{(8Sni(OV)2Bq?AYL)9dCa}RAYo`v6*ILn=_ZS<u&pWx<F&eLjkTeU_z!~Uw5tzY0bM7<{N<rDNlIMg12ZZz*rtloJ7q_1vDM&fUF#`c@@cAo0?$tU3ij7#WcE^Id;OrKjwv5l327e!w4;32MZVONoR6Yf;MW!1Z`k!tg-<<8OjdK%r(=l%D)XEqO>M%d6%<kU8au8(I?|MF+OX_vy%@2^Ge%;yOd|01BNIr=}z9FFJE3zHhRY{18)#uABovAOGz2i1q*?4fl%|eUGzIuTA0<tHC&vDM8~|i09Y58dowr3w06=o9Udti=dhJ{j>^>~51ptK9+sUiKAYyN=&%9ZURD9C66&zFCscZDjH%F6iP|^xf>Dv$Y7?h4RMpkEY?fCap*@A4t#PgC^0^j7j-jf(`flrYU!6><P_dN`>*I2`G_1~zr#=M#HCHS_rF+7vVo`S5C?0RVc=eeUpI{@+%<|i|gyCPjuiDBt($CAq^t-UpkKV}5rq}mkv48D?J(qVSvu!Zkk?ei_0*?yHtG|yq@ff=Ab50zZ?uWD(FqdlS?V;$T332AsCh*Iyc3^hI$Rc?L4qlq_lfOnb-mz;5EL4(*?GTr#Fms=Q;tkWaQJZCV!W=Y4uhj#2PM8g=w}2u=7q8DN1bV|VG+T7w0K2Z$<oy#)Pm%HgoU?S9(ag{DdOvtZF!^@kNR|y~<QhT~7Qtm43r{Dlwj-*5DJApcUiy`td8!7D<yI6w-LxbU<iN6fV9PZO)+Q=}X_z^=C)=#!Zt<o@v=9<ZVeNdR6AkuVnh7_0S9tO&Yt-8JDr=O`P|#|qP?)5Zaw6s&-(V>W$)Z)%;inSz%8vxHZIM;o&K03+`j~6_sI{y_V?;<zdS(W*2W|OvTQU9S;2@zC<DH5Y(1c1QbvU8TGr&^IRMMDP@0hF-)%FB_8753_j+k*&{86ej^7wc<e43zeE?Mnd0h!2(CM|3a1KD8RQjN79J_GV}u+&owT6>sLL?&LXiO0wsl=P;WeWqpoz?QOw*QF3OPs8(UbAh<I96Rjl!ArispNvLp_{nh=H%o7Ky(gvuX(sn7=^3CWWdhbI{+y#e-Q=T!3${3cvun2{^+EG@k$wJJ^EaGv-{b1eA7QRZNXL^vT!=@m=}PWI`O6uWVCjTr2inkOe)%DtdgkXC1#fCB&Mv{)2>=Cr%k1O_^x{gmbiiFYsP|Idx!`dfR(Q5@h~tYr8JhKuCnj{9#md>8pF=X?&?srs!+}#a8cXI|`*1{atc;w~la+X)DX`iZA~!zao3iWW?_A8r>_|+BQskgBf7DJwH10o}vfNB<*Xb-oi~ZkO#UGbTh!9Q(_M-dy&HGGArsZ+3mNg@S{DN|pL!aJJQdeH^;U#s(qlY^s^?@La_}*3ZJLN1cyB|_jr;)oCwS>HG+dD<A9n-7CyO^?Z@ZV9|n!l*DCD3I#%sY$e+qzZ{{RXKl;C+@F4!!Z>rC=i=8gY&;D$QyV!NgEfKa|mXtD&oMg$Lr>n?C+Un>c>1>Bi>#5vPfcQk4@Md*Dl@&#saZPUlCo_f8KS&h{LlYIBz57%DdTd{zj<wld!-1Dw-zqZy$*f#(78*b`=!;7?juHh57zf*-#K*o*n%ia%Ka9iP3(9!dorWSWO(1Q&;w%HM66-j$;m4#Em6Wy>R9w;tM1cmgM1mZ(-xIgF0O6%$|iMlxBIIMMKTny)2In=D78eMXw|COgwRVR6GyDc^q;caO=DDPFPo8(7ZhqQ`TBBtW@>WfN(x3X+XH6`lE3noE2nu=C#Vy{xccgD$S!-&b(%uz;{E8)7JBVjO}GnL5qpgPplE;m~2dPht~>So6O6r|o9sF0I}%0aZncLAl}3)Ff_ginF-XM@F&hWG9+=MX1QH+s>{hhKfWC=Ct0A@}NdJOI&usujaW@b@~Z;RbW^pyq$r%!|gTCyqG=n!E(cY{e5ZjPbi}vUerua4^Nce=i)LvCOyen=EN8MYQ>BEWNt2r983)PecX3|Ssg)^MmO=q3W%Z970;KCACN&j_u;uruzL)&M0s7}V?gsf>*GT(>?K#CvadaqEE1&)P$6QEK0eM2WH`j<G0Y=DDwJMIMzJ=IJa%%Ce6zz!#?YG=YACDzer)n+CrOj3)IYgG`HI3d5t~`gGAa`YDuCnmZ6?njh2M&uqVxu6+?nW|a(MvoOh*6PF@Nqc3pC|{|0f32Sz10jb5DsfhB3Psc0EGRfk2=!0aiA*dFB_Ng5BPqskc`?<XwiYen!~Wo=_rT(;<99%s6I%HqB&=oKbm~6bEydlFIfJ5f0L2kq-(|(YXtsMolj9lhg>|?iF@?*&hIE42s|(glAqiaEZ`aHmVViAY3TQgtl`sJ(2)xZD1Zm@K#c~BxgzhbxKU$4J6biWfLL$(m>bt*s=RG&{%f{+*mHJ1Vo@k8fKxiiTgr(vNbYuX9}nSeCK4UTrr5sNL`N~i2qFB;G`HQ(D{;fVUxE-BNqwEa>VT3)&f=1Y8&%raGkM%mZzU{YU%06P7Av-+2$T_nLt_D{P_gQFVSzOWZ3szP+>OxQZhmSXKeiS2Mu^noigb*|5Djc*L+gFc%tQc<=+FJyk1$=4vn}UK}p0tiFvb#FpiIuuuN3dznmK7u%EN*@Oe^qxm?)%xrL$-q@Rg~{k#!6(-g+|prqGYVPDU$|La$cx!(`NlJ5oFCv}dQq*%1Q4z-zRz8P)DrET2ZX&akD+Y)4(beQ67w)=@&NnZuGGE{6pRf+nbo^fm~urB9GqB)-fK^Wc@VZTT7*bpl<!tTm^&IhIZiNXbo-74ppTLIv?5q}`bSmiqvqClwluf6XY{eVVdneqF_G_ZM4R=4pCKvxb1?v9U%tU<g3{_ImVHcgKgbDHgh?=aM{qvrMzrAyj~0{k?CFRnk060L)*O`;xCItCa+;IAc@;RH(Cd$h)`guo>p9nsziV@m6?$;gr6ap85v27dmT@jAu)wA{0kL?&-ysy$G|WPY+TEX6a@<%v>k?D*`0;nO+OdEKpi@QfXjGP}L}|Iylydscw{LdruBHrNdk`n<D6(`j{x;7OGYpg5Z=^k+1uevV@s2^1s}l{x~(n1?7Kz_$a_R;!z5=_t`OX95a~9U;WxW2=DPEvK`&YYN~>z-=&hY+XRNB2X>fO61j<j&ZzMa_a}QEe7{)Jm;R*D_>3OfY^88s%kroYAU!>w!M#ETibZ+66p?fVrQ1|&}K927M-$PEVgwNE{7pnF-0DK(d-;DzX<!^oLDpFukQB@vG@x@AB$U|`^MYY0zwKs5fHCP+l%0@lxb?OR@6(mIh;e(e#}xQaYVkznXHT>NTsP%=MH=faIGSEVk0q3aN|YAW3*nP<teRQzf<GguFRa`6k3PNAuM`fHI!r|R#HPPpa<IBD$$HpQGv@7_I6^mofquvhX|eAGN`U5bZqpJn&!G$1ohB@T~8KM(5L)}Y`-Q>*UM?^8|`$5)dX(T`HCi;WmzLi*!o_`_zcF%z>8&a)Y%!V9caKFY(~Qley{m!^q2`OTb7v-QUj<y8WpR_*Ix|ibd*0`W4z*Kme*iI?9gz@gINZi>3Y=d!o#j<MO8=uqX%;ujslBgNi65lmiR356mk!d39(>Hm?#V2a=w|@2F)PYD7k3<6ykUYr@;;(e@)E*q`FWb4}&PXXOPQjxLY&`sNBB<hmhuD-p)Et>Zy^iBI@%9&I8x8teGn}x$0p?n_hVI5fTBtBDrW9Y}qkaa@T|16TeIStkgk}h@bH2?L2T)-9J&Du`M&fWcoQzqv`bd|EvvGPvvB`x$(>RV4a`ynK=J=wj9*VZpf(XUTjU9p1?AZ>Yb^<8p4_h+(iKGVD9heF$<v{M2-O@00nDoNm7d#hw7~Wh;9y8+^jsq)5Qq$(SX?2*e<68xr0X+dsB&-D+AcKN1VgSYv>a_vb(d<*(YX6gf>_aIi1<S(>qU=XI(rP($&Sf_pDAMHN+mwZxKLGW_DA@tmha?R#mcOIxQ>kGWZmhN@~NE?>PP8cOO5qPw};d&`Z1QRS2Elj-UDPf88N8blZpbkDu8b>%yz}xk)SNx9QSSS@*qAn6Crr?(IN2zYe7L3MgqJ5WZ`O_pdJ!0e_O+p)Qyn=DCcglt%>8<hzHqO(e*BgMPr}0@Re~0Id0g;;TT}?sRHFUxT?|M}O2NJ+@>$`>+z71XGV91=Mj+o`~95sH2Y0jfyoQ&}RG8o=H^%T^j?hgB={=ZJj`FtV=elQ8M86VoIX!=!8cr?;_Zr20833LcudMav%uGtyWuk^BHUSgDU11<N}X;Gf?>yed}kusVzGylHf}{m-9@(aSm(%@l(OX$|z3r!?NUk#iDml8+%|l6-%PRbXga@hm~?&nLm0fXseJC7IS7om56mv-8)OdvtP6+%!ZmiZ(Y0<#1n;1^>Z(POEJ^cMdG4cGH`Da2EfYt?n*fKInbC|z@GK?rXo@`G=yE@v#gbBNYxyDb<VL$d^p}_EAeO2)hpQzL+lVZ6ys9&UR_?(?htTb*npiJu(V*A93Zs*6rgjQH&%iqw&&Qa&FQT_({lrLxnkXNg$v3XnUropH(91~gDkoQP&F&;)?%NoTK&p`JNdbpX9{;!k#8=mvU~*}byfBd*RUm-`fma7{bS>KJK$Rp2G-B>T8v46?~7|NS)G&$Codd&PYvZ9T&Pld?K>keo50M3R0K*ARuIB8g565HT{Uo^$yt%yVX<nf^(D2qTZY*vjeyV1%w3GhR?eal7NRpJ_38qvJHR)T#c%*2TP)y?K=VQ9FcSp|mifgc4&>-#Yruu=1sl_YE17`XA5MSC_1HE)%o-%>Pv4WI{PO<BcYaj+jFxs2SR!4ZWS}_h91DA}iH~4r5rOQXxcxy*B`m0fl9crZ`o%02{@y0cy2CzQBCXjYt-Mh}X-o;_gvX|9+~0<Cl=GCZ-VZdCT&tpVu)zww!g(Y?4ho3oi$KDX$5_)XBB0!g+`>(vYYfyhwSrnZVM(s>fl3IC!2v35Y2plRhGmLh3H{B{_)9Iv>?{y?G&RGPQid^9E)!PYp(hAR9G4D*I)ICcDwOip!7CW%k&q1XBuHdrb$!1A1xWt?s*85Obxwr!qv4CuU83-2qLz|DD#nI_*Nt>avYXnTg=^Uv_n{?ryKAif|2d%t$@~A04S@bj|9@Z|fu;5M9rpi!eG$w3vD5Cg`aQi8%Y8`m10>N)^bzU1&NV>#Gi-VBe}FK7!^D;&f!t}7!mTL+#JxU?>ojYFy=mKae800gQyfQWq4SwYWX5y*o(-2&&tZthw#{_GApgEB)idM&vbSR!`A+=!BKKkcAOV`g%=2$!wD;{(*xR_ADmH6yN(XC$;8VjMfpp2vhbJ_|a4t^_8{k2X*Cjw4cB|FdWxG@(!OHt*G)J^QHuyf~2%`Tx=CfrTIe~+X*JVC7#g>;wB6AwwS~5yth4?VT&_)Fic#mW*A}zwSF1U4bdEncUXd?~<6<Sz!g(Rx6J{q2nmQ(=7Gnk?pVaF0DOOu+yOLUsfC??S5fs$!zf5{aANQ&5xK?TGplhq63AnBaZ+aQb8nhYR_xe9fvDB&PhCq@3Zzp{48KgoiPqz^ruW|1m#_o->8yOHal$Q2n>ILDQ3Kyb#yh=^W_V!d<${l}2tgEC}_irJr(h4{uLZ0Z^Ea{bEwr<<RSsAWcX$ODFCjwmF!n6@@CsBzjOQt`pWwq`^RG{dol;$FdAI1*>5K(udYiIzc`9EvTigef9hd!6-asUC$#U{c5!IgVIu&c^4*w0~w_c#I&RAt+=)K@n0P(x)tB3V7MO^{)#|;}ILRfm9}!AB*^D$_qtD#?ac8NKCc?GPZ$*rnLI3+3uLOivl&wnL9mZxVCA1xM&gW%svK2E15@tjIbfGgwZ>!e5_Wi&Vl+5bBzuI77GsKbY3>IEqOQ-N2$_*VUm>ID(VrzE+#|aS{)7#UpLqy8>?(C9Fdk&a`D_H(D&#zhENSy9Ffyl926=!sYyToZ*2(F?~=$^1tu5MXRFu&A`}^+?ABojpaJlDSXX#x&KasvI>pw6K@5sD@Mda_&PI}q^P?$Fm&`BA>B;cpQiFm6Ir}A1F(*o>EhE?6`{Eyn&W7GAg-t>fh>-KVj2fl!9n_IPSyuvX`uMXXFDTG6P+qBb3<~BcUKU(Za-~~=NKhDxhOIXSHvl(clwr+}5YR{~0gXY#wx9i)SwUx`1Z@y!1~=PgSNRSfh+ljqRJmfwh|`nTc(m3q<xa10y`u`YDJx66!e_Z|XiO`WuEq#V)XOKlB5pnsW2K20F{KMDy-6OF`KzJfx?qB)HwRrYb<`|yXq$bcZv5&~YpRp$iPp<9C*y&Jn=8CfVK%g+&G!o4<k^sK?h~7Gx+PS_6`@K;$!UddOD>;s%loM{fYq+*4x_Vwas_%DCN6GyMaHb!T(K(4+St^cHv}UiS5@g1k)LV?zutM??s+i+<LtbqB01kLEJCnhBTBk<yyu)a{QkOqywd}BRpS`{FI4W<Jt0Oub~7}m^|%1CMMneXmt0RD#Rm`VWAry;H)tD5-_l$QS{!|Kv;{i^75-TQW8|a^nD3(Dj)Ek9B+V3wPy#iX3`Xh`G5?D84uraOMEX6|_h-oQQE8%O<271>z8pG>ORmOI<K1Bpz+2Ppl{z)6+uXjDAXQ*!mh>rokQr!_Aw9cH+GpZEsg4n=^vzOWvR&a*Jj2!w!JlaMW%vrbI5ITzDT*?N3OWC$KO#x_B3SyK8TshxxHO|)W#q)gZqo7A>&vTjoGEgq22`}JM_%RP*>mx<&BYZ}4XPNnq4#v05g}UY?h37R+?s+nxp@037awabel}yN(GqbQ3ML7rkviPVyBn%TWy52H)tH1^g}mQ6@;-e4@;-#`F!}z2rLXbJz~4h-zYW9pIkO~hslmdN(g+ERJQf%Uc>$D?%WMTw5J(SRH*X~S5s4|4@c}_0oK=ylXn5;WWGb?9fiUb)OMV-$en}cxDJuZbxDMzdxMY@871;z$*4sz7?W{8qLsupF@+p@ymt|cr`ef&-)s#GpYGgbEs?Uc{G7M(v3I5=01$&<HXmOKhW*s|bxU+kz!VXp-J(cSOGZ&y0p3NW>iJ)9T0%hBdz`F*m{^SXv(sU89>40j%LwV-PrJu;JQcZ_nsxxgS>&56xMIQX{WEZ)W90eRw*+gE__bC4UNAv-B;MGO$NvX|M;@Lf~ULUQoo29tXGQ=xi>FQ#QvFRKNfw9v;7emH1d2h2umK$hdQMr@gDyIn!C~Pnj-zSa+6BT5MR_|nkjdSdfEHWM({6!#DijNjXqXW8&Qg;}zsF{<ipxlE$x4=F;8x2UI46DT)v(k0zZA!oS6sEq5KE=uhK|*nt6aplV=JQLEg0)aYiL#-fu}ucSF}d?#gcR*6(N#TOQv5}upVF-Wr}xPhbkC{FxM`gy6*l>J=T!qe-!#w<410t3&?TI~_Q_xp7%6V~-l<tL?yWAjkint_6l*?MR~H&Z>~Lua(aAj)ST!a&$(H3tXibIPA$YFoab)s%uFG{XqLT|%`KaI`qt=R6QTf)K$SKlcJibXy1gGbV%`th{r==>&1c%F6>z(@EJkC833{~30-WjZAZ>@Htw}w?4OBtobqm5}AtdtE1p<-Lbmb2ihAIvccCu{xUwA@2qO-iW7?y~HHd*T1Nb_P?W(k$+_21OyvNEZmpr9^!iRRstJCrn6&OZs|(0hC8~-x>@cl0(#+1uUw8HIlhiVlr<AEKxz70f;UE!1g)O2ZI^S;=Ui-Zx0)QL;o}Hwz;{ZyL2Ipp6N53Zg!!Y2$6_To<tSk5{EM;#6D9^X)hc{96rX>a~bhu1BKDXUB_UF4mGqE!Einuo1TjAeF<tG&@IeTAScnHA7L?+p>x`(FA@~{McmU~njAgwCizH0)!4Ku;<yJ*s84ya`IG=K$TO*ho;6<n!H0*r_hQ`h)(IE&FO(?9S^=p6E`k)V__V98(>lOqc~etQwy7s*L53g{<I|<(L^)gt{ESvT8(iSSd>fOkIGA5XazGppRJ|8Vq|nt;QS>etp`}Blpm($CJw<BmX!_v9LGcm!@j25}!BG>uT4eCLV9XbpFgIpgtY<ZBg5a<Yf*YILvh+$@l-Mci$f8&@yVjn`baoC-PBJFMmc2XkmJ2><ZomZzy!dQd^-XjP>zTw%Jp3e?^vRvB_@y?FeGQjK%p;17PtA94?}&r`<u4;C%YeCGNnm$(gk`Z%QcYXmM(AA*nP>a<*)~SBcamnS#Dpl!K2fS6n_?K>e^4HaF<$Nu#AjJQQ<s9_5*$G`O7l$6W(PL1h8;gGPv?t>=Y%ds%fFFowZz27h3Xia>Q9BqV8&xaP&R*%p#}9ExPIm3e-{@f*)ITh*$J;(MP_z_i=baqcUXR&bDIC^m&AR>bbf*_4fw;4Vv3~cu{O%&lUlAQ1jpt!bSKl5$Y$WmYl)A9SiRa;(ho{=1|PoN#g<<IeFlqJsnE;ddzBf5s%E8y`lP|~v<Q5vMlnCxNSO(QbPFRYP>`H34k_;t%M54J5-`1-Xyxs&xA~M8KI(&1@=`uk4k6Q$1lNQIjnLFNWH*xE70<!YOZ@9_z#NsSV>4aYoRkm6-&!lKrz<7?f+?<J#(QisS%f8J?4xcM8(U)uWWh<a0`tM&htN9b*n?)g1h;}AcKh;zM&w#u%fiv3Mls1bNk!!VHLVP0iQZ@3d?pC4b2Xg=P1=#()8twrhRQqSJ_i=?*~)=H?r6)tAT~7Q9F!oiK0?n5U~W;oz$$=}@W27hJsipM=2It!pP)_(%W+a0Fs*egf91-0w4EseTy{I5pNRC7y6ZG<Y>A8yypGXW9u!SAaA&q<hWtdB$`Tc9#*j^rn_Oa|M+vR;B8ML!zNuM+^`@NdC?jwZh}n%z8lR%lzAzgJd-;@NHaw9|f+Rufddu9DQYx?-{;TF3@(XNBi*WH`77qv<dMBY0><IIaOy)%y=N)E&l45pM)8R^t>r<S8KxEfZ#1}_lS*?Gd{tAJ76JZxY=wUZ%RsymYf8m9(E4`7mnrT;qm<S4(VzW@Evo!;>tfpid;+1^uv>3zGk*vyWSY{0RoHekcn%0)lTya*di=4zqZ$i4e7Vyl}QRpC>Z=u9M`;YcS5Wm$y6hfy&-L^KFQN+xwA<WK0sf1+37k|3>56hSd?VoJU(cv3BT8}+6Fsr(NOFWz%G%dJ1wRpyww4d-G!F)ram`^-kR^wodjXhwhoM@6g4XSk{`tzc?R&wKxiv-F(&o-<@Wc@xSADYp46$oesPO!5ni}I8x6I3R!ogFI;57J8{27tGHqQ;Dwd<AT<<2)(Qf41|awa5c^-jZ5Qam@piZ_;6pmIHJjRG9jkHWMZ)V3eTiGd@8aVr34TO&5kQ6f+-?wofBJjd~HExhSzIN$s#ui}?q~$5PsnB0n*4N|cRi@=5ydNwhp7CQ$Ay>tu-%h~7OAVaKOgIlQhJm_IT^Vo+E{e`~mKWOOvOGMNjhk!p!x-mY3ruu4^#RZo<uBW(fugutximC!)=p^Y;Fx>`a4lj;#pSjB=V?KDjaIN}pjzOZMShVvY_tnFI#N@<&?4m;Od-?A(d4_Moif%h8{UlY&{IOd!L@i3`VR>KErcTnANHj@)C#0Mg#8O%gmCk@;kzZpx2lU$L_5+bcEAtqWvbgwKS(mhKE=5K6;zmFwEr&^lBU!wa#%zUJ&YI=|##NKduG$!Nx*%IF~aDknydL%Q5Q44xy@6rzfwhE#ZWY9jJ_{fzV%_~0$O)mL@5`E5|AKWz>`@7#rYU*8=+q{%8gdOPptmvunvQA2~^;mK(h9#Fp8n@|as@)h1+iJ@N?>KhEx-NHHE+IXHrR&mZ)b_yE-Zoyiva9zJt;}XcWbo7sv*6;L%tbqgCkzf-$jOiXjy?=q`e-ypUpb>Aprc6xjNtr3m07b%=5X?D2&t*qnqZ=GBk4Z3PIR_qV;e`q;6r~WQ|sY&W4)k{G!HS3!EEkG{ToAKEwdahVfrL6=paB4!$Ag=X!S_=`IjxQx0tMCmEC{7z+Vn;jmP&Hj4I&X&IpXHXsP#(!KnJIiEnMYfWiC=IV72h4J;yWr-?cwhu0Q{<ybo#i363ASVy+ddQjNWZ3bZPoxg*PKGW#b&|8}dOm|0I>!S?cZfWv8m;G#;d<?KDp9^NBI($jFT8tG*b@zvrjgiw3El7dFN(;QkCZk?GUjxyd27!E<cQ_z^sSK85BptFN`X0n-XXE&}25j*EQ$kz*bTB(oMD9pEChJk0o{dOfwwwesk}%z~Wx`aqK@=i>PIj5Y6F0_zo>Fu+z6+j1M|yf{wA-2<@0$3rlNY-Y$h+tlo^n5s2N#Jrx^G&!N>v3jJ;mxCd*Gp`r{He6g3y<ZLo_xA7)P3nwDJ6G(RJiLwNMWiYyQ;xEK}7J8<4}XQ71}DLrkHPf)U*9BQ?j9_2H~u^@Dezr}}MojarrPP3x7ctq`9js&u#~!8{K4jP_SpcEttLiAQjU@i)`BOXOT~4XHi^w3Prk@>q_;17hQ7dh_aRngl2HfJqplWI(xK*GO`Qdw~+}fQoeJmKG$DGom}#4$Du!-dkrJDY1YJq}<r!4cVZmyhJN3`!m_DYxMeN<bH%+9cAp@Q;pUup`oIlXd0?^1e?o_1a4d*EQSR)h56Gopf*BWVLd5?<+bvNu)v&JCRxO}0)9-}+h};1x}T(u8QM*0<N3UpHpdMOs9F0tuTY)~1j`h)H+w7J<#un*n>Uh^=<;IpE`X)x<}?<A=oM=!Rzx%*+`-R3tY^>AIMA!9&{g?Ah^%0^sHz2C9ic0C#(!<xCfar@YgfGeXR(Zysq;q-MCPA>7R(PQ2b>LxNYpXxxeQZ1zpzw7vC(kCLo6I53K;(=lBt)_Tul{@KeO9&@#jTpxlWC%*U9O7gHTLOdVVDGBS?J$4FXg?Go4Iw`V^9-X0!b<W8!#({_!PH0`)n{K<tP^WO*mxa0ix#Q`yW2ezEGfHPpkG+nA&yn)E1EF?CP|q(4Ue#ASZ4iiUZD0}77U-=k?LUY|K(g!GB#U!>6~{m);I{NPM|`1Y2Axz@6qRn6PbFl$Fr6T~fdQf*UAF6g97=NfruO4UN0HCMeh0;XCGYnydBxMG)sktS?cU0czLtMj?VI8*LEtN_uuS;1B9Q#HhJS$kWja&#5JJ1EJp_HAF$Di_YC`?<T4hV~`~rD-;9CD}U{5?pI)D}_M!aK*3mkH^M=CMq<o_plNk%)NsFGzEA5ta|rcu2P#rRR4E%)kv0))g5;ol=Ff3rSh=;;ny}EpSPIgVKp3H5rS=IOEKPzMDhD8Ay_kBUJb^3oZy@nGU(u(;JD@lt9IC-7HlI?=>H8Nc*8ebYdUJ56;!+$j|#tSjCU0s9Th~p7NK+phUC27+dsVq{Vzz`7+2`uWxU+ew!GsHumy*&#wn|5%^RwjiUbe~y*ln{gY8hg?>3MtKX@Sr-#i>dj_?}#pF$<f^c=1K#X@-dM;gKbZU}F3wsFE6Wm@KQSsnPNnIQ~Xe_Uu-`5WkhT2=NFAJNgS>+Sno<5<_)euMxjH1p1^nxacbcHCaSvZNv8ed{Vr2yioHuZ>EFT5M8K3H5#87i1AY8Nm3w%peQ|>O9L?Mt6^0Nyv8QWL!Ioj0`{-iJOV4XAQY-WA}%dpxmstVDM~;o7aZey}Yqj(UnP+&P6YGX_d@dvQ$)dyKjU;tYM}gM9wyMI1x8kzcAGyYRK!w@OQqEQdGGJqnDy;9g0Giz(;hiz!A;bLy&c-4nd0L{Sh=n%<)kp8+9m1fwzW<SYh1VZ90jK2=13UU;qe4t42`_Y$*vsr6N>h1l^!IL6saC!FIE1Qd8yTO8zGTXb?<D2#1zZeqNQO<k`Jc2-tvH@Db^4aD+KX#co}h>QF>Qb%~KwO7g4VpD2Ab_Tq)!)RJPYXN{0cs&%EZBq0_a?$(}?EpsCyzVg8%j@YaaSw^U$+AFeh<npLVg_((YD|Z7`?whK0Zw_|6S@fy;zrO?~J=T%faU$!Rs%MQ7b#NHyg55zMH3_&kB!d&OCUxRBI=}{zPa{+Xwl&f^FrnoWW&e$~_{eXtu90RsMhwy_T)cy%lM9=9qVPKkv#crNts7KM>T6?fVZiOBELoIIwX!Fcs7w~zzGk3bl<XzT^mGVbsA4>(F*>*y7ko)vv(-rBj$0jEwSGM+$L*->jfI2`<TE-uRP4185#%jEXK_I(IpzU07NHR#Z7ZEae+q@;nMJ=v>K!uBIZ3cFBcHcuu1LM0Cj>8!K>P#;?k$Qw?5}Sy?>o%em-t5mzVpA?VBa&i`WmO*gZfi%_W=@|wrc4Wh~n_>Rsb;_D!q=|VV<Y}wrT~e^$^qzXq~2b(+vom_4KFSr{Kdv3s*t-PGPq7SvW480W@is!fd(OEhpb(<=OVOJZtUtFXU##b=me9+F_~L1~-=w-^J(|ZIV-j){n5aDxTy>`(&1})%LTiwx80~zHc|Yz;?cSE!RJFi#og4BA{TJ57impU_DMPO?qH{Kau+xAr@`+R85!$f^p&ot(}BnWV>*Rrm`$^22o(j71~`fHMdu^ZA)HXmg%`8E9Yuu<Z`uJ!#p+RuNV9Y!i*(Hi|2UhY!W;?1DlU0^C>=a%S`{5_=Gr5H17Prf2GxG{u-95-IrLZ2)ejkt;jRJzhI@+YUSXIJF8VRCZ3+vp*B$(fS*>2l%7}>KLV>7h6Ks2El(n?tpX)qn+!<$&Q*z#2SHSLXi>jEq?lG~5D0iFYZ)qgBOEHlWzm^}1c+n?86SloY7B?pMi)S#jCe_eX4F`#{2m@-|36S<GK^jexez%%WC8a62<XZE!B>)Q!V}9(P|{6TG=ciHbkhXGRVhir{UD(NJqsW35czmZMm~{#AXx;MQYAj~yK)=BtU^V<WLSHK)N}_08c(65RGK=dMZ^PJohOz*rX4x+(i973-NR5GXet?<SOwMPmmKg3nPQ@{Ilnml6FD7%5rh(`k=%$j#rnS}nfxkg(N$vb71Mg-<x}R5nW_lW3UO!7wXYk05UHq|Pbo;^G|?)Qy}F)C6#AO-Ga}#&%TV`&<`=&aD!mFaH~uZdD`QN#sZ?<X=48gK7oB<VY<X?4DVk4XioP3z&15-NXPs0xdkMzBsX*XOJtx#K*c|DHSA_ai5o=4OUzO21x$fkR=vr9O!xt*|N)m6WkG@tLc+I0<8Buo0g^KIpUbE~MBg%#MQ>#^0j`dH)6@5M~wXY4+Jl?SNZ*}HsyTpwP@2lnA`<hjjuX!a4aF^+y*Z!p|y}h-bU+_Y;_mzy@?FYIs*nHzaRZ(HXppUnMdHtdmJS!7FR8ycT0mEcEF7@M#&~g4Z%T(O*S%fP}ZrVSFf&!esTjI)|Lr+o9vPR^-1O?5`ddsx)bKADKBRdw>AxO+RkzP+gpbmtXb(qyLkCDg&?9?P699_UWQX?F@k0(C43qo7A2a+`<a~#fNdHGOIHH;?nDb<gZs89cWQNLL7m<c=^pzhlUJT5^0NDVtc3NyQKM>WE;RcGi68cv3+IN?B?DnX1j%Gp5LNRM6tIKhb3$@l`?f3J`Mt2tzOM+ma)yl=tzFhPOKnB<sIF^5j(T_pJe#B2XmEtIx5%3#lH6$A<()j}!yXaYYVx&fmci-L=2WfK9z6rycnXh&1f#sAu}T$@p=11WDUyah|@0ptUlorx7qVyb8(XgXl5t*SU$Qe)gi`-)P~Ete}(C5%c^i(c8l+BElRRaKKlXo=$%8j<gJwP=<ttD7^23`?QO#)1`1rQFVzdD*|~q=^9N6<J7}u^hYJgI^7atq_@<!dU=zmPk8RSgl;jb`@pEP}e$Y9nzoLIQL|mnmg#`MR@(fI=jvCRJ(=R&5Nwi?bi$;{_`tI{woIslXDE{Y_N*%lxgZn+%K|jIEAA`el@Kfym=x~xrv89bVmUXc%=^p9#E)x;*&YSzB2Bmr?s$W&}meI`xLg6njW@O5X^dLC?#R{>U%02wL#7RlT6F^MEfR_DRksO#1$4;n-zJRA>mL()j!h1w52iAIT1p!HCge`rsV|8w8myvQujyB=Tt~*gY`HD?hyXMQO1t3y_oVK&i~Iff0GaAFXF14L29P$PPvMYEPY(lg-)M96ulU`MXr`PO5U6(>EN_=448a9i!y4s-$;lrFxSuSK;lKra;r`U!kb&$W<FsQw+06^a@6U?khc@fJ%Z<-V#$`%nH~^diQoiRh8Oj_nRt~Of8zAcem&0r04_^#P18)HuuRkD`H`NyiYkMt6tow1=L!92skJ082hOxc0O}YtwY$V=y^-fA;L4A%EbFLy-u>>TWu&O_!!#1@M@j_Irbov0P5xe9O@Lzc4N|^Rm4Nffyb?=fh&Pi>3UJF{Vu^{9$-Kie)4J9oF6xZwE8DymciA$1-&><8tBg${wY_nqeR5=DQl&hI_Kb%N+qC>_#sY<+ZBFYwH+3eYCS<_GHKXgXbM4PTvunAfKNUys3;Emyk$X(b*(H?M^U`*Xdh11c^@6h>=dN#&$B!#xU47&62Uo=X(o}vI;!%C5e>a<7c|^4nvCo?G$``ZwgXsXiAE95GgX@OeT~7a^B}H7Bg_lxs`$A5Cl18**+BL2JmeVgnzxCXm(7D9qo9?oR^(NJ?sTg&YLF`;z9G(A$*3X%_Jn+f&`PQ_4!Nb?1H81v<$@=p8tNQ=y7gLvT&FrtVei>qm*$>o{X(@x&-)}hmdgAvV!0A_m8MOWxw0`6CE6$qR#Tzlda&!xuU%$kkSd;lHUxw35_xAp5o;31Q=ss>3580X}Q2g{Fti8>@xGQJ#a?bw#{G!y^d^&Ba9Vvptt2lxtgVJe53k{w=ro4W^=U^mFuTi?p!92U@N>H?K8p6Z@uR@i9k8d#I+3-wf5cXF01QV8fH3_K1sJHg_mpw2!I<dbLmRJ)`lgLLX)4k^Iw%KSw1MQyTV}dyGYMb&*;je$@gU!sI8D_B%^H|nRfLv)5{g}?>a!ypoq1)NRqhb?6RCyB)`*<3Yyb}*9o9QOFcRkIpWp9R0KFev0+Pu>P`XqE4g>Ttq0QGA?#|EW{%P4yhO?h-d+sB`SsShs9M=W>4n<-XT(fHY=VL3QmMqxmtx6bhuQEz{aM#r7WD;)QL?;UcQXtYsAWD9zD5;jl@*^Cdj)ye<Go`DmisCO($=~YYYa<3mITjis9!@XX5F!{HPy0g(fUrUj7H&SFR!?m)j6g%f-PEwu^iyB#;RUMMDg)J7~cMmiJTU^2=4$epm5PK*x^tJ?G8b9S_=ARfHln}FBdR@fZl0z*@)7Ti7owh1m=0pnNcR6wTocM!hD8))(2#oG!u4&YAH$C<0%B`OK!C+&OnPAln&adb~b}TJm&xn^Ii;~FvOnHGzD(&`I)df>-J3lXzv&0u5GsVdn`~QyHV84oJxP-!gyqP7q^3zMT953K;#pLhW;HS)IWt^O8lU}9~mNm-dnY#e9MhUH6JyAc1M%`SM8@<^5Dcc-|@O)~%*Oa(0&KKJJFj+iLRLcM?BZ^#C-oJ9Q^BG$HbbSIbUTd+LR^e8mIM#V3d<a_7@mWw>V|+M+WI6Z=JkZW-nncw_KO}G*B{nyY^s9Pk;_*?2V5X(rxp(cp#Yqlmg(9||{3Q4K?oZ8`M~OZj<F7Uzp~fG-yW2=_rfzG@)Ps;DDr8#q97jF6z-=(}q)F5P9BQ(87y4027Hb?S!e}!dC5RwVIDCUqMoXFH5%XFS{|&2Dx33Smf<I67%cE|RyvBf!F3dYHRxdMuc6!@D^ijFY2TJNlgLh;GafLa28Hs3vn-ELc<}vL*!nE8D@o8prGtqPSSk9B{d`zED@u5ZX`guz2zx#!)pxO=Ej~Q;ekH{bsYf2ZI(sx&;tT5kYZGIQTUqW0xBX>O-t&e_6`1)wqwO&o>>Cg8my#Y}|m{D*j_ijXi)cl5LEjVSuyC9Y}`@QmO*_d^e9_nWxR+HZq_IoXc^o)vDe~9Q9B3}I%7conHHEI3CB$p+`+ESwQjOr)-UCv_CHgfoAPjO@kp$9oXib#M=_aP`MFUOo{jM-78s$8fYw{#LeTGpz`p(sb|!d4E)qQI5&?wJq`q2+Tm(J4_}A~<aP?M1wz+_x8sCZZj~*4waV^DudzlHv();?;lT(1K!9$@-5--ZBfrOj#tTVsJg|FejLqw_(qo*@5`aT`fd*RP3Ts6gxxsW{+(ne?)|Q$$TFPAPcSG9_e$yXLtoVM_8*E^4cU@V=~4@_Ev*Tt5MnN<wGM`iCBe=U&_h!-oQ~q22za-;pm{UYFRK9j^s)x=Oac5-rG$@ws8b?#!2ez_IlHxk@Lc;?ZfIyw#Al*V=EvU$lkaqzA2i8q`lV_RWo!%3o=$t1QGHo>*O^9hUeG^ljX3wTC67~3wOi|WyE#-^ijt}t2{Za7L}IYc&8WMd(E_>e#Z4o`+Azaons;6)2*giKqUr(-Kw`;!gDx*>SvQJ*1i5_vb9NdINX_UXDab`JI=SPb<C-%pr@(l*V|6EkeZ;eP1P3?kDzM=o<hYbL)rxK>}-w8rZ>wuH^O8)xa*m4JY!1220dW0(1?S&5#~E;6Jg8=uSN(9z-@v$APXJhX%|Z5K`-$Xe`QHQK4Q%IiG>|kMjmJ*wR!Hnu{$*5r|d{{D&RHeOBf)m&>T@%Zq96z&SzB{Fe0GgQZCqmT3Y3V$}?ZS>xsWguritgU*3f-TjzV0q9y12^3^7FS9y_6>|-2y6R0k?SGy`7**!HBcWBfZb5&se-@*@^#ssJuj`E%-&NOk3rX)Jl<jSwI?2g<3GsH|UaVivLtvg2)C3IY=g&F`((u2&Bhujzd<}ZEq=izSTk>89ws`aB1v-ML^BM(U)hm}|Ql5MQK9ygD~d{}uswno0S_=Eayr&bR`nl0uK&C#qJiO^UcgO<&np<iqOn3PzdKnBN|x3Oo)(hp{irSzg?-{UUyvtfBkfN~^L`?QKtI>jg;n=(e}G3fJey;t7dvH?^6|EPg9tj*c%wV>T%K32A_#6YQX`gmdaYj`S6-^G%^9vGOEhlh8DaY`%fnSvO0Xv-dU&@?HJ2TJ0!fyiAmN=lZ(OPy>?8Z1wU^jdqICiWf?>f(J)O_7p8ty!3NF0E-(Wm)z4JPh!f3A@g9ZCgAihpzdg)2BG-gS{53@m$Vu$L>+vXwN9KcX;Z?jw!Jp(X6YK{gzOP9FB6f<Io%>eA@D{rxHk+El26m+V+tMGmN$8GAllEO%IF||D~^5*a{My3jLMZwP1MT*I6LZ7qxq>XoZV^G683tK3Uhs{BN95dohtDK{HR!tJjZMb_Of7U~QhCm6NFA0ui?J#gtY=vx<51BgGM~pe_F!H=3F#D#PlCC15B2A5k<P>6Bl{6n#Q*t&d)Yo5UcE@gKeug}K!1M*%Tw!M@z-X=PZuE|U<#3eHBjEz+B$i~ySD!AOlJ;1v0gu%Soo@pnq=Y7!gq7|5`;YnH;vb~Z!ZZHSV%XQL<AT02dIhemWt+6SAKvMi5=T1R2YWlzuA)ZBNm?YY*<tvj<jCclnaK4)Dn=}bDblHE+r-&tw6n`&J-b5y=#+_7}C5w|6uP@>~T+gxbhh94YF#}X66u++%i*OtXKy(hK0wq2}kNuf7%aoNMJTyycPxaXDAZBSpLUF%yWs@25QxvXt>r^I4yN5G`N(Gtr)|K-(e2LcaEk}(Dv?oe{?N;TWEOiz3~+c;d~w8sO|sWx|ltWbIJydzpSH#5Tsh<QCkArN0K+!70{;%5TWDTxc2+DsNTL+f^6#{zX}l~W{cOGOaQ$gN}xBF-ns9wzG@!4J!tS=}Cyg(8tUV)!}lxQYMjhX^=%bW)|8-jEEEZc|+8Hla=0FVN!XMbUVp+tedG<M=UjHWGiZ1#U%~!dkRRB_xF-Rg`uN#3ms+kaQEC`Mv8l(N%3{0aMd41~(##q?;rM-;vSFF*?&(I-D4m0V3+UO(#jEV6DDLiHJ5tZG2m_>0idU{Dn=>y}8&W%U9g}$RbfN_jbssbuh8AX|qf(&px%De4>Mj7e?ninWaF9Ifg*>xIHc&f(8b;P(-FZwpei5EJ==t@k=BtOjai1jWaC7m_D`K1Hs7UIoY+?tQS&Se731+dju02h=*O28_TXoA55_Y9+j~St4JNqcsO9b8Y$g|iF$|0IWd2m8Ws;r>{3pE!A=kDdI%MiyHn2R`7eJXQT95-4&g9Rf~fUnYL$C-+uZY}#FsZEzD4Wmb%;HAh>fwks`9~Cpp3u4gvh+Uw+^(~J?|~$96ZV%SNUeo5Psr<(D&^ADw^)hHUc?jrxGH;>(8cb-m?8LXRVX35=_bhD!bgnJuiID+B)|0=f7&K{bFv>1D8n*&<S0&bE3W$MX{hNMr))p;Fg$rMs-PQH^Z?+m$<G+J~LCNAUX(hJ8An83qwK@0}=TQ0e?wMO+?e!W(GoyY<CK?g1ZUvsb)N3dO0Y<r7qcHhlO8d%=51KBvE%%wq{H}$J`u=YW6|r&MgCj<!%X+2P(!fQpLm@Q00x!(y^er>X;IRVp+E9x9i`Z|1wWS8Rffgx$1p4>r4mg-;}#-g_zcq-a7Z-c}LZIM#xpgwJ6(nr|OMr&h;@+n3K{`4XfT~$uu|PGtn9B-j8hEALcTYm0&hv!woHj7IS2fQ_{>`Vi1B%v;7zDg&(ShzhXrw|GF52z1v}0?L>*#1C*826nwPE5$+#tY<qT82J%nHioj7O4qsYUBY@EgCxKZ`9f_ZnmF2)nWiqiP0`3QDOwxvz96p4{Wvvj*r7|91$kh`RN`^sZ6{L*R{R7%-tsY>k!Bo;!3f$wN0Xndp=SaZSiMYW3)P`x#)#fcW*cWwaw`{Qc%~`1c$95Zs5QT?A$s5gC@qMU|!{%(d)0tIXk-RMn*8RP<Z0BuR(Fn_#)Shf+PnKb{GVEGPylu-$NxPL0W`-)<AelY_kEhWRg0g&$ox8tm2-&y2SI{Q=+m>q_-)y#a$vkA$VC|_4qV8%h(<c+HOq{a#e0uz&bZ+?Va?jf`2g|AF(v;9_IH*T}yM3*3`3`6U%ok+@^FbC|yPQ>t5Jv7e67ImJ5IxvU?u>a^N8&To&T7q{A32(iJOn_g{166p8St1t)0QLdsLMw8x1OJ!s#cC^7E5KAM_!a`B&L%)rt=a<Np?M)VZirSq8%tV?%3AKQh$xx17#y0q{g>dK4>CAz9nI+1k!*-+tHPooVmQw#K*{uGr4qwa2t(S7v*;KBGHs>9uuNpgTC-J5i+<PvIqRtwX@&6cJ`B(Z+(F0awm~tNvWcBt`2XwDTPSF+DO`;VDf=$grXp{ZqOGBdC@2#--)dYdNPQDKCvDcCG4PTAwttQ%$W3;zH>}Ga1UI1Y;Qvos~ncfE6kYau%|awz*O;tFuS>;(<Kc;<ERu&S|S_PRLD;__>IAL9JJfuUhC|DIY6Bcc5;(e<bway2a{zl_p3Aa16yEhZXJ!17mme|1>oR{&SP2W`ztUw`O4PXIX-3-!%K`lUfDUjV##l>jTBkS2B)ssL1x`eu%1u_n39PgqB43)2tdm7|A${cW~WS_yKe-u6O-g4zYJ_A$z$<t*iLrjCLv$1kUQiO!M^hA0`CMD^WT7X-25Sa0eEM27RNUa-tpxn{1ITj{<SsT3ObD6N37kJ^BJLii3jN%c1KRJZ8E-48O2CeLRQk1N?IbFq;frIp+Q&$=J=BH9<yZm#^6R2A~q$kjx;w);>tzJxz_S^iQVHV1+O&{`ps=Jy7XbTPn9sDSK-s}doZ96C({d^1xk>kcpw3LOeOE8kUmshKV#dG3ojW`Qe_DyE`E|7dO0F(m&)@u3O7#91it=ILPnGXewOJLYw^TLNSCTjbit0_gQ7j(Idd$4#E)<*Q+%moKK9d55^zZrAT~Up7G8F^lV(U`O5>4*XY*fF-9i?FauJW_dKmuO_bQHSCi;joNSTI?>OS~P6dRdmnDASJ$tdbdKLOe#np}C{Ks&(dQD<N@dowkQ;l>n^FwQ(fB*6pcAkJ_emtx)_xZ2nz14QxJ5hC-qk~9vh&UPmf4X-_lX`Kh9$gJ_PJ@3QRD@9<;Lw)43l^I85)FZ_b%g9FM`Ap?{+zYXGu!sbrLR$T5_G{73+0o$O!Uro>2Ub`Gq@evFK62(LAYBLw+VYTiQn)7nFXrrh*~3W+0~o?j!bo#k$t<@h9wMV3Uv_BmfU>ue#u@X7NCe*o0`RluH}9E)aCm8T=RybWbmo-upg=gEAyF%eQpvx;{zA0U0wYrf-+;g;gy(3@C#*YWFUiFL&nuN7*b33|I2s;!_L)B%Y5&{As}sO5h<np5o7#ns$|nwG>VY9bXG*LLX{5Qs%dOXeaD^;cs|-YvSw!W=xUvFd1(R*;St^*!7+ZGKu0KhrQM+q$-GjUZGukXAV8I&P5dxGHvzM$H6V9;OK9B%N){MOW)PEL%z<fi%A9!S*>C(-(c)w<LA%6lX=NXhe959N(b!AytN+i4_WW!>pPGIm+Qe)2})4YQ=?eTIod>RFq@u$u#Kc&}137BhR+Z<>+qHU-al~||3M_&~5#OYz#Nn~pZ?zGM>!l_<W-AY~E($dT*PA`F{BzhgK7f5w=imE3Q?m(OJYS(72`{}Gt3QF69FHMAus-!mfUunM@gA6}XHL*?INsthpd9bfQG07DE?JprO4)R@N3gdvfJxEX_xEUOw5g)VV``DayTY^k(v0~*Hi(w)E9h=9JDwgT?c_T*FH@+U56+j3Nje@AEMPA;x1grqj1wWEhM$lol&B_S-NNzCbQTua&<(XDD<<|$_GD5Fh{EHb%;;CXYbUp{ty7OaW>M7(ZUMTR6W#NR8hjug-z=yIP?y9)Ct`CO8xv9%!K)nyQ*MvCA0I?zP*yI@FO5(ix{l0M?E>~TNu=tCc_kZ&1m;3c6*YlhH^(R;OCs+9Y8^8YKQvBp1e>cCzujkkJ<@V5h$X~l}<jlY7uisKE@sqLo4gDH#|Jr?h2kL%uVL#-v`JKOh&}aYub75onO25Xh>DTVPe`T)k;!*r{eOCIl{xy8SubbE5y<TT3fkj%I^2Pi7-}tBQzIperZ~q_f|DTPE7FI?o<^v$Ptd0K2^22UI3NA>wHI!?c+8wg}1HpQduOa?N8K|WYYLJZ&Wm`j{9iKd$RBPb=Wm%di=9A<<kjy1fVkN4`sXk#p#t3z-mZaL93Q77g7tXN$l+~V+l}~I}5-ymj9=hHv)}qMfpf^9}YaVaU&?FbM&2;~>0^?!J)oG{7BDmQyI0Ld?oTD3hNjgg)jI><6+l$%N!jGSr<fYXcTAiVN7e6bV;c|K7a-KIA!45Pm=NWhI@}A^9CN1se=4|UbuTOjPs~@YG>e<RzV0A~fcg+UI%>Zbd^@UZrJh;wH>|7a3a(2Wm2-DBLKKny_YBI-XCOj$=+oN}^5$5mM|J)L0f-2PcJ0aMwHbsZcU*G3{4z|^sdG#mX+v^wl|K?=u|6nI((_=E_+4T#3Q}%3@k2I-y{gv;WaBSZ3r}*x_rnmpv`bfL|Q+)mH?1ab73CHk7zYeQkw|7}TN@4E(%I-tET)J2<<GA{GSia_ZKT_pd53?^AY+rl_V@z*;(A{9({%bvGzH>p=8{9p;cWhAqs#Ep<S-{TQYa74#*YFNWw8bLTgt=D@y#MBXy}EX&zlVM$fZT@ELy5B+o3XrkK*I{)Ewwu2M5z~C8@oN))aYaF(f4$5L{o*PZWWeOeEXh_A+<<oZAmGx7_wuXNHpo)UMgkd5g8&)eYq6pcIo&zxJ{B}>h*!nwDOnZ|0zymW47D5S!pJ74j@Q-{SH1dZ)}YgbzCVdRE^?<xL|SSi6pVC^?qON;bt2@fm=o5=>A4h7HFeEWVRyDu8sWqJYB5Heia7PP1a;C*UP5Q{}+Ah-v5eqwnOaydDjpFC35Sz8k&zlyD8(#d?A;gJ>sw{4>apU3DF}FjQ^J#-pk-N3_$^Frk<IAzi6XM`RY?wBNvlO)@_+gogvU5E}4&HH=47wmeHv?vPyQCxzx-!=I2BxrN~sMrY<HxNNd)tD{A5fdMqh%;d_=OGexx{`C59-Sd$(e6atlfAdZq;N*R7gNsgVtf=iQUo*VN};<q5FF{EW)fMf$c-UA$C_>P!T#Y*MIbWg3#Ow`83MoJ=nObtS7MY}Mzc{q@!XGbi@>HLHA;`4`t!F1YsqG~M1>gOg>CMpCbI=VJNZGpdX7{*H1d}GIIZ<<<|j(d)F6u%&f&`s@+cz~46=J3W~(loX^OA<`aQ&HNLYtIjVr}^#B{;@Jw5fl*{G}IrV`je#{wr?=T*@cJr^$A3TL=7Zrbg(<WCn+LQ&AMX)o7q=x=^YoP&zi3x9!|np$#g~P7}g!{$mEZEitVbQ-dMPv*%SxrRkkx0Y4a)JGE^>YKIFc&_seFV%3%6QqUB28^zAtn(ZmFiB~LX{W|c}VbY$l=kp+l7r~xmpqv)1cspHA~40EUQ1e5~-4|o9aQ+g-l;QII~r}scoX$YN-I6z(iuK{`ntnH{)vp~5}XGW)(_l+Fa*=D>}FbToWqS*X8CB|vL2ekJwbl)eWq0AJ|fOzJaDife=6UsR^b6FW@3&sap?hKO@c-`O&(8VNNQ|40DmAQ&83n`gOB#hDz077;Ye`$qX)~Kakz!l&;y$On7q-3>3a%0_?+(XU?9IP?cUihQ!lkfNo^QP20!lIi-CB`Ck4Ompp(zMpPL+`*`^{V+p!)@0+-2TaAaiaXAu>_BtU)m*Wd2kc&QQxi&-E8LM^1;M|Q6|3!Y5wv&xgX3bqk%el0_djRevJlQgL-=!iSP$WGtGa&@Ns2){KET@Hp)GD*ur#OQi0@AAy#fpraD9LXuVU^vyhDP*^T`qM|2eNf^dC8W2CR0sjC(Bn6+eVWMGzoUN|DfZ7cS>H8K{Yj72hvnoOumRt~=A79k={<X6VM6wj$un@1xV2?_@zcF9N4TE44n46Usr07AP7822ZjJ4}2OL>+Q0c1^g<O&JIe8P7ik#Z&XB@AWq-gO{m3p^EPy@xF)smlJ7-><HVt!9onNTPAwabxz!05x-i(7UQ@AP1E*IUO{njwlmS7JjjWXDs;i%m)#7~r_>fitfz62J9@pg2$G!_C17Tf(W{XcU|)SzxumyT^#tnN{s-S>xoPm}I`euaAYUZNg9mcPTx!N#w7y(hgTMY!3nz|FQ|rj*a`FsfY%XxY*TaW_67-SenJse|`W3&utcor8<=q~}43tVq@jxm_wH+3sjO%6hXehSi<`K}1Y>j@H&%&Nz<5{e@5GH98;EeMeR7s`Q>XUh=q-wSeATT%HWo0X4W2>du*0dlb!@BHzr^N>kXD7ZkW?o<hV=#EP2@CRYIF}19<g<JXV`EctpoMvkR4NC#J7blLA5r+G6>;PcIx{g5l{Td(?0LuM90UjA03(-N*n&NoM*Ys}d@#QOY`w>r5tD=%$5bAg+}c7n5;vOlMW&UhH?hXFf=lsCkr)=Y+VcKi{8G?0!>tWN`Jm~#T4?uiqUutND~#F4SPXH~hL0??J{<k8*+!dmO(c+O8zZw2-w2Gz;n8?f<;0)umZs?`8YWTymj&cvh)mAY7zG~_I|qi>QQi|60`pnGHdI<Jq)bO@A*+rsJXJ0FQ0qIOrIU9PUocb5vW!QHZ=SQ&g_fZY$<JJ}fM_m}%0&HuD1fBoX&3-qOkoy#_z&<<{VcAEA^DHIVU*x&A;{0bkCd2D;;2I+!j*H8`50k!XlFhlVr=Z`2PoY;nxYI37O>GGh@L9IViRO6#&<;mnhguoa_GVoBlHyT&LkA!oF!Qv8NHmmG!dmCD5PdN(gWGc)(ydF;43v5wblnqdiQ)X52~b`6dd|f%?~09Jp=0PG9$j6QouVsMBQyZ6^-l@%UK#D0CE<j1>oT-`!TF#VEBa>4`kXU85B2$XG}yTCnzQw=rhaZK=Mx#i>%dJ4X7A@_G^=%&nx};HI)eFfOkY~Hp=twDLYR(K-(;QtNfPC&E5)MCh^i#sd-8$y;7Uc-@Mv9RUX8&V8ErkMSFgy)V#_;%F@$XXP)o8mYN^#NzKdsAh`EO_Dd}dpmrsrllARfFRUueXEJA_tYb7+n;hs`VaL)qD+H#hGhdyG?TfoTL6AVft-`!`H;r{Jq_A@%FF&{+&R(Qi-s?9QP@c1Z`-BsFfVNIh3!>-kduYE!^Vz?9OV;}!=UM0syx}}MBT~3E{O)P?o5)s7n5lLDS2S+v-MQN=i<-y_Ix5ywk4hQJk5>I~!*3(;Nv{h5*+}Ypirr!wNjGD$3!?M6I}CPJ_!d{$8=FcVf+`NN+EgZXh+1_cl1w$CR=Tiqs-(HCyNrt)_LjXjn^Q{ES>I_SiC)5wF{c`jGFsu)i#O)n;NoPMZ8J%Ys}0P$8{yBW+K{E2stBR{bZZb^cMED0KOUJgWOEIdyzK}LU3?vih(^<zC?~)e90M4Ntu_E4VHv_ND^T{MP<oBA#E-s>1pq9#ueJcNShriO>X$X3d&e5!=7r`sf}6TA9SQGV2HXIvE(6Jzfp)tLq*u#8d~+GNH62N2Iuhb)CFtH*339&YIN~cox2yzKRT)C9Biezs3xG|~R54#xf__;E){Y||x)?Y+$=&$k%?n#&e4bF<mxdp<9yDU-u1rU=RX*-62`k5u_goUpdEs-iJqC9i2^5;aJLWj@jo6K(|8mh*KYXbQM9-hQD}f%GlbnFiGE*9RQ;@JFL6%*&)d+v2#voMy7Z9YaJPQ)xodpR>8bThc6}dFuDN95zOJv&0?lYeNGHb=$K5*c-1i3`17?G1oOEQ_J7-u^-QVV8{Dc{y426+Htf=0h@vd6s{WQ)%F1j+l%s2b<Jlihiwj3`71IKVZ5_T*nl-LKXpT9%n=S>pC5k$@e|b~92}?Y2<yS3r#GLi>-?&aT|{Ysn>PWFRNXpECs>Evynd&eTlbA7C6mbQJkH;i}AbX*o+GdEgp-p@OqGdc0|nY>wJq4qQ!gT}SK|lr9XSDKU?4<O>`JZO;}GO;cnXOM>Ew!f2=g(0%A+b@tio`{YllGL4Sz&_rP@J|%|_>FUYPCqz}spt^O%mOJv~X1NbFru9AR#hKk;++g1Z)=A3uIanT(YQxk=E?-2#DQX>CQVfgUhp-}q<81w}JmKH6=k_7QpL##xKk4<qeoBw(Uh)attsl;CV3CCq%y*o{)8q0$qSoI^f6ku9HkgP)s6OIaTx23%zF!XsqpgoPxrkK+kar)NQqlp0CMDJ&oKb77IZWLxgEFe4nsK<yf>?Z4A}?lZj;a&N7d*94{fuMqRe<YCmnq86$GoFHJ!tNex0Z5zlFkWvw!H)d`5bC##xU&B@4wWi7q&Ya4ILc)?=N>Ret7WRVZMEH*7f^&8-kAzLwolvUE=RL(@tBDc+Q8Wj`5a3{QY~o^@y*xw^@~e8TeWyxUsw4ukQA+x!VQ>y1nObS;h;M#vyjcGCtX$=xzo@ZX^UJQRJ9bqeJ%b8X%5KWkYZAk=Ll{)}v-+9KRVm)MkwqDR3M$VXDHc>jCwhyT<>iuS?Gc3M1)*ByFhCwNkZduW0McWZI5b@@=p2dX7KraBnlG>s=XQ7lZ%@Y91sv*}-goj-Phs4cfg>X0r^UCv%G4u{fFO#Ytxp_N^Nt2?Uh<+jb?!VD#><+`h33(@TcgBd7Wdi(K8VuG6}S6O!qTvyW3Yn%X3}@|g|ju{>#mKhII#YgknHRHtlZpiKrup$^D5Ea6mUAi^O3RUoAY8#7eC*WAJL9F$K}W`^aUTvc!eQ)yD8#~<Uew@sI)mCABS92tD^%2-G*pZG3WJJ}lgZa}1x5Yf~&FO+e|eh>lynadh#Y6BaS>Vmg~f<L{(CaxN&!nTgXcD*9}kk;Xs>EB>sxLFsF`2NOQ7CcNh-P~cVdHl%lTE6_FD-H^N#v(WV6zI~XilLPH#gWRPn~;f8uHI@T@U<v$%nALS#CpNR`8|)^Y?9I)qujt&$HBJLd^IQA5@T?T48?N!dL^h%d~hdLf@#`{Bvi79Nh)9wjZ=g6jiv{-G~yi4qA!@GN+>8&E36E@iF{kU_Oa19im~2CD$lYjW|}d|wi6|mdNTw9sDSl$PViJ&<v|6Rg7)G6@RbT^J4gZFKK!+xj+Qzr0ynF7ORe>;;oQhYDc)PUxvGz7+47XvOZQGNBt6-ZTEo}3rF&j2+NR2^1(P^L_Na*P4iD%t)}>pe|Lt>5yJm_rlyx#n$p{ZQ3reb+?Y!BRgV$ocl~O)+ikouTcDXjh({l?e0xs9YBdJC0Q1?j>m6m;~jRYwPxxGQCYjqFN@L07@GW2~0_A~k;A8!}AI`Fff+@$o$CAP{Sf&vXI;!+H%>$4W;WjS3htzY7G$iMov$bYW^1H&f%=S<FAsmr&SdD?1!k3CDmHB4j;^+@e+O*&QkyIX62(@BXRVK7SJZ)in#ruq$0jlI`y1N2|_uKIl(m~>81&xGXntktb~QoFx}5Uepo(2|ATHzw_UGj}#iUkJ_UFX~&n<mGlwF3E8I>uC3KZRvgqR|4AY?DY;MBb|g|1MmqG;R)rbPJI?mE{W<^c+)joFmKOMMye_t;{NRLyI6px))E;Wso+QP=0U4K+sHU5v%N}vOA~}SDXqPj#H4&#W=z|z?3I*K=6R|F6q7H3!ww%mHeXR$?5I?uwxrCzTlo{HpDFlhZ|A&IoU)VaXiz~>yc1bt(8rrS1HO;%fz=Artrj3j(P2f~HMI_!<}ea=DJeaQ(i)k<d;oeGrv%lGf}EGi4c}qy8(P{nR7keEyHa4sP_?eJkyL&vyeA$U<0W@b1lpbudJ3gE=N0r@fP&8cR2D$B9%5%8&$z%)?FFY*s}$Qb7#p{u5UjhJtR!g>4IDe2xkg*@mmphAf*selE*KlYxLDdJ@w&OQJ`1DFtOqjEL@ZVpUALdm4iS7>Wn3$&!=eTEZB#f`yDu6jmjz`y>PACw`yrzFlr^#02of@q<oOH9_X_tN^c|~nby|Sl(Tw2M$oJd-f&3-6r>kDWI1{~TeOK3atz0`N+Qk(FevP^HdiolHY#4KIAsA#gu0X{%$8CH(<b|+jNZ=J{J?1rF_}+{9YhGT&?C9U-W)M~kuyY7(ObP-YHb=kv@n#b%3$PO!vyhJe-B${f-jO9KN~*=>v?*SdfoeWvDtWxFEO#{1nN|qIftpXX-Vq>@c2rq;5GG|Qc2x0yWbaGd!~;=Bo^8gacl-15+0>ZkT@{bESjkP+TiNZ(*uG3|!oN`{@W6Qrt`D>ZkfvA-j(QJ{q6J4TNw1zo55Kuii(`aLVY#zdS9bIkDZf9U(KAUvpM^=T0I-g6TMn7Vpa@<zdz7@5aWL%4m;L5JU5skYtMUX@KfkpK#lQdMh1<(Dr*%kDCUxXeYs#>YZ`b@~66`%Psdk5(e+VoX6I$3xVi;DZ1|H~oFDD@_l58U;&$Dp>V@s$g5b-P}wG&M<<g6Fq*V__|iAjhB5#>1;iD&jTJYHv{(U`-fPp0Z6##_}_;rRK7oiHjP+}nozY`!=&DK2kzQet%dT>Q+{t8@KvW_b*h%MGX&VI85m$}~g>NFt(?lm89tKKu!;!s<Sp8Ud2Ibm#6zp>=V-%$6X`MvqoLz_Zbl%eoZsX(B-Q#r}b7x<Tpe;oNi|R0_Aq2(|j_88w$leTRJ%-OBqKW>FcvXMt*e6VC@rVG)UPg`FO3=gC&vCb`%vB0Gep8E(!|(Ndfh@vT1<?R=if`{$&($wcM9d3`2nIgR#(g1xs#xBckoxSr1_p6eTRXJ-Zph8GyeA4)_?s8;X>gn({;z4=WPWF#SO5z`Chb5-i06=mz8Q~Se}ayXbAcx+((%&Gv4f|83mvV|;(NV6+Uwh(n$HDwYR2BKYQdNrsEM2_4ToWN#;H$1UaFNP;)`Rs(pi0)y*9><QpmFNQKK+urn(MP4c3gtk!kxu<U=ST-d1tW=N<tkJim-}jCCU0F*7O^=oN%yh^Z1F;J{+kiPlipFMJBY4kqUC(-I>sb9Hw!$goH<G%{t>1w+`sKSQRh6#E12|^l-z;Ij>7pUM?s(<{rum5rG~})jvlcZ7H=0j`ZxL%WmW4@wCCK2OFZ*pj8xGL)3!C-g@MJnLF)44znmOH;aGJnp;H#LPaZMs9Z7(fPLVzRUGuuGNj`5~#<6?WTw+p<M&Jl`D=2t>;w@(__8m<MgT1TRp#m8fdDv8Wy#vEzVBQ>rW919by0Qx}teX+=TPkU~;3s(NN!WH`MR19%m291en*xXY$MB_ce3-bTr&`^>xPORWcXi{l<}ZB!L#3QgnSan(Wg%inl&$7~L(`K1)rzMwil?Gnt+#SI0J=R^aeB=*g4Wb>`eG5aVyl?O!a`UPo{zw^1%j}staj{ob$0J#c9*EUcExFJFm;3m#<4o#AW;CYgp)UH?7Ah`dregty_z5|cx{%RapOmlRI*4ap<3d=7Ami(D(Wzi#fH^m{D;d8Inb2oLj(C6tcaE(@7%9V=sLmF##iJO78s1Y(t6QIZs~WW|8Iya(y;FuB{^>y07xZv7<?h(ZOqmFi=2WRgBW2T5VH?(y0H1-mHK}qoV^5T<*8{ayTv_X_M-hMrjEvCqFKxx4*;Ut<5TCeLCa2Mv^J#z`N4RmmeJvcziv}{1B5;tw@NVab!yi{>%ukO2|=}YGkZKKz+YELCE0B@lUv3N4aZXRUG_AQsr<eBWNny{g9jnI&8yQoRQ4+`uu7CnqJPELHg<u6p#&~LkASqx&QaA5AwejkCjvyJ8KBx|lPpSnio>Z4jYO?qEuLIDqRsS(`e<JNLp0IiUaJ4ucr)2yr9mDsfv6Q$UCW#j=sNLvNP8;D2UW4ma@9R<f=LS`6H4|s8LDKDmSe33WTQjKg#|(Tsg@cfveKx)W$5)`T?q*b_?^{faJT!Lg3L<o2&`Z`G!~_Dk(au}qKG6usIEy!el=41Oc0>BAzYVB{iCq71Cl=k``!b}+Rtn4lopE(dOTb3x&hPbMVegih7=1WfU7OJt8wKC8%$6khCgjm^FL2m7Mg!%%UAUSP^W|+8b{xm4MJ6ldnC7!c25<lCe8U0<Fyye1&4B-=%9=V`m`upD>NBcoQy}}>m|pdX7Mvl9Evy3=5aL2ApzB%CHL2!Ap?<NV>+HV@fny}c`_gOBLeIe`qpSLO&NOc*o-%!#ji|U`{w&4P=6#YU>}p~`Sh%YMlS1RaZZos?2h62KW^;w-fQI|`{#8P>LCp#jO0A7Z8>V#hOz^rk0GmF2mFz(S+5qX_6B>SDC3~@G0Idi$|HH}RWmr^(Y<O`rj+OxM78LLENKzz;dVqM*465jSB(jt4Jrx}-c{{qJ9n&UoxU-WD4m4@leL+xRu&?bMPUXh)B9xdj2F75oZf(ha<cWvSmfQ2Xc-*V8V6`=lX*yzpfR;O&Ip**qt+T!r-r)R{Lv{*{n_RZ!u*dl*9&_jiK(*V{qi+ET@8z}e@urqO(n;NXG$X>|8o!_k}T9m&*ifPmk0O^=9zx!gE6%TVk{$ZHaYi!@$3A8zE>2|f*3^xfJo=hCV~)TlQ|!B+f4{86S_G+@^uo2CbiKwenyPgv%fk&Rn2_1ae$?4GKD)brT8L`D>e*yeDXx*mK4ArNR6B?R$;V4v_U%XfB6=JEG5cR^S}m9G}3B0z42eUb*P)ea3ozeZ~W#vLQ>@+NncAz7%-Ylz?$}bGpu~-+W7yn_inG&tb2M;y@#rLt459E9P_Z&+P(MM?v8f1=`_+BBYZ?}{1d#5h!<jFOj;z^h_Tx=h?qpurqhH#Xt5I#QD})Gkw9n+hzJUbDAFLJ7oGxMdEu4s^E|&_9mX8<JFK<WUc~Ihx91*n%rR=zsCo~-!*g)9?WBbZIMdjg30uoV6eXDfq(Tuo>ry&CAzp;}7T+TM0t|qfdbBo&r#c)v(kx<{>XjZSF``fvoQm9?;+4pwBiei9si30Ol-XD2i2Oyfku=IQp4luT>0I<cmUUD2<kPP{zS7JQjh1w}%2+2Id*1UwQX9dJ-wUE`9DzfhM#Imh_=oOrV(Wv?0&o^Dbzqrq0i93Mi?d-5kF2$GGSu%jK9N^>7C@G^2VsHjb{HIrHiGk7F<Zu~Cu)wA9UteQ#A;QiXP7|LuU==-aFv#ZDF|fwl|JMC)H6BI;ycqh>GFunrXCxXqZb_Z0*?o9Ssh`NK-NsMC&HOv4SAaJ+eUVrUX0&)ISa9c`*XrHPAV+szx`JH35?H8co`XUnoJNoS+nNPHu4N)tDcxyA*1T)LsQ@~Cg=rw`Hg8BctY0Fqzc2ai{(j?Aon`Lky(CDFI<SG4ao?v+-aA4bX6ZwK!}8Whj)?IB)hcGxG<mZZwwC+>`8}E3O0HT<2PsHDL*nhoci=jX2!1IR!zXNGEDS}o9Hj~qkkr@d#`?cMV_bG*l~_UQ&ImJn`Y`(SgyEH5J)b(<8Pm1#pE%kXgs391PiBUu2y6m?xCQm7S;g*K;q<wa<;G$92J6!L}bcU9GJ<YaXUCeYZnRYk_7_RIh_-Pyg{lhKg0akh1F(K4T2Iv--GH7>E(~#=f{6nrB^Ma24$0V+T}?La-Fxv_n9ZTgsJj_&onXSAED}ym-4w8wv1Ok$wJ$}T}VN!5DY9MraGLh;$9ygPy-oEXf#fCz`8sdMIQ6^fzW)nKa9q_PXK>pt~;FVU9(a393K(pN6u8-xd1med7rVe&Jgg)+VbceouPU(X;@>wpc4-Zz@X4wRMB_Q(U|m%fD5Bw^BkSyAKIh{k+JIoZCU4@S6l+!;Y3lpR?C$7E1^3BIJHg@1nqC(RYks<vV{8N8MCfFc_hjJ$VS3N2G&(;U`|d5MGBN^Xcp}_uzPVx;tLO0*t((}Rz$6eF<Ffe#-2FFA$qVK$14j^g!w_YB{{QvA~3GLK>kX|41$y{6c&Uee?%q<N7)6<U8-62wn@Kq3vYf|VLv44Af*jRhjH=b?Z>Yju_sfLW(TAv;+Cm#){fePo8dES6_tZbLk;i>B-4R@am~z3so}q_BHzo4J;gXaYt%9vJ|KQ3>Tf2GV0=%{MlvjHB)vSD3#wEjE;w?K!&ZbnP?Cyaj&_nAbUo;reXtfqYvNgaafst%T4sewGc%Kbn1{V(uhj;9Ynx*i|5GphioiZs$aN1dbSbKTJpIB)8P5k~V#xS%>L2QchEQNvQ>lZNHzB2=($KXDjWr6(uogyjp6j9<J1KAF4avK7+{aV#1dq!?U4O>h9AnL%apfK#8*zPlZbUV}LzsMKu{4?$`NP$cLzQq;)~x&L<r<Z@93LCk>sBU-Cr|rkAktu@J8`%Y2hOGMTGt1}oYH1U104KF_j19Ef&8i-%7SU2rrjp@_-i(-CpIL$_bEX2_mjO@zm!PFE#*7Nq<Ln2uOJxFBC8GMn;a)#F<Le@*_1JkY-68dIq#hCaxA*bDc$8uQ{*~N=guy^Vb0nzf;LxcV|usQs<LwK77&B&9!8|W1dv*h`?8$ogL6aKnj!H^sX8@>l9;9p$>w5^VXD*{#Mh+rYDWb=bvrX-rl`_XGix5R$lY%2S8EV^%($M>Ypn#Ha|Wc9<?20n<0L24@Uh4@g`H)kgsM=pr_^LZw^|~T3>6@jm}E<j{1X7V8Ks7u)x4JZYrhD#O2#CwN}U3&WtN<&2p`S2-jMWiMr`EP9cJj7sU-ocZneSXuTiyX9b{7P)94dc?Uwe&d=TRXqy^0t9jrA&$P6jh$X8sbHiV90#!an%&bY6<goX19;^xKbQQ%NBax8j;8C-8~4pz-)vDs=u(v#72H5Y7{qrB!r<t+p*%wVu)(MG*F;0@9&St(_%_ZrjGA#<D8>y_~yV$HvZW6xr|J#!Ck<)6O3KCfYNX%1gkAj4(IrSiWc{R-xXZXMi5#}8#K$AlIVI5x5`)N;SCf87mSI`>va<l(b;{ejR1D33AcWP*Yqa~hd6?2XdUa(s1@tDr|idai`ul`2`5Lx)W#wgflOJlWt?v8P?acC&_70;G<$6bXY%dq#JA&DkO?y#5eXZedVBJuer%WlP-tC70a70gKdGqp1y8s?v}RCniRdw>ZH}gzTP*T|if_<tR++)pNntD?lV10gF0$@4V3GRK;~2xqGDmU;nj9y)-ou+f641oP9sr#>CHgT~zS)g9KG#v&sHSSVG^cG2P>O<h^NrGR*~lyCtlKD|_;Uk6GiuoJDU}(R5IE%|x@($z*jpTL}=VO2<uGOZhjHa&>@1gl<GJF}?u5pOb&RbILm={{xDN@rv}N#)XAaS-nnr#ID&j`81*Q)q<zpT<XhS(r&9J-D-V|ZZOHpR;0*U06r=8lR{gQKB5Fg+D(p>VeUPd*n>&8dPpUS1^*{rS3{+^gy5^dV7hq$zXIN)pOw{%S@0bwF^b%w28I)B7FjN?@pn^!ryOQVmurn>f0@6yzN~-26&T#F{f(bKE?A@0>XSHxJB4QTwErydY(LjbW7B^YoJxQ=2X&iA`YI2prY~o+F-=19bL(p^C`&4#sK?{xTN(pjA;_bP_DFPGN2xOEdm<(}QW4O;BCVUfJO(oiUd+j&PlWv~%fDc5Ost9qfg6(QWTynqk4Wo6TDSa^Yd!l5Yj{~uSLlzT<bT9)VZSn!F#%hFFof0YB#;D;c48K&Mn__GwE&1QFptCy%z909pASI}rP!LHmp&rJbVg2}8j=pYCMLesi-N%G(6g$$QdG&5olu1ozxH!+5nl>%)~_vPxt}3?;d`uO)Gu`KpgA)ckwgI_qv@#Dgzg)vAejuH9f5u-pJU98Y@w%^=fc7cbx`pl6Vaa($!_w&CW*{evhcT$p^dgaXO?9HTzSJTYI6>XWonL?UQFR4C0`p)#;H&r2z9|jpoW2~8LQsjQvk7kF5Ihe5e6lE&q3rcl9tgsh{1S)ePKUaA@2cwuS~)2qIKRhwooLPau`~vZzPu_6X6sge-09drlR?*(yJ(p(l7+U%1Ay?-2<$T`i2vc_=0QT$ba*rjNs{v494;-Df9+uxjSuj<hB^11Dg_uc*|a1BT~v5k#ZE$+<0r9x_fNx8Ot7EqFMHhx~gpR<wWr@rVxd&6Vojrmf)0tzMLC*7+=&aES+n$1taB@5~V*DXL23t8qTsk;b=k(Wz81p5^-%W9`Y8lO0$WcH|p1RBLs4Q6Q<%q&)SQKvjdB>3(O2{=_u))Yxe%&z(@(;5FnnuHE_ru`{5TOIzYz;N)gvJKV8|04W^2XakP&kt&%S1c*#ck*8*{1i6Ne`P}h&^squU~qitJQ+IXsC;So@y5^Zh22nY0#4A$#nW%W;=H#l2tR!rg{Ghm$arVZ)?qGoZOlu(*b5u|9YtZSjegyeOPZ^kWfC!Jccgc78SSf#_d``{|z4AC~%_&@o(t~Mdu*jFx3)a%r~QJ$!4aQTSxgkorJP*$6ek9xczPJ5A}iE@JZggQkHdh@nak&GRWs+Sijw2(=YC|WjoE1o<Fq4ldDI~AW0A*C0rTJ_rO*<~*erZIJ-gg;~i#Y_zlz@40yI8n#vAY8{8{n*y)q2QiA@?9)%+f|{&KB&lg%O01!rDWj*nm8H-$><VEo@_62ySgL+b=ejOT+^V7lwF$o3$C(7F7+p?0%G!K+qW^kS!EPxphWdjF}H!Yo7?u<N`kHi@6T1dLBoVf&!oS~W6cnQ$)!q><+PY&1LG~C4P1|!kNeB~S$bo-b=vur4fN)Hf+3)pt`Ij|vg!!BBvTh$6ebPDn>WfKz}MFO<8U*X(-yyL8?ONvu>GdZ#;bn($V=*buK+dmlVe>Zh1@B@nF#`ZPQ-^gepiIuX>SA<@#qst@xV&fDZR&D-S#GcD(cG91MYcGtZ4nLzJ@`2B#=V~4s+)IS#z2xqvltd4RW^|n=(>=+|(|xw;#+_2;dhgETs0IxW|vmrfbmT@6NYn)|f!7iTDW%X<~+n76(jP>U_YmaE+*(k1!Bwk8w~Zp+*~0f;<q0+i4}jt!8T~_AORIEJul<Lw(sxJWbA(+M$u2NpGs-uQ1Fi>;{Er5ku4mYAiqRg}m46`KQ8)pa@;+wW6KT#NYV}NU(UrWoTK1kMOgQ9mi(p5sdkk(SS<i`xp&(5zBS)H_8};@+ij-L}*-j3~~-=j@Ga2Ffd#Z(+Wo12#6KZQjZ=nVTAi2XqmzwH@M}fhSN%jsVunVFyofF8Wd%o#dPqHuty5jDBp8^%}o0KLSa~gmaPlN^(xIQhC8ZCXQ?WcwWQJ-jg06jKuBsGVIolwVQe=8!*+^$K!E#}C6(%j{@QDBCkE!lo42hhj~tuCEe&gYCsisbLcqpm>x}=oTgxT7Wek=fe-wuoe6vwtT77lIjjZuKI{@H>6(>^r2$Sl<kwwV{Cc&g&^|-DEf>pgo#qcs$+Jg~T2nKfZBfZk=bu*h=@3p+bf8FUO#1(?V-=3RU@x}O2S*YXL?<)wvU{oGczvgR3{#CMIX$9XUiEFM)Cx;LRe{F8fq!xk-av`V#`TtoLkZ}(mkuo9d#fn6sqhQtJZp7ncT^52BR&ACb2^ywnHTW2b?4ala>|<I90oIp|+sZH*6H(<2Ek=h;@lymx-WjKZx>`3pOn7DLn!)CU>db~}>7qDG{(AkBc;hPAtDB5ej1$xNOw^FDLS4gp27dAts5qiFNrr2b4=HAUvBSpsNoWBj7i(p}A>Dr72kEl5<`28761!m=r58YUYjp!t>f7~SX8?=Xwo#D~9lF>}yRmsoH}B=@&~r9K;H&5H&Z6*)qe;=^5TZkw{8ZgBKm{zZHgyZkn|DAAqk?=eVg9tjD_KXtgb>}Z*iI~l)}?OA_v7n1KXNn6^QOUPfA4R^u5i?rHk-+sVM_i#zt+}C-;<l&bJl}RTL#b_=|U!Xxqa{MY5GSjjB58}cCu`s+z>hO)2uUJbnQ)f)PnyKq>g39CoZ+9-IXX^QPs4q0@KahA8yj~HX7$`RI=B~<k9A63ex;#Csm}~6Af5MXhIH|H7ZdWz<x^7?!2X@uo6f{m1ecE(rl+l^MnIgYA~HZTKNr<V2jY2oofaRakay?@fuc}?AYu{uncia7-YS`LefROP$IX+Gx?VH*}w9kAv{YaZAb3;17miUPmQyD>e~Z0&iRNB)y{_M-EsQiL7Lwhq3s*Pvt19&_l(MWLlO?^9E_-&ygdwQ2UXge0XUC7c7ckGxO8{K<yT`ZE#nI?ht<d`&R0Z<G~9zZ{Ey8K5$3=q>>Yr^f^JYZh&(FWRk<JG@~=Rwf;RLHYVeQ;4dS@LHEbk#M2bqnBdAFxZ9g6)ds8(UFGhAV3--Y`aRW8*vmDo8hYEK;t_fj{6v(UIyW}J0Cu1tzthf`_axxqI!bX_q9)4jyT5N7H6uG&Bs<88n5@QdBP}p2OuBjVMpx3HDYM{JAA1qo&3@02@5GgxrSc!0RN-kF9@DLW-ke&a_9|bgoRS_%8PmN+CLmAHQrzB*?qg{`Fc9wb~TbAx^dCwS=gQ8~Y>kEHcpo)%43~>^saCWLE?(k};SO>#1XhJtOVR<@<2`xk;T3!|yc0%AEn&>iBRPK$VUJu-%UtKyOLOJxXnDfpL>I|tD;Dyx_;U>ZAjuC+J7ZN5R_DZ)*FoRG}FDZ|EymBD@5+C>XHh-!4w|x=#-SkmIoGf!7#g_Gc7~H;}%OJZ9{Cn%0L%{cuSYweP)KJ$Cs2*c2gm!D}>k&H2lZVA<SDOZy49q-DfZUSjCOu+(9i(eQJOHlFz$&q@xdelEiU5{>0y87_Drfr>1RS^*0nUl<kH<BZ%m?NC=tB02eG>^*T`EMO$(2)}s_vMcwRO<2D?D&2Q8|+QE(GwC*b!_O)a$S_JuSB5d%_%;gwyCFod`_HY|GUXJ0(n2V4!wbLi;Qgd9!&WWsYWUpl#R86Z|F=L$X2siA51PE$tZSw7Uh-UpVxSA-(+OTav0oeZEozT1l#A+5N3mRSRLpA<4N3FC#d)br}c2;?ZU<46gd9&Tu{d!rL;k4ovQA$eNNnJjuE%%MmSs1QsdQ{TnkSQ9VzH!Aw)Xj>@WaYjkuzlL}Y#0imLMuc}XwS_zxcrcKn`%KqH60us*cRe#_{Daa&%m=L+Yxos=Kp#yKdohYk4x&+93&JB5-OlgPJNlL0j#$vi|hlY}Bl#c!N50{#6Tuo0<>AllEl7A-a%-xNR(clSoT{qU2rjh1EfzZ=gR&1~I?$+4UfWHzWR6kCN>Eh88fEfzGzQhc%VwdX@gxNT7s;s?Ddm5XTcClk23)AdPlYF|}ti|wBoqSF$aswV8R&6ptL{ETqhm|3XL$dbENLeB1gTu=j+`W2>+!57UzQ?s4>eZ8H^;Kq_ZTh03S@A~!nW<^}?}eZVnj#&8G$@!P+`0p+uEfy~vj>G(TajXvM_p_Xn4ovcm&qxj{yV>zz*0W)m>cCJZgTaa9vf6(>jXYCMsC7N?Fr%Y`8YRkBD*rN9N2u~Qamh5OAI6H<*wrkOhbOZ`W4PMpDR!}n_}xvRPks2tPT@n5Ghl>h!ZriaebJ7Yz{a!(?#XA6#mrGJNt}_+ZPsQyaf3;>*|8ofO@}#qXSuFM_cP!)euj%7}ik;$l1gat|0L6?hIvQX)Gq2B=xKd=Y|k2iCv@#9sfevf-GkiLLig*WHf3Q&;`_P3k7^g#O#gzcN%SzjJoRL4ilDi>Lo*Ikds!pC1&i0T@u_v=a#5FJx<Kl(JA338{&EA;v_pSN->ck9Exs`L+rVCXGdSkk`-HEC!?oC88^&e2(``2eoNF{YrM?Z>Qbk;V+HOX|G<rEo2kvyXLUDYL+_<-P$<tnKBB;Otoh(6)<EQOh?lyY?!*Vd_dXrP!U*+lyu83p1LEmDZNE$WyfEP%>Vtaq;&=F0J@Zmn+d9;A43n2*4()@(&`_-e3sA{%x>9_n&Z{1B0JumG0bRLY{-MYe+p4^`+jdv1`0zEviU$`fE;nMu1l){LDt67L&Ri~PcDqvSp{fhRBGa^{Xb;-Pr6stdp#Lh#;<^@&IZpB+6+kkXPch<_8swZUEe6oeV6HF-l!)=Jli>(NjBCI(yjR2+6_(#@ewDM87}4(c107m_>CC{LOVloflPjdhn%V{h#f)f!@K%s9%kYhN$R$188vr5@IOXQqWnKirF6>fgT7XM-ymK!#ack(K(nwo`(i=3QvipWIv=~H6cB0f2k1}sCE8LA3Yu22{!qUFb!VBw`i6u$^p8}i)@+`?uhTpnX&exE@+vM*}rh2SjciN*&VvW0ErXq#NQ8PC+87{OVy*{pxqQGAkt?E1?uaeY$5Y3(RJT^;z%Yrq{eu+}!c>1tH&ztOz`OD>hs`*9UVIo)qvB2@vyo?+c<muy?7b8T)7qb}VgK%WL4hTaHlZ&Z{0)SAcvc|{90+`*4Kc1g|1VNq8*B$QE426ItaMzm)j5EOftiOKuWQ&rN4PN+HD1X;@{A9d9{W|H5{579U(@Kx)$xnPBiPd`2#_u8xk(>Q{%YpyxCjI`AxL=wG2n{edYt&ormpAS^tS}r0DcRk+@4U9YG$p$f4Gg*Ry<|}eGof!b<-oP+rDnhMMw7>tD&2R&z;kQv355vvl<dqVjiF+0?rGIVp1RortqnC&bkjfvsq8><l^*)$5MRmaP?m-{5(3U4ZmldmX&IJISwghknpI|!<f64?s2fa5LVzw_d}St~U(NIqzbe(SWGqQ<TYPSvdHvi2((v&6_%Hmy=GQS;fWn9*CLL)fRfCE%#~pk=!QTID&y|@op`ADza}eM1^klfUGBuA=Dp$A#j*>kojn<0RxgZ&^nkGsQfIuVfQE_#>Hjj-&@7P~x=m^eQ&B(ngag~<#cb>&nt_FM&Gy?_iiOM5<JZ2F}0P>9l*z=SqU0k!5XVzyjz)_L-ax9n>qCnj61kyvjnioD_*9?VNrZ81c_!ky+k3wOd8qkm2$80x4{tZPBmTtSTF&+BCwV&wuB#$X5+=JY}paDy7C!yyjl**-HuZvpGPG;-n2^Z-=(H#WhJ6rwA4uNgQ#qhvyd~8|zIwFuQEG^&&$WbyCD+$yuV0G>}lPCj?TF-PQ_ah3i!$Q{;lXKr#B_H{Qn!8<6$JaI`Qp9WW2%OA`0`=S^_f#8^J(j2}a7NcwTtstC`Tx2lK#h&L=j=n@L8g;{aOW{KHG8Bjt|b3^?`YRMw#!o@V1bS)5^j(|9vkr3N^NcyQ=tGWLtW0;>?H1giq6nRvpC8-IUBrCVisl&Kd_;k7UB|*7%x=E#|iW_rXAd4fa_7W&Rho;Lpm9fs5h<J7@D!s8B(%jwW2OAdz#DRi$I>FaiWRbdJ8yoi=cvG+JpCYysgaBwvR^eNHK8#6I;EB)$AmFZrQh}hqo?n8?c6`KDB!D+S}GFv4hJ_E`sp^Q{5T_NOW!+<!S`uK{sojah+DFOVU2Z`NP_{Hy0M7by#CGd9$s0J<EM2liLy(x&n_hOFNq%ISW_O-NTwcCZ#3>=Rb{IJ%{P1AbZrEM97!v1NZhx8F?x%`Q;_=0tB6*k52v(T2>EilGUUTbw4!4j<I>@fI;b2+uAdw8ZTFzV@)8=C(N&%x~orsB=qF2J?wb10P08wZKx*-@J4TU#_+`n)uWmRPdQy5EYjwtm!`thxFjrU$CO(Z*D2Oq$HEm~gq#f66$y%5w*wZXle)=4817RWyuNLuB#7bsGw%Tcrn^AExib2I^b=JT$Z&@C2xv0$`vcs(u(WeuC|q`dY(L9~s9_KT-3Wsl(hvye{a{t^0n1lL)jI<rj~%8^{p)~WvhSKHNshOH{`#q@i6YdWd(@GE?bu-owpM{;d|ekP7TMa4D4@79sc(p_)8Y?q0;K=jmd<b#e}j*&<JM@I#!Rd?uj-zj+FyKa71VX~n3>-0USS{{%NuV@b90*QlJ1!1uC?SSDOr-LMvNzuDb|MBG*<?2H&Ny6q1!`Qe(RoVu-3JQZpWS`pzLoM!1+clJ~6OX3!u=9p|XpUnG;-eO5l6slJ7f2;mn`1^+fI}rOIqK`&yJO5^9j-zE>|*W<0OeQSX|^aq(vIp0~DfW%hMJ)#P!dn%b@*6zv;szG0S61%&?FR8aj53m+1BaviI-5-NOTbuNh{hiOsco9Ud9oS(DQ)&<2bc?}}8pQ;LQ;+pD{A6L46NFYyr!=QBjQ%rh`qseBti!y%ppQ34xGQ2ypE!+*D==JmzNN%V;S;rWXg9^XOa&Tz`*gjd;ED98(=QtIF@tH5fKt3a%s4*E42lZ@?eobdZdZn20VBL#&R({%T5sEDpk$|VBpTN2sq+pzz2jaYktMz|t7&b`9n%^s>)dqee>U8sSW!N6VX4}_ni%z6FfXe)7R+lsK>weDMXyLnM>4?8gSl~|3>DQSvN@;H_c`eRU`EykM%;`4}6lnG|IfS*hWskB`fj^xgC+^u>686bZtuRu%v&KmkUPIWLGL+E=&TcljjKTGO=@UUb<jUuA=Iy}ea&2-a9X9Q8X)VST;vykCJARl3Rwv%LI6PXy7+ZCM{u$kWF<smR#kV!8F-kmmep{z;s11_a(>J%K;^noe_@CPVoX^Z=>j;1Hy|VLIBXa~jn$TUVD2EclDH>I#E|fA<!=ECBpLXm?)U2gNN#}tARbn2Q#9AZfEDBen;LK?y5ogUS83UTqfg^~SD)p#2N`TeS!FeS$5$2K{v6iuM+Py1q&@3e`K<Q@jt+Fs%jT#Ga!N4Tr+qFi3QV-1vD;*ctsiITmAuz<G6=!%T!i}I@$*+09oh(NLK12`klj?cy>dNKB3NS$%(~i;AtEWHGQ|*8L>NT^seVn>CFrOCbWX^o5re~9j2u7RpcxR`{9|Jp0bb@GHL3db{&}is1I443#gz(D7`c|{QZ)7ktTRg?&0Z26c{++4&Z=#-d6ZIG}S5q`H^=n(JtDz+%1a@Q1DZ{kQ?wIMLLY~33cAub~%UZh2?H+jo>~5j5D!E;SGsXO@n{p*5k`_-Yc0_9J_OeXm_}ZxKx`3dm?Dk<~U!Eb!x2LlEZvo=to;1_ilO`?bD*Dr8t%0~m6FO_wLulo4pfo;rBZmo90wVjyZ9;U2ae5)047nSNTOeMdjbEsxpZ9z{5g9-&0{CM^SghzRF*HSZC2Ta=A7do)LC2QFVrEC5A*8`&d8Vu$XK+N#z*IOM^cbUSzBGau*k7YC(P@!va>E#&Et93z)IP9OwLJa+Ss7|c$Pz?9>3O!m__B35BH@p1Fy|1W7kEs<7_h6>;qvc&Eqk~R@P8393?C-{eyAERB}O1e*aN$%$xE4UaM9)5yspe=#uw;#cyV4?3<cb9@l5RgUWs0EyRR0M<QF^iE8Iucinht2tT->@v1KWV)`WZQB8Sxk1=+e+rc-QAD)d|fA1{0px?*sY?VD5GSg-uq)RV0LQ0c(0!=lopE&%jRpwfVbR$pKF*FGt6C}*_v&pXcKA~qCh6WO$76qW<HvomWC1jCs!qRCosGw`!*6|UbpM7Er161f&^M5ske89X%@9Q~Tp?Vt1$95p$#MY?z}CT|I7)Qb;|G7F{y{w|#cwjG{c%judLdqLvome!IB`!|G3A~@TW&zCQil-j5(?nhXE-;OWHpw8mGnU`qz32Xu1LAjR)tj`1Ruw1}8^JK2P@A-nX4NpG&U`aHBlc{4^ycTfHeibmF4DlT04se2da(jdN^Y1fgYP4reNo2&Y*kXk-$uFD+M`rbE+{(o)xy<WTGMLH+mhCt01-qngOba0eD2bbki=8aWX~63k@sUwRiZku<Auh78Ud<fNT9QPtVO{%_FPTqjICHT7BxQ9O`s9lsK^^oKj9@S1i|!{q;0ALRb66bnlp?_-clzDD<!JsnfQa;zzdZ8tcaCJV;g3YU(?M9=JM!)D#g?sxNgMKFDog**`o=0JH2=sd+W3Q;=YRa`SNrwH*YlhH^~YEE$5;6OAHV+iQvCQLe>=a%AI`7wE4;n?l)rZ0$Z3DwUw=e_#E%E+H}q?~{cHEb`=IW}7xq)$o8SBEC%yOYo(mhp*ZMX7kbdnx`d2`PT?ZpA#uS@h=f8$e_;vF*eAMGC-|Zx3Jex-!{@LX2Jx|{K>)Su${hwLA&9rsMOeUJ62c|AAWp9)CmRGz#j^U13tYhlzBcKy~OsZZ=zSW47>g7}Qq_nJ3B~krcUWj+pfxC^Xoyhe@|6(#ROQQe@*cc5hW4#t}q1gwKrBs@|SzJ-rh{~&9y*}JX^IQ@r^FKFc*}nblU&EWfMw9&X^PE2@hSggHSy-KXTH*2LUzfwG5+iU<TwSic%wR=gY2r#aX!A0*me<ed#Ma-!D@iL@VDgKvrc$uWu76(j+kA`Q?-e37gw+v(`zS@Tz_KU1)p?4DmE8a#Z1jJEmlv1UhuhaI&)i;fD*<k9dbqvm-hSQQ++g25-2C*jniYE-TG^!1=f(Y?k>y(^nRR)RV_^Q7_|w1m@{IlD>+Rric}73o;Ns4o-v37XYk1?Y<^JnGaLlm!>+KgY2J!8;3m<ioA;>5F{tH5AKKQ`y*W2Id)syk{S9|Xl{Lo*EpHH}bF#lBbT%*OtOtb;hg!yNjpIpCeKFG}*muI$P@AjO-CwwEHk35-9>(VD)jn`v7Z!XKL54v;d-a7gDn9*<UdIHWDP@lNDKH=4647YbAgn2mK{kioLyp=}&3+Rre&^-h4oT5OqP$Q!A2yGqMp_yiB3bFa{FHyRNfSN9MvWV<+o7jX(X@qzu6sWtI%`Phv66ff410qHz%=;0YKx6bf3LZ+v1vr6&dglew?1x0lHo=K_<tTUz<kJwWKTXXuww#AFa^g^9-Xe$$n@&4^KLAWhzk+n2Kzic%F|>PchCn81LWQ|*<!6%tB1!PvVtca<W@9N=$kf66E1Pn?RFE2z|4ZpG_+y%;7AOGmjU__Gn-t?#0D?mJJe|41-k?9Oc!18zV~pR8X4fA6$Q^vbBN!vXC$zX@Vsjvtg$~iF5itX3gkf&?hxTNs+v4g{Akge$?kUH9X4I9aIZ>LpGw90HE`R~^h))1lgK#;<ac^9bSe#EO79;!8)?BrpXiy0}z!%57KCHtMQW4TXUg~jaz{+%*2<<F`PWB<wf@h#P6z%Jz=HpKimXr)gkp7b42NFbRJ`I-m1{k~B%6fH@Rvd1TNjo*3@4^z_qv%So#{x@q7<P6{QYb6-F(dhIXB=ch2r5dr2RQ-=QDkKEYg&P;7vQ0l4uT&ob$5Y>=vzJwH>l}A;})YTL+NE&A)*O(F{!H@4OA#%i?D=r(#3)@Hj09TCCtJSCR+^Q98!$ra04U+nd%om4KTpPaQcjEpj$)>a-6d8x1@7*PJYX<Axv4o;5CF;mM*+t542Qai}YAemVi63Gm;D%>kI5pFDLo7((waelMN>MMAjK3Nchnh-$ar81Y7xn2TvURqeFrL{TZ95dSQMVlD`miI!82a3rKv2AVP6G_6at+ciZl7{JaMbPVsNuvcj%T)a2&Y()@Mf8`}dw-TM9q+0zz#6$K#(Pyt3tB1)O0ChAOZ?`pM<?FoxxZXc8_92};p$;KRVgo%ieIVoyq0#^VQJt-s2N*!Cy^W-i2dKHi2f-+;56YfZ!SUsT3tGcw<@&Y`v2iT2CwGpxG`>|WEqKVSoc!I=oYE05}a5=MfBZ})Hx1%F<qitDniMkZP)ulr`QZ0Zk9;%|0G*yX0z={N06as*Vnifn8XVTmH>25h@Ob#kiSm#d0(Vr8WV5nA!aTtm$>6-VpOo)cAqyosaheqFsw*&n7a0Q%D5asgke^fL>vik=D8oFC|JgiU~sa0eHvf0QjE{tGI?Ts^HntQ_)m%;3y>4g$4aIkGh;(OnTh-^lJ{>1P_K+pj#n{=<Jq?n_^6#li9<+Uvq)Sxr{+e0$gjU|0CP2F0L&hR?^u0>UEl;YBaw_NBAJfCD*y=-VLB(nE1sxuFuXk=h+<EEq+XMH><4Ax78s!QM7wlAgJ(bWj0!Y06ADCTN7@q$u!2|#5f*am?X5{TDiFT$gS5;0C#3jfQG6=K|NRTx{7V2qGp6jWXG@uV}7U`xk1R=SBvtTWK!AZ*lK8!6`J#*%^*B~caA;DmLq>XEWaa%doklh8Z@_xf4FFq<|7oggi`!rnW%oW%+d8D}xV8K9{Je`{Dsy@;)GqxnR>dfDpr-TL+0muWzmCSJS6x$y=5-e7_|YhA{?i0R!ZCNBSGjj^!)-0f>zjM>>JNg?|3%J3=RvALSEIB|yCwCS(gLi1T&Xn@yc%`v5;FEl$wUM(41%^PbC(xA*4p4&ddqK&9CTX7oR{kpY{X(aO~>?KObEUJU<D?#hD1TGw#`o_J{S(E!|sw&t?lAl8l=H&xK_rw`VV%0k&IOV0%>IoK=hay=)WC-`IA~D<VvVd7yi5z|!=QupthTjwAK1S1wn0ZK8$TY*G9xf7pmcl$>peDgF#kQ9m2{y`+7Ap$=p&ZZ=TG*TBN<H8}jseD&v`<3XB@*x%+s3enqPC#<U?a2iAt?wkt<O?yk%~nNeJT>JsR6>?wA!@#gY0jvliEgc+TZ=F&7TYH?`bYIl>A*(gnt2by&XflBc=XmPB$^h0VzmRBC9;aP{;~L9erw(boyzsbui{=qFJ}N?r`d+kKZJRm8hDkxb(OTz?>$D4yC!kF2DOCU$j2Q0iu)xk6_^8;FfdyX2`PUX1{=BqfRcSBo+e)9t74iq@>w~tNT-bg$@Oc0hJXeh@r((yfCo#5_;$igbWojNQkI-5~Wsy>z1Nxcty9dlFpVUU*MmD+ws{0ihP|Ua+0zP;f%ZwyO2rZQtSrM_6RTTsU<YHQ?8T*kIX08RN!5kH148&9}TYf7cG6<hxq*uYg4sgJ}`T`Hs*SFZdxB<q<S-$8adpp44)*Wki@nU5<F8OIwX0_b=__HDEW|lqUv!(j;KZi3JZJPC7i$R(wHTY;Yp<M_eMujHfeVZGwKBKXku6;Ea=kAl1`?a)ue4soU!OMnNFc<lsR)WdagJ|a(0b*fWVbJ=0!rO!~Ej;Vtr$Npv<&~m<XMw+g8#5EG)^gD)sD)btZc5uAcjaeKt=PX>Wb2dR6nr{Lj~W3x+$jKf{yh)(p`8gigqX(yo`!6s&Vac%XWbdQ>fm;Y0@GB3)=$FMo|eD<tzd2*2_11rN;O6%LUo!XT~WjS92IXA2xJ3HStMM|o=SP|22Mhyc<i2ZgkqeNbnF!59Yc_<+|omLDjJYLh_GW`|8p{CaB~MJ%k53aSv)oH-BmuX}!-gJj6KcbtqBsQ4e_`iLAO{JJb=r@G5cDL(TPE>w@>R!~Q3>=$~?Wsmta)>n?2McjBri93kqKuMQ}BwKH#m2sXhq4_QslDbrmFc`9u1)DMyI(w9wonxy7^sZm^ISC9t(AldaR+-I4QhePrcWh*!YJyle8EUcj7jbO7-W!?+@t~l%8p4BhyE;7?Ae}RK3v623pM~Wc+0R6($km>C&_Wko6aDHJBw*!(*0X)OsU#yKelP{J(S>`;QJ`!i>+0uOQeO61s`)gtYjFOfH=++%Uazwv?khQ5sv4T^g9ITTwu-ntMo&_r4?3tT5W_*s2&IV@2HkV)rHjeA!FVWlt%=`47ICCB3#UzueypOV<*T0i00}|}D);otCc{c>MQnO1;BX?fC%PW2))Q<UmqtZZa!K*^BDI;*MuC=;kbR?a1#4FvcP-VSI^^(}7$*>MlKfrktG;ahZ`(rZF)r^l8J(qPXOqz**Ml3MQC?_xIp0`~`bAH9CPvd1SX&6$%!gSHV)h@^5!M!@BXu<v3sP<jvkNIXGh^6TqUA*+f{vuz0*VCwwR4bh6k&sE<^!}iG>=kz7q=j|Yg2kQ;$n(Q!c>qX3E%umCAnnWNYur$RHk{SxrZ$@NWKg%)SXzos>nxaj+^b@$R&BN?-ktHR2lu&+?2FQ3|tx47P&6Ezo|SES`PI6YTruZBJ8l(W4so2@S0~m;WNWalo6djseSxg@X7eEvDmlxH~oIDQW7+ZsL;&1ktS2Wht43EoIu~8v{D<QAe5d-Rx<0Pa`MC>OfhG-okR^z54v45dT7bFg4$Y_n%tO#hKwsns)ymcN|4b?j^yN!V6~I7P-8l6a*&!KEh5RSEiO$QhPD%79~WgNMF^r|>5Zz{1eZMagZq<lN9i&dC1DYjh?HbOljT}mz0mB@Ev=tBNjb58)()5ZAle_*Ba@Px7|+o(A({Kv-8cq2E4;F<i~n#Y3<`o<2#uim!#ZbI=**o=bJD~oO@cB$Awy=hvsgTy{7>!tVt0PG`WJl+pea^N$|W)u*_kk=6$DxqPkOyQX*mp(ltZB&?8blYR`d3Ai@Ptg4FVO=hu=fZ+n>Yee<U-nyf}3$>6E!LjV2B?ar)KuWxSeF^Qc6qe$k8JZzf}k$MIPfs(7Y*iu5#S!1;PKdHv4#S@EQR;7I`?b}+eO*Jm6^#Oy1&)0t}lV0EwsomjN!Cp<;RBr!Ar#|;gYft|5<)zVBA9#pn*R@~r4zmmLuj9&(CgoTM8_+Gnf-%3`SQHwZ0^{IT%`WkCmoV_=fEeZdMZARPwlyEJT8a7?(CS@G{wpmQFb9zI@V{h$w6@gSv=sfMkKDF}gT-3_rA|R%6h1F?;X&li#kQ>B`x~XkZ;J2PLnUc|_0i+^APvW5al^bSz^s%lsTx@K2YZnu4HQQ{;#jr4TB@x^CHaDwN8EUSHu6ob}?=wjICVS$X{c>}DVy#-sAMpXUwpMa*{9IOUeGM`RSq{Bu+29z>@h#5{p=54i3(U{IzLHx^P1(Ei$jnBPHxofEo{RAHLEj>Z+V>_8AD}IbF6Ta(*1)`7GUKKh0OfCjlmM|s;vT`fk-KyuxqR1Zm(&)y+0;JqF?46wzv2S?i4U(+&oeFGTw3(&?lbs%WVy^Ukik?qpyetrmAZmJ<dJK~qik7@ws4sDnwADx)g5@}m6gYJ8r0Bqn2(>mpv|ofYs4W~#~|7VU1TC$$M^xlL-oNE^=M!^d6mr-Y6Yse<R@1|uLnP{##a|Fn7^RW`MHwV!)g_tftL1S`}swqf)j=C-OEOGy~$kl>hYI@*OR=Q@ar*|mocn4e(6p+TED^czI3#EdX<YFnP>-agd^>pxtr9_%;d%*IW62T644agP(o)Jnx%*}WB#1H-T2G|RR^pi{@`V%WKyY-FMg^ozH+6&!p9gyZ#i2NvsiY@pws<5dwS;Np@#cO#vS#ZV<SM*ySYTtlV2E%KeFlKQapjmV$88Y;1xEsj-a|6%A6g4dQ^L!mT`^J+69)HROw^z-CkHttN;E4iYu8StTp4(g+J9a4)xDVVv}y5KKKEN<y3Fp3rgqH5%No@=UusvF`4BZsM!Hpwe^e!{FybqkWT0Ly$)F|%EO2P40A)7O4md3mD!g40~We3RMP?$B3&n5KM12n8f!xKJq!CufemO2qeLLjMCvV0@d5)aTs)LUo>lO~sUG0?9eyxD4u6bpG+8g|6BZ3ks__}3zMsc5Q9NSU5xv8YxUw_>EDxkal0YfgSKFFUU{HUt?sj-LEn3Y1`^7;MGPoP}uiT#u*E#S=@%y+ZFJUtc%2SfsF>d)2mW2*wl{vz|bsZUwmg~%xZ#2S)^}vg-tfOE}d$I*bj_RF3hK<pGvA}{Aj)0FtX-B1+`s)L3dkLzDqbgjF)=^9%8^jwot-i5+Y#vR^U7=f|f)w6$^=Z@DOg4SfdXc{5gJDMXKF*~Yy!WIl@Q5KWtg1@gQ+Q#ZF*P=A&|i7BZ}dn{`D6i~MJ4!x|Kc49(z+W^%lTq{a_GfD(K9iHx+=#Kdm*$>A<l<<LiCMY{7LQmn$w^vbiP8Sv|hp=P}vw_zz=wR-AzBQqjs;3vMFxpyG~l~Gkl)IF$vFrb&}AGhnF;P#k)LVj@3&GzsD<!#O!2@^paMPg$2#GbM&fGbF42rvU>&FZYbono_ocMi8i5Pg+6m^chs(HtWWfC6`lkYJ#`vGF%7&7zrTifAsGL`Z0Y~~>Mnlk{_&x4N&;;A7FGfq##FeCaq*CiQsRx>s;HFM`-*adZ;}tn5Us9fg?K9hNUWH}kZ6h<QsuDqCsB6n#ukv3y-X0FL;9n^`{}#6cCrgna0`yz(P7zLY(2<aJNhl}N;6p?np{-8_369)$^C8pvat2hi|a0Rn483lIMB)?Z{@hBZL{;wjqH4fR~~<P+dMXZ!}YHM8?K(2eE>bEo?jWZt>~~-OH@g5t6FT|CA@M5jLpjFPd6f)1#ouJw)vD+)`|-Tc=^fx1|sKQTHuX;|JQT0io`1IwvJW~X6!o8<kpT>fHBIc6sK+p*@^YSI71gLowouZq~>NtML`ssv3D1%S?kcsfdES_4l3F*)<#xs=m<Zk8_ixaIBa0kxeDufP@V6@J+8NW<wT63<xB$*OP%{souW!~tPvG-L}o!l7*m~CY0FxkQh8*I`ioGZ=|cMtQn)Zuh2{}g9X*_%_LdMupV~G)oq(i8ZEKH^_K1swvIEuTgEcP?(F~Vd^QMawx@qEPwBfjDvu6`@nmw-A+$wCWp|>hWsBH41PlskXCIeS-;fNQ`b=lwZbMdE6n`Dr{OVKHvo1w>^S$IV)d+^P$Je#xprLlA*KGQEn1rVO|qn_X6d|=iT%_vel40c<C(J7_gBeRrqqlS&T3*8_4;fPXS8;Q@?zZR9Rt<A+vl{U7ePLB@hO}A%@Jj%c+7J2PnF}@GNUlYEUDQpEdDRztU&`|G<W`(#m@kBSo;#fH}zz6C{Ben!6yMvY`HnN?3!ht%c+V~U&KLe6)0-!1pF(DuZ%${59z4asdWT<kQT0xI#fgc3P`@y`U9-$?FW@!vXXY<wld1r;9mI~JK?*tKRnh{~~8Mh+V5v7+!#ClbFGKBj31+9tYe2=De_i38e!elnH5l_3UV{a;3mrqx=Zr94zv*mYkzi&DL<yqF+fdQz&eo)i8|GI+Kxj3?$2VV<X=eGo{y_IhuL6mmBWi{*kFTtTDh3RLwl+1wUg8|Gh+ISIWCm?(GOv&p4e?@Z+>+Rs1b2c}fiB<Xb)a-@Vt#6!~)`O&A+I2wEsF+v)`cCZuJ5K%fpI_;blwqKk4cWU$fh8FMHsK-1U4ct@J>U)tR&$WC)dgO3&kXhUS2ar#?N$K4VD4YH8$5sF=q|L6%qRS9<jH4xjGdJGpRna%v!DZ5pa;{$HUQ5DFFrJoBQ@I=0*|Oj8L~16q08!Df1_UM_6NWPfelj!blom57+XW1!lhn6l0a)-eB>wdTVr87n3i*$1n5Er<$j!D2l0!Ixj!a)s?-S&_f|NsvG8B-o+fi+8gGU!U}oL3x|s!SX2%N;SURfNX*6HM1W;)hXH!Vt6U&_EC+iD|MjtIT73w7j4_LD*wv^1Zgq+sUK3KK+3tl9dn|6NLqBZRu$DM?0=XaN(;3%&nz_B{Q!0Rk+clE-?2lpJ2<(w>6>NPR?DvW*MsL(P#E2L~-z2L1wRk?1(yjIvKN3@s+BH*ze4RCqParxH4?{NN)KLGj`7W2cnZw3m4eur1kZ}1=n$9*5u`3Cg;kfxg5rw>usNa{dH-pA6KEOd?r%{+97WTt`CqY%x2n_1nd706kg1`=EdmlO*hYOuO0YkYUa$*@?8wLQB=HOijktih6<_7knAGMVj9<Htp9m*$I?OutpUcoUgUmh=RZXWeq*Msnhe=+{7JzOD!pH3&`ASIw5B5_38b^N^KHd80Eamm<bU_0TEC73qh^$#xDp<5LWd@kzw<rSRXsnbLp0$>+mBXU%?_($neIv-)%*fv=m9;H#{@JD_NR{_v2323$5AWEWRp@JRC!tO8bLBdi-`6M`DFgIQV|Wuy((i-Y(Drj~3k^Q0V|)6T)NXAs6!#b2xpocP{-G-Hf<>YW8Kg6T5n=aAPMyRuHpL%+q6C-!B-ItL~=J(kxP@aW$nwvOp8H)wHFQgu_u4cI)+goG7ZoU*1dwsCf46gPm7OmH#hKUt}2ovtV2{4+QfEO}ioc#Q=Az+<%zLkKs|Y`6XY>T3xRzpZbM1^48kaGxZW?YVb2bVBc>`xL^C{p{IIx~?W5wA~XlmvLE9q-!GPt&pA5qFqiASQ9SqJ^8EeN(9rI72ry>oXps!)oM$ekJN@GL_%Y39HieUm1EV2tN1nCI<puE=SAeo9vf~ctPyjb)flRy>u_n2m=c4SdZz9jE01)*LSR1iT4a^oEb8PBw5f~Ac^bRsbt%mSeM6aVe`^Be^-BHrS08KNStVZ&1}fHKS5|WR9g+5l9>jRTh%GDy!<yBX!SpVyhnvBm0D;TwtFK9`k}X+l=>yq`$fE8hTQ5q)h0L=|%3cHTtt6|PO*J~)`8l^5*oz`aFA89e-GV!50eMe)y9vF9zL}k-6HU)(vK=3wpAASearGEGuq;ie^Q#%LODu_TsY>?K1}5Dv0O35cSk!qIQ)gaH=*x%>%&A!m-EZ;~w@UkllaxR8VY7SgYeTnMq>jXFzQP(J97B3d7mb22x5oBeme(>f_1m>cb-@Kh*s6pbH^4#F1)))oVWL&ZAcN(A``-#F*qZKnKM|b4VxboWu_<Ol8{or;lRz4sT^Ku4RJ$c1rSt}UD4<B#YdZclN8u@>8GfYMwm!~=5AYi6lPW1#%14YuVie-U0BV<&p2!0MnGShk^sbXmK#99C5loOcYC`%03vS?hp*-Iy;7%Q#*I#&xKI2_7Hb>~xWHM}9otC(P1~?iK%uO9<!T?Kh6-16s%|K;rhXUk*<cM-%ILldDSJdeYpUy*4*{{wqmSQ_P>oSqadO>XV0m{=g0)7ZH#E}jbCj<@$j($LpST%&@@4&B@sAeD-)IL7F)c6uuz0ElOH)k(Tg<nSKJ_!|o%kwhl0t4FfY2*edQ&c%7XO%~pRB;<*Gn}n`xObYnXMV9xHU<Rw*TjG^h0bicuz32M*|(#s;ZZLJwF%E?|M@NtC4xhq_1;12k_j<ByjPiZ;GAd-cG|K@&uT2atFrM^qK$0&&5Fung7E&YzLDqFqNinJy6r)82~lJU-o4R<njFYC?3wCe_MzM`OnAPZnsG#tvGiu%BP_z1HGjb!m1+yyp1&VHvgKBonawS?fxm88n-<DW$p~4l1xA8fx9u?XCR8s=$hjXgH{R0HFtfP5Q`fCG+^wj*>#kc`MUo^<So<xm+ixm&NujJY@d|IrSRZa~!WH33*Da+LJ5SEUe*Bf~xdG4F>}eO(|K)?^2^Qq9Ywrzr`f%2Binmn$IEzfZ^~R0#%$%adRafuzXR#7tbb`hD$QW^(mZ5H_NKvubuu*4aB}stAjUmI*z1w`plr4>IUiI@{f00GHF2>iL!j;eT`ir|Kt4`_l71;Cz7s(!CVFFXFZsXptrev(|(ald2Q>#D!bKA_%U#TKLy<LuH{XKQujaO~IliW{wj{-M6KYVoGBMNM>r_ka!lGfFtl4X1W_5V6{dkEf>R6rv1k<>Fp0)+*RF}odkBjz?UvdDvH(CSN?gFoDmB?sZAY#Jtn?m$f;nVZStkaVYjj)2c{kht}QY-`@M6*l4N>@`Pe`dL!ru7UT;<%8oONZ5Vkk_!*flUn(X`3K;4g=3t{-+er@ch||KYc6mr`&dG~b=db69*6wP&0h}FKhV598xSZnYe0YaC5<n(^XF&a+w-&S{26^VsQ~4gO>~sSnsT@VZ~hTCHZ?*;37^BQ?FpYUHVaa5)IlDxNnMS#X`5hoBA|%%hyxE*=H?=2-$O%)vmk#le8B^r7+m1Wb-|!@T-niVeFpX_tc}78x{oMOGvk<|7vgxT#oaaJ_7v?@lk?v~F^ZT>(y`7x`Rj{KU`9Hu=0hI{xk=40!fYi+Yr5QRc!;P1JT8nY11R#rPM$U|8@km(NUVR_!#S^}OHfMDB!2{aso!I!o%GBOc4hc$Z=8mKg#aMlI(|`3yc*=zh%_+>uemiCpHow3dq%GymNTYkkCqYiSTdn6un@0N^pW7a)XV}`3wQGrmnQ%64~D;CO|+suQ4XTCMldb7aP)>aW*D+(!J=h&P*<5F7niy={4d|sI=ObCYuFWxtJRWZU7+F_1KeLTnI(*fP%SYEGT!akzin@NmI&ZcXR|GO)1*8(c%m)BXUUP$FDHA@*1DIUSfFQViy*vbZ1F~)GAb^Nf@-J5f39`^IXkiUt*dV}Cb3^+tqbS1$F3l3g#5-v%5K(%jOzxZRb(IXdTE82M^7lkyspNu1&5mk2iMgRWFgstqk|Z}RZHCe;u~}}Ywy{b#ZU1xi)Lt6hOL`f+FF@$Y{tgRilS@}w?1aX?3s<++Qh65Lsf4V2Q%h7HXbD{lgN9>HW-tr21Lc1WH1M2uibt%9@(C7dIa5A(_2MH5;lMWN-~aA3>QpV7$8`rfkTvb60Rf^6w)fV<VYTZBgjy;#L-rNh1ip3jVS0-GG;@V>E(R!pbVz2z4a3Z*MO9yp^_RXL)nRu%wr!hu%`6;fK>_U&ouuIx51xpUS7C|x68)f`Nm!zDM+H6h{6zn{p$L0lPB04V~W_~aFBv_bQ%=5ZVfa7c&xpLDOZQvj=8JKM*`CFEz=Y3+aZLbYXn~@EkJA+8DrV@;gf7Ci_5t>l&ro!?a*^CEn+aoJtJ@!C-$IvLlfyZIMru^U>F~Dl4J@RkFKpu*HC`Y@Bj!dJ1vHNR6dHics06s_ILHZ=l2ekpTcs?VvIeK{7Bmt9;k=$mZ>l(s6pQJXBP|QFF!0cVXMITeddN(Bj#?xYVwC|xelSk#e^j4!~)%;5EtV65t4OdFxh|Y4C5QH@vf)(v@{VSCV5Z{v_kT|F|iTB^VgybTbSuyd^IRX5LwUQJVwbF%mgLK%FXGQ34<>I#mwOpWsC(yaLUp!hbO4r9BVQ%*>oBWnj50m^G1WM$Fn&6V-T~wj_O_g`A=@#Z$GBqTEmU~y}Ng?ZOZDcYe1C5K-L6q1|8j*5>1U(=^BbV3GW4A^F>9cm-zJJeU(eRvR^o;Ve-N&{epddQ2F%*SOZhqK7%Sdvhvq4knUVa5S#f0JB8Mf?h27e$VP}qkG(gD5|h5u{2z9Kp1B4C(;wb__ah3P?`fQo5&M=m@Kb9lN}U@6$2laUXa}m)H*~_f)U_C~^<Ucy$%+_OmlZWHNlBDfG)CJ6gMkK;L6>~Ju@+m=su0Y$bLA84uavWAz8ju#UEzkIgXenyGEIv8twZn|K^iMTE9jUlnGi$C$T(V3FH<s$VmSmScL*LVHnWA3Wjy|i%e3mnB4fs_-kc!+9f?Ob2(Zf>s_pRwN9&_tW7|Y)Tvva@0bBc9&0h%9fwj|T)~9|TBq6+FM`<jJ*i^vJ4r!C+2wFo>gQ17o*0j;6xSyv9w`nRQo1l12&g%{}0EiWuX+j_=gwg%v{0((ca8;nWrw_=|9P99zgM?_9Ubo&0wSk?&OwA4p9>WWTD^6!zh_m>0U~#x6C`i)!C}qtVy#EAU7BQ2|f1_nA_PDY=ryu}_ZB9L_3EKOOO`A<~t{s7L8>F7p#D8d_2rfP-PbC>}g{Q4<wqP)1fB{j>Y7$3{&YX`1XW0t}-jTo_+(RJ6#Xh~GV`!iRn(7tAQklAZ_bXq4W*DF9iit@%@>-lk$3Bo85AG4JB_3QCH5st1I=oT~Q{EeA$MDLJjl)ZgF^~CnL91TT+EGmds?wU~TM&ttlc(-BI7zF@9LX7+Yb24$(!`6_O~GrD3I*tw`n0^V*ZG_0%2E-<0)0T&423i9ORlgJ<FlZkIK9Z#jl4eVCr{I&l4BarV$eJ`%O_r&Ns%?Bp6k}|bG#3A4S5Pcrq776E_bbw^`~=2rVoj52B#ztWy9cw`jzU&$u2ejdN%d2PO!H}EoBf(W4jPzL^Ir^4v8V}f)(aFMNQeeiO%>>$q3rLR)J{dvyus`vvz=oy6!lCCZ|$3%uk<%5vpS*<2>v+v9&e@3cIuK6;C0|^#tqcaK#8B81L;k+90N|`f5rwR-Yp5njOcV7u|cu&rOp0u+jssO$IkldftI3L;|UtDG%ouUMPWaB)J|aAKEoXh!eVkQX}2D7=8^>>5>0_hMlJ`dGQ7+v7;z0WLUmDlSfyV+>6jlSo1~*YUI#a#lJ29=j;(9VhxRBqCQ(BA*l=5mFjjzG-h<fSTal|@|hOxD0PF-B~nZpT_i?0BkB1nRge;!f>8C45{oTe>-b%Ue56wH1s4TpQE+idkKx`PnMeYSZXy>Qm%enat4!T@vy5H%daxiVzb9#U>egJTz)eAudN%#pJIOg*u0{sVs=!`NkV3McQgEpOnn`A)a5|*EZzc-7)Tai9$;q*wf}rHzvKv^}z#5C~P}}U--|uE}YE9f9#PJ9~ta4eMsLY1yXv-Q&kew2qJb^M92>HbVyEE#I5pd82FDP<!1r0>-HwL3;pc_0bgS@_-Iux-xp_haMa!P|@BRvQdV<{WN%b+_D4F}8(tcx^Ns39FntQrwOK0Qdf5jdKfwDd_{%sRu^n&cwuoIM!;#81}iFp_DGsE&iEUak=^Io$%G8c>p{|LPk-<&NTk;Dj;gMt-kCN)9Iy7e1*<gq~BB2<<?fM^rnKf`S7N1&i-ML?vo@z4XEwXl%;9g1KApCJ*OXhf__bAanJ)R-cuLO%l(N`~-Nd!<?#p$H*sN1O<v8&Jlj1=`KN);4W&R3-4G>eaBt#U9iWAqVRRbWYbuMW>EdsiYlL|>?HO`pf>tD6_4sbh?qR}=Df3i*w*wQHvHALUy#{?R7VmKnrui>DtW6TF`5e(wF9wWK6AajIJqy+#RJ7UBBBHUs$1$!se##YoXW4HGv5omY?MI&#ko(GaTwDO5l@B`6;`CyfR^>~7b~6j9+zuYs}6H)qz6$TOOv@>zMUhgDNf>npdu#)k)5@mF<9S4@ZWXa-jT$HgM@HaTvHr_!*i=k!e@<~iR^<4Z>ULL>Jp)1gGLUIqo2rDI`svUGboEhP8!kXl)D`n&9&<Hj7CKb(hy)2J2~Tin#;?oc=D8X)GK2<JqC%W%wIN}lhhUprh3mJAVoT`X*4=4Y|cS`2${=t{IppW2y0RD{Tu|D!~`1ZoZxDxU+153fr#P3PEP`7^scih73V1xF`w%0`Yx>h*-YwZVplz8;ZCGF!>jM~j>&qzH`3s{Y&@nZ8k;Fn=$nEncq7)${pOs(f?&j9n{tC8iOp`0K~RVi+%rRY$HaZ$G*YN7%70C``Xqr)WV|Dq-q0Kqp64CaQ81Z+hvL%MAtoQSTBK(5Y<nMgN3g>s2|d=W=p9?)qm*X!0`_w-V0~fJq`C6y?Ub^ch$ePE&C5~Kg{ijW@z4d@)in}}M_o}kmQn3_XG;qg&H!CigoKXXuye4lW-m)RZM&qZY!ViAu|}{2u-<IQlrWm0T}*3Am-h3>7jr}Uk>>h;yP2oUWvk`m`j<XqnxS~1>N}hknk(aG6S^}|B4)`j&yt=Mt3mI={6It$Zl*|l7q+%BJww9y#^gX9P6v$I*;%(=&xw@ZHz7C=sJPVK&H$XiEYvu$M70_3KG@aXA=`{2-AC~N7$iWls!U;c!gQnA&!g<#Fo(+bb+zTp;~LO005!D0K&D2<N>OunHDCewwR|f0s&;=+>#sFBHh5>f(U_`>RwJV|mupnT%805hft@PyFC%(q!p6}dz(0zC{I8-u!BTAZ^Mox*YlN(-v<n@n)o{uXEb;)#miLRLoEF9bISElc%ytG`Ydq6(^mUf!42M8+f#cV>$MwOGfYUBY6%#3T2EmQ;;~?u`CY`LV&bl*#f&*x0f!VJu>m5t=&_z#@@O27%PcUbFaLwnOb_}KSjyY?O88y75(RmHw!8$oLa2}pl>Sw|Wp_i0KW!2J}Q07huU%jnJ8rZGQ^_UVk842-Y=BI3~JQ`*c)AVOP78xmWS=#E6q@e9@Bp16g3L_)OR-QpP)pD#upKda0k0sHHTvWp#XrwCB4K1xa5m?v`bBQ4>9TR7Gh1dTXu}84Jfv=eu^04R`3{yxv0_7s4iWG*zL_I3MhxXgm%uDg!L8*7P6yo;dR9R2+W78_n2FUXf+r$`Nop!u?1j|EZw6h6v&2h);5Xqjj_XfAynDZ`^S-bgE^X70YAf#=~O*J``Fs**ZSp;$QeBK^BF0vw~|FQlrzxwp~fIbdBkE`d?k~jJ}@c&NRFXB>$j9O~|2$D$8A{K2A=j!X`Tg2_xj8<n}zR`@QjNU=9>hki&W_i#!lE}{~G&Vb(%4Id1lOy%yxA0~EX<_eYEIuIS)mC2jaYSKV*zDu>IM=A!p{HTq&BIe?YWj6f&C%{Qd$g^*WxyNV0!MqgZo5$qIUWZl8^L#Wm9bkD3V{GZ_88<UCaqkFlr<`iYg|~*Oqk&zspcqsxn{0Ib@qBoAO}w%4{34jWq!*FBZ22Yw8sTnEd5s_P}r@GHj1Ki5BcJgq`X{%t}G)xMzcOzOkFZBf?@zANZmpHT}rksh@R8JJg0^IG6@7N+|4o!77qkVi5o0piciuiGt~KK<{yd*qH7Gp9*g9+ccKagAx%P@4RcKF(x-^c3(AtN5<)@p9e%XV0Kcg|R{HI^>ZWZeT<91ef#%mTSwCo0hDBN9Dg><YH3vvM2tSKWtt5%A<1nMF*id;ijW(jZFfN_~<?b<jP)d^bV^S88Q1sGvMF}yqmke{$#>0ujA%|0j%AdxLruwL%%XooKaT-4)PBTVpXWL)Zz4t-p-2mUTyyVG37cSPx%w#1zLz=)Ix75t3iLIbaWOVK8j7!v;^JvPZA7><@pt5Uk`xcpLzU&U94_hI>(N9xS&N^V|dWMjFl5_`Y0nt|Qm`EV7dW*&~zEKy@-Ht)XIx|Ms+DQH7*c-eBf9hC(o-yw{^-Ll=t90n*v44j$N2W?~_|r=>zvbHc!A|~xN|48G5C5n(a!|k5R!`KjZRzZmLP6-}j(xGrXB6su3?l|WG`Ci!N$={~v<tak<uf&h*>QD)UO1^sE~3~G6<P1_*f`0xWnsMGHB{!#O-#_0L<Mh}x?;QyY69<V9|nG$N_=$>*!8N_sZ_pY2=L_V%zKwqF^YYMn;BH(*3z9Iyn5+2A}V2QynSgo^+0(H7Pl~U&e?os5#iS#|C;Vq_nnWsQEQHw-ze~|c6`j7(QXv8mt~uq@0E1FR=KL!qISD#Qn3$XXLqcd?^uININz~E)EO-!aIeNJHVsNdsJ`4-1@Ly^=C2Da4l|k<wbhjc^R<stAFfo>s1xT=3txtK%Orqyph6b|HsL2I_JeUyMo%77fDQ@yl0le3H;yY?r&0*wKk>;LAOGczHED|mr3FP#udGS`o{R<XoIgw9%Pgxo`<M8?wpis*Jf6N$P=>G4IaSPFpTqZ?wN0r#KU<B$xMDKLIBE|Pa?3?NL3lY7doLpkWjbQgu<2eHePvni`rB77bW8vy7XI^WZ6Ex!am>Wm><Z$VtQE{ZH<wj(o(*6KSJ|~ho*ymiXp_9615Gsp*`MKI^3Zwx)3pa?U4+^0u26HErO?Lpw~3SJZ9m_Hr`u3Fti%M$?`$^P=cY?<3sU|-UZ;0<+QLyzZ4DF%dy)f%eaFv%+|S?+1+qj)q0W$zhDR;i4Q;=;mIl&aI#(%)%*c}RL|I?vcq)zfYZ8E=Dn{s)1w{Y=1z_1(hJ_iDk~y2^*+&gMN8X2^z_C$7m|aoP+{A*6ePT|Lh>xO8B_m;=f{!h>(9))(1(O(!9U3{I--SgaD%w&HBLN8t&Jt2StPG<P&DNAnQu?$hq>PT&HJ(_YPPrMvcVTwCN3POKQ<L&fY~q<!E4%7g9D`eWhL!G$Y6I>RYgbt5JB?FunAUvvWID5?PEmV%@{?p~qMiNf&~D5_CRZUPRmAj(t%8x9jJncVX7o96cpqdPvn^{iu}*7#c&iV<EuEU!eKX{3A3*y>%hKO=Z_nOQ>n$zf#xaCTc)P;63uNwoM1@lVe_rGa>muhsW*To!-L&u3`=JTdK^K=g8tmsY14r4jy;t^}BZb$MPta;-XPPGLGS4lWi_G!8_0OOd{n1OHj3#ywEQ@#6XQ(?YrPX=o$za9lsgc$;a=rnAfLcV$y|V^h4JC^ienzj6hL5O`cB+w1G7%;kw2>7mv)8)}x4qRxnFrzA2y?0lQ7R*JUD!AM5n}uP@O>oLmxSp*qN{)5GV${4BJqzkk)dc^z2u)UVF_$|ki9qomVw=4x}w{C6|0e|Ms?HgY&8)$9Y;>9vLVwSe#DiFKA(A^zIz9>6y&zGgq|q6RUU9NA5CxGTsQM0!3zm0rP<WwgKNU!uPWOWVl`xPa=f~@_T&6YE9CLCp$3^@3!Tc7ic$5ImeB~m160?4WP)v@nan{HwO&y+QRr~qh;Q0*5DI5+)&`Nzd5om;EG{n;<uS10%lh#UB;1l{ZJ^9bHV2V>%DReQIs?Yq5*od%=g=$C65!L*$s~0ITCkI8v%}X$G3DK#O;qMW^Xlw05CgGE#fh3(+1P?%T<qP1wMqnQ#P-1ai9+c0xlydcNK{`mUu{)OD6WlH9uB-Ay?e(62-U)O)G>-qmNrUO7L^jVW^uMc*3dYBPN}4@kr<Bw?5@Cgo7@KB8ugk0)!x%=!UW7Yh^`z6DEH!Jq;Z&U-XWVGDF}f(9KCnDFq4b@XQAKvvmfZG?bK5vn-Yog6Lz1rLpi5!UCN~kyGagGP5_YjMb{kbml%2dc0i+3#<WI5*vC=75|}%|T)l?nxj>nuexWI$05QzY3nbPIrf|W>=6)HZn!7*LUk$VaH`WQXo0FW}87N;$(~q{#4W%v?7L}fn=K;BX>S|&~z5&Bfhyyy);C%IHrNr|tNGBx!@&|N6>Z+-0Q`fLFmal=hZbYA#ge&^M4t>i6<cMYfCg-VUn1uh~S5N|4DkXp$($#n2aZ7fOSRQ;${gy$5t9lJ!jEJB+`=9vF0gzo<9l7<lz}FxwuWxZ_b%gA1FGSH#5zH>0Dz0C<rwmL?%b67X9Plz6v!)^NO`wJel&M1M!~A0W2_N0^anT1sIm-TuqXAV?XJ+5c-$kE@(nI~+{x_}e@fkPyk4dNJ;7O5FyDfm68H0ML6j!Nr9Z)&k)<8Jib%cABkW%w%rPi4HCon-)C6S4N<hmqMVrdPkJq63L;~eymC)y`RizZjzA!K<<o^qE>&_lsJi*gF1oJpgyMgu#mkkt6I7nQA@Yq$tyc-RoFT4ElHfg#;WIvv-rC1RnTRbS(njKC%5Ca#k6bh02BfCQZe`%u%&=Hb#=1Che#lc@GX+^P0LMTFfSG;!~L1c0H5Hxs^OKNVV+-5%JTt9R?+f*UbB1eugP9N0k3GQ_3`TD=Nq0)msO00j7ge1rIag5Gk{Ym@@DsPf5`f-gJpg9L90;YjP5ctqkjBw?2cN)?i@{(3-FlI_Hr%?7i-IGYwu!9A1{DxF_)IGu?ZU~=%H7hefDPdw}yBXpXNe+1#G5THR5>%=;Y(U{9lk5l*~AG_WM^Y{S*lyv~y2BO5%L=<5MNwOpr=bKf3q64+tP=d(5!)<9<wr@2?hjj_c!V7%43)g<uaHo0skG966AN`&kfFf0;#68oFWBu#IvIE&xWeQ`a>LG7nUFPfEdjcRr#6-U4ikLHT5w6dC;Y0I8h9b4*!_?Cf26G^Fzx8R`XJfl&BH%g?Zp?c0o)E>NyYs6nDsd}zfP!tPECA6ObznY=#T86J<imBP-*s@QBTWhur(WZcqhZ+NCY+nO(#KtPPcP8<N)zaH%u<b${q&nVE|I1v)z%5Hr|fp&f_6<PBiFtBGGgDYU-^>ZW%@*X{S(vjo<Y)u5o0}vx~N}T6mKulN#xWUn#DQd8>tJED6CQ6I*B~}3qPU}(Q!C*<iBYwbO@P-n}INFhCp0~z;gdF)%Vy@*MU}dwmUCEvpbCg#kP*M?9Nl53%4B`KkjEcDc0gW$K;3heGQOL1@{(frV9k@Wbn>gy6aKXE-cax$x7xC0ZmB1@a-&IBV$!v)Q?)Y$a-3@T_SDknMI=Q1IyRo%U4=2Unr$6%U8czzS4I28eT771x<*e<?BH}mel=Z^B0?64Hkgb5%Q0@b1W)R^vA2a)lY@;Q|Tca*;L|DU?H-W)pPzmsfKq#PZ8$!Qk_<BYz2|f0%jIzd5gzgFwOQevL++t(=bczB-f{6Wz{-lCqWg67xe=Ua}!)6pR~NiIEPkYQ5Hd2OcC<joymD*^7gxWNQ98~sUri}^nmYzNNP5=!M<L<0*(A?LbD$mBRR_un4o;N>*R*mh&76EmPEH?{<q0_)ocb3t6~~l<~>Vw@@y0)5-}SJOj`-LG&4b-rH8*|U8eI_HH~<K=i45n2K|cXizu1)geXP_dWZ7}=5S3Hhgp54#>yS^Lr_gb@XV%TK>&(niT;Boz0#Vt#VlhSv(-0@*xN?Q|2ZeeC2fQIUAn>rN``svQ=w2>bD2|i)6dpGMe?(e#R7aqp=w~P9!r~Dzq_7Q>+-poEAGtv7%6EfQ(nn!v44e3Dn#?MZrzhGIBtd9V%LPL7lSj7KEm(>Pfl1$?t-nBLk;#5wd;-nxm%YPo6dnrV!I{w%A?bafek5%vR`&*AmP7J%eopyIsb1TtB&$z(-*|$Vb?q@F6gw|Is1@FP`I!^?PSmm33rT_c43E0HlU+ufpz1PO(C&5Aa%g2H6obHk|<ban%X776wwGik)&XdAsS0Yh9V2rv3J~>cd<&7$Ccw2Dusm^Lomt0!oq;bq$Y#=P~e__?NH&dTuHnzX3ylyniY&}N6_hL-BX=w{6uCR$wD#rcAo59OFIP@?X2F=+DwFX&B3)l+=UFh7M>EC9K<V1yGc7(JW<GqT%tzhL!Cx%EEcshXic_4*c`;S(0Xkq(<Yz7=7_gZ=8%lO*b@5*23ovPQ2PdScmIs-aZ*0`M^}5?iz#|_bDiKP8B+t*oUShv)Rq>hHn_1l$L2E*uHc=ktW;Ijac&`2%mB%E87SwGtimA)Q0#$|zeuFfwli%~MIw!@={MHgPpS{YBYJUtV{P{|t2Gw$_9fjI=f9I7VUu52uFjM_XpKTc>0Qa2XsqsSJ*_XiP%vNkI<r$I)EKV>%aR|OR@`*9`J%9D>NMwOq`)c4QQ{hEQQ12@DEour{BmE`lS3Ert^dHrm9Zwi$3QtRHsvE({SlO5L|-rY<(bx!RCY;E^7SJz^4h4SOtVoKIn{4`-4XAvxG$&if^x<Ky}Z(6)2<+Rh0>?>qVBKeRfe&Cg4{vQX}W~ZpwkqvaqJq}1%w{nsi@Z+F5ywOp;v%S>(n_1yajHWR}}gCE}b6m_RlYPLER0@MfnNeb*dq=btR@ojk-X$;&k|54YpAK{cIz+7JfdWCnDsf;vp<NPIvFJjrrX2K}SY>0@y%Q?5VAzoRFe|RdUj5In#gVACer^_!H2yh4(;!t0fpT?GZZOfpGN_)M^*M9ldBXW|WO=Hpx+~5!nEzhVaw>VKWCKG+tp}WCUimqLYLzjU5^r18TO04ene9l6-0jY$S52F*G{%;K{UfK^mi@v3*Qg-EQs+69rvt73BkIJ9A5_5f8XjtaOHGq*?{LPPyma-g&SaXWTLQZH@u4OW{Bx3TGNy8+~M%L$U%j8`y?U2a-N5fdLDkgCE^DGfG7j?HFbPoR#nP$!NWlS0@?S*E>f>@tS9Om-)Atb$v8%IZKR4cNWghWe9%b)-L2r)Y#!tV_Gd3o3I>4aV+)7!SWa=A%DsTP2<4!5_|hF$bpSfo@PxGv+$uf11Qc7#<Hmeu~ic3>Q{oym@;+0O+C1f9M)kWEKVHmWb_;<nblLv+v?Y*Gf3?={7+z43JO?Qksp()v+E9D=KtYna`+S`HnOi3O+gEj@5C-6BJyB9eM8c_IEO@Ywq`fH8|&D6V9cLvvxuTCQYth1xz!sFUBbPYH$(BTWlO3ovWYlmJ=!Uey1*w3l@qg}Fk2%BP-y?;GLmxB{i}=T<>5WK#-}@Rc%sqGGLLgWS(s?RE<r52ZLYEPr85ydHu>brAtlhR)kddup6ocOZ_7ui%)XdZMNwn##+!p41`>#gvvXUs;$zWgXh|^~xNR5_HYpQX;|TufyJ*C8(+!U@oI(WbEQ`9om6N2p@Z^!PEcG0sEU$8uxdI>rM>n2MQs|>%7vzc9NOEy_Rv%XQMJ_H@i$8mIj;(gjA<$|GYcBOe|2*(i+==St+=)<wa<vm@=G0)(iIm!D7ETuN!Jtx#L{xLTQ&QbzYS#@$gfTolF8`8v^O>IVhI$4igGeQQbgtZ=2D2B*IoCemP6q+a%*6*DDe?-+*2z~PtS!M>$^OboCu34V?v#VO6y|aOp-$Q>8)?5Ul>#B!W}TnBrffilO*%D6vo1C6TEtyShCMo9;YTDLJjgP`0DwBf$PC&(R~Q>p?xsdPnpvHjRiSt%NaNpF1n<(P&*b+=VBXB+wF+jinY>da>tnPq=b6ljxS7U+kHwWJ=9+~=+$1p;M5UEGx|rs;V^ccF&b#Ybt4<C^rZlFxU1Ya1kczu*ZB9ZC(D}k8FcYoATKZfhRZMWR+F*VRYaKn)rOB$I*&g?PDLp~^c#{R$Ag@;>l+IPanl#J*?y|##yf3Fh#=HvbmW~`9ceqIb61-XhP+b2{zwY|~9(U3N^}1!?3~oxgRhC=EPE0PX_O?5zl;sE<Db#3NhR@oawAj@0T_EXbEwy20gB+Hy1Q4PAQ+9i<HwH_bHU719+#e}Mi>ZU9kXtbi7R5|AgT)Y>jhRz8UGM{gC4I_ZIc^7wi7~GBi@4q|oEjJJZW(`a!A+=~|AlQ6FF^@8eUW?iNUke!Z74sfosEit+>{cl2UH1Dg^YPVKw_MkH5Td^8jiEgBi*Ga@svq3t)Yb4_W&K$5j?V$AKU}C-aRId2YL?`7ELBGnlNT$DS|8*S^>M&r?8yWVpYIuU01rCC1=GY4{yY~u05Horl!hnE(+)YD4Cs~n7{Zi`75c?tb=EiD7jiGIFm(guV1YYPut0+g+Vovu=t45bIa=-*)T?0(E@U87pgw_JKvPQ+FH5$mA_hPgYN&wTdZ-5qvmaUYqXYVv?fkj%qG|!nney0;}-VfOH?NlMb(abs~y{H96^6dhWC$K4>qD(<{(c@G^J+sa3#?1k2yn|HQOn6gt4rrsc5B19%YPdW?bLJ%9YYM%X2rB{5KkC-zURMW8sdB?l>D-#L6`?I=I4Z$9it0oYa`jvx5|gjT76|o!EjCx^B$a`ft~a?XP@<p8Tf|$)m|VE4X+iCXW<w2TA$&=*i<<8zp&iRiq>zH~Y(?B)=**+ZIze{75UaEoO9hyI3zIa~jUFFgObI;6o=72XCkt!gtbikMKe{09sOznAs2w2<*`+5}^(j?|Hq|Ic^;{grt`}pSgQTgI=Z^=C}btub?#4rAJ#D)Dx}*WLI5^CJrHn!Z}b<#2dfB?q)_q+g$_g@V{<%esHP0A7YeI7(Nty(buxI_Z8aT4l53*2);HDz&CRN18y1e7oCF(A>h!{SX=K|aDjZKm0+FU?K!MqY~N~cXT;jxk1WJcj_4E!0@dDzq4oV&W>VeE0OwZQQE_&51F~9Kv_g<Y6Jq?1i#vH%>Dfw2ivX><TXUY(2Dc_J8&+L02}6rAK(pu@ULuoSjK&y=2ex3tU~mE8N&bVc5n?dD;4sIA>AqJ(a;O-YK%k`hU#Ts|ki?Yy_=%Z-ViqZPedyTfr^!+9_?2=V?u95;0?IgT9DAB~geK3*4!V6TH(W-76)X?{epJG+5(cVqp@J9FZ%_#_*<UY8Sd;rL8>SmU2WEb3OmhO=Cucix*GO?Wi2aF8Gc(B&G%1^#y<WDU#Z}UGW|x|>2R}$mMmd!JCbyfFQg5P)Tq71!GpnKa0ZEq)uB2LDJTU6n5kp-6`agUtF0qp+N}m|Tq&K3Ncxx9c!_HM<>L!FSmxbH-rQ60Y{oC=2>8&x7rbRGmC`xTf^uGyVvO<_P#!aeXA<PRyn7j>Pdc`k^?y++SL-Fd)gO>?<3KqPKQugfO^q{6$$MxmoBNsL)zP-rh->pkh%L@4P&}g`Wl6rzTY8tcY1;%E4Akvf`Ras94)baK#g{#(>XnTzc+sUmX>JSFUEn57aOnq4W{H)w?62HTwgS6zeYHCY)h|rvxO-HBTVOvr?g?n~O8A5&p*$R@eo@?2S#1v44?CRehte$eP(`%vype#}+ujz6xIf(UO@4}rgY9d6qVe<Gm4c#=bK<o3cq;CvklXzCg#0ILB-CHmTECi44>fI^Rr5GA>MVx#)pNY3E+9*+DIxtd@03lNeW^@8UXF~-9ug)xw|GU34tf`eZbt{YDw7648*QQ(>R0~sJ%T3l;Sc~Q_jvhTppYLB~^1RBZ@zv18{M9P6mrkBmnLehpBua6WC_S&;sarEI6PcrH5e?OEx-2njzOAyP=nIX3+%lfuzp>Uld}yu7@6D3(H@(*Uhj3{<hVFY*VZEZ>0q3*R>|n;>27%sYs$*@WSPwyYa3Ra&eQ{aoj~p1u1jOJx(n8c&zNZtk%fupO7e;Fh31-;Ek~zR(99@mUHHo{-W~vC09nBZAv*3gAweXn|-RVpYXBOvVW|K@*0Ju);dPWl1qBS!`8)M#5?BxAVD!&=*$7FI#v{j?7Ups4>@}sj^Ye+Rzu$VSG$xd*^qU0z^Z8c^oZ8gRggr%yng?CvpRLyKxSPtYHv-D3uL_qLTpGoxU%Sa*3X@G%M5-fnLUMq>12BD}Ngr&7p2rG;eYY(P{n&O{q{ydb)+Mh$A?sBF>%d-YTGyF7fso9jJOk&XZgiO)M28RA51~FJR^d##r%^CR;3z~OsjLS$*yFJz9<?0(9UCY-<MnMz^q>1_L1-cl{!rYy3dXprX8i=rsgt@ftZ`6_l-ktJXuj69D7waQ(D8|94$H#)plSkfJ^a2fh#Gtv81pmcAnQ4Jq;e?NRFuNSpFV+$s)cJKgX+<XALp+V>#7QDVi*wkWZ>nwA9)tz8`Hd9Ql{uZfnBE)9^M1Z7kE*v)UbO7C#q^%uNw-<A_fs8cL5b>ZNgbO4){&fVZ0Bv&)t-_$D!a5ve-Emv3w7<6*`$#3`|{xO-aJ^n(mJl65DCy;ESU2~VVn8H<tdwv0@ZP*CGjo9V#e^kf9QG6Jstk*xc1znyhBE4vvD??6%^d#*c-Gcnxt*1J^kU2vNDG+C05Mtl4Kf-mH!31F&r%M`Mh!$ty)QS^CCS-!jKhrjQe<0Ai??Bo>7vz=*~oALuYCLTyng!E?=|N<Efc6J%|u~IW<R?fT);ni_wHIm*{;-C+y?C(1V~}GTD*so4vte9jIRadrpS|<QD#l^GPsU2MQ50Y-$F`E;Wx1)94=@wZ}WN*-?M{o9c|t&R}nMMoVT*{Hu0G)3!5u985{ANY*2Jzw1>`)E$7W4x@BC&&@8WFa)bg-EDReZWyfZl<#&%NlT1gN3efbT-t4y^lsxTy>5KHx9f$7P>$sBPU9=B8eg+d>XD$Rw|ZYYDA0U#<Lh6yK~!J#vu`+(rR~5u!4To?emeQXH<psdAqpcG#IBJisErqyY{g5|44D|P45vmwDb{%{3rKGETXK>tQ5U6^#W`tIVf+b0jR`_D57Y)rG>Mic;<hv#!rB=c+8xkDk-1?ZDiwT~Y?jXq_-J(3#2ss4IVl1&2|4l|VmF2|!bY^8;-f1AL)<p6SYoFcUf)pcm!(8%B}6eM{+svS7EjdDtDW}xR(H$I-d2Dm)|c7fQhvs|o#PICK4-H$!+dTPWWvL8sS#oE<UN;C0B`RYjZUmozY}sv{F4|vFB26Z?17k1t?n3A^@d>STIgq+Gu}EFL|Cq-@QZpiID+3p<2q$BIP{fK3o1z?B5>-qNp?0UMm^G4HXP99tEYQ1Kc|GL4p=h6$3Ux8WC0_6%}muF2dueYyTUA`$poHt8P^1d_D0q`svRf2NlqMOy~Y*nOyay|_&~NTsPu1`E13VrdUM9ydwQF<{)q3@3llqw!EtHrY{3lWqP5yMZ4!y>2ih{QfDi8&*7FOYFsLSxG<Z=pya7`>3jz?)umrItn#4V9tD+g@L<&fcD9qqpJC{1`na20Y4g#o>R0otAh|KIK92xzA?VfR*BR`_k`rI?Z<2lIU{4yu!4uS(My^EI?!@s7lhX^-#9bp)NZaZ|%@1@z@180d~9V3a>S(Z&q0iSE$K`C&=Z}M58SRU5R4rA&9`AU4vdi7qSxlSprJ(?w^`L@BUFx7Ym8g{!Ho_Iy5ZR27J6J3+Ar&J~d`Jb}7CxY;j>%*OK$2;C$OkG#EJN+xRS{+0D-pAQmQWg(b`O9iC3X4Yscs{S4En#?X6D;SY%{iW2<=zb%$u}2sWeNL>93HqBl?6u0X?v0$kts^dR*Q8F$EgN0B^B=oD?fzmS&gahMez$oB>95K+@S7~6#6q9WTqbk@t`#crw>EGb?BXThk$iw@_<*i#q$vYsrbI8wPqU@XKZ?>Md5$?T2|(Ft9pJPgo)_hbTh9p@cX;ZZ@8HccdX2hA7^D=I%`9FTLID7;$!Y6RUEOQh{UT-w1_M%G;wlR7yO_KQMfO(b4xlHG@Y6uF`M84bidY-UluJQGx)Pq3^811E1lX3W`9*^VU$!}aT-7$*52iWKK0us^{PXS%883+Ee-?RS-P8@WrvmG9B&L|z76~GKmN(VW&Qc^p7EGWVrbl07I!Ll=*8VCxa8`9l6RZ~7PKv}SkPWzOs3FbEeXZ7tRqvh2@Aw1&(&jOjoq7otqLy;E(4GlvvKj!1Cv05EHhs%2rEa5Vx!>MFVN{nlB9E5NDw<l^7LZFjOniNaSkyA<k>Bu{&k0E>bN<>c>oyt8bl(Y{07!!Ey#szf<&*4tTmYn!EIRv2Exmld|U%!<r}dCh~s8WcAMMM)Qj2?vq+$U7G&ZD+AT|#>9^u=6lb|C7cR@4^a^?t+dOk+?&Kj5xHu;%y5i2m39dt=xR(<}q%0XD%>#XtaY2rF!H!9%mB$2CeMp>;DgFFM*EdkaNEeo}rF^gtdB+v?p^5HYMYdcT_edkUXf0=~PJ=PuG5#{fw7M1|SRT2aKqn8Nhr}$f34eO&_tg*lKCyPxv4O8%&J2w?t<G#i!D55i=%eg2t!NRmmj_R5-r<I!7gio9t({Yib}nP05UJTP!aK9cFGrv~CN{?hs-gj5)=H3+UZiu%hwwjU_z7nDuNQ9}o<ssVn8kw#u%ZRl^KDO&GNe&0MWGPtuXXc9oPXc}Nx$I$s!<xY7z)ihenZ_fWEF`8L{hzY4lShYh`LlN17<Ti5B15<P2a4Z0Gba2<F6uz%APQuCVq!t$iA)#N#LVog73s76nC!=6v@l~AA9fiYR$T*2i1G1x2nddahPL{IlsBqUVH6Bx4L(q)F6%Ez6kjPywX1)<Wj*4g`g%hiP9R9woTi~jwl$3-7%8jg$d>&BuWfHJVo$YP{a!nX%GXF8{g-7e!sV>#vJoo-&%VeVtTKhd-nY1tWl#z)qD6Ip2NQhS)uws{wYSFj26UWP<eQ+@ADBNH8mCVKwc;;U8Kx&;<^~2FeuJtNfNF@d5+mp+7<S&ud38rN%Qz%a6TI5VUer%b@#%orvCNJ;nlIFr9W}%6-Ekzg&${3SiOZ7nZoiMUUf#frLZufx3hw`vL^L=UBeeE13hZ9v)qsE;AGg0k*-#|ldZ~WDeAFtvO2jAU_B-69^EsOH2^eh9xP$bG{coj?y=ski%}PvV@>|MA69q!LfzE2bPQIdx0-{0sE)zC(p!Fi>8)Wo-d}w)o)O_3s{-7>ms5`5UKuVZkKQ29sYCysVw^p?(W+)%k|T#R(}QB$dNt7dtCE~!i&k)S6|IN&BGTt*Cf%P|p0hf74KU)p+8hCD>w>_3BN)^i%*{ppq5DQ7w}0Bk_#;R6heQw8PBo;P5xof=*16miXkw}&pm6dvVhCIXs8OqW)eHSL1lV~o>#XvU;xi&Q5<JuH9oNTa#&vZjzp!ukt}E_cP$QzcubmE{S=VgsbTvv;9jiz=zTf@LuLD=U)+9mt81_BWgbx%XNk$JTuhmE<6)bP_CRE;_KKFY5Qp8~;LQ+Gm0og2yY|<f#bZpZ$Z1^kcRg~T%TA0(C9EN7xD8tIw=B#KVP02Vqgbw0G104+uCCJs+Dv917tba;}sm|Zy#70wWHFP?DE={LMe<@6%iQ)u{b~)Qnv;3?0&k0N&T<6p?+FmRcUNy2P=ReJ0yiR0Upr{nne!|-wof;vW2-S|$Kk5H0e`M*E{``lfJT*3W_^g!Y6#%$j@*T@xvPa&@B5z}IW);(;4T@Gt&(x<G+4$U4WL2*nVu_yYaJ3se-*MqBRbd$owloI{k4d`NS;@{W=E<t9N_NUw{4`5;&gK)&hGqSJQJXWQ=bFNrStJVyh*9IJ4Y@l@{f^tzP4#>VAJnjZ@09+`p7m+V8F{O1%{FAtT?rrDxt`wJww6qoCVY1TzFeBubz9qZt{n&Etl%hCFjM2z%<l%x{IE2#qb7eaHJY*CRNKi`!_22+jqRO9yhdeYo8{nr3qeyUk|yk2Zs7ig)I2nHF~FLXA{pPTsz}$>d)y{MVEQNF&d=DDI!Ax67KKEtQ1BAWyxq(5dM|(78D~r0=!)NXQRWZd;?O^~h3Ud+f$!w~Om#zjp|<G9U3z90o6}g%RO6GCY1u0UW#ZCo>G{juGk5pSGN?lDhj5N;!*p}E{0Z%PN)%*25-)r<Kv#4ZabUNurmT)^khy|r$w{2*Y+t&Cd`jpywcq0_ncOz27s+Uk#(4qsolqrK*y1yN%a^x6t~hSrw0#GrzFyUHA|%w_D~=jLiAotM{`d>s_<CQ{?DAT$)w?<yE;wkGZy1hB5uhti#DA0-`~q8dbbD!q?6`3HYpii`K~s7Y)6@t`zNYnXUVdXxi_ASgI--#$)B#OS-jYU7P@xKggf8n#VEWV&`Ptsutkf_No=uI67aT7Z%IEkTM!y5pUE_dyk&QVXV7}PhfK79K0`CYIr}TEuXP%+(<{&QdlhEF?Ev9{ak_?t?l4JEF|Do>3^xpjiX0`7~wT3Ag(5x5j@GL!{knlvBW0&9cs2OFmw_`n>zn^JqS_fK9(!;5HA!rRhKcdH7|2ip9<Ifl7*B?>9q27u|Fz_gf%)crt`y|^sAFuVvVc;Ak<y235j=zVLiiG2_$k+7@f91=yBmAtf|I<v}KR{Ude0JI|a@tYXea8mTWEY0psRIb*PP?<|;^~~9G$6BqU{r$Rl?as@3|lkKuF=vPklA0D%K!TR8|vryKHle=F%e!dCc+KrGv8rM?05#E?WqCCO}qC^d*OQO#@gV<jURezaA?y$s<^EFcs4`coBg@J-JeZP<b}BAKwPsVGg9hEvyv3WLZHB3OA-e(_v8Sl1>GzwvT=oO-e&@$-$FN=Ez}(v#R6>}0d^x5@oVQ()KCBa{6ypQJ)o>ZXI@0F6)SEM$`1i$X|#?ezq=_5)!+9N--s*U*w<+#6fQSuB~>kn2Iid}J9myinOEt6+T7F(k_b%%nZ}Cv6DzRfty{%~!xL^@tle5)&NVMbclR{5fQ&_x2@I~<bO;tlvVjs~R<&J9GLc#<{8ByFT|X^1=~>xwrl6EGtZyD<y}_5HJ3^R=!tR1+<B9Yr3%Lp=cb(#)WO+jfGi-z~@$Tn!O=w5?y!ds8kNIz|#dYSl#C0NY{8WO;WhFK<jS`~FJx2%yW4icgR)Eor3tF@yah)L4vk9Y}qgbIyqLmgzu*I9>OiDYmo{)MUNQC{dD+lz)9HRQMq6bCtnVG#x0!xBA>>ayyjzB*G_SySVfW@w#B^ycds94McG+8YRipxpx7JXRB@R$>xo8B4bO@t)7hF%AYQpc!oU>MQsm+TpjK=mWo)RFd`Vr<0@3wmqXirH^`&INUsWvxL@k`cUn6`twmk=&-tkI~N*5OAZ8LK1Z^b<gaaUGr+_MB5nER{vYJR_=ogggzgDwP2xqGe_SA6-RE@%ARpydM}Tft&jUu>Kcxf)r!emV^r$Wq<vJTHglnIO{gxh5INFI^378o(iOcHM?v6$o8#-GoaAaJ=5lg~Hj-OiZuE5ASi+u#$6&5vpmRgKtM|@ay^MK^0vH8Hqe=RTENknfWEVzkPR<TUb-HzcH;Sd*(JSPm;TFvG$G;Ye_0Cdcom|hNRe7Yp-k{}W(f+zs{khZ&{&$AX3IU8rvT?xehnwI3^q*hspFh2yU-dtKdWU~{hkts9fBMg#-r+Cu&-ms1Gk$@Wm(TOp@|9fnPx{ZVDTMgxK>Zr;ZTa%vtNd=hxAAkoHoy0upX;^1dv0tDKhZzqm-Nr_!T*fJriRr&*H;zY-Cq9;pW~mKpTh_Jj535yHRy*A`QG`f?*8)bU*G;7?|-LYgpeNH;^V;eibGvgBUTsuXMZgryUEd(+b@}j$jF9RW;ztB&x`^rN$dtf6)Lzyx<Tj`N$3(CxL_sY<Z{~5@M_K0_5<ZK{FlkpC+sU)D@n(%zpNAL-fITuJa3PQZod8YZ`S{`_V}xpEC&qMTv~n;4E(sfg!g>&5u!ETmv@vkL;IyFE}?7uZrrg`pqo!fuf9|lrE`q`^5!~ASYPDkgZqV<2hi#|4Rq-*yuBMjjEMSkSl*iNmF@hii?s8vFMHe`U>+lO{dSSdWyjl(5MDjaus(kK6~gM0(ozmq$#j%QNy>hm^2bo?*?yC}6HU`E8Beu;+V|*xipxI*Zpq2isMdd4fA=Ty#$Us$zmE5h{Gf9N`>RRXtUiJXmFR;{UHj+j?{_Zg{TKYfe|^uN!mAgy+k1O&!{(FTe_rbkvi|+J`Rn>m`dW{Nc2)jQ5Iom^?c(h}Z(hD0V4rbe+b7lj+8&et5N%!h@Q?h~U-Ru>-}k~d?(?fp?UHNx&HHfoKF9XKo0PMAQm?;@lCtfr{WjWaY+cM(8ij()@1|h<Dvw=;by7HYkV!HRr9FYzy}4}oFVhZoNge+Q6IWC8xpX*Yh~-cZKu1K>XTgQ``njV{*2H~`Z8dO!_F`9d6vm1@A<F<ffozfsl$kK5h%JIbRZx5cv^G@t;Qr2r#H7ycnf4B}ssTj-q8eyh09#B1cP5~r7*hwW=0p@<y~RKYOL34b9Q0uDS%h+=nTCwp3zVAjh!c*n8>eLQ+L;|!fO()oHOhd3Af$d~+m@uTU44slntNDnWp4rwx!$5Q5BL;eqS0*^WQrL{vKqO9_IqQ5=U@t4vjG%DV*tBECM@S4h8r6qbyE`_R9*6$3ml+sQ!b;oSZ6*@dLk7dOLBQYS5+;;`6lRrC9m72g(R0KaWVxU9S7@Yv&F3;OO*!mK5?O(fmo|T9&R+)ned)zV;N$tR3f!yh3M^B+QMn$8olQUakS{W9cfx)H1PznW#w@wW2R=BArw_ej^j52)mJ|l%VYH_nRuo4v#c3h!YwcEri~uro>Kay-NU%D{*<Dd`hMf`j&3vS@3{Wi2ul85_Ji2}!5YG;`ERM;=Qr6tn!^w_*Lm}Ob<Ja1y*#h~dh^0y5k|J}_SM-~)(4DjfxGvn?Y5X~FWnKAlNbojAL8oKv_ILY;_~kDFkEX*$!SOox@K1sOzZc(w<S|p<L@lo<jY->%UWcGQ!qQvg{;>*EZMcriU==}Ce~^-6FzthYgkT4VFxG!u+L022`b<SNIOy6G)oB5d*r*YQCJaTKNIPCOQ3~#jYJKA5|OTffVTq)ABQ)zRR#&u9fG+D5jHbw`a;%9X$~%X9G%|5#{U}0y*IQ!PQIh2#Lf)#(Dc4={RmRY&T_Jg(sbfwbaFwhm-lEoE(wx4T-(M87-XPHXqpXn?v@ZQ<=s;QWcS@ThGB!f27YD>p84vbVZZMuTJ8~GY*+mL{#q{qt+$r@n)^CYE%?%~EcC{*i-g>F^zrBn5<x6N=dPM<snud6$e>NaxLWav!;=?`9~n2c+BvP3o@fYi{?l-3V>5MZ3zjQ{Ik03KaJAJZiFEgBy<070n_s%WuI)O$X0^B5tmCUyTT9il0Ijbxt+#}>yuLacKSx{{k8VEfo!6$g>?rh9T))r`Ht47Q7eDxY{ifc&srzKc?Si|0$1&W!W`FIty-RoR$!b$*5B+A-itFpK9WF`*b>nXtS8>TEEO;FgyeC@UM(#0{U+exf(cg78e8d_2MC-U9D;-1gL)F&iG`R0jwP=d|j|}iNagUU@<!WB8EpjA^iIjf&(h;82GY0R%KEcX-FS_#-&%r6Q5z2?ea3Pk55LO90lDqOQQlTMSN*JY1H&Oi7#FDA1GDh1Dd0}B74i1*s(KvTQeNzhDXWNUk1t%lr>Gp&fxFyqjGASrJ4>$x2%MpGvhSgweP$GJZ@~@f2zr4W5OqEw>$Ti&<m~pVOIC7avMEpXq8P2>R{53PBO`-f8GnT7ck3P9=ukZ5nLz*8lV*iKiHp6vI_SkdvowZ83u~BS9PN^P1B4Mm2c_8An`JBQlHBr}d`GU$v)bYuwB&_qyv|a&ZtcR|w{wl=m!!qarxs%|44EjhqSx%DdB%(7QPN3dGmf2532VQg6Pr3$DYqQbp>1-b#N$MDJ@kXzy_kODR&qxrNvf~7s;y&wDIOgPzlhc|y<6nglH#C5`chdkdOmLfIphw|>(TQZ=V_Z@1^J$0=^*Z+!56Z7-GA&=8Dy^Aa%@*YLd%F4Ft;>2&?{_<&14sFnrKx$4Z|^-#&A4Lqe>isguFqgv^ZCtK@HGc`l=h5_B?YO*5Csj8a{kWPCs*D;hhlSNdQ|g;1a@}RElsk<9T>s&LNv<7Ns!lQF3Lh54)pc%1sECkRSwC80dEY^xuJ~vqx``GbLV4yhkcMX6W^Uh1{nC%Al?Cm=WgE0VP3a#m~fq+JH7ix3-fRNgJd<i6;yqt=Maq<o!w+oMdy{EDpQEnxX7J>QPUcX>akJ@X1bKb0ayM`ZJSZ*4W>*dm_CvE(P<`8X0mUqsV0jGE%AI?v7x8%Gim~Z4U<KvArgGe{?Mv{<fDdi4X~iv+6Z1{BS^Y+Z;)N<MbXdwz2d6>)=#hjnO?<Pdk|(uuMNn)R12N3*LELk{pXt8_MLoh8=7gxtZm3&VtY`{H1-{K;y!vog4-6}c{J|fNS2)MDMrLR0RNqc|HjwufS-Mjz*2n4rk@RMmw|Y2nrrl_`=ncK7L%Q%{YD>pqypm*!ZWu32qSSrA?n$-lHG%m{-(Xi6l(Fj`raE)wEPvD{BSw^(nQWnd?lp^lM!@y8qG`+N_!>?vV5Z&RMMrb*8&P8b>j^%or!anf+m<ixR~C&HjO;q!t#Yb?x=LRKI7ytmkM&4yDNB}KZ`KF4+?66q6wt+x2SaLeJa8W4ooi_RJuzANNYFFlRLeU=-t$`qZX05d1usBlB7~bw7uMwCxn9%W({OT8hzV5-dOcz_}1fb;N>75<~y#^a2Nl#ztCjX)bjcKW<cpPFp8DC%+J#P`YNo%3c7czJ3n~fM4G#NX5jd+3ctp_&GRM7#EkOa7tOA$nH-Nj9c{*rl^{Fjdz@*RU*}%oDIU*Aorcn{r#jAan&Wvi$F(3{2zR1$<}_v`_b94Z?1m>U1gH2Bqdlz=)D?i#DeN5fZ_MPzxi`W%H`ZVOswMF5(?@K_M(yjaEGd(q#oHz|S<+miz(tufxo^#QBo8NSh4AX^8eIslUx`^Vfs$TPR{MCs^cFA3q(Ypf14$Q3;}u2kqZzOx5-%!dvMeHDwqOi6?YecD-Pbb@b#-%{Yd+8V5iS&GO7c-W%T`I*I8`u7Izi>I=U6DxGfhAG50O{@;+7n*TzYw8-8`E1aA`hw^|~(d1;j8ZXLGNk5l2uHP1lT47$2Z~F0)L97#5TP^1a7o&cSJvvz~A@wu&ZIK=(4I!!9xNmnZ7`CPIDc*D0A9q?&G%tRkU+N8Mt`2w(;431b)<fPt|QX_xU#jxN+9M`HoX`f41E>3E2UOI~&uDRRn7d~Q3^vv#ECWUhg_=3oXRcrI%5)kobkk^{O17a51Xn=@*(S+EBxna&ivpU`=WQeCUVrJf-lq^yXcv11u^4w8As4kdx)k=}`?ojLK%6!|;;YWF9hEjZVhU{3KJ%OEujW+@az;7{Q=M{Nfy!N1h||A>Nt)ko{>da@@!*E#k={{I<EisS=kZ(|Z5QU?wt?w(n(Fv$RlMm^!M6KWulnt*9{<(ASVSJX@6lU{{BB-K!mbM{Z1hsM!{_*9@NM?FLTh=(Q_3BH$A=T(s^*J#vcsuh@u<2w{^#EjoP8*f%Xw6lZ=;Sd88wUKy~B7n=YEq%q`2xI6;_8ros4yBQ{Itn<twgUL~j}{A1;3CC;3D!&{lppZU)g<PbRq2_1<yfBprymzOC|2%sp??MXAiK_dY6|A^{A{v%qoi>5P%cU|6v|ZafKA6t!^rHuOo&JjP3*}pPS{?8lmuTg`yAAA`4(0T+|S(@N%D?QBda3y;f%C$8(~*mkNmi=?-Nc~j^f94qho!fZiC;4&MGSpGnjBM@S()daN!a$IiimMLxQIylJbm>Lr4==u<=ZtZ7yYXIY8tIu@I`<x%hSh;3|;cYT*uI=HLEGlK{@SC2ru3E?26K3~bz+8VEha+eATeK<d`nfN5&Zl-p$0P9Z!M5fzg6tz=~tCPfk+Lr?{RSIbC(3lYCdv*^SPrM~=dCVQW!`nWy^eBSP7Ol5-fU4kCkrRG(I=`gJ?AP(RW^DxFe5OwnjTF2mvVvBd4{tp;C^9+*{9W%<cL7=?DQVqKI!>jL-24dQo+`te!;a~V_9g|M0eBur1simIqS*A(x4e6<PS9<D|QBsm`;>swAf_0r1BHa?&)^S(Ni*T>>rFuG2V{ef>#bDkI#rgk3qGECoWz_)a&s+ki=L7lfI@osIQZ&k)F`nV4BW8XIF5?0cZVd?G+B>a8o+5!BON!7`owjC2tl<ehNFpi>j@B$x$fo?MrL%kv@!Rix^229&chs*v8wmT2<TWDC;g0M&+6!}-i}#VGyv%fqXXEocSZt}{z*#M0I-Ov}%`2I}&|nC7EQSAXphc>3zr58Q$xO!LS|H4QnQ7%#_cX|{XZq-2@i&WaZvNBO(JHB6>Ycf~@${a#@(z=0lUW@Q?{%Oa)$VM4VK@Z_3xjl6IU+3tlUTxWvqgtJ&B;L{{^w14_m?}EJY4y_uHA&JBG2E4h=J}Oy0UVms}VX43n6i9pH=P<^q^x4{dj@}@5p^G9xeHu6sag!jkb)OUre=vI=$f>nw=e9H3fStJE(@UnAP6bec?RxAqEU_d7e+uvKck*h(Ih4n|D{)s~(1ze@t_XCKDxj$}6@?T~d|;OMS^9VDsML_k~K*xR6IG7yO-{NC{;?pm28ql(UO1fNfS3lKQzonKc9@AIsdTrkEr%{bgX$6C}~J)jgSHF68i%_iAY-*3n}!ajT8o$x<WX37bTZ3hFFs9wvYrtdt(1527Y*FA$Uv?fPqTx=PlEyb;gq7x6qVpK3@CA({<=$u?-af}ssN{HCHJCtc<)2p_0$TL7T157Mindpz`=D?@CpZR#Q!=xDT-xa%m$Qv<B84PX)SfB#i!M2$5Fd{f5NJZ^tN4cA_hj@U6nbMjnkJ3?<qt1)pBD~+fmjVLYzlLnx5CV{7*P05=|QBk5wIk2J9WIWXnFtHtJyNxusP&>!o`m-gY%xb5FN+G!oVT@Bu(?}`SwZd!0?@`oyt)i$NGG55nzLs&N$KlN8K%EdXEE2JWz_GgZ3RIuutb!seMd~L&pd{22X6a0<R9(~R8u(B+&;Ez^3M9XQ9aDL!zpwUsA3j!CYRY(9En~-cE1Y~^spJ%d8hgu>YrF>;V^`KtV|hW10WT&2Cu<H;U|*22y~}y`2W|T#wh}MKaKUUV;mFW4!OjAULD)&dB%8e&qPjX%(^+`2VCkO#sWNK_sIKH_a+>vfe-}7Lvc<^uRp8JDGN6x7*$j6kg?jgaV=E^W0LM0>o%x#)?M&$}bw3XM&k^BOSFWFfEmk^UpiS4%Gg&~%3cjFq)kixdnrjSWO}5D?*q-W~$m%d8!mIIn{4mN2cP5G){*KbdV$?CAX_yyI4ysc<t0EWKmLEG?k5Guk?{^Bt6MZ=h!xcwk&83zas9}#%JvQ%5^PVoc($Wr@gf;cmzJwn`FQW_VUB|>!yjR--$pw^aX~!$P{^(Accp;m^$&O*;RUaqQH&^xuQTe=TGBjdBTts(y%l0u%S>}cj3w`a(`#AM>H`MNaVQEbkbyzzI&N&2&0ir%Nbvmu(+9?+98nr2^c;#|qxc~of_b+_5jA-FNd4??;AfojSU2)#0F6>{hnaLhEbSC^so0|GpiUB>_&NC|PtcN|?6sGBMoZrcHB9#`1-iVCS%Crbw1iK7c=&%5HbfRRTb3~ED@Don;N&Vrf2amPrnP%1TsyE{5q;Am@>aKhFaM!zg#zrR?|N2XspjcO5(6MsCQEH9?u41x-sP6qvOVtB4FT;D5^Js9(x<srO^)y&_Ecb6j55QBcmiCSPV%nhILbFv{K+D)78+14-J+tLMzq$O|z7<_#%7v=TvXXnDLEDmAzp~lNuF9C5RLMe7cEo;((Mjg9S*7;u3<PIX3iq?iOZ2PlVr{&I3AK(nm{!+C`Iw@K!7=7g-_Q7mYP5F-2@&#`9xELUuvIj`yy^V|=FXbagRD-XfXl)nFG_!A<1P;`f2}3JK_$*;x?8bpB*5|jQ!tg}VM%(9PfQJVK+hriP7mB|JTQ*7ji7e%(3^u^{S=Ef^J)j!{`}^j&bNOG`Tzc)(1hvYCOX+sXa4>WrWs|p9l}M-Rzcjsplw}{l_L~;#vc%`bgWL96!2@HJ3Y;#O?AmDFR=^W0)A0o`<RbxQNJv<AckEt;#m$1TvGQI`aRLKjw)rG8*B9YNW(8(1~Ya#9I*mJpZ5(0-VlO?J(3vrY}u}Zo3Ij`Oq!a}D&7LNXc$Ib+kKq8V7~mF0-e5hoILf@Q(Ri$`&j3J`FY2+k6b53MVgc@I_4Bwi^)9~rL-E;9cL1?)4uv7@4x%qZq%{DV+}VrJw^-|zb0zR7|w8d2)6pZQ)ryLb+pRrKHRIr90XR{_-3%749wg(0!ye2p>NZ;#cw0YmIJ{RtQPNCarj%zw0>pAh9xAlY_k2(!>_CUz`t&?J+Up57>GGxiDFMR4=iuV9fW%W9y<XC<<ES9^ls?gt%C3pq8)4~1!8OZT~}juA#QRD14hDjRJiWd>BSQt`6!yUsKMa_di-%Rr>xz2>Eyo5$}HDP3i9t72jVPW<F+QIB>Bn_Rs9_cL1%4ni81QIay6-R7aFLOxrfzoptWUkt?A6n;~K0@Ttt}fxnU54(A)4NJcIsa+Ux5_*vs~1<bdK1qw4xorss#AZN`c=)HQwPVSPvJ0@|!sHUU@&rKCCnl_ZPzQ5C|!j)rq#`>oE~-z&ZmzdmNHTz8fFzmNI*E62$TBA}i-f=U5<)1Isu7psy^lQ;cV!o2VR&)T}|u}^!3NOX?NYWPMAF({u3NVZyNeW$gT9gj$d1gRC*rKgjku?xjYhS+`}WiZk#GMSaQ8JD?2rxfy0p$`5VHTeeo082YYJy^L0Ykeo<7CQfrQQj_C{-I#1?tcSm)CY(BsWzQdiXZd1VlFoR22)Zni1uClc4iG)AV4Q?AW9u6OpZTs;bei!)#r`BA&eI@d6^e<jVqE(PM5;*OHRTWpiL@uf>7yI8>w8P00K9EZs~dc*$-uGVJxp0TND3TL(&01N6@wOK|v^vVMW^Fc!{Mw-nuBco5iq#u4fXpNXm8pGksy@R3kl@%@`r}fRyts+#5r@0jnU3m%9icD;rT+4(H5H{z_Z&mm>bSs8jfN-w~p=13$U$y20%Qd&-8>HTLgP+f%M??^O)@y=WsZ!{3x=7gkQ26Tw?O_g?r0qo;Acm~+4Jrpu>`YyMHAJGB?;c$N6$dW&2}Xlmr9xDkJT`@K{FaR}A=;PyuPfSdQaq3^El!>db*mWTLNwa=m%+$a>=^KUM!TYVy}0j`Gr78S!3fqCm^);r371E54*rawxE&NO}>WEK_jp4-9b;^LZlNnZ&R$wGum-B;@$#+-ZHm>%>y?8Q5lxx!Ly#R8qrJm954N_}FDbe$dPKgrk$f%V*(ze8zgWCxQ*OD&baBmrePYcsJ4bwodi6)}2jMNRJdnn^~olI|Ao+jH&2<43-H3e6aEEfyYEZfLMT?uF+!Hyr2Y`_dvio7l=E-6B9PJCa^%`(x`XnDtlm$DW$hlxU;Uobt0R@0hwpODp>iQdqb0OuMkK;ivltU*7~oHmwisoc+NLUKR#Zna(Q5;T4k@D#8pTRvmxm8*pd%G8jJjKEvk&vj}27Z6-q&thZie%oCu5(qmA)FR~=_+LvM6_%h%O@z#{V=7iphk*jt%x{=VDVfZX-hKb;z>@3s39C>)3DTCE`v@wWzruswXWt6QiLkaRQVpCMwO#K~ehP`j4Z`*Y`oah^O^ZMfmZx!4A9xj@sJ_6D9EskZ-P;20d;sbbC96NOkq^7jqvA!Q63j;}gI<HupVJ0#yJN)1j6?3XcTW|NAyjUsg-jgVFH6yYatBU`uS~e{<81&U-+2B&r{)jVzuM6{y2qT%mU^>M|6j*{;OY!9UsA8PqFSUcPjI31TNbk1rWXh(cy~VM{Gq|d~e3)MhhHT;^R7KG0Gt#FxK8fLD7m4{jb!VObk@rEO_(KGPLq#v1yyt5T6{bk`-(PGFe&)l#K!tqa_nR8*?>icdZ#x>)MZ3SO+*NZJ_qRp{r`JXXYs6PHcfq=Ftj!Aq_mZD8HrBm4L>}b?X)+yTK$nFPav(%<7T`KzG0FgDm?goEXo_j(?HanXCV$;hA6XC_UP}RPzQPd7*1=DCXx+yfy$dj){i|Ywdkq98AOs2B^BVY<>r<UGL9^%jg*|2LiRP?#F!PZP=%<!zetDr`-7`n<M;$2NeRsKF$F8gALxz3aOgJ-_r*1#R@1><ePi_<ruET41Q09mc_Q>+h4!6WWOp{63bRzHuL<FheIUv7_YC+IdldwoUkMkVM4tL^No=Yc`Me1Do9{M+m>T-F+l3SnTp0Aqv7%n&l!ySDmtc|}E;Ex(rM4!4-{Y{g<>sPfH>ob^f&$rph1)97IKVawKg35$wA^0Z>u_2uQq(Z~_=V=`FNf1#gjT|~Bb}oBsejye_A2b8MysJYo5sIp2A=k+o3DRdv-js!%l1o>|9&)~3QyxHu8h)W&Iu?Uejk22FTUM<gQXu*r@*^I@fYnRmoEY__XIlw@DYlj#QTJK{F9<hPS~mT{L=&u;c~Fx0WkasVZ`Z4MOoZE;3Pe5anJX{84vE0o_+6fDd@=`5t+&A=a}*hp?6@-P)&zRJP!vEdPu6t=h{eq1G2u|BXs5Tf)b)V0ognq#*a|Q7{L1IH!aYNH>}~$+eJk9wSmCm*yh1}xD=XaDt#G51skZbRV8@q*&INSp=h~~fxwgVJcf(-@{U)sFH%MSt{>Whv1RQU%w!$sV3Kx~n#R_-Smc{wpOmNR`g4?rY1|Zg!of=Med~gwV?92pr3dTqIa!qijPGQ8IqB*C$9!?>^I+1^}uo+bozd<6en?Wp~k6u8JUO>n0WZt*$HNnk<_i_{SPS9%;Tti9qL`miDKBw`pGQlM_p%ccXPO`pV#F1pFcM#XviH^bXH$qH(pb4(gJ7vzpZ7>ahhe<Dwrv(D436?4i4fMNPE0rX&TQC*T!^h9+f`y*=zWNyl_VV(L39h9E(MXp>lyK;+H_6dzL)enmLGri`lBd;P>f}6kxknXv37bhM{<@9K{`h?+(#+twex2*`xNy)e$4*$ee5SSwyCzvtUFOHFzabeZURwbN)9X`_RH6}e(j$79phpEjS5!rL?Bd7unfO0<#u}=T<Vx0p>-mHEFJ@x85sPLo^bQJWsbmo^Nm21c7)E`&E8Z>`V}=%H6GJkRi-_ppVb6F|d-z3@`_bCoW;(^f`oXS;0rq2(X{DO$h2D~p5vQAe;^e^GKZTjoYf`uHu@ibx>uJ8)wzwdTe&_ROv~lHX&1~ZA?lrRswO&K*q`*5i#<usf1?vQfP{M6(@$zQ2&amlca{&*gd$%;UEyjMcw_O%yHbHqw{L-$pov7DUVI8!_wqe|G*yM)|<9$uHV^~nzk?ve~WZlHJaFUI60{OjcmM0n(GDJ^QNy%JfcP4(V#x`O4Opmig_{^o^d*$B5&In1Hmi4gfa4bgCs5fD4!F_|>yKBLn)qP3vAuhRkTyk}69uKC-__ZuL|7rIdOxH8}3cnY@(O5%(i`O-eDZhZfhMRijOnz}9L6?VK?NtN=*q1Z1q6iuYdryM$8ZZM-UV@{n1+%jwtGMLqX7&(>LKA;Yj9?x-ItnJTC}_AFZY?St*OkBKQd282r^OU55T7v!(qJd?K7<wPZ61Uu(>bdSs^Ir+!GDtVmAsP`6~oeDH=Nl&`e?KUKyjR);D?#IiCG25gnmZW$KQgAW9t(GB#{!ZpDD~<C9T;$ccW-jF{>$jS|ex8CW0rad&UE19mBOdF9p=lim6WPPS$M7<=0L1H<BAzpXv+fEp<=9vUSdvnp_E&`B0ZONsQ;2!m{aXYGT1TtCRGyOzlm$6m~jCHp>o(p6ZR-)uA_lwNbF-g<UZH1n%`2011}&W+TB`^ANY_o!HhY#S&N@luif5+*}q#+{Fz4n6blbcI7+<w-k47%853d2qAZ{1m`DGrR9WSGhslheuW@DoDrwYNpivbSPe8s74#tq;ue&rVog8uz9j18o(yl?wgFakScTk&T?)owt#5qBHSEdm!!|^j%G78z|2g)fdgp$DX=ox*7W!{qX$$ND_9}Yi@{CHHu#*ViccJI(sk0e**Hf^D8+XV;_|$Ykpf*n-A8lh4+V-Q)Wa}|5j(h^#MMvN(`KVnz4PS$$7+2MBGK;=3Xl74t)j$JhXOuQ-sdQzN28HeFL{wOvZ*y?=NyMdL=JCO~s!i-d;YpIschf~y{Lp^L)`imwQ;)6T>3oph99~#tsj0T7>p=!e4E4dh%0)d-A%ry?m3O0rRv5A&V1E_C47C*wrkO;U9TQ^Vy7Uq=l9g6Mv@6N>2oMRLT{)os<u87I9jR4|;o)AkHJgv{rt-Ivk9waH#q>VmsPIZSN<Epe@lalCN4;(?aD==i9JQf9^;^}bO}cE(rA;g<3838H2*gMxDhQT<wP}asZb#;|Js8g3VBc@Vq9Wlw)E#QsQ0dsGw;^(7PfLnW_2Uh%6rt)EAO#*p>brU|P<;4fYop{HkprnNp=q^PcoaJbKQQHThQI>r_llHq{cymDb6dggH&_c(rYAE~+ksFZ6gPVecN{h&!k5-P(L#}T8r8gMTI`sqwHBv??b~)({TMxNJYlWIXG8HS`>BF%RYw`Z=tjm-NVUA!JriR>KX@GDKcsQhm2BU0cOC6K`l~c(bn>3BHS7t=-t8?459|4=<@e;s^b{k(ePrk<0VRQb;~!fxi(mYr1YIZYtmK^l9$A&A>h6-1gDl8F%}f=2NXO7kWicw{<9+6J*)Xr=oxo{!+L{Pk0xwK56cA8{&p>56-3w235W}%|Y~UE#8>3{XrJlz1s&PWzEj25k@-LcZNC5|xeo(NY`b_=#8lOx-h6&VRGjlK)SxOf4>mgcc{Z=;Z$BSaZ&$|)AXDTL~qqGe+q6u!EkXK@xuQirNNqP=|^=^d{PzNZB`q}cTv=T~~Tz>Q9VoSSe5%%1#6quTNLcdj7I#5XI3Z*3+P;btaac0d?G7BTer&qd4600&Dgaz|aq_h;m)6hw8EqlYiKFEGAf+4;zkEn+5iNu!t_ao$B7&i=^#mugN5Z)t>aPw7%!=K$mOH#|#GgR<9Ib4c{Bv8TyXsRyvbs*+C9*~NkJFiYd!yzfcys(jz7;yBo#<-xN0h$xTroK}xLS0BS_i6$h-o;b>e$ciMrZIlXEzHHKvB3%>hI|;*9aK(mOXkiXF1D5sOqbc5A>%xZhKhjtC1i5_pYDjzfJRB0((Ht*M&Lv?QI5rQH*AlBD%C^yhWZ}EiCa)M&{Uwt*+_w%<v03HHT~@L2~Ou|a9K5o08tFz4cb|3x0IxQ;lwuiem2!1&e~zatj}e~h-&xaTPo7GY)^ZU0J7rufr?GnMF1JA!Gq)}p#2EpxwEaPWC)m=aXIpbl(LxAXG?AoF!yRKBKD`DJt{Uyy6_}K6L%cu1o5$?c+krcNN82z19&AK2ep^6ky^ySLLEv60}i+pwpZ22AgmD3Rx!nRUw6cg1xBLU5paef)DVGBo*)TytB`RR2o7sM?*O>fXnH1r_zXnC{HhrFUhk4~1FR8etKmXpk-F<&YaSEGgX=>Lo9n)l-htDabl4dp8%Xkcf~g=bsO!Q7kN@KRO6b)!nZ9pcGN0CX@>x$f<!4PTQUmHDR1>G-o?H*zObyo=!7b=*0(cD<ZVOqER9szo21xm0SOGqtXQ}ccBJH1Q-e;99mP2s2(xU-si-Fa!DY2$W(}Z{U{l^j|d1A3Lf(ZPgR`ZpQ%c6g7Sx-UT9_<N`T)HxARjrmEQ(UrMWHx9onP3{27tc_Hiuz~03D5ipm&9#`Rjc3pY_c9v&eQX<FbB2<r;k=y3JN*!OyItUO?T9v&VjehWL6N_J!7pa)->);?}$;18(sR(`T_I(*rcOEICkhlE!Q>@rO5?l_v~anmrssdTfzhG%9#|uvCg$8-WW+Z=2zdxq=ClWOob?Y*B9R6(A_`7a?|Vp-j)jn*Vx<s&l!v7Q>@A*J)-670Q?!nTo2ss(O9Pa(C=TK-gm<I?oRu1E{sK<y7I)Ji?aed?lU(%tbScN$MFG`vJ>}~*&&Fhb36~Ru8q^VK3lGYsx}|u$749CJN>{kqfXA$or!Asq>C>K)!te9c@8FwgKF@z)nK3M()ZLocHswCM3QyEK1W>MiTh#wsPi-Upl6hJc}W-iUd(LJtO=FYIgijC$6t-4a8uR9CNL)gAqG}NE>=**jU4hz5_SiR2Cj;$NAwz2Q52jgWCBs|y3W-_C^dm;1kOOIm?Rqk`POUCXCjr&K@WE*H9rjPA$_Fgxm7aGESI6(e?~Q3I+Qp}nt-CS3PeL6F@aDdgOaZ*Z`n>lsi_pKyWh!EOojO~tMY7bBs!dAC8x*C=SXN{AH(?ya_dCFnlggX3hjLHp_%HY6IN&@fpt9N(@_S`>apbkpN0KOG%*ui%a}O`$rN_vVbJA+5t6BCVKO7uuAgtGNZ)E<<-f3u=;4d@ir=DEAwgoJeU%!WRk7&#tX_#2Em+7VVpOA^)(~E@qd3mOdvBV+XAxOv6)LQg(Ys2^E_zB!O39mD-`)z<fbfJSXcWYjG8tPVOxat+x0|}bfKUM<kR#~ijp(gj?xhp4oh~iJ{t&QA7B1znCTxg^!=AEXt?LN~C7ly)-K~y+`KV&-KTz>#GPxsfw5s8;Oy+gF;tTv7!f#<A_<7bvUz#sQCz3bk|7!89v43$>j0i`J@~%^V9V6n}sRdHg6#zoK%p^1gdMCtD*Aw*wjP8~H);T|gG8pfCNM1tXNF2$=*$sH|dkd=-1P10g6dTqUfr7G1#eByJzaN>AP_Y(A>Pny$-G`N3ikev%i7L&Z?7CNj%&M2Al_7JZ=J9(mUci(Z+L<y~qn|u>Z$RDH=;-}y%f)o#E3e$sB@8?j!opqG+;bH7rnr0>`TzvgS~FpLh?~R(<3f!O^4Go!$!uFSBwsgoWxH^gm)6~C=W8%Y2nQEC81F0}4d>We35>&UB<{f2LniTB7uzt8lwZuu-`-qJT$j$k^P$UIX>6UD=niGy_tmip0%6S)bzKy>c6|&hRKBADFtG{$K>3vYRxfp`>77{ZdjmU}dGN5cTpLBCTGc{97Z|n-PvJc_s1H_p>I)B;X9x{`^Yt<jK5Ll}stnDhI#=H<x#F@?)bEE*1ZY(NUN06BLBP(}){8R+f-nI^FM*mF(~(gl$ebK)r6^SK&E~{2?tPiq)oBi~d|V7iD{)V@Qj~pbJYd!j8PWiQ?6l4}p%`|W<VA*yoY;vPcu^KyaWlQy=j&A7O5*U4;Oa_C!E!rJ`|NrRFh4lx4ECt|o|AlU!Yg<;(uC(|KtV-;c~+?;roVT~p!iHk#%Bfy?v63N?T%sG3BbtGjVS&SFT_L-qdQHG{FXb0;|6bd6z}PFNQs4{`p@Z<q4qrS3G{Wca;2IduI&~U%M8h1xNC;hco##J4TfyE4L4R=a2qQPlY?7mTl_w}ZKwhKMhtFvanDvGnXMa3W8|R6#ZW_(Zi%-GF$QCy*P)8)h|;<~G?bY6rapAvD8=HRc`q0Io{aqU7I|bO(g#PdVhnBo`zafr(}gl9rU8i&>z6LD{RbXUpw|P)&kF^RUgFCoeq0DFt54;nJHKGe?g=2-b*=_|fwuTrG_U%ncgFg`y@W!pNh0N!?kE)UW6J;M=b%hYdCsW%luvwbAIWBa@Y`^;Nq%jUe9!&dX`#a!D4Oj~M6C{Vd@2Nc>;^*}t;O}nX}iORP<NY4ROQBfGSx(D9nS6sJt_c$3^}bvI(ib}#A}v|)FjoB*&6jDw|MgKk&VryJt-L7X|`|#3xuLxa^2CamlJ9_C?^hOcyvnP6=EOmxy@nr#iM~q?FxhYCt`8rPJiXQOXfYQs_3WU&vDO}^lXxpCUzMq36;$L_Y$PCrKHKP*%WfaXaeQ9U7E>j^T*`x<v-x12V<DN!eF^%$aW^Lr{b4^yZWs!7<3%W3gCXwakimaENBmk3!pEx<K|KTPAFWK%LyBnp?EFO;4$oi3w?LQkb#OW@PVvKw^-wGj(bK2b=>wGgUm-TB3Rc)WU)g*0p58KJ!e1}Wh{sS3)T2W1~LrFN@y}_o%PFmGvZsV=gpOmZ_zgozYyXo0kKfSAR$&NFSbVrV-fDgni5ZI(M<}btTb9618b`2DU#6!-82wk6d`;yphH)j0O*~<mJmMa{^R<{`|o2P64$<*fpnE?SU8Cl;!3it7o&>&j!-Do+-39-STC=yxFlmV3e%&O;K|33Y3hbuG>pq^U>8oJ5Dk}ia$sVoc07wlj10oTNMw`zJ?WugtTz;M<-Hy#q8&z+HjQBiT{WYkJV@M26|Z~@3%u4K6#<d~Tu*3UAMJpTC4L}KSvK?U$>umilA4P5%8)^%+XZu!#7MqIjyD#0)IN!lBP7_Ah?!Yhe$kmGR|*|d@<{)ztK~lX3C}E^a?#$a5|02Ph`xojtG8VXcj_8w^<x_7_~1^sy9Ov3f5?U{;z|9K58Kf6;g#am<k;YZ82_kRF59~^)wgFF6_?RBY+<6Q+e`vtJSJu*9=GKrY%q1V>6OtCoIMwrEMAr=6NKm>!nGoXf(8SEby5y7W`AT+qF&yV7qyE<piFMNIt+ZH9ZBoK3}EW39#9bNB#M}`vCGws8amH=0VQCmi4Dw!fsTzRifKw>P8=^}=uovNKk|pi?pt-s;#`qm3N%<14^2U%VB)waf3W*=Oy@pDCQ(<o@=+LHy7?bN?OX;rumMqbId%^)Vnwa>^3)0F;n;UmK0;x(fYq6>?Er$Gy9JT2p!<YBVo}(4X34$hYm=l`GUk6K8oDmdb*PTfc){2ZMg(b*K%>m3bb)z@MOl$Yg6vjbf9;6rM>~uN@jSaQ$4H1#dBkYSlFwv%k=a?9CAdHxO2J=ycQ3IL^s}jK@&cs3X?5><(NJK#F4O`MTC+`_@=Gqk@DZkPzAilv1pPc&uRebL&DDMYJar(_k@!di4=*MgV?Es-F(F-s;#|kvLsKtiS*pI|h{Eir^`?-bJ9!a8eI+Rf^qrdaxGSH8RcA_Q1&U~6ruEhVPx6yaf(B{GcG5lk&Vyl!1#o`Q*_^N%h@NO=kJHpOm5(5BX{WZa$}fBs1NjhEL>zVjCSpJrEgvfv8^*a0v8iLJrRA+|rT#FxU0%-0=19R4;2C&uztz^j1^3;<)uNX82fE)P7UTN>u3bL1ne)P#lV7;$F;^iw6uq$W+@>Tqs4joHw?+MDHDX3!Zq$68ADO9fp&<O0wt^aqbZ5Z&eU3knI4Wf(M(tgriKVM)q3pZ9;^iqyM~U*NfPx5pP)ht%O!Qs_wJe7Jq<rSYDTj|j#6L5MD0K6caRrZ8u2~Q23w6J6{mDr-xjY7;j{=Y@*$0Fn2_G3f0V7CJL?R7)I$6QA7_D5!K)c)@)O%E-!Ui@}OiX>MX;6g*qeT$bSxKjt4Ku$F%S)ICWsQ;@i;CJP7<*=+34qh1YY>0n*AN|5u$Dzzm+WHbH$Kd2smUT9(<z($hCHiNBlZHh!85yfkgRAF?ukUwDhf(+22~NFVD&2zHw_<+UEw22BOMs7z~05_!(q+K<ObN!>e&&(DvuTgd|3^2!1DX$4#;1^f0OL955Wz>2ieng?c&GSiI^N*7#u-(TszUN`FH97n5g5>FB4u>A2km^j@}9A6S;D!Y8lOBG_<d1(3xbrNo*+4Vt%9pPztiQS6Sai8RD>_c@SLiH5ia2Dw;<Bn@$cZjEMqp$#5hoy#RHQqrt9+`l?5Vd{FeX{E5#-J4~cDw`FkjA84;sSEck(_e8@#QX99Eq_<@y8|~WQ$<nrqt~&jsR{;;GYBy5moB5W^2@FB(MU?0DF@vEqRdhQ)Q<#LgIqECPm6Ol5yG~+>h{#Yc=}Ku;fg&QrD2f3jG8^DnWGTKbbSu9mIhGOK5#0qTH&OlWqLhF25~z0Qt^Jqv3Z4LR;7jxBE1C6|VMYGA?#Ec&U}2vS{nj*rhU|djU9`zh%H7$+=7)XP2Vn$9l6&^Fdq5cwvbWv45&l@g!b?OIFy_o~k@z%s-<A#s;VKx4^w7E(Ob@F}J?sK?YPs>6bm39S3K!}lUy>!=!S$WQH;-EIMtD$EBPYB;#vEsZGa}}^b`QylD~VTl>c~R|?o#SDPVrT!XRdP{Fuxhw7D+@&v^%%>SqDiqYeywJ8={dyCjxmB-T00est!=N^oX$z3gwGvL8$d%d_3SD%rAyn%u>@mqNA7%!$3cn`a$W=*0YRVGv2v(J-8F@Yd!M2b!DL$-BIm<WZ=7XAQgkE5ftO@&1_SD(rL+_wlGMMhg)vruOAO+b!df*EIb`7D`5cSlRSV>g|Y-PH|g+<Kq4QgFQLAON@)V_wg`!)y|}hv@}Q^ha%!!bAZ^G+V9+EGnE{a#7YKPiNmJ-S>UD0_@~f6id>1J>p3F<l5|?BmzcaI_nxB|hvgZ@?8L}T2mUSk#>l>QteTO9uT`HD!ue?}HB!v1h@j<9|?o9qLjpjpR9pwnSpV`fJb=AAx`A6IjflV7&Pv3PKI9i<$41pmDqaW34<YM<MM}v#QXl2*f0c(!Pd`F}!as^BSvaaB0>BnF-0nVB}9;Lm}#k4`SYDM=@tGSOUDVFeU&niZO<|J^Co7>uh0yxetDP#Ppp8!qDA2O!a3P&mr&j4g`y&s&Y6V8}C$G7_@aWM2;Oxul{gUTK?-``t@Q1taluVTXnprXQ+wWrEaPXYA$%Y980Q*O>g41g~(O$u(mI?6LZ!Ad;tsc#dQHt{6iH3DIB3Jq+W>y5aeO`p_i>3h^dQuew*7r$jz1fX9_1Zy{FwwuI+1ujFU5O3BNA^AkjA99WB`a-TPKgAw0IE=8JwjdeqB5$Z<f^Wa_Az;Um$$hve+w3H|kI<$5{)N9eaTjMPg@{U4J18TCDDEn23m8qgJ>lvrw0%@UYQ9w;aE&Km<q%%rJkQnyQ{PupsLqwT*uHSL#$J8}uAx{?jhYqe2{0;1yq)o7YdjFMF>ZJAC*W#kYuapE$9c2sqbI3Nz20F~X&0S8obaGuZntw13)Z0kUS9XKU*B+AK16Tjwa(Or)8cF3y7-lYi%F?<daJjRFD`=35H8YvE_6+A#i2a)B$9gRNsI`VH|!Q#OSeQoM0;!T0mRznr4Ga?CXb78hi?tXshsFv*hox-1vQ5!33Z%k#8nih-;oJDlcSD*J|xu*v2dK-O=bm=n4}lOVOZDjE2HTLt{mf-$SHt0OVk#V!&hxQL6rV$)&9R<j3-v48WHxhfE!<n@kCr1PY{ycj3<ocA~}_4GQx}TL|J59=+}p}_`Svx+_+63l$u#?YV@J@6BDz&U_M@*c~69BTtJ42JzNdkhk`rHz+3lZZFj7&YKslJhZYo~04m{tu((uUoSIREtlm4>Rk(i~&a-K?h0Q;|z@I|?;TM!zp0_&7Pm;OvPMsvWRwB!Z64NF@T3lu~EE36atz5j-S)L_&<92*aVR=nuEXmgnaw!+R=0#rF=-{}V-U#;0SKh0zyb;h}6qeIkVL94-GKJ-2ugytDg>sh+aU~+VlJVVq59{xytE#m@0n18XxJd)Y#zC{9LR@yhMxa~ExNc;Qy%EtRkKxy^HL>H+-CXJ-OspSL>*(`)GGW@yM-Fd)Ps@eb$GQ2uadqWeMdKS$>1BSeuHoi}ht(YjE`{q$uezw)m&7i<62D%R!tn9MVG708s`jD6%CKSmgWae<ipU}J>t|igFmnsaPPk0khgceTrnTsky3Toi7qyfirjyPKib=8}VfCA}VmSS>KlHeR7SPW!ioly+kaMw;m((GviOD4ADMqoX2tJ@vOqM>&1Pa{u5&2zxR{uz60vt7hd#AF3a<MB`(iaxwL_$LQ0DoZ6#H{CAK}%aMT<lI%9Xv-df!OPM>7a(l3`8T8l0ah9vI=Y7gZ4a!NTIUO9holgn-uoi|AL*a#OQ(ze#+ke{_f8Z$L~Oe#0nm|D`XXw0TBwLWESM>)^lP%2|*c&L~L=_r*S!}=uKk{VzH)Cc?Tt|MzD9kV^-mUlSmy1t3y4{OmX3;R48``A}C)*Nash<ib*>CmJmyGHzN{9KJsx!5f*=v-ZF}0-BU8hw^=Vo#SVenM8Hct0_yN_MjhrzU67g+&-~|^awEnl>mh1~MDy={4nWc_BcvjV>>aV><za=$dZaAK0k!mgSi!Mw)aq6+LtO7jtmcry7Jh`KLI@<mk65xg31d8()gqBbChUZmcu(9fES0$_BwHDVMRlSp-k7uKz-<v!M?Z1`4?N(YHi-O@ZGM}%Z&0YybU2&rlSu^OI%9K!mkp##G!@xWP?Lo<a6pSCwreOQu5#!gB%;gN>pF1UiwhN-hlMz(E)W@*573{K`sEH*NCrz1RnlISqHRV!e>-!*9J~}RWrXM|W{gnqE<z@eA-n8NL8a{2*~t?-AlWq6)_Ts6NQJ}r*RD<X+Y1B!=R6wPFyIZegv!kKb9|(c2Ou8#yDQ-p53;QlkR^1yiYyd&CgZj9QPYj2e!p6<D}57SGs+d^$;+zQDz9bd)47;?HUVc5pG)>?HuKsil_2x-eMdlR?^Jk7l5wSIzp0ty!EE~)=)nnqw{I<tgUL^LR{WZ~GnFFxyolrLh3K8LO_oSCN}h8Lv-2@~EYa6}OYysLX60%{=tl8$UZRiG3=!V8KL}02ntmpDw}00xK6~NEyYfA<o9p6##fKU=UV$sUkR&K}UZzC?XV|Q=%vtaR)S52=Id|Go5uE#5Qs*4M1TI0<jnS4%9$cVtKdbiD5m?0f4mM1OkdOXDwxq^11raQqZ0}9}L524?*VS9{;Zz5wsxN9WMYQfnJJAT#A&`<0+7JpL6EmseR-pv8rEo%L>`Z^rD}_mFj>@5v2eoimA*!FhSGkm~HrdWbHO~huDlc4v<WYy|jttNQu~@M%GI%KFJ?tK723-^B7f_aZ+C9%a1aZlazXtIaco2v3`$B%l4CNvJ>`Ul>;9bR3-;bpMLLc^~8PMfxJHWr2U9JfPYCx+a5TkVjY+oH?6R~0NfPH>+9x?IRYH@I?sJE-mqgF<a#U`Qu{0uPba~4#>-k0r5geTN7uzcroAPt?%b&u7%uDAJ@f%$@Gc+aOHpx6(yRZNr(n<zNZA-WixC#%q&IG^M9)UMlgY7i56h0p$xa^D`r3*4eimV!HY1v?cgN|+Lh1E}Fq4)TrsH#RG6d95|FU1<RW<w`p)@*zp`A;bg~D-$eV7*ZW&64^+9&KrG^xbK#YmrEa67TvQ0t!~NAEzzXf8&$w;*$j(93C3u>FNZGIDgEuPhGl{Zci|9U*lbmG;5$B=>dRFKE=@&es&gtxpYMB$nH3(7%e%BIuMyin^Z>bp`2lg>cLEg6>%rFvW4f0ov=+|^lIwliCO{rnXThZF*ROtdDfwONA)7qk+H30J1#$9)Tew;)b6J4}dilztB3#~?`7Mxp&kmHg-VSEYksZ}~C!^P7<ZU~7+k~R0-Wv%){bY4|6Z@DZq*_c_cC{Y{SstmeTrNS)kdvdh62s$mJc4t^ZHiRt$u3W9SfL!0=VO$LspNyhQKeyYfllf_ADie|m)(vH3&LTuMN93oZUKd7c*yiit!Mb#8(E(GIw)Dm@?fe^zA70~)iTa|Kd5a;1)c?5wbHs!ESjH^d8G+sXutRGq^Fzy&oU5Jc1^%lr{ztp)hT(Y8^am@zVA$4D!ndZQ0+%%B`M3gCwQ74T1KxQ6o2L=%30}Qa?X$5zwio4RF_1Jz?hqYkiC&6UUqR!mrL-l<BcC;XL(!u6q^!LR>LRO2qJqo7Rg^7UmwM?5(v`zym5Bx%w!Ea&TJB+A>8{O)>dJx_WakD&kan`zZBwm>td7u-0}_gJfcHd!aZ584fmWWs~Q={4RiFw(sSz86?1AHjF#b@3kArTCo$e~=4dwGS4{iSd}znD53NbbQ{aUPHKR*w*1Is8z9q<pqbVWUj1AN{%ZdFCaKLccL#D?pB3pp_>%FSOYH#spNUe6&ES6a+#vas@v1;5c>5&SrL|YSHbI(+6C|iS#$;5dx4<k3kVEPA*!9)i|w<NfJ#hmo~M}d2+kM|$NdtN>QWC4hZ`kC13huksIkC|a2d^?gM`islfn5Kuf<+aqS)sHd@bXj;<J=ctRJM$4et55#qVrbTY3fds>n=zL|Qoib|y)gAe2kfbi(3@uU(&2wJp;HdPSlrM0g_W&D<P5g(6N??Z;1eYy<6h`Gfdazpq%Sq(!GM3lEgCgo1sOQXQ_tvAO<B&oEFoFImUKP%+^L-AAY*~84P%8^?r%f)xMzj2K8=4ijU%B(+!X7Ck4>xXXk3tq8bBQKLHk}$SeQkL-p39mK&G^>dq|A^tXNIpAPgELIG1d?CLyqc1<5MT7lql$0w98$LXZn*EG48CW1H9n9a~cH(s7XOM<(#Q2I|MAuAISrN)&WhC^c43Hdhj91L!w1RZ4QQ1)o|KnwYo`&nW-r3ytGY0t~hhIMA3d2JU4u+(kWEpgu*WV>QVH_2Ferc(!+fHbillCOXjKp9aUWT9EsHbvjsHx!NgklG!%vtYP5Ww5d69AuPV9<j%PEnR2#qQ9!d3HXm1g_xIA-Iw`dQQT^Aye9@8{RmYpXV<6?@Gd2zvEvbp>a8I;kG=<Vvq9uq#R=OpP@oTyzCI|mY<eddb>#b*|L_n;?CR(Ct&#c%1P<x>UY}ddWO-3H(#<7pjiTjkq+!x#SXp(pIGdJ)o4;y+iJ+);Ftf;sN`2q1Z<x0+-d^T6o?Ln8lZ_@1rx)s+Ul&^Yg_~p8fe+?aYc+7o69r(_S2)qw3OOa6Ab|7`@p1j4|>KU!;ccEKcao+6A%M8=)0>({Se&u@_E!y9CSU$S>?|8RSuLAPASI_mK*nl=%^k}?Ak7K$`$9@UXny1-4u6%Gso(2)G;rh@Z>}D6I0FFu>4bh-Vt6X8a*1!*>1Y;Gi$@ay#i>Qr=yfO^&(4%HTt~@g>ZV>2l5&3=1%njXGJ*aHnejq=7=GOhAXf7%>TiN$2Q>#Y3sVaZYpCKN${!{vYyAN#9*Bd|O@@<G>L$u>j(9x8GX(lfA$IT|X(PuRDMt5~Kk&@=~OOVH^sh-WT)y;5h;9E2sj6Rc#TLg&7w&a((wY?PO-FMh#u=5XmX5`ju%>tKo>LMt%UpIK|{AuknOkQ<bpZ^AHzd|2*|G8b~#$Pyl1F=<vsEEI|A+~uO?%EKy>U190uUhq}*XM5*tvRjSgeBb@wr$OOzQe5<9#_}U&fk#5Z1O;V_ZIB1z6tAdu1}ad*Z96;UcCAE*>I5N+Pp0@EDWq3rHn7d`nwK)nkv|mD*8$r3)`t65L_v$uE|&xGXOq<(G-UlR7&SU#>EIZLX&897B=OMx%3UdtqnS&L*nZE>#=ELVGT8~#L@0$)9?;!QO5P~Os}vbE)$&N>k+gdNPKLDuxj$$`RD6Nus$ZaQ}>-$5d*Pt@D9rm-rT_DwBglhS9KOcqTIj8?C_4Xyrf-;?fRvQHz(YnZA{Vg<~}S1wbfR4TWgbIao(^PZ8U1Sw9k?^pKA>qvDu8MGnN1OtMF6q&4)qmCa)|HXr>(23Sjx3*?~Z)do~xSO=~0{gvammP`<1EGkVe?qjai%B?z|*52)>daeu$~+FGJHx!*ycw!Q)t5Vd^vFpozUdY3#nOy*6KWwgsno#|dVu&@#ty1?ACK;S1j+g7iMM2IJ2rNRG&*{^wY43r{{3?`{0mCCLYqoD6hT60iX!lEC<s@!v_XNjVT_Y7;#r7>AglxxEQopdwe29R(79rH{=%GcCJ|EscEs&{(m&1wny7j?{knlFjn29odBUr1sCa2z#%>32BhxqhB^N#2^$f6#Z7vqq9gIsYy@BmZV^dD;$cjkuK0=1orP?C_2%6W~@ji!r1X?9QE(B6IlJ_2Z)<HEoX`QWy--qmy&>kJhS`3-@fO#?|(-z~!t)Lm-J@iKLbgZyw#@-u_dKxvMwN8;sFU=!E4cClGO)NCpkt^^5xr-#UjmH-9IU!<H?_IPOx$QNu9tYQyGiQgdzMHqv}lN_(?zniU4n9GFar<q?Z{>RbPNPzw2ZcfI~0wd$shq8g#ULgY@tl(JiJ^(327$L}7lkA+S##TXxW+>oLNqEpmBV&FR3($2Yvs6w*9?5fEFm6Ne<O?eIt3K>TemKAvnOIY92XA;#UzAw7moy;I$b+yB4R1AHc)FcLPi6R+Al`bRhyNWaTXQYBzLqC$ugX51w8jeYvD;aBDq<HoaB_>;s`Gf)<!$py1XzuTGy=lipXSYbby}H@~@()I=sexfF#uFP+YM9MS3ui;?w<w<Rot<k8Nfcb2V~UG25yThj#!%d%2>0?g@JN4-V&l&8DaRBaP;<n`+`Ej+2yhupOWDHCOa|x^EJ_eNpqFk+N%9NDM4BNYDu$5pgz6(Y$VJe6_7YQCbF^|Gyl$|V@t17<2|4B_uK`<`u{Z*j1)$^)O>Ap*CaJEAlCTsd=Y}-43t-AWn>L_q@r)Pq<Zowh?Goru0GlTgSa5Bp%!+>w(Y%Mzu75%?D6*xslcckmuaOOZ?hdjF4itHz>`W@gpvTrgH?m0-Wp*d1%}xEOdIA5(d$rb<P-2pLORL1}D64k222-eTINl*b6n*+(k#rI8Vextt<<=`M(_0mn36rV3*WwZVyu!8-hX=44i`g)Z)kl=nMi!h^M;X120+~08Ijdomx;qw+Rx;TEj3j~5o=OTUi$}Nv(MN_iExN^H-uOGx<sFGSiX7QW(JXj0XGgV-<vpt~rIWaj(0u&oJ&Q-uvGqF%b(Y>;9*39|aq#x-BWQKPzbvJ~PAY`>fGeX%1|2o@%f<@-k=P5ja)GkRZgr8bEa>=4OP`}gIxnIBcqR7m0vPo|#@fT{ai<RY6*_&hAh>KTq;q$nVmzq&1H^DZ<7P2y0N6zVi+6KJ69q|DD>uz4qouHY67rfSAO$!rT>M_l@pVv^%kb3HZF4Z`gv=l^HjxP2+6Xo;yAcAaxO{PI8z^;6G$av~?g+A)!d&Yp=)&Bv1%?3iu%9_2(H_O&b4E<^F;yS?NKl*rChDwA?XxEeE93<@ONY={PG;N)0$Wa&s1B-wIuKzbpvwFAY_2=QtTU(ybPcUBZ<~(xB)gdU$*%u^v%5ZDZTW`pB|=~)k%}=IfBb%J8EAX!JvG)>O2%C93bTfW>ttJn`LoK)+4@cCeHG?tZfjCwO|L7=mSLB*Kx`9~X0nEUeEx8X81{^QDKEDgj8nwIV#X>s(!vkRj_3(=4AWrfNe+{R8ku2x;y@0`8pvA0N~49vj>a`2W+!xL*hBsin!||zl6d;6*<gR*b4#wyxau!Qa`mzjTP1x}p;k|<P0i6y+RcIJhspC!(U<!)Gat7cDtODh2-W^VQ2#?HgJs5(sjiwVUViEFi%D+IFVu2)hGzE6_$7-vS})*9dpdTy-GB8Hm0;c@%Y444$qW$#)L-_}XMf9bvh_k+A?B_cbK3e%cA9WYEvB#?U3{C{u@u69SmgtA!EOr7Jr$VKjpbxiIR@cR^PY6=pCwaI>S`xfV^>$H`B0kAgAzA$!EN%(X)C{+#7qi?EpP`)TYag{ryV6us5RJnp_x3*QQ_ev{cq;1sdt$quDjS%v?tYjJ5u9-W>u`4$yLy4Mtnv=AGjWmi}N0m#5hzA=SKj};KyI0bmI8=q!ZJwO}w~raFun3c@!{p>dghukQin#OD+Lb40jkobpb?fC7Ud@a>`yj7(jx*En%?00A0>%LUSLm4_>0mdI%e+znJ<X)zV!apKvJpv&=Z>!3%GD))(ptr5%MQc_4Tv8Q@Up8`PQ1bBYohU}!pd_rw4N?0%DUEhk~KlLR>WXm}jyY-Ya2o*ILrn>NLNz5DZF{vlNo6CllSzqoKRzog?k^Z1d8_4oi$^^wU=PfM<ebpgTpU+QB)odDxd*f7O#GfRm(XprQZAD`fJX`mncW=HvNwI!k%XVn<DsIm~;K25x(XUT;!_EFuTUdeOkAXhtV_t;5EOTtju{kWh(#Tl+8QKBN_6G|#7F(!8@L_cO1)Pqwug|?SzdN!c{a^zz-W;<0~r=~M|I|i8zgJ06{EOjCEt@yrIW78FWq6=fe@<%=!%v|`OJ{9efh<-(WA3+Es9i{4!R1Tiu0~YJ&rm>J|P(2-kjJb?4R}VN^1tBo_&|#M@o{z9gD5()&8F{pWgN-w>JY3+4uNrysKsBUpG0_qhn#-pBfGV%U($OV3td5T=)WlDPa}M$7u;ic{c{G8uhHBkuxGR(QgZ1dBzv+k~Vvo?BJK~LgA)4RcMT(<;=)TF_Y@loy*bR#*?*;b0Y4@Bj$SpmAD_B`m=OQTYk`Ya>EFAg`&Nf3>rK!g~2FHdArHsOeN*Dl`V#=uw8;i-4VyB-Q4xL_j(AbTX;9-Cg`Fov^L?38`niN~KU9qs9Luk2>Z&dO<faasW;<7E~)I+xG#I62Fnq@IwthOVKo(3C_AK{kcn5V9>bBd|2peSV0A%DK^C;cz5ff_0HUI-J~*9e03Q_7l~sPY6W!~!is^o1}&N6w~14V|-}+sdW}$H$7?2k}(Ru7-g{qH+pXQ<}3je|dqRxJS~doio&HZv+WY>?kG@lTwza7HLb~*x|?BV-cH#q^B$nEhKqNot9YA0eGXvGT{M@K2B{Id&!V{Ye{n_WU0**#|DBaCzB1}lEwB^l!0uQ_ofrDV_6o0MCYisT&5_S$dohF=Ybd5k5t13)(h%sJrCOnmt8l^ft6*>y%*-QS(ni#NBqS}*po!5O_$&sOmRoi4r8xB{Nc8T<;9i%oUb7prumrx1lwf>j^C@s1MN-PQh1N@+$<1@bk3WvWRii=cSlsS)@Fvr_VOzF2*o~yfB4N2az8O!wOk_oVg2&hxfoE#xc1EH>KZ`dZb#L>*N^#;U%4TQ*D{17k-!w=to!yzKvFvKvjo>Ll2_pq7sGn1{@(jAI)ooJ<brhSfYcebzdZ2wiBQ7ew1100LHR5c_0P*m>KQDz%`Tn6d>IS)w@8k8RDma&D2G&1rOtsPdx@;#8TSgt<dQlrzaPw+*HTo@e2SMC+{b3;&hZq{syEiP&SN?!CmQkGqNGWMYqTy`Ct_vd($@4*4U&-Uqge@!@m6qNPVcZ)6B}tF60S<2&>>n4Ns4yq2mR{E)iDd0V%6LdVzy`DWi*dk;RrZX#}&Y#X>0l@i|&QINaU?9L%Iff-{3S2gX+0PUn6?hTdW8jVU4XYC`WMV38(+~-N1lN3b_q$vLS}FGu+4}EbtSn{|R1LSF!PUtJf=BvwnDzYA(@zXYghD*g1qbcrnU><{__=e5rEE8kOi+Bn$a6Mm>BNf`Ed(wgxuy)`hO%g3P_$7zw(We$>nXzBSreMj1C62ZAs?>@7Z%w{#S}(ogGxK{$*>4DbB#<4*o$G~w_P1O_Hmn^J>R-HM=S*9cZH=OmM9SzLgS!LNRx2$6TCTwT(c`#~2YB)c;1Xez?09oUg{?<)3QI#`rXnq=tr!Q=|+hwYPSl}UQYk$0mn(d2S-3g(kdI6h~n^mRnByn(~<k(&3sYr3T3@4i&>T(}JH&<i@jqHlJYY|5PVy*vr{ES#UEPH7Uhs%iQfIW(DOyX1&f)w3Q<R9bH64KMDRu(31@I%@-{=&uGh8O?M~N6pGIQE5Ww{}Hrg-yYICK-Amz;A_nW$can(PNGFCJ~tFo5A0~qF&SPqWOF!l)LKeI4;hsy3(SU`ZRhu5syFSy;?Yd``$D-wz{aVF5=`XUAn?h}GtivnY`Y3drY>-VdU8E!V+gDirQ;g6mSjlV$yqi7q0Ug{s;I!dg^`O>e6C4UY=E53TU9Gm|4bTX+>v>;dI+$!j*f7214gt_z?xEFcd+|lvSV0n08WY|Q9T4tpka<{_{T8nh1{QF@&b<7&K87nHp;{tRx~6%(kdL|4Hu^(h^+x*CzgFwP!tUynN&wkMyR%3?|IqMc&CUl!j420v@TyyoX!-sDbxePdH%B1l#cS3`<ynBZ-B(s#&P9s<G9aJr@Utz7aMZSjpLSTrB$C^VaBXfNqUP4hi}-#ZHkorQkzsKqhHr12U9b=Q<8)&iqog)5!nl8zBYf8j8JA!x57y;YIBR{8<LPAZ++f|t;rh{X0RSCCT}bl4D5dspG{Xc63)xPkOODpQ^o_!D7`JX=#2fwXP5fZw%30)U4$BOm#`TTP<rLok7Io}#9pmruRh9$6<EA5dB2MdB?f~d60v$m_tErNnI-cRP+lv#kC;jHdZ#e6S<ebmVt0^$n~}2g!tr4Z!o!hu7g<w4X91u?fuuZI8G3L&fkw~>I9?hj&^e<ELhRuNO+Fm!YzHcz3_^b<0~HP=!sUrmG(m|0)X|ir?%i8diz)v^-KAmdPBE5;ASBy?WtS_HFSOA~^WrbLDg8OrQwT{c|3o*RQ8GqOFrhq;=T>L$w{g37iUD?P3P!PlFmQ37CZeWC!zt0@Bn@I;;tL1Oa2T~og%VSJ%cGDq1WHBw{iO0?5^ot&C&tjC;<iZrNX#!Wd%sY|k4eRV0<^Xm_vp9wUdUoUyPSMh<KuMtI3f@yV!c$XVF{gK+S%k;)D#+<vv@{{wHJX5*f4P#DbUVZOfQ!jw;`|hbEk?$6rD3^<x)l*c6_{CrzUncf?jyws4TLTwsZCxVn;h(g@hEXA~LaNUG|0tlzdx%RY4{7|JhfyfX{^Hr1vf0_pN?EZ1qmBR&UlgQJHCtgJt!Gs#(`dj?FY44bA&GOg_2dkImbYi~MHwP6iLv(j9&29=LQH7pdpc?aOje*I|VgwzR1CF0k1&xVc7gSg*TuhUU_lc~>K4yM5{2v8hQdmz5!B!O|`JA-X*<%{*{~`RaYCZ}YD%g`V$(@!g%JdoHZk(O4~A(?B!{_>zyv`)inrhZ%qroUQ`RHC5)cyP8hNVvYbVzNF>4^vL@ElXih1d=dKR4|rAIH+9S;NrG=ZdhHegCnBx-cu$X3ydrp#N7m~*bS4fRK*Yv~c!Xdt+X3(rVCGL@5ypJ^(Df7V6VA}}4|R1-(uSF8vT)|6W99*D6CAiJb;4G9IhGj>@o`2Di8ijc5Tn2NMPm3Nl}~6!mo0|JGd-A-u$zUs$MEFQ`zSaPBE6Am739RvodxY0X`Rez*j&nH0GRw)^=4y}&AgA&g6~FX24=@Qm(DJKCqXQCyOGjeX8*3p$CB2utv-TnTJAzcxD90=rc7l1#;P4k5O`cvJHv_yQ?#tnj1M{AU}XrMCo$q0DU#2|sX1XbP0wWh?Nnt4%hkM?Sn*Be!AV7??kXTNk<+^AJtH>Yx{{<Nk+6;|KJ*9*@P^;QUeB031P<88*ziU1_(jRj@3CL6Kb%(me=W%I)`#7qYy3Xtd|xv04u}X5q~S1b4B1<BC2hDd-}tk-Cp((L2#dx{$%JH-KLJ^b38h+uR%kHwrZc;D^&;)l&|2*m;&jiQ;jkDoGsR49&h7}DB)5(gB4E02$c*LbdGfWr=dxv<%n0cQnWREpk`SZOiw-90xN=~Im`DrA*A*OZGdL7Jw^-c~0hwIZ;GB+n+NTw#BX8i9-EBF}6NfX`rXMk!{U*(szx6(zUY!B`wzh5kJ<6}k>NUPq{LZUFHA@?_*exsuM*F>B_Notkx64*7?af<Nd{QMTR_&%>tXIB?eGAgy4s>Dans+eG;t9)yzJV=CC78Z~B=_sC>EsS8&GojE^8rQ?`I<qiHy&8pIIHx=Npn<DeAYltrR@jNY@^a4s@S#B6Ji~@#1-K}T-_}dG%4BL5)s>e(>NVg`b}O-HgYbC8Q)FaLa{TKbi-n<DRyD40KGasB^MV_fjKSkyhScLt!Q|>jb1)qvHOC(?}mk#y^I}`GdKKfROD>cciAw?##W>kym0g<l8ieQ-IP5E>oHnwzSYZ@o6v-=5sIWmb}}}x>R<)WwBr9toW~Xe@o}1W8Efi)p@#coQz54PBg$kwlC_ar%dzfDB~S2-vJD1t?R9bSfdhJd@8@pxigHXo@J~|r0Hm%?+=+^dP}7@4)iZF4J}@Pjql6c!Y#|pKOt7+xihApCEva)+%8&)M0cJi>wGfjOnsXd4d5Dr+GN5Nf8?k3{j3YT)iTI%{@<{jLNvke`J_!`E`enY!=Ev5fo;XPu7e#SIzbdrkhNcLNRfIH#o)an9$;E%iAUBLm^^P-f?ma~{!%mRvZlY}>RxcKHVaMEK?|c9$36YA@l0L}M#GGM!7jubJhw7=}VN+sI)kZe({NTU&#Y}jzoA6}W^w!krLHi@_nYr-<;^OBdR>8=<v!4-O_m)gEP3zHDs9`XS6^XkxGq#>TU~P@#-rRL2RuYKNAih_s_(3EJ(oBkS?sy)PVdNFrM-@SEwo8^RQxd5x8a7y|B9*OsLkneUc-3HnkOi*DgoyP_lyfgYJHxx49h2Otc5mLcQygY9lLhkO0Em6>0#OJ*AG(8(V@H~7QK2fSehXF-y;l(fv1-fkkb41}4)w$Sjc>5jTJPob6P8+q3gswRF?8=0S)G`>1Yg0z^3Rv7w`%JuW$!&q7qe?!b}bSOHCY}$>1_sor}%2~BS?UDDZUy)^rrr55#_9gU)&aATPklz6)lXn<=7Gw$(j=l)CUpfGaBXQ118?xTI|2_q1imN!cuy`5?ka>R%jX^%oQx|5G$Xq2D;%hCt#!}U{t<tX5<KTv#IH#P7q+ae25QDr87h$e-6C&`wP<RdXJxZ!uc%MM5W8|g5M+=m<w}>B^=_j7(u;xRpNy691o*JRe)Zs=ZS9f$liL2lH&7E0c?2v{X4vTd<YNR<mqO}&I=DKjw@79mM+G;C?p=moA~uV={_il`=S}#K5+cKg5U;L)!tUQzmu|+@HE}gu@VhL|7AKkt#h<G;YZ(IpgEUYYDSWJji{lGb1y0L96c(O$AH#+Low|DMyID>8AhLCvT6F|n<UHI|3%hni4=I$R#AkwmrULL!n_}H7(9pSiLdY+Dnug~g=u&rX`=GuSzX>k7>Djqui-yf6jgu7r}2G6a>xSCB539dogU_Mo^$<T(e}&?C5w<6^AQn*Y8*j91E1|A&TGfgwgUqJNZcp&i8E2y#NujU?9vVqgy_4YTcBg=*5P&{tC<0e3TPsjqq8t{sYyyoGfoIWZo;UZ2decSn2E9jxxldM*Mo)JI|<kJGCGP7D9^Nr4vtA=pVBleW(xHZ>Zm#%HJwn<J|Z3xnaxx!@RGB3WvNqxz<ef=NT_Ohdr|E(So~ZM>rc#>NoqBlZ~2Lj-fGQY#$2UflJEiXrdbswE((9}3qVc_A*Z=PP7ew`Qhedo@gPSOe6sJmwmBFB?}P+Rdxv8d{gp9Lc`|^hhO+tv!#i9ldF5&MgjtP(>yrfDUCR-{b(b%0v>N19vNRFJ{LIgIto^&Xh^5^-fl9Id16K9mE5Az9b{VWAzZeL9SBK357x}0a+n}9zRu58qA{6zh>$?RH?uOkd|1V#@2%whGli5pJ5p3&(SM%q6&&-(!7;)%UPI&iL(cL{YK#7lbD?vct`l$)X9cj@7#6s75rE8}KXLxU!iy>`ORJ&8)a-oV1@#PEGxYo@J6}Yq+DVGn_U3Y(zOj}M@QGcV-<q2?PLi}X(c7{7N_+5z!F0E&)Uk#WC4@IS_Z?sPJD<7IyeRPvlQHrES*AJl&jVH>y3b~Zx-nvAmu}3b|H+`tVJxvGd1Vnd>p0P^rcIJ-l<y&OSN})u8sAFUl_-L1e#~i0*1r5~AFn*5EnF0LlsKsJpU86=|qY?TOGb$n(>qta76Ae(I2|Dpp<1-{jl8HkN%<b@womKp61Tm{J!?0|J-6T?1E0B+vUj*NQ*n~Nib+%&C&@V}RBm5OKP3jc=MQpRPYJ~3qKjMvF7U80_V4$&Fa3E$cEEtvK)Y<pnBg}j3rj_9w){8`&5%HIVXE%md*hyqgXBbSjwJ4t8eah^^MW>s^WF8}q*QDPFH`RgG5dsex^h)rKtV<2rj+CJE!O!DgeK6QwGBu}Qz)Ds^xSoY()t+21s>XPIG1P#6cN{?uE0H!)b?F%4@L5`K<C9_{8~L1&*6eiRByR@U=CQz%O$4eLzpM`HBr>YsB>Uc3b6;;KFqB<YkV}NX*^%uE%51Z2_J4g?=KQ(EtgOu)%*7+$M&tNEv!HyhGiUB2yOpY}Lh+GJ%A3}Sb&6<>ZU6PJyC<RC$)9cK$|7_#>PF;OP<<ZE$j|naylI^**4vREt??;SbLAnjQ<7QhEc%8|8Ml1OVY{>RoHsQ(h1ykXi;EJdE^lgT<}MT)ySU1(<0`v`#thdF$&~v>6IzZP%PrnXlc_$<X<jhNlYs;<7~kD&KvINGVp0cT*MG#w>qoTl9H&n52@kBH*Z-ToJZ0PTCl+YVKTc1R1JQr=Zhb<)O;307IwBvnT5^IXHohlPHjU_`JeDyQMAFf1H*It&CG8C^gBifsZa&ua5rewfPT`k)2`tekNz~Lt#th1!cT``}!#~?_JUa43cLn?tBM_TQ@85akpd)up3=!+{<Uk*p2_aiN5tOBaX_#I=;7Qy)#{(A-G}B~cU2d-<PNi*8T)0HXy>O-`yV#L!-|V?3@?xI!?jW?J26DFZ^rmA6DmN*X>3{z!wDZ=ry6H=))p3H%a%;PZUr81Gyi$6LN<va87E`?_)u);RcQLNqtc}wcmHieEPo{N5>jqrK3wVxeV&5zpM#ExR?n)&XQV+$vfg5mGRDe~ti@kXN-eoc`J$V;VP|xK}mT0x(1Y&GT4%RAcEru2*fC0E#tJURhZ~nZS7VLf<!X8YF>!JJRquBhveNCy>CeOkh-Ak3JsCD{b+15w}=FNbW2RYT3c0O$Hr(MXo;4jU$*yUy9j$#{0&j{84uW~Ne8-PG!@SJNa$lgo0?CZ?Af&m`C)P(DmdOH)YYq5O!8y>B{W}~%!#$S97w0Jc_>-Wd^*a0}JbsfRwu#@(#4lay$He)kkiI-U@M_+`f2v*6`X*{yNB-jg^9TEbT;JWJ3HEBu%0kTP&V4`)XxrNy=7K4z_Y%ZBx(c~j;!1y{i1I&zLYT7xdJRP67sZA$z1cNGC4QaUgUboKS(S-JF=RL=#91KL`UlRoOtos19F1q&CVf#R8E{PU3_7G<pXu$MW--5Ko6{M|?@?n!nQQh!U|80i!r<6~YUM1sWp}M=k*sho}k7p&#4qdB%D(uIybB;zWnL`7cX%B#Et6(XJ2cp9>UpUBAyJz+$V?pB&A@V*G3PB@HV8~&WLwZYe=x0(ZoAtjwn8{BP&or-;zXcLYlvo=WQ|{9%1!nAAeV-|08uuYKq}k%_X{xoE9cl?CNf#U+IN~z+F~mRgFk0v<?V$#muy|M*pNZXz4i&66$Sl&q4&qaJhDb$EG3G{(t2OlapmFe&<axrgWoZwEa}b8T{_>q@b^q;GX!sGa4c!`k2!Z@oiLdTBBf1!i=f?;k784w<bNldWmuYSv2WyV(67q%h{$gc4<U2qDE&B@})TU8V1Vxn`Mi@<UXpLSYlHIV!Uub`My}5{z$MJG<`_k~4JInNHTj4!N-!wZQt?B)7efbfwqt|8}Rl0#O=2z_+mHx}0Bs3p<l*LB^ew?BbJUZ`_BvxPysXyfjK-FRn6zqwTqLPA%Ti1=MoasbFro<41;7?^@w@6S^dK`>B>w!7$C|EE>H7|7X$Ou)`LV<z+wRkc?Z}C>-iKj_R+DkCwsKA&NHcOnt`;hj*UWjo=*CXzIfg)Ib&P-QAdQ(JNs!hQFW{Eh*U6VdH<qCcrt^iMJonBEUSHUnwyNn&PNAdP!12BrwbVa;#aC~A}TV%{F0Qu@GzJKGJ6y{nx6h*dU*K1b60I_(4{T>tMBI4RAO1(&K4uX?##k!W%L$XxM`_4UMHX(9H`QN2EA*=5tR_<?VNu3*<^k%-*7P6Hv7r|8Pa5;U@LZ*gv(Iyw0los$q3_Pe9#WcMMXQ9zoSLf0-;OzY`NOd8@sDpF{c54ljUByH?a_S~l%O@}%A~jRvG$+(!Kw~95H&OcRSD~CzqsbqDDul6cfDd1u*cA?LwMqIBRp?WibD_FNkiKfK))`B4Y+K?9zZi8@&DZg2Jg4!IKtM+~W}^q8T#}@<Tv*0d4TvYX)?G2n6+2P#qLUcI%mbp=clI6)HIG}9SjxV3pmyW><`nEK+|)!5=v8vkpBP5P=5#ASWK6rd^c*P{Re#<A(UQ$@l>wKQj4Mb2`Z*m9OGfRly1pcd4^1ZuugGDBtKm^K+mSli^@M-9#i_G2ZI1Ydb!sWzQPT%Fe?V*i9Ag6&?^yu@6gfdk>PR_nzNDbOOCa&gb`OO#3c`?1Ri-J(@X@;Y@=3;9C$`JEl_cUnOEd#o>Q;vS+Hz%*6X+~bR5KsUmajxZ5$uE)q~CE3tj8%)6AUB!q>k@ivUGGP6C0Z-52I2_ns<-OIM*<p%A#njkL=w#I3ZHWE{c&(+uBnSS_w^($nq0Zj;O3SjihiULoy__OiTsO6(bP9ni|JALtuH}(8lq53pZ3|+Mx`EXrkxdgSwwc7aGEJu7vKX9Ifm9%z!0Auw-ZcAX>;q15$Qk8cNKer$*`YAKB=Lw36;2=T(nK>IP47R9;`K*;G?Ny5tr$*=f-}NaO&|#O&0?wcinh_P~jnI#*~SkB{+VabgCGb*$F*3_ne3)zBG|xS-%&iW8nC(-77GBj!V<h<%(`Db9}35!Z@uoegMQL$zGDnatG1Y0P%b1g7vvj1%gZC&Qk^C}}d;F;V92(b&;&vk+5qg4Q%m&1tY9C=XYJc#fkXLC6xNu{pPrAS34K2`L6J41GNBZ1O94LxtraVk6<i((jBy#xftxXp<8CNt&jG8%DrK%DIPXxl^)8Dg4)#^|?3JPWhM%!AVn{2A6^AIxLq{_%IjRjTWS{d{E48axn}YVz~#rm1@=)8Z+eitX6sotV1_09Ai5UUq~S2D35q7eFu<=*%HE5e>r!uju_QRrFl6l038w#h%uOVLSe|;v3>|FymNikNNqN*!<UgvZx)t%F41*2C}$)-IEF6SeT@jRsb!)45n&KY?NmbWA})+LB;|#v9NB3o^^$@K&r+MYhLyWw*Ha^1&3OeEut@7k?W({0pA>184@?S&ZJ2d^BOR;*=fL93wqJMb-?D%Vdn(wW21%WmoiakIv22u2v*EKx6h^jeR1q$?;M7mNOIt5U0_cjh=?M2&qvse-M<O|uYpRtO&7g+DsjMKG=O;=}7&0|#oC(Km<}+kyo7GG+g)|GcAz*zb%H4qD3cM2JYLk27;jxLmM1*}E(bndYWI{IGCbe><a*x@Ncw3~QzgJ}(3!jDek=3N8&0WKUK3>qtSXIWq_9|ogv)!K#v$zs39CuHw7ieMc9O9w1U?MO6aRu>sM7=9D{J<6W8{5>}nSyf%9Jpu{=AJtVFKeLveG;l3LA#oflNj7{R6xNtCxZeryrJU(5s-Uf2B?7s<j5}f`pwWeWr%*W@)YBDLMKBbi?V{%sog?UJz=*r8gM~w6``$>s%Gjaij|+igXDPsD_XfJjwaD<nA+&PCYPa;KS$(}!)gUed&argo)iR)NYL`Y%Z8T%b!U2$a>8lJ%EFBNrS3QWzL3SGsAy`sTz1E?lO2>ZFiZ}!s!9Ypj*_<M&J>KAlL?-s|Bt<Q3$<^{(}Tu!-qu{#z1QCR{Og>mvZ^ns>gw1wtwh`rL|^n-(5E~FL`6xHXauzrF&YR)?2t~|b~MqDv<R^kG=f+3#TQ?MJmpOVMN~vYeDKBbecx}4Ip^AY|1alMooekm{A<_VYt1#+yo@=<@A6#)&a0Hv=oA|hT^^VV?X5+7Koy6NqX*QIC2Oci9->r#NR>fB3m>rwWbGB#eum2Y;+E9m54(WX0I*Ef0m|W(g-h+a`~Zf;%qRk}%NhL0$u%UR`sY3x^gw72)C!Wxy7HHQ((J##=gMutvT$MfS2~eTXlu&^JaAPGcP5C*t_JQc9Kb=aQK4F{&&+U2u>Sy&=Q}|VJ9>Y2n5zcq_`wa_%H$n!F9&Tovbcg_W;UXet2cH)yg65Ian7J+5vYwzGyCTLAKa5L8Hfo`3u@L0@++UE=b%I`2l}jFYiniG4ScY=4!60Na!6V#JrcHrlrPByoWf@vn1YGy#99e|4puwgk)EbKf`AL3%PbOQQw_HVP;6j_F4f{J5ZhiZEJ)T-z_^o{j{IF1eD0*tSzVRx1)*Wt+gs&plxMb#exwLa;awzAJf2Z_Sg)9xyX}RLGk9^+xJ?9^>J@MKwWUV6R!!wTD!G;shl)>~w0%chMOo~n<BD0v(MG*8kIp!?p=yoI_cE2UuN!##0;!+U_sdR3KhU7*$%T?NQ>G`;5aop(4wL7cYe4rXLIy?D${RaxcP|l0V|+q~E>xLxgy$Z9?RSRkw;Rs}*D+fOM!Hig9#p3NuH&2#SdgUHx=@Q#YUpQn>nBo8paP46q$o3edB&naZmVo*xNva+I7}Qu&YxLUy{Lc3P>UA>9nnplna7z`l}7{^^FYVKDyi_!0)Hud<FozVnm}kosmpbyz;IP&D!1jr*oQi0ETRXu_r@vdW`Wq52~~Y;giL?xOWwevs}!ZzZlE&h;S+9P8T#QKx9G&YZ=%FRpD13eA{zteUY_xpPp-F_4L41di5~w>x|1}<pfV$<kvl&5feFIwMLb6Spe9m)96(T3MFk;Do_s{nl8N+f>FPR}tR+(-DAcE`kqJ(un`Ie8L%fr>iByOx9cRY;@(r#9tfu(R)P)&%LJ}UIAKGC2^T-yDzWY{<@&*)!6H7lA$l@a7$~!kdS)Q1sSv+WzAOgfJ0UhMvtCn$BeMsd<6KQRRnWqCU%92XSJ12QyRQ*h#s+b}(n|zQThBm7z$z?X1Nh!UU3PGf_t&`N-OftqIM+kV4*`S<LvJ0;Tgl0Y+f<3$rkttCrlR0pd7Z2*Go1Ka{DkZWP*4djvbv>%CqvnH`(q)z6qo6C2<&s@wOD#ubpk=w)i5r7tmN-n5mZFfL6G^~2_iQ$r&`lnVj!M`+mW`QLX*2>1XXgL*!)|5SjpfVBa(g9a>)x5p6m@;(Ljx7OHeot{c$K8p(cJ}mrRC08+mAwPu_ZKyRlb=SZ)898R;irLKsKp{u5#=|qf|{@vVD{%3}8~G)q)s^h;IZy=cZF!6>z=ed)dhwf@zRWx}~X79Mtp;W~-gam!5?BBtAuAD??RDP83sB*MXpC^V_Ia>TcvLEak^`_wK-ObQeN?Edxz~r~(<8-GW>WUb!bP`()N*JEp5$%RO0s1l4@<2R-?gb;^AmSBJT$63>^$I6tI(^Pm1$H-QJ&eMS_Cf-Ra}#wQpG%ukEHylJL9c-7X*qjjZnBlt?|o-}LdoOGl+Z{}b)f|GbgVB)O`{kXj&H#-~a$Bhrs98f9X_RS#OegsgkKB0`&3RupOHM^tqWz^aU(JVMvI#gt)W+RT~jQt;%4U|ftxpq&HqK@znEdH#l$6((sL5?ek)oJjnZbXkv;`+~&=Y0M}H#d2aYi+(*iI0Cqf>7@%KF0!6Jo;pSXCmX-H^IYMCh~HNW&lQ~J3QeSXH?vh@|Y^1fL=e?CG4bi7Z@|M3@jXvf{AjkMyk5|R=>MYioj%HR=|AW@!71)<_GQ#GZHJzf8L<})hLq#Zlx*ktzolIRp*0W{aK@{{%G$GW7W0h8>xa2EGR93=mlq|0TTbjCk*s^!`DMc{vnzV1S6ICY7;g`Z4_(UU!tyYXPs0E)ZTA&#;ULh{|#2E?&$C^Jgl}X-*Gj>?=leEzbH!wc3Z@_ap~z%<#OuX>st=C)TkKY-C}O@;wMJLo;Dd;;=1tKmL?Ziu0|RCl|&7RR-<R4OrNN5p->DaohkXnc&(iRE3mQq-)*hi`S9IW*1BhBc)DkGv4eX~?pZ+P@=MQ2G-Dopz6d*5ey{9^@_KD&*SE^XX7xSLB>9=)4))m=Ls*xYe&;h=Vb3pYr=B}N?Vs14Q!+ejpyfpGvGPi^CQld5dFpv=xMeGIYBJ`$$FHWwz_8*lKUehUGn?AaNy2hicAkk(Mo^yx#FXb5VvL!v=kiEg&09!c6tsYp8}<BJU;DXPfUiKyW0h-v)~Cpx>8aCuWxwm$&>yB1NW=uMHpK{~8(1Flnb#RR;YkH&y4rIv=rT5--?D17&s$&cX9Ad?iQ0MIYn>zjkXljC6%YEns?<LJ$SbwmKmQP_wm;y+|5>Zrnk4~Tu3P4GQ?(5!*`fok?%+MON9aB)fpUQe#xrp<XXHAg@aBUg+O-rT0FqsAcW3^I%#cbLkC2glEtdxxhwvtz4op5+VJeXv1kiTK`AamJ2g%e`lSHy~73r6izkKx&7(bQy@c@)ml9Sd@9SWnFYLa?EI2Q9x6ch+TMWD{QJZf!wCL_wv8NH>0`E${7`8`)uGX*Z{R7sAymY=OI<WAwSCpnIkeIQYoZ6fh2=jyLS%+0EL!+RSjGnyPa^VOzJ6<}+su%CTjUx^1)6tg$N9?fFVjAS9)dzCt=YYzK|orS`w#>7$=$mo^uBi;mWM0%Ir6C&^u?MD;W;#GE_%#BT6u}UsV8IkzYrMk_+!N4M1FLrhHJ&ilPYy31{3rCSn83DY<rfwB*tx|0A43s4Z6zXQ9*DMsuDg4(qv6q$hb588xb?J{$(jWN+JjweqlRr=X`KFS<j&>X+I^vhSr)=C;Cq~ZgvNC^eR1}sMZjt@j?<saPmn}IoHpnHL-f{5ixjiex6fK1xd1j;|_y~xTD3Alfl%Xbo#j)|LLDS-7JIGrw5EzbJg!6o^YTYV4Cu!j0ImxwVV|1%v`IE${Bpx=e$Zv!xb5@W3IpH7$0WA6E$ZAtiMoRor8UN4Hj4@`-ih)8I%4cs31|j>N>pvsNDj_3jwK{fF(=GZsN>C7MpL&Mc1r|B5RC+<C7kV4u<R#rv6)wq)g2OFCYzC?)zqMex=NP_C-lzIJ6WDHYbkILE!TMFl9I|~h!`dgqyC}M*paDK|3IyCIKe7rp>dv@%CA3#Hx7<uE>e=k`Vk$%L30GnyIL4%=Rk$V`hlO&*@B)QJ&BmP*YDX^ceBy~&p4eeZiV?i2LRoJ{EGDXsU{rSYy(6VG(w!M&L!@d5b{GWBRk>hF7fD~ejFb~C)bFTUr6fD4vy0kC7m$Lg|54W411J2l{Yelj;#vk%7zFm%le~S1@S5vXYa(JCRg^u2=g5WZ$)GBC_gj<{$wU(IE%QwhJyft56kz^X?+pLT(@xf1vR`gq|H+?U?$4iG&mZ-lKe@s`xxzoW!aw=*WB&ZfrFiAf@Wc5te2I^DpYm?^BRTA^`sddaMf_x-evQ|*`{8|8_q+MphEM)%dhef~^x5A%7dH5>^k?`X{n>r=pK_)5t3TIAr9a!d{uBP({O&*McVjrjkN@dj`$&7yecBGg>pxTFU7ApQv_H+t(dx&tOSIqhK^=g-_);4+y9TUH@;gH-cvv*iy4tHWrb;IMr0flj)rN+X@1<Zo(hZO;VyJ)%(-f`hqkd5$jdDJfJaweRYS{d1PWJX^Q;;-Eaapx{nLyh%^(`I12miHwZeH=rE2K?TY-L;>Ot(3&C<wjI;{7L5O-t)Vqr&`tbgL`5{wF2!SUp8~*V<taF5)Y>sD0gNhopZu2j*U!@6Ca&?kRhe`($suafHjE){|P!I;;-WASJJT_1pJi`P0`8q>?dJcV+p!nz@4{5X`$sT&ea?#<F!MuDxPE1K*vTiKy0B)UZ#+M_gWC|8(JfZ-uwt{p3&S6vj%+^YsWfzXU@AzdT3(m5%nSylYhC+t<U(v$KPo-go@3-$DLtZ?#{HGRIG?$HVp&0$H~2djFp7Z(sTNBeYBL#=U#rjq5&q)~|eO^>yyGoxgRouUw*Od;0#x1(9FM>Xpz=Sx&-@V!dhW{?Sjuj0D<d4)1`HxG?;gAACin(5Q`o|3nl{Lrl&5{qR%~_>9L7<@XDltmvZHW~o6)X7re-JhcWm8AVf=4z$CZ{INo~2RZo3&}#H24{|coKQ7COj4Sjrsb_E{nk!ULQ`(@UWcXP2oUTSm5KSOf>%75;V*0uICt~TNurscEBxUmdTzZE7M<kUQ(_6yzZ|G#cs#=d`rmV3k8ei2i<D!<i=+{>ONTnT_lznyeHET#vsigX7e(mb!t-v7aJ<*ow#%L^={PN0bLN?+u0rEyI;99=Of>mk4m1c{XPe^^MZ}5<?(acP@F2KfYl#yIz>4-6230Ps{1)OC>;j8k`%8MdsGU(MzB!B^0A(0wFH{y0EvRt<cnTM4^=D;e<N#18aZqcy#uYVZR`_ht_q@Vb0M<rkOJSSk>BelAHH6y0gR}kZg-rOc%nY`&Dgr@hB5f&qw9eI(Gv|k9ar$KloTR<avRQpzTMDo?3%edg!;L*Y=1_(~i&S4}hTq;gSj-#^EEH(jP;cnKu!Eg=bz`omi`5U17*SkY9Z#@aWTny_O*r@icAE*b3jBEbhN&L5I!7`*wPUiI@PVE4YjNR2BlUJcLT@(m0^8Qneg20J;L|OOJUL+j1+sg)ChUhl&nIFNQ`a0C$=+Tq9rUv&y3hvT$;7F%DIKlT!E~+N11AUui2(=P~bCVnmv7m66aO@16;k(z=-~_cdH8?=KnjoCS44~*XmPx+H7Xcp56{jcMx7^#^Op;YHIP(eWXYBi4qUa?44F$NK<URogrm6tvWoj>j%Os%y*tZ6W!2OSAhC!9?L_-zZ<sBXG*H$AK?t%)e%uaWN)8v$(wID_i{r|v6kV-nQ`7u=q(!>XbKcT{GG*f}pgYaDvgk7CkM@6N$Ws?r1&t>6k(0>o)hfBiE<d!Pli2PUb$U3v5@}tRk2NQszdtjohPUp5<*wmzqY5g-sP0v~#sIJU~IAa3B+#Ahka5lv_FY_T0!98&_%^A*{ovA7R@?zMz=QSDk=nmA|l3WbZyd*O3>Nsh-SEb$zY$Q@fG?oXBwhP7wsGhGrruJ?WK*~%QU8rvLpdLyeCP^clKsQhK-H{<gqN0Y(LUQE6TkQhKI-i@%7=-ol4CN{%Odw0Aqo=rC^1`WkOGL%Cx(D40iSeJsm@Rkmvlz)N#dtYmb;cDrOF9|T@$46)$ujbXGDT1U1Y;8@B%Xhta__{vPVex%9V#t+l!@epd*(<@7dO{2CI5Q5t8r4G{@nBc{8J9*z(!Ri(G5ApNX#PEWVu`<fM`rAJyXgyRM8dc5(4KePIuRnZ$D#)1L3Wbnxm_q3C%^5t!F?yFt#Gp1)}YQw8UumaoF4jsISD?^`^=N>QbmG`KJHKiGhJIAn-F`OgNHef)!Y$G9C(~)qpaORl~PRUz%-6##n#+6Ykf2{yx(Ix#fHp0^b;*Gc`NPjXlDz5X4RhxSGtImsJ~uTo|r%12XF&_Mu`D3ud_DB*Kkk$PaqDShkGRvm-ndY%)TN@D?Ouj-=RFaL%ua<g9i=$|d@LBrhB97|rAHC{BWt+)jrTDtuetCH_UglQYk?BEt0?n5Q!2_9V_@&Y?Ku9-yZu0?b3zNP+%3R2=Ay$s7lYUT2ovI3W?VN$?au60Z`CsdULvQH(Rx{Ej?@&Lj(PY=6N0s}NMle>+C@{N#s6J#K0K*`#M6nZ^t+lJh091ybvXdxPR{M~U#Wo0rlak@q=t_hlW6=1*{TSIJxDaJb^m&*D0qYl`C}$!VO-(_@va=Qfx6+3sp|Bg+eE?<3Xn^h827so1h6yJ)kk!2l)FRW`eFn~veG?dQboCh}m;(8BD>eD%jaoYp>8*2Q4Yoj5<c6F5JVu{Ilqs|OKG7DU9GlPG~KEu_&uHP}B>-%0$4NAnZX%6Yh&MLTYk5A&g>noKDW<s8fnV$>6ISZEO^XOGRb+_A&PMnWMU4d>nFEjmUW8J7et_1h0#NLZSscBO;qpaB>*n|axCk6Z)6fP3)4_={i@pZ4{-@iv<0WI5U^$skAHqLUwR&=OsTh4bgOaS5n3a&$>^@3Jh>%RGPKQZ{N4V1&_AX@bn{SN@x-Bdd6Gl)yEKdS7Yw<>xHAa;OoBlsCO<{ESPOsWR0x#9mkPw<hI^$;2W|Pfk{sOyEPpBhu!M@(|(I?X$%btGFOA6LnRZ3!4qT%0F0#B$yPQ;)a@WCiAPd043DpBr4jhdpjYgW7W2$fXR&kcJpJP5rvaoqNq)BZWA0k$*|WMg4-A~<k#QRD5aAKEr8oxS}B{9bMQ42w$_;}CCevvc1g3vVG+>R#QZ7QdFeurQerVJOSy3=FcKjWS6oYC=bMhI6ZX8BDp)+EgNb@~agZViSievTC|Fd=UqJ)KAa>z)yxqJKjW$+A4&6}e`Pg!3{Jt>mP>=vFzHLwr>@O|im*4!jWNQFj;`NG95akWR6)&v}hWw_FLA+bsMkl$A(!?-Ip4XYx=r}HpcQG_ZtB}Ce#9$8Hsst3x`{RY-Xh*Bjntt`HC3c_WElNxHG&SGIt&?an{kc%<A>lnvqFUNOV^|DCOIoJkwo9~Gn5~LRy*7D=TZyJqQTA-aoy0>P_Uv9%)6jD{$bWuqt+W$A@<}>(FRYaUu-JZvh6vfXz;rXl<HJ0dUQMzz+p_4Hr_xh=p`(pdqZl&sL_~6uHxWaLjyj`cr33`JvTCFh_>|<##GjGZ+mqK~<xcKXy~Y|Xn`?P8ZzM&eUHx`h4f!0*h$t+_mZ-+pg$<=LZyA%_@_UGNGf%-TLdw@0%W9soGPck|Xf4r(D)Wwazp<zcL^6x^emFplZeCg3n{w#RQGSdO#?1C<RUAO@-dB+v$7f|HO*-~(X?3FXlJYVPUnHQ|8)BkUkVK)ojsyJC)M@V2Vy!bagP~KS_uHQF?BV%*0KIpngi1<Eu%M73X_^_AGr*^T-r@oR989Rrji)M=RC}8jh}=p39U-?@I!cXE?mXmFonEDTNKGVJJC{3yK)r{8fQ}7yHA=FpI;`Gl9%wsWo`Y%{lIxh|C>CuU3UFf7>#;|)A5DYC91_dVe;iY2^7HR0v3yzQ<rrCle^4Qyb(uJe!Vx15PwDA_wou-b`sN2NK99`YJm`9-J1pD}bZhK9tr|<VnGx$86BasK0i?MaKx!57H_|?Lko9hl?5kYoL$#pnPVf>Y(<LVL{>uqmTsFQdr;w8G9+bqAYWu+Sa18zc1~iyLbZjZZy3EpH2Oc&a>=OD<?k=Em4hN;Hd&kQY5rVsYj8tw&U8O3Vl8wYB?i-MYQt0U4z13p=$Q9{5Z3-<)Ka3tliH`eQJFocC&MU9|bzk$;ncJeI6^TY+a4S#m^S?%xlclTnVu89{outg@_w49zO?S7;lrt@&l;llbD^KtBydGuMwl%ztw`N?JUyd@ou4~s6H}s^D&!QR&6ZA-&-!r=FKuk*i#3z_se})x(Jkeb39)8xKm{U@JxXLz)-9W8ZaAYsjT{vL|D?`>#=Wt+llB!e>D}b!E?=f#YC1|!BtBv(hsx^#ko)QM&IPvk$@J=2EOjDySm5FsD!avO<O(Isnco+t#ydMo_LV;s$mS&fC@Y)_mH_nP+bx6F|XFnt*!1lp`^|r(bb2MofaNIiSXIvs{#Zfkun<mPye46d;fiQx5bW<crO#LfVxS~#i&bNU|YZb}iehO<PlU``snS3lN#&vBe2lY-5!-I-w+#ph`O8^4OyqPkCrrv9-RkDRww!UH@Jk`D%l)E0xy}VkNgCmCQ)5;j`v21hSdIb>WEa#!QRJwI{uE_#<%d71HfDgp5%2AI@LH*I6`g()`=Lkg#N$TFo<8zUinEoPyvBa9>&zhrjKcLeDA|E?LW$AdDNvG?ocEt|G{@EKdygXf_OvNQD4}XTF*=(8_SYXLFz8CdFaWJAXidfiH&<+;t4ijTA3>d*n@GWPNy0egCX>5|cjBZ+|O~VTOqYZ4gc7c0;2CS`w7tkP2RAuubuGKwv-fZKcns!jUhk13x|AouFQ&s8EWCcuisstiX6POu2lxHuFO!(<XH+fU!Ec+bhRevDc0cYL1a&z{0W>V`Oz<N3~O(v?-P$Z9!=tcM{w%B4-T8b7Em@(h<kAAp~b))pfbqsf@E@It%RY<4k(zp^FQo>_vS6cd3-DS08Wp|lw)+-DA(6OeA(O@eT8hV{x>?o~J{fka~y`MMEMbaaV*;~9jIvNv&{T_pKW*#z};GTX}pYsVq3dbqz5AL2pTHMJ%E$n8rJ%@}rvqw}GpQ$qOTyD!hxDiYH=4*?9);u)I(|o6)K-&J!Ed5Z3pXeqOtRxfP@tz%^&4JD#Gx%A={}kpU0&F>!mxyb=(A~UT(I+A-_+4|wN_Iy|la|96%JYdeuczKecUPW6AN3P)TH2I?+Rp<Ipga>#zI*bqZZk(RWCIRzr$YN5SYpf>CF6CBc`2t(OY(toB~MR5$_3?+%P|k9pwQeaFCkP^Zqo5cOkJ>wX8&O7e9&mwBfdXD5YxY7$ts?(Og~*gnSaP!?UK8)RyiO16P`?(Lj-o)@n|z6AE{i}Irg>6(IT%nC;xPhy<M>T)IAU!@#G##pjn2(=!ePAUas!wtspEpxP5SUSpVqQmPDV$2hXGbvy>V5L4AB<{pF5b?vr`Zvg%dStI$NT65V)M`ty)iFWH4f?RzQE0>Lx4dP}IE+Z1G+p%H}>36OEcjXbTofVFg^+GE$GdD&(GCEi&%DEOtmw;ZO$j7#ILJcd&%2Q5GAFS2dW3e9)BXuY>?6VT~hY%s&esk+9Sr~?T8%co>T<!L@<d3G(b<zS(_U5y$=sxlU>b6JZZH=?uF?DR>uh)N7jr(91>CRV9>%7#`$Gt1_N39axTyEo&_B~tYc@+{2e#KccD$<n=GHz%}uX;c|ad$wX4wa^?@nS56dIJwm^2*nD%H`L=&y#<MG1}4UZ>LFTJRPEsfq^hOQwY(*?XDcLb&(SxJxO#~coy4QHx9OMW(m(PELG(Ll@WA%u$yvwjYDogmAfj?GLsn@rtq=yJnOf?*n9j&pX5P#ygjXKd@KB}+Gor&byTl9|o(Z8$AJ@+IAE~+fSoY5@aC!IJB^QsZC|paXS&JMTc_mJp+34!1n~RMYb9}?sc)1U`hj9RP3$grRvY;f_-ZW#Sm4(UvZtsZf68K^pBmb9+n$qym32COkV*f@?I<Q7RynxO{UCyoI#yUTh>(6^qR0?g#NK<YwOO~2imdb^3(F3fBsw6g86RtW+L5iQ%8Hh#G8w<^rqN+^Kn!1M+l!OQP1P!6eBp@{A(`&Fe-WJMg1lCh)CG}qBe7?dr<Yvakv9I9HrdI81X4;T<yQwCp-n!W8O>dhJCQqkdvaimW!^SjdSP5$E%8==i!mT$*wdShH4t2S0<rVFuf8f1Pwbw$yd*1eN8wz&oIItEl7@SIa$5gh6GO$pvtPvOW@t&;z_EeVoCy3k~kr%=2WXJC2ReiZfY{nqUdZo&Lgh7?SXvuTCGlI!0b<32WTG{A|iKt{mD9LaF?*^|dyZdW)88V{yAI`G``wh=p##gTI)Xw1DcoQ-+&)I;Q5H&AP4)>Wma|x8#|Ga*9fTDu=;Kl@k!||{#?r=$w_E>vtI+GhBB3Pb)37nlxO@|BkRh_72ydJEw(^+`z^auz?w2vq=@F6jgvq8^NddV7E{t>jrhh%HCHAsk)2vSxButFj=jc+({MU;C+Yng_AUWz{PZ#V^WKZhqbC^mYis3Q!_C4e*hxv)CreF1gmWJXVd22edXni-;#${&C7obF`8Y8e0{df9WD<&Yh(a(1$5yn*@Dq|}nswDj4GT4Eh>SSWwYR2RNQ!L-Ba(69-EQk9B~?5DE9ZDwqHPFY!n>dAc3p!Qy2HJzAZ()VHoL*^i1TFN94m>D@)01*ZUlPD>4XEj9wa4|lmVqrLI#AQ{@0t|GS=UR+HjLZVsGU;!9R&8K8!Wc#@`qegZi9uVFzH^&h(c?#)wK~ZM1)wB0$)L>ay{%V4iP{?+QTxg36DtUg4=5TaSiFL=3~2VOix_3|?*dLx9dEm)D;in$8dlAkfmT`r3pS9V<DVH|v2Nsu+naW$G6he~s9WM)F!Zr)X`}->NAwzBtR)BQdhwrCS?p8#X$2K?^cdRC7tP2Tjjxta%6$q|U-z%tOfbY@s$XH1;8fuOvU#a{UVg5&_qD%oE!*{1q|k8cn`xpM$nckFU*XN`u)Zr|)aDgOoV)OgFOJ8mlW}vj@r{EIp>AME6K8IA%PC9Q+l6MoyBTzbzF3`pGu~aD(fY{Kc0a3Ai#PjM$MWT2M^|r3y#=8*MORmE`Nc24XcqD7Kh-$Z>v6RQy|}&wCMdmpyKh(fg+q1y-ryTW;lKE3K>t^^-z+m&CMn~GV82-d>x?<5>o@kn5QhwvP&zk{C@e~SeVzg%%VZAXXkGS%q?m$T!cpzzC1AJ>xCvuM&T0i21yVqTOaNAR#d|Xd%%Xt1mpW-O%gwo}2LtEWfy*$4YO{IkqFGnO5XR_sZH@Hd#X=AJI)znq(InI4tsUYUIb-os&t(aL!HkXsf@UKKN9e$nx5^YhK|LB*>=?tnN+kc?M-87AXE#d7`@N=5VqwX{jb+iWGM$DYpRXeKFO9}5(k$bxtelaK<%%~E(2Wt+DEYQNtKzKDHe6gXwZ)R!2-HAXIJ54P{|Qqzihzr9k}-CAW>G^MP}$jI!Kiki6GLj_h}G_q&{)56qV}KUM9rl9){MH^Aqg`+_zyWzXBkJ)gKklP$HZ|Zj1F<=31iBfsPWJ1Q4<Ow$c%c2*!Diy9sKc<meM!fKkR-3L3{o?-O~Z3X*eBq6fOK7gZxm9d1KfeF=k4hQU)5KkY?L>DY5QZE@1>d9oX>==p_<DfFW^xK$viYn5BuX?f*MxJ`#v=Fgg$1hLW7b=(5DhjcNMeDh@uRi9>cE8+m?^n<Y}l%q{ze=!5weO&1hso|sKe=BS8kJwM`LN*X#mX;*PRW6ROYZYqwa$|n!)Fi;DdzvuOgLoS@p#fP4B8dGc@_SmbFNHW38MPp(X8#c~3Y+w=Q6K}D2u?CjD7ULqES4{Sr9e>No*+H@ip^0Ay&IafijciV7eH9Ld54&h6QT`E%#3UYTngBr&m4(5nqTzH{^1eu36ai5q2>!QNp~K9923*H%k|awZ&J7dOdo$S;ZA~?^sm2Y;WkCue@8rZ>xe_Q11Q{29=!#OIXT;!*A){#1SeTq)yu~YC@T$DQJ6im7Guw2HkrRLoN)?YA=z^j6qgOpwkf7i+3Z~Ftud<VKMqUxE#4>3+@l^Y_1Fv=;q{<&VGvG6y3(G#>rbEA4U~my}SaGSWfhk<0z|1(wHQVxDB!5m^kpdB1wacs}Np3T+=o!ABvr_{4H4!fV1?Wacc(kEi{9O`zGDTI%Sd?h={6)IJP1;MlB3=+`05m1n8S36<W-h2o^q6SMEAyS=AtD)+T+&jwOEw=dGPAU7IwE~62^Rvmlhk0V@umvr-gtKNU7$cMTiJZ{%?X)9o>c@?!_Z9Gk-1HDPjIvusqVzIO*X0gW_0-u2m=aQ6K=0sJrHrM<PX)C7FhTz&CDvfqu03`1`kbU)E)q6#-9%qF^-kO#8sF$H&RPWY<GFU+HT?^|Mo{1*MB;*`|Q+m1m~kNhyna!HI_3VI%%CMyeuB@S~@7)Yu;I;{beTWxL=lHQzdt^J6MKzsOtWiHDB^lVC&TN3uMZeaFO0!0Q-?<Q+qN4#mCX-gJeH_+9zy0SrUWaGxULpp=Z4=DV^olWzLv3d`1AKMa>PWK@i9@QK5+c`7^7!i6I(@F38MDsSOPgAL-m-?lPI>bBw0G97aIY3T7C#5e|$h?p9w0C2a481;>j$yi!p9tBYpy4_p?q^HTenVbN)xt5ox8mL_;DPwe@pM4As#=9+#NCfW^d<e9xqQ}%muCeKX%5=@+`NVC8@iOV=?TB3Kz%^D=j!IYa<drpKOmREZW6ZSiT3YJ=dOv0JQV7{-a%rt9@%By<3-rE5r`%+7ETnP2XR%P{a6Uy1ax2$}8M8BgGDk35_R;8KC8Emo!mi31*iD2sK_Eo-}(KWY8(TsrUltQjIhC`xDZvr_>7-^8c04j#wvldR@jb0KG6VbGpzef_xM$@y129JpVs|k{q>S_g^RN4QZcE1h`(foaucb-&7_VJ#$06qNsnD#ai%s|g_s$qE)ao#;0AMZ;L?bRa+Of39tk_RIV!Oa$N5J-Yk8Jq0N`V)O3%UCJ{_uEbS2uJPanaeC6!V9%6a&G|IYZaOjjvLS9&Rjzy$!jBQ!0>hB4iorDk5lA2GD7im3?wmKO&DRrB^5#&Hl&WMqMDDDXVrU8G#Fkb>n-q%x*75_ps5kHgr&X5mrgVhVPM5Vto#ANM-8;+(zknoXRKIs#Op&v8rzHim|0){-dDOFna^xSmnlsM+EchQ`-zgGz-)+UUTX(FvQ5ytk^&4IqZVRz6lWL^pM7JXi{XswM42WgZV<|1o8S;Ov3>!tLV0>;**vQ?fV=d4hf#R#5kBo}!{S0ke!zbwcWfOBJUp1(`h+dH9H2hCA2^ykfPW>m4zy*P#8N6#>r~tLB_`;Eprht_`MNpC%`Be8We?wYhh6O;>r&Eu7WDr^_h)>U37jk6|96w&^4W^FTW;|cVJLt<Kfv^P2xfdCp7B^wHiubo^H`<PaU^>pMbvz30!FdcXCudS<l_K;KeZ`M_N~#43<Dc#7^#sLYB1S>Vi~F4z_ezzbtW3p%&Lua&8${?d}S|7z{+KaTBamXZ}d^zSQdHl%8|E@IN_k~12$kv(R0R&wFsXR*ZeZ>W^&M38AyXM6TRgcZfC(TzNHNDU9CtWLoG);GZvi}j^Tc8xru>Ma??;{iokS$IfAQ^vwjY|GPI`G`G!@pW4sR+8VB8`Aw}u`(?>)_UrO@k)p}xY=0`cPp7;jAY1|kdK~P|vP<pZMYOqynVtRjEJdajlH`VRPkFOxgld3Y}%~qOI&k32&u;qMl6(k{1qeKF;F*9@av_a^IywpI<UK2hiNk&VyqN+qy-N#8Oh7yHrCWdM)*z78(eM5fND&>meEDH}4n76TV+|w#9(ZnQJ@rkM-fs2&THF*iAB<_)!aNkJ?bP-K7o2n9B-L;y~h&9mohE<ZJR)$m-!tsBtm7za*%N+iO1#lR%#?f+PpLUrhYR#7(ZpHj10r_q+1hKl%?^*cp(WWq^i)Wwegou!+V-abvO5eC=zi2Q|(%3%5Ocx^;&1;HOIrhQJp7#hGdjaR+8x$UrTra>1CjiRr^dt}Afd<KRj%2N27e0?hYfbhTt6>>SG)`a^M#Td;nxvttF2ti6!@C_F4m}Y4W!MbNDRi&cI`wIf+2J635mLZ#+QIHwIw*06Kn;X|0avL^{{nw0w88iM6%#vQOB&JdwZg!zJlALj<XCsUlkgCnNg=e^Ozp817gP&x*+B_tF5;AuewN6vS(!5Obvo>+SI08xVB4r2<*Aj*XO<t2l@i`(Khl^yF-9@#7omMv94W^<#O1+`_F1!Lp7_<}_eb*DCIiplIKL1UTCa06`)rxBYhg`VuSbV>_XN*mQnsKJV;T{7Yv8)WIR$asX|7jnL1yAP41|*SJ!+h&BBt=g+%{{AqbXOEVVI-!>O%eL-~Jih!XzMrih1GxU@OR(z4cFBLB6(r!t{Y=!ckTH;jK1;S?!|j1jfp$I~9$mtWJVf6W>FmW6vQcT_{9;o3bCFB%K@jwwiEpL8lu7x=aD6rI6prAVvG3k0Q_zI5o&u^)_HfA=McZie{@tL|P$<U<y7b2<f?YY*&z2(GbSyF{kNkuuMk*T^<e5B1IAP6RxX%!np1yK=2Rau@Ao^M9|V7dUe&fNNFN~4KioQ8yIY1aN{?K0_ilVm8m-pJ-MgU^TN!3u&f&ae1~dd*?8C?hf^IMXs8iM#35SsejqIr%pI0_QzfJhJFid$+7reNCqixxLq^bX3X0)K2F)~<b8yru+wW+xG@QeML4;(;WY2Y>$JcN+s^fGb_sfMNV{0%d5S^7{M*3~w>&$Zuu&6Dse1>C#^iZOg@W6pLlw`hq<v(N(e|dVo^<`-rSMtGL5H=8bsF>KE=esx98dYV?o`Ee@<E)4FARq{JM5qyb_kyZ%U8ovMk1x@{5*gbV(hj`Rhq5;)uec|vE0?z}NU-NeWa*FE!yGQecI^P&$CQ5#ZhxoeB!>UqF55^`!yn3=`60AyVk3Xhg!!RHeqJ^5hrM<2JHMJLQ$_eu7O&z=Ya?HUPEuF$VgqTiqS<;E%%ZhhvI^Lyu&L6&m@4zY>5*OhEM;iUlY8~y%okUjEfM<o%Q9zL;Qhd75)G>|hzST&jJ+52#xovb!3;Np6L{K8kKtGaW0EGx!N*!)v*~eg8`ZepD&c9X7rCRIsKwYBgw8<J=nB$fRZ&ixc<@ki|2ikkKk~_V_<Oq5XUa8s#MmQsho~J&ov)Mn@shBhs8Q$UA&fhK*iQp{ntVNyw1Ex=78KG6vk98x38mxjNJQPEvH9I4`^x@AG2wDYPHMn|og*RiJ(B7p>)R8}k}oVzq&+4kwNp)oV$b>C7>GPnwJEM<wO)G^Xu1bN{oAzl#4Xc#B{sl~<IM&B<sZW2sj~K&Q{tPnx9u#t(B8am0_t9zOS@$*HQHPHxVdzyLX9`msrud}4oa;U(yQ?v4w_LX6KBj+5O_FYnZ0s@Uh}FNPM;w%zlsYt*wlLP;S5jGm`I1)-(zZx|H}t5!<TFP=e(kIjlYzs{eVg1m@JzP)Mv>I(oAr$x1VY}c{X(+xy;yRfJZC&;Z1oKCWV+`s2!!r1QB{htOwjjmS<!%LYC~tXV4p*P$5#_QN-YV<H)Sk2|M3aMcq`x`A*mn$B;sY8ol%ueYnN5#R|nW$JWT0LwJAs(~qg1ujXWx+ljRj8aMObVWsUT#=xNKmh7Sl-ir{o%%!-J%ZVGFh3AzyVfL(?N}_K-O<O<F+~C*ot+eP4F$%!-pQx>(R%7If;1PlIm54nYymoHHE{RHIXT)P&iXAI8s>zsXv8%#-fx)(fFU91-Y-lRw*gvyL3}gz{9L-CV_L<%_!Ed5<yui^}*Wp)eUMPq6vp<Y^;f4__LGCxv{x4<+s`rH9CfItN7n^w@I|isF?$vs(Iii1Uj*yA~a5W=ysm_8-GfS>=-RKH(rl3M1DreK6R2gGuFE~P1wKVH9kw@&uKgbf+saJEc$PCvc=JM6N6hoOxxXk_*rjKv<aOdVP{P6S<BFXPeJBI!8b!XTjuu)a?f!7{#hyD<ae=-ZK_bS1Hr1`2x#}LFrDT->ZD52IcD|UNa{)tLedPvx1!w#(@0kQCsJwPnX_(uml(lqx*F|6E16$xmBT(*gRB(fbz#?d&3%x}XE=xo-Ob4xW0c0LlBSTf&k=X*YQgW@6T_3k+T-`4<0$n$#^B9PS|V5W{(C)ARniQ7u??MEBvJpU%p8Y)>mHkWVW%y87EM>xOqO&^#YmjU}|g^Nz6-zqq&7u8tgtt&E8380Fk;Y!>gt`;YeKwCeJ6kCKJI3B!HwAII`&ZOmK%*pt8c`8aqFpJbRgi)>ISo_<mLi6z$BOQgYNMY^U1*s8)V8lW~IHGB3aTeye(8;>`do$)wn)ld|luloD&9)8vt(q`vDrn<$d-Q&H>n6`?(^yHlHD+g`8-%zegEcJf-$JhY&I%MW>zG*(ynoYX(F62C-v{>SzgDfbVNICwrq#AIF&cJDvN%nsZP;KuR!xiw9TDwtKq7?>#^UB3^R{u3v-OI)+I#X%t3s(E#*1mSEu9K+O@fu0q8e10Dq{u+!vwU@27{HRQ!5wl`NT-%VrRXGex=p6*1IXWQFmV(3#=yz+7Y+Vj`ZLB$cv9#s@$o6kw3?6@;ueddBB47qR7b3eITDG)vndH&X_S#2db_Us2qJmWoQOY@@~(_!}qC{7Xg09L6&UuAPRCeta2G0Dl95t-tm=d*mkN|G9PZT<q#f-(3s`Y5oB+^Ej3!RiV|4_o6}g^O80LT8AENDq-}XIhjL)Yvd<2@)El@m8xelra^^i&lgUY(v^=J@p6E@{xK8rx3I9v{?$aMzM%fo1H<hUE^qyh0ThTAy9#ipdHJW-B1m7A;Ro+o?!Rv#F1)LPy*!j@F={a5^2g}5siZ|vlhDPGJAfB^?4<&ZR&6jL~rhuv5<O{X*>n)`(0B<Ink2klmOb3IndhQugjOjnK%Rh6J{Z4z%r`H~GLRzFO@}iR<_@C={8-~juhW>!2!8L52YAb_v?$Ez@o}(!|j;o&YZKGhY7Qy`TxeX>nq0Yda`_MyMzWU~gjpg3*iIrwhxP53Pr+&O?2oMP!f5gvi{4HsC=3iuy{+>hT9fbxP5s^r8NvsEw50Qqk{g}>_@vMA`D9|cv1jeu!OjmOnC5EU4*{YDh5DkH9qgViYd73a<N(AraXrNU=^|C%iteq%!kZ0vXn@y9FN{;pQY<RLDj%^kchhHavFQYdW4y405i0B%!eU?H<Y;g(<pZHetCO99fWJxx9tm%9bXU<Paw^O!0%+hi)hF+uyB?}y01qgASdvRx32gx=f%$iF_t^@0IE^@1*J|^nX$=5%FT2uIir{=2;!$?uS^q>C@4GL)QxS21QOMh%okORO6lvsI5V4BpO>{t?C2L%$L@=Q9MM3hZWVigf^`rtaRd^=lfiu*Ct3a5{RoIF-Y+%^P&qFh!Uo|=9HCy|l$@ESO>rC1(&w4lng4|?8S74kM~yeN+g=F1^JEK`OO(;w!P;s3^0!b5!|zp`g@Ymr|7M9*l)CFOoqfuTdjwJbV7+G1B-8%mI>EJKOIhfVBm*pe$-2fJ*uEIkSV$tMU_r4hMOwU-enXrEp#MnsQg6&*mjj3snS(RY>DpCD5&a%GGv^%7eed=&wTR{2fT*chPFRpv*FCRKX6((}m_3#bp&8q^v}N6J(CO@n%I4Pvc2>^qfC7xqZj;Nr(CXWH(F&)B)pVbVX!KVGcU-~S^NL(zogS7Io6rGyep2IcDfJGRaGCkRqr9At_R8meJdHttaNJJC;J=V5R`Y0fy%D&z8i@@R<+`m3jN2JiuazwfB1k{>Z_X$=((cJAqJSMt37XvyK@dnWTQWysf3`Wt{^%j#cB3cZC<lyJpYOz*caMN{xhZ>0A^C$2bT>m*;Ec~L%ObRg>*F0m!~6<x*X)3j0I7MBRfT2zG(wA5hjQ7iS^3}0(F$)wnbgiJMRv@2Y(h-m{vT$2CRDrIX}B>*^f-J2);(Fl2Q7<Jf76`+ir^h@r~+d%n@1Lg9jSPt5i8PI=_DU*Meen|Nx-xO~tN7B1d+c^J#rI+$u*ceM=xxr;F;XkWwjcf*@kUL6gzShypTRT6ER`R8l7B+s~b7oab28B7V=?!Z_GPYn@ho)pI{z1Z1ScA2|gZ)+J%M%hd?zZDC>4^TKLNXGt6a{-9h;ux$6(|x1`1h21Nk<V6FrV%D3x-^$DxWDD^b2!cBI7|04HKk^L0Cf_HEN8SVVCENB`Uj|YJ+F1X*|85X-r;>pZ}nF=lrdB1}{&X+nk{Yal5`}lCm-z%QVQiJ0k7n)Q+(+b>Z<SynZc*LIDkTZ!nc(udwZKFX|Z!n@3jM-O4pp*D{35(GSr4BvNY@j-Ea<G&3LM)^nr@z~JYTxw7b-u!nLMwDYOPKkJ?2J`9~)w%o{ke>ky_o3t@Mdx4pTU4+0|?w+6hd+ix05A4sp>|VTh03_@g;RMBanhm2nH|}w0mktsQaYAfxiBLQkna6irgeQ(^Zf|I%Hl_#Eyv5le<ER8Sdz2qcScQ)@B!8bM8vA54*K$0^y^r5UYor|U{nf)Msq75~v-I`({U56=6X-_Mlx5~*2BET!WOV{pVl+b(kZJQus!~ET#9nz7$C-MVRHAgEwW~5d`Fa<;4=)@?7~p7Hh>{OdZZHI{A`9NNiM9y5ZW(#gOyS0)3vpb^N41HJq{{Xa?Jq2xU%BN3mixo%yZpv#Me+ixHgK~@so%T$$ZMaCn|JLjyl9P^Zw#g<>2K)CRo|!Sy!hqM<(Jn!Wu`>+cSUQ>uqoZzz=Y<1QXQk(h1#?!)*q=?!;Ve1B=vOUld|5)=7aA$TASO$S{i0Ki}ht`KUGy*iRrW>534)=+J#*-Qr)tL%@v3*4|~y9H4&mJ*|!{Rsw$uUHMJW1u<zjUm4Cjn7}?|Qe%i;!)ZKYm)X6ipr;<ieoK#+UL_dJ879}!4$E~bWQ$l<`6A+JCL}i->FmpB)6Md!y9B_lOAR`JQX9tr(X9~Afrz{-#IPR^BYjA(zmg1hy$=0~%9L`?kV1{Z?l8=_WG5KYoK$HMnU~;G*Fuf+rQmCDapAg}u;3f({Oo0*L0EST(!~9t#ZUkDRU}eL3PLn(!vDirq7gRR@EL=}X<ygTCp;=u0VF=ep5*&WX&3i5;JD=`(wLn1N1bV`CO(O|bTx#$$Y8tg;$&(h5G!L+t#PnJsp^Q1VlcSVieF@#g;lSW#;xZ+aIqg~0x;mq?>gm}58n4o~GL!Z^gL$&JuPmqjf+Y^r<FY-eU>(j5-A<Io2H^2BIn#Lg%qkTxYS(<jV&w_!Sh?AuelW`<5Sc#hp5+bkfQ;2M;ZP13vok_A1Bx-(_{tQ__rLj*u=CBZlQ@}m<ayFk$e;adk>`;U&5ph+J{zn`;G5_8BHBz0HKl4<=l}Odo4ZxCnVH0^0v#B0Qc}g|zx<KRqFF5-WO9DggG`}u^CrD`SyD$Cua@(ncZKm)6!o2J&z)YA76DQM5O{0UFXY?mFE&8JVdqC@atDk=YThat%?@QT;1qX2xTG<BmTd~93Q?3Zk&2nX1GA+D?Tt=YTy$P~ff|*s(OKnwC)W&T_HEQcIY21L!>LqHZ#FB4sI-pGInBz|j3*a^Ik8nrykFwW7|bG=r_-T^8FMtryF{<0&Ue|wRI3H17b<`nhlt>?pSu5DRqz8Gm(21Y=)D7bIAR`%5?CtZs4O}+&#?2)AO9GajoXu4e&_ew&-O@5ouEF|M|@=cRQrQ_@nF056IuB4t55h#6pJ2s-f&D7oDyf73=JRuOtt#R4-WM>-#-!TS+#jKNn+vPUd#xLn=vUcI(e2@E6>!X2DZkecO9x%<+FQrj;O~*(a$5VCpHe2zH<L~ZlC>YlZet+Mla8NES@E3)tN-!?VM7ff8CPD+V$!6E#cLPhKHm}Y6oMVx&*tbYixtfL@zMlRmG+ixse9Xs&?GaWkyufzGlWu{tI7aHq6`Eu-nXr*m64?Mw$Dq=RvZdyeKjyJh@PQ@1f_@{?;T&aMH9>X+SEf4Eu8Uyw`fp&$3>nNKR%4qeu)+uGpCVvRG#|ZA21xGR1T|RJE=M{KaTZQtd&_jA}0UR4>V0izDi{ujj-v<?X=ugdv8Cl@nTVy|)A%uk69o2x#;82gf;=`W>ml%Q_trpLM!ZP!TRtG{2n8&aP^%-!3QX@mFCL{nHfu=^XCi9I+VgssRp#Te_~=eV(296d)Rpaua}>k>+7(N0h*bA>&x*SeWV@oHT6dOo%`;pG?FVmJ}X!peE2-4geo#>V09O3RMxZ@;Y-cBK)l5#}flq^Sl!-8aM%vtiYbe5ExAI$PkVr=Y}LT6gJyBB6!Q54`(^GQ-y_h`9js9i=4458jZaiG83BUG9-`yiAuqmsFyn;q|{J#;ZA)I#a*0F;pIBZi4V78uGY@st{S;UdL0}Xn=0p%P1L{f|B0Y;ei?K!;vC<z(0qEtIdEAaqjj^6>|Cg#x%i4D+?4c|Ef!iSIRB?w>#X%`&&RcC>q?n1+X}b@py@@evp;Q0+8IJE8wb*nH+f(NyGJ6+23*hT*<W@|vajs(`f;~+F#FDUF#HAhD79}bi}|=t-kTO}jOIzYf8(~ZhScsnkjz1?#d6iXYAkVm=gX6PB<LT$Ra#d`>$({QsSN?%c~=KQS|=R{A7<AEg0xitIsH(%8@K4>Y&eX4yZ?Ci4y;-r>t!FZClT8e{6qB~#;rC^1tNk@11fg2)%~PgJ`s`&Q0J)%x+ha}-}NX_wn9y!>dinh1L_^?68FDk$$9zr3lusVnV$~;ssJndB-3Zl_7l?q3b`9^TdL=zSCtFiQK6C*@-+8&FnD7lk<7B&szuYzPdu$jZq5N?5#*(ux*q9$)j{Vk#zdv;%cV9}Wia|^zyPWD052^gW*LPO0G4IF8JYa6zZSSUF#X0vdi1hbm1Jl4WS&`xBA8KR04>6j?C4C*Vc1!T9<jm>CEna|{5lg=1&Y5yuu?`o)uX3jYp>i+fza+kZmCM9g;9C!PQpz@-u(8L34;v6>@dMHtbHpO>W*3`xA9O%xWB|aqBn&Pt*GT;*m-0!nT`h9kN2`zJWc9a_;D2>jZzAX;V`KOC_X)1Wcdugql8sgbHqePbV045@W&N4h3do3p+ug$F=(jvw5kr9=!|7-IPA>gW0jR0tV+8S3Zv;@dU=mSgHjb+S#MX_8q?hJ6>P5Uoo$05yfcQBrGt`Qg5%E;d&vf*WaMIuWGPS_TY74Kx%plK8a^MqM18b2h2Qx9YuRW2zOs)pJOYyH3>>%V-OF`&cz?H1)o@p9KDE`DZd#4WDnH$7;f>pccX+$()33@t<EqK1f=~Brrdd)><NLHu`Ds7z*hFG^6z*mvQoADoq{G7u>V!*XZ+UN2OBl^XN)-nx#j!z3bD1*lRfP_A^yE~RlgubIL&7krBsT=yCN4V)m}#1k<pqJPf;JRhq3qzrhLw6x@G`jbLR*NI!4%|TO{EhT+qp~<M;ew<&IXd2QhO0ukCt8?^(F&N-%s9~&IfKYI`ItuC6$kf15YDdmw7OzAc#dO?)j*2sgHa;Nh}x?&oI=EM6{oDNtw;*qO}n+ZBzt)$9J85Y^t|BjDhj+ucN~-OP}YP9-drfHp{SMH-C|lz#)3<^a7f4oRyWE@jIjYz=AgJm<Lvl^_*O@7L~7Of-xjvHD-U{_3l)m&n+Y6&G%$&DIz(^iYrt@E{=;?H!~{!>>9*h4k9PSPstWZKAaSbgP>qE_1@;qnwU(M@9T&*8KvqP1W_$F6Y_YrAEqN<D3&deWYTkoi#*~LI{1y;smxE6PmW}oKz@SLB$n*4WL1&)4sPiZ5yD>36}h%hX2>&*GkdK>7D;&=&DXBE>D4P!CP%+RN1&?`X6Y|A>CX8FRZ!?P-Og@hRVYIdsCRm!6q<l%Rm!nO@P(RUcf?A|rDLt+S+ep$B}<H8{i|9#7zM;r$$3DfhWeJ5&KFx&VqtN(k6{rA?Jj)9*9xgtKAiwnRCtiwCIPw>Wt1e9f#B#SwK^9JG)jyivZX#JK|qO721ZAYaCbf$k)-Qu33z0gLJ^_NYs55k)B-vBGV}M5uVVpl%Gjx8YZiNHRNFid^Xd4s@*5NNLc#(T=_q8AjVppxJsEtHB1}Hcf21s`b9vZ*kL$QvS{S@H(@r+?UH6!tKI5Z!k1-{#ahy@o?R|B}0A0=)%4G}B2%wChQ=)w4fF`^EEC2!`NRPuQ?D!l?W*fcz-retI*8^90GAx5XBkICDc^4H!b}X`#caA;VPQgtRh64t3Ip9M%alp3*v^CJmO6X?Bfi|93K`jY5;Ioau%l9OD3SPyACJWa1g+NCCMF$NU^g#)`djh7u3?R6V(ksb-maOsB!Cambd-?gxueetqDai1udo>+W!$Z0RC>{`~t+Iswc6t4&KA{hSy=cL~3^TE7G4BmW6L^a-Emd#C&Kz+mcUi97W1Ypz#k(lI^pb)WLG&cW=(1q%7t(RK2WWa^0^zwq`O@*k+1Q(twT!ckd|M9Sp~la21y40FnrqODR6~K^y~#LZgguz`c6xA<)8%EUk>szNOzGzq1Y%iz`ar4<|5j?I+y;RvEg!4m;b5WQMWG;SdZ<{JcMm~M$u%H^N(<vaW<H0!iUa$S+P{bc$v9dCftabg9BAH0oXI8)4;6G63>}<a3;$LLI0s)9#wu%ihF%@Qwt)pPzb?S28xZy*RxA~AJw5QAr7BEC`T=E?ay3woXHaUm1@oX|-#utm<WJOo=i8M09^?xIr4Ucepx2f$HK^$FUm*f4Q^aG8_lzMh7TG}q5KD3(G)8F4i?6M5**v7wwfdx20FiPp=mNmc1W!Vzl`6b3)!K|jgXIcd&7n7+pd2P1c8ry!p;~`Jd<2|-gF6#BAbT`hg;YqSdHB@f#)1wYm0(sQGBkjQz-Du$BfFvu##}9v7}|Mh;MgH4f?*hj%$7}YDOAwC$jjL(n;;xN8)Xs2x@Fc%Uq3FuZCLD_mY<8=t<0C5ASx+IaKlFftk#}mJpi#7Lq+QaQ*1F4mAL+v&Q)|3tX@LpHKAaim{EHX3RDMXU=(diGNf8{n92=k!?>dCe$R3ADn{+y2B79|0BWQ>pR#aibUy>$nelk%rD+k#dsajb^RyLIOZweC%Pv^u&I}7lw%HM{=DD^of5(8@8+4b$+yKB!jd{;lWU}(9wO$n2l;fNZD(6wjH>rqH*&aK5<79@Z#1~_%vFOHY@-45iCR;Y_v&T-9nEPb=MEg>vSmw|Lrl6%fecB9}s1zYqeB1V2Pi1THo%_XutDR=``w~eBuk^NTE}a67!78xm#Z1R|`K*EV(gq>7@*>+Bf-S#<wf)KZ=ce!Wl^_Vi+Yp5A_@c;ku05tz(+wOn(!(c|muS4XBW$>}+iKIT)6jr&0Tu;xsA%ed1g}%77A(}NCVZIhC|{q|UGtdN6fGo{WIK~7W^59yC7109AT}bI2cDg#$D~MOKfWI9IHwoAHcdM4{G?cPmh&&yD$Hm=xl){yTJ1~iN^}@JXP63ct@NiRi!zY+Ubc^&)Mnaga?0pf3?SDpYJ!o~w7hTlc*XD+f0x#iIClE?)|2A4o-}_5y`C9RAXd+tl9DNuZ%axeTmJOqSnx!;iLn-zm?ooxX|*M_bKXD|P1Gjx)SYGqR?GbVkKJJ@%X|#NB!j|Y2on!z<l6|7N-HC_ZG$j*5jD<BJ4gQnFCpz`Ag+6O8(UH?#)02UH8#N~=URWhg_pd<mbmJ@+PXe_Jh89AOK2=_VyjE<C({Txui+)-u|3#q-Bkz3shZL!S|16g(Xk*gOkmqRbNcuYu!M^OMaO_hI^r#TBL!Eu;6e`s0G<IWFD`PsI|76RDf`UTC^p#ZuR}+I0Z1~L2Y4*X^L#P#S|r=<4cv$Xxh)i;^-%?l_^Ln?7v`G(de9@C|1v|KW1O?h^CTS8X4Kp73U<y;(5jAopcez5AE{&i5?&wpzKJh+bfH+Z#T|a%@Q3Zl23j?UzlJ`T*L~2yAKSpMaqTQs-*|(i2cLwLPR46yT;gSe)me$BBK&L35AtN70rMfKI&@{8C=-%?PgGkH%qrUCh?_rbRHGHk+R)qM_}RZRf37Mu#|VqxXaja|c1<vv2KhKkR+=rDV1_7trFb^vyty0?Rdp^ccCFHso^63~W*EnIPOgs#K!>t2j3!Lo9t-6v{fbfn(DuL^WbyJ^x!(Jg263oTn?F)G)$ob_$TI~Ax)phaSx_e<s54WT>M3kw9%p7+EgtQvW26{=U9g)vw`g@}VQX0V{Q6J>!?weriHJKXrz`z29HDHPy09G5Eng(A&<D}{pO|CV;2M&q-9~3wJac(7k#pf&qA@&HYVj6`8>@z^#Wo@j&Gk4nj!X5AtcLB&o~7Cl8rw$ZBx$vAT5XxuL4Q~{K-E}JRvYr}jz-gIN4UL2#zW%s-Lj75E9#MMzGC~m$>2j-L%!Q`UpCu|sANy7S3iDz`r+mF1h|=4g|R<3H^LZ2%bx3z*olXgOieqfb};o)+Xr>ILRdC#GuG`{)DPZQ-OKQIeJWvWenA+UNTyr<OT;ylgE*UABBe2tH4k{XngdPeRv&B^QdXMvzLsAOB^(|W=2fbrHAORJ55DSpI$KHn;AGPlDovhsb_zm-N+{~oK&?-kw{mqd0ZX>Wg<N#iC2Qw4kF|$Jz7MVV(H;)#I)z0*ba4o{@xc!DQb^=7m<QyF-4v>!`kJa_^FsUf%EHp9VKTWg{Wjsx(7e8zV?kW~8SSx%HNkI0yA8K(RnZ}ZFPfHW`z6V7i+8G0<|beLQ&vY?Wq<VXmn8xNAumJ0tlg!(xA>?pj^DLN5(MucewC6U5$!m?H7ak0>W<|s-=>rLZgZPoak@4|i49`RTO)PZY=Oxwuh81jXmZ9k^J!x{FVoOEPORW(^5KIq$FQH@M<T*^{_001#u7k?5cBx}?H^eym&vVwi%B9N34BWxRmQ3Qxkr-pJgkH|QBi;COwCMa2m{Mqa+rN)oY{E(q4_8#X>V|ikIay(9*(JQMEasC`Za!<AU3p)Fy;fxeBShhVtuml3-pCdn@HMjnG*mkr(vQeTUq13>cPm-0ye|@ZYYvAD%q2UKzyW3Z(?OWNEW%-dWp5_!Vx`S-`~RFNqB3Z$k#v`QLLPQZ!wnnJ{_Q2ANWDWGQwl5jAhEJhjfbmb1Ek_qnOD5bx?r6eNjsFGFP*==mcKvW&CGD`$+Sm0pCEjW_l})wkzswZB{x3)XBFEj4zXF{2S}`sE}|ob2dw1S1Xcy-TY@@I5=3$Gc3EsRUb=UReO6<mQLncW8V__ErG)O>cFmID#||1)^tc!@C#?(sf4;Mswbn{;d>`S$G`)@&hu$?3_EADL!D^C>qXM-Hf!FkuZ8b2F8&=Tw*GvrkiJ`bmy1wqaJzxI<wLC@W)cih;Pz1RJbLe!0w|D+XQOS~^8n*XF6A9f4@ie+6cJ`Z@=)~1xJYFZp=JsO=_Dfj1x1pUC7K;_@=zRG5#&2g-!tUKDF+3EdDr}>Mw3dW&PULnDrllk4xwK7Px*TqHFQ)Jxs(TH^dp11@eJ|fa>@@8D%2xq!10I&cgM-)B9=;G!>sAHv3|1D8JY-Fc`{OYGCieXe#~Aj{$F;#0nvwY50Se)F#`JqDx7tk1ym{zKwk|n>iYg@^5mFd?pC38g0baDhfcMlu<W0ZwqrQlIccW@;Zq6wk(QtQ9YI3LVafvZ`|1-VH9i>}CWA4Cif1%azYbt!M}NRDr<kWI44&M%CdDJ~fY)PoP-z`apYqn{j-@BUaK4{vJbi%o(>ck|sHH{}WI8ZxP`l%*pq$z+Pwp2Sgw>VmB)9pQDRSc*`i$or<ikiFMQlE!3S&v<I5EVDzwr~A>_@7zoIX_F-f(1VaeLU}B|VGV`8B4jC7BUr?S_|3@>hSOpnWUK^6Os>3yoW3otwMbol?SeG#K*>6tr<<UqL|wJcD2gp+Of8y?siKi(96wuv`#mnLGBSk~GZ`fDB`}jDch=60uNUNfhU+kaHrUk4F6>8LWI{5-bt&OW^YlggO$iqre6DXd=1>TI%jn5Ln3U2)ErSuC5$eJ<I{IGV_&$`3t5r<=}va8vH@usAP5oXN-%MHQ2;P3)F2l{{xEZla=NPQ{>h7_dhwJ0ss&Q)$(Z=+np=`0;GURp#me~uF{_M=427o%Bn9)$%Nrl_35h_*zz-4bj6;~VA_w2a=bb61YsA{`!~2i6+SRnNHnWH1z7qCvp*@P$7E4j&8rj`)i&blQ=*ErpVa-K{zAnZ=pmHPtmvfRHcs}6s`9yNZeW91DpzhTMUtsHq<E{WAOjHz<R^N0JPX|wZg#~?^vonQEHR?*53e+tz1u2;-25!Z^v7@8R3B6k`Wzm=UF92z`-Wk4aq%9($DnaJ5&DT|&tDSOx)SohfLX2$-qZkbp>}wR1V#<LYa?P0u8JbhATJMtimR$gc*&J*A!H0Els9pmI97hDmOy)1_3`x*r(XttT6RVAZquy9oj;c=Js8%Z6{b{OuDWNqw`b{o(5kQ25d-&+$jJ_MM{G<Pbdy<WXLSjazdATT!(D@Ap!>hRc-6CP<u5MBZRIL7z$@9#-(h|q76~IHc-g=(aTUrYQ6T_pD#J^c-9QaQ3u2*1Dw<Su@|3uPdl2$f9>ZDf`6>>ZW^+D<y~%8v@=CKG5z26%wACd#9;Yt(QeTg%W2%YlbTAe!A0axrQ2KEf-O0<6j+Tbe*d@^jNi50niu0*XF{w(&`6BB1G>IC@k^>@3bQHNP(M%VEYj8#5JSmW+ST?hPvPMSU=N@7SowuSX>mtD}do5uG+0h7D%XGsW68IfanY+cGRa3#)w`;-*l~zM@sZed+?X0T{5Gvv&d!J{bt`w#SR3RVG^2E@gB2dP;L91kLlXyv^zU6`h1S%{4!6zhDSKn3ARL;O2x1_57grrI$F}g2Is@UtvLJ?bPRh|Ls%9Xu6y_sMkcp5kIV>qpGs;N}~g?!c=p|>o%;_u}-Jk;z8BHTi@m>xQEEMoIPEo3A5G5}lJk5<|SrR}szwxo5dWD6=AfbLxYb%H#==u8`czQOC1i}(fyd84X(8yTdaBy#_TeP;i4rCjk3ewx7C=R}wtw~j=22rNG=Fo!Y8?K8<0P`t*X(BgBY$6K*Ef7*lPKhbWziOoSL=!_cJa5X$J<E=29v7i9Kz`1XC_2(GwuNBrnVLiH2Vh{I%J6&y(I@LW-<>9>ZN4|TV@i<MX)*AkmTQuNzq3tK_lX$dg9AXj21XZU1+RdC*C`bpMeR))-nc>Jl9OB+VtuR75Nss`X!QSW)gW^oi51m?O2hyJdPP$wwTjM?59=uWteq_gpQ7Tp(qby>UgRo$-+6Pl1rsT#QtJ8DSi85z^k-AcI4!tv`zOS+Otn&3m=1^d%B04-^ahYPJC`v{FrCX%uWI>Cfipvq%nCOV&8kJt&+n>U&f&46BDMw0`0jp53h!S~6Vk<39czyPAzp;_B`{jj!aPP?NX6n^37#7U8#}Mxx)8ixKLpJrwM=mqbAW!5Bu|0BRk)d3SON1!yp-$?4V1va|9QGbD2lIG05a&3c62o$(v&~^4_Jr8tKvD)0v%%~$%3uQjf&n5x!!CW{&DB~|S`^$u9PT35MYk{0Y0siTG|#p&s6Ybn?gEm7rw~EX{@HQmN=-CHP!s79CUz%Q&^mhB-7(7Fm-}f|f;dnL;p~Jx3h7Uli<(Pn_btu_167jlB?e3LT_iZt^GtbU|Llnxvn3W0!!Nr$P<So-ZZ@WH$7|dXvJtfu56A|<?cNzXct^N*(8L%iN{S^V2oc@!A>-b{h5EOWfCxi{3RV=(bT1YoF4)2P>`)?OcIMPUjyj%lAX7pjIvAbVbF8O^NoBByjXS4d(hGQcA!8xb&`RLiY^aAMZEmL=h|#)$-IWLxXBv!`Cv%eXsTUb6a}^T4R=X{KmeaxH`9FUoAZ;qs`7gOc_P@YGc+Re@$_<o5#1z0T@dCj3e&>H6j8g|2Fr+9MXsb+~+YSDvobfYF*~($;6`!$Jl_?$xvxHYrILrVKW&gFk!Fh79c8ihtv1J#;ccWN7T08h60ZaAMab~1DUyu?Jr3zS0VMosi1Y`L}5aXFdwNtX~wOT*RZM_$=8s9ET<<J`AL1h?868Y!2V98FkDMuH)n!?4V@@dhsU1}tNZn92aOsTR)B0y-`{_k+Q0=x@O-jW9834_-)tpBWG`W%Ft!Tlot&WYt*_Q)UrS=xDWa@{3`12c>Ke)r9s7VvK~?qc-)qf{mOwMC@=n{O5qH&Wmy`X5BppEi}mG8yh@oZ4D}$>Sl<u8S|sc*>(RlJe%P*pEeT#N4#8M$87~Qb?anFoMbttgQ|`r(fiZ#G7Gy*7h_)?%-|F3=;dH0`Q|x4cuadE|iN#HG)g1nc>+LjV;PKoLtplc5ar1q+C;hY}o9v$^)d9C2-OtH#Lj`3$S*Ta_!k#Gr`f;!;hk_p<!VbcO#N`FC6VmuE-*$Qg-^Qudva21bOdgqmh8af}J2t!~o*0N5d$U*wV-Y40KA~FadrI%@1S)2kS;E`U!?%aa|*QQBiqk<TU1hR~O9Nx*-g#t;&KKo}VY%m7{WY40k~~Ms)NL=d!#=3U0E6_rP{&83OmL=yl}3+3WY7tza$?4l#l_!}^NgB<Kr5ozlFq2_iWExv6}F;ZYF9m>!%RGq+Jq4$)>d@+k1TGY>`%%`^Lp6t_>>)d>J-{Qeg{f{V*|$ezFz5qAx(3GJK7*SpAd5G8`q48TP#Ak(${a-eT{qu`c_eJ}Q`Q-lmB7&t^g5DEq<;>)l+0;uIN$WE$T??HZs9F!e3Wd?D2ci!aiqa_gW(XXMBlyBzwvV^<j?-7eZqH5U48L)i5#2Tc91!L_GO~u3rw504B^`50&eq+g022pCU=cX@|tgghgu&Z+B-VF6T(jXG_y*bJ%;wbxM`H03}UO1dk$Fe3UPERF<_?vul**bl+4&q$mxeq{g7od9dbeDWTYIlL`P9#CUg4%`Y7+ECV`mV3T)yp3CACf{W_i4U`t8Y=e^ru&|XGF7SA9Z#pBUHG$A0$$fVY;?oOBE%dykDpx)(+4ji0Dj@UPp2uq6hrP-eQ6w81()~*WC9&*E5?&L$r=jTnQq^-O@=i5HIxzy@}yDgKyX?n681I?YKR`M$~jtV@XJSUCEVJqB8Sc(@L_-`<7f{Sj#1@bhA($ZY)kj92?!lyzNV`1-G`k5@h(uLz1z{kGE?*{e2rdmk*Xu?rGcd{u0U#MardwGOn=*%ttRMYt76@PJ2Or(HWmF7}pSJcrYUB{Gg1wy%Nguckw2^2!_MePgF@hFpubarkH0$y-yE_82g|9G=TG#1-ZbSQ^hy~>`ang)nQLt@$}@kV*Q5Dsk=f(%}0Mh-@T4*MsH;me$TH7^e;;NRU@vE3gwq;vi@2QR{Hh6qT5rGj1OjrusNiq)$l@2-7mXZboMs_@ot4G+-w}HslY}%{-wzNYo9et(2I@zdwvO9mHC(7wcfL<J(u@<g%!?MC*C>;p>aPK)cJCc;)@q60QJ_@AT5mA_9u5?NXXDSXJNC?72dMJJ}dCDS~9FzqRV;RUTrTT@*9o|uY;ss|0zr+qzN)Pit%Thw0;m=e8KvNLHMoyQhw5#JLSoZa{}-yRP93+@DZ5oI5p6(BUhW}Jor2X%Ay-T81<L2)ht-RLy=EjaV7>w-FKGd9F*}ri+?5J?#w@r8>cl~#~#yiTobFF@GG4e-}R<Xb2uSI5kp#q8;JWc;5J?f9_vJ5I@U*$Z4B{=fdv%SVif74Rx&WKPUd_x7?XTCq-7BCzKyD|%(b%U<i1gfGi=L@&cHL#XxS?~5+ea)8$-Os@h1569rsVUzvAb=#XWrnP|W-k=O@!EJV1pbPDiu*k~9&V#ji|p2vxpl9W5I}+1@gV8Fw>Xj)?1Lp^ji-US4rqnQh53p^98W?rEe~Ip#L2cmcL#yM=?>JTm1OYmQZQjmp({SHAJlO#)HzgV@_%d{}Hy4tu(YF6%{t5}tWxLNh-~ea+&e5-3dfY_2h$d*U9jSviG^pCPMCkFknxNBg-9g*|W`N}j}Hk;a3*2u5=M>5tKD?2td%X$<8ek&d@!W8+J+F~0!J-(xwZyDC%hR9(k9(jQAG+Y|ZD$W}Elyt|i)ubeOp)}g{R@*W~MB87~CH(oZ@a+uaKJT?u{(Co)zw}K@bRVi8R)hJpY0wkvwfaG)wNDe!pkyrZM5T|&7g7QQ`b#<@<s<q#Ek0E*fZTDwb$|yJO@2MJ<0Yj#Ym+pJ~{RenrBXS#ttMCLVS4H~C1YcFoj${)%=?ro@$vknXeU>jo0Yh*YUr`fQszYAb`MOvRCe*h_wN?V37FdWWxUOk<4xd03v@#3ue#TJs5mcM33u=(ELto!jRWul7*PeE=BTx;TwMGLc50JYlP)LmpKqy%)qA+qNbaDw?2Tl_%jZ(CwvPaqL!>mHRzzMXrjfUVvz-*$8ew1PoDJ5AOM}sB_))P&G45l#mRD>-1zpt1hDG-Q-)>C@L9-<u<1U%2CiA{``i^4t0gGPCJ_kVrdB(k*-^@#UBYAQLH3g!6rR8mf2`c&V-8xQM^Z=q;^TQAY~`W7nC?cD7ol2`_(uFPxmNcG|*RfH;WsX7^oqZUzZmg?bpLNO21Xs))gqA4`FbZC%U!)KKIkY<@O9LS5%4AQA+Bf?Q!%{6RFzCPX9lS&;O#g^}#bf%k0XO-wiN>0ECb(P`{FZ^#mbH4*{*Z;8%@SRtO<<nNl_ZZ~v(DC9e-41OOe5oUe2@Zge@jYJ4B;8B{9=*jW7uKTYl*^%t2ZcWE>Kn3gwD5Ec+Jj@9%_f(%z$h_5)!33kTzV9gmwHnId^xC%$&iC;^5rmWi3DIKYJHSVE>}q}_uM+1<1&zYxoES5;_1iQT`Ivw^EjV2&3$1tR6~7Ay0lsu<#sz5E330m*Z$=;R40QBP#nw_M>KzWS;xBE;juZJz&O@NzgizJ<<S0<uftHe4Hm{iLjWS_c9?K|+_-XgfSB1ZX)_>G1+ln}*?i7z`g5uURyXC0)hfGNE9Jqgl%-w)#9$v(Vh)t_-;NIQ;@IzwJsU(X2T1>7fW%h^NS)~daMIE1WI3w>4pMTv7)MU`vm)uv`us-8gLVM;L}PkUPOI?pxrERe$i}oTxrOaEcqNYI;pyCXEHf<V6lgt*C4e>(>QobIk$7c-g)3(?FCmg}|9{w!88K<THDsRakii_);m`7g&l)nld+zyqc4f!U7fq_}c{OmJ>%ggRm7klj^UU)5b8^qVjUar=22uGv0<d*6j-EM=p4a0j>PR${@D}8r;wuB{d2EX*n;`n2vjO$&s~pNQns7WCP|qAt&s;1hrHbFt{t%E5UxaAonF1-moO&93Q>j5s-lU)S;4-GhI;NhN)e|{j$2_m(Q==gE#IA*42XJ-j5(gqSZHGNALY|4Oc;=Nvvgf7281ulxz$u$_@iS%7#%iMjuvNkaDhEGPilVKR&s;0@?ax&XWvE&x&vmVQUaghSKk~J5`{!T(((|A%gZc;V?6+0mldYA5roSE5$7E_7WWog2UwvI7dxk7Y7Tc0;S4$=;0cdPiJfxM->MNmjvsNb36zFI%kV|Xo|8x1X4PNUqS*vZmR$6}qy%J4@2X+VK!LBkrJr8Q=#|9Pc5$Vn+1yBy^)LA}*Qf_9~&d~q1O5zElm9M(__e?ggY(EXrEWzO2OMUBIw0<h~H*;mo;mSF9R8a)=7EvnDkKi!m)6Cg_XPz3SFc~v*#urTogde-FJ!<=-s3QH%z<G6_`Qd=JLZr6>8jxrCDdKWm0AY*MnKO2%egLuszk(5>pg~okX+|fKeeEiJ$yySsEhA>(nY=9lwP&Vc_j>nW`j#r}b$a~)%{@gcWe|P4eB+%Xi`K@(J?l-g5)8)MKjR{v5_uKXn~VcHVCUr)Aq!>si95HdmdaRVSCa|Up?cNbIrf9SW!_jRU8woYKw-O~JZH1pk*z!33j|}tb$xI6*MOh?y)Pgs0ahMNOp;J<@bdZwx~G@@CbY>!Wp@`omjqCC;Ov$76<OG@1H&xU1*nYTZ)4_^AQiS@D-^_~C*=KQh)0<?vCGJCJ%oEzW6KTM#d1^^{thlxpq&v`nY8OI=^s??WAey`1=DD>^a%%L_yg2awCJY%I3Zr=i(V%1L3JUlQ(il)&o=XEFk2bl3vQ5N6uICIvlZ%-JEnVIl!Khn)Pmd}4wY*PRHg+}kuZnFNB8Be9PZ?-IB^sonBMKcaG200a^+y=&u|PFj{wS-@5NXDlndV?BOVjh|N51J*Z1V{r#F&#O3Uw(j~|)A2P+1`HQ*+LkEjF&v$%3EGx(7zbuE3Dc4{&;RZ6)Nm7+klAE>65tWT{*P4>9ksJFKael&7Mlr#ZzkSt7W6b--LXS4&Yz7s1CD^~3jt0h>K%Zk235*c0|V8MrGGm3H1uT&^_BE$lwDsAJemX*z`jCf7X<kIHi%0v0Vv~&f_%#vd`LR+#X?qxh$4Dvo7zhE6_$H|{Re~c;nKW838WgPt?fjb9E#d}dVks-jEXJ2MZa&AZ?F<FSnITP75@70t5k;`T$G%&=NCtD*ZAjCP`38tkN<Nh8#ZnRja;}Lxe;&m_;<I#Z!Mty5Oq5w!<Ck%!MKs|`XAQhL(js0YkO37EG@DWy@!;>voJ7T*nl$en#9r(0^-};Dqa*`0q6`$HaSq?p_VAz8~oq3w)^6?8oDt6bo&j)+!a3{Z^cmQ%e<egoa!zJp{NyHH6_=m9q|1@K=jCo{0&%=#hEDfFRDFS!SONeKiCB|;_aAYFhwc}C=+Q<&I;Zdv=EPiReb1mD;tX2bNj|Uh2cOx5AWrGu??gOvfSa+xg5*-k(-6LNt7ZEvsh8k?Bx?&2d-ocELy)K&RVV_s*ZDQb#b@GHYd8}Hop~eNnqZ_K|31)Tmn=qsCQ+I|_9xK>Q!>3%6F)B2`M`E%-g9vHP@c*Kr34cF%ta4H~!}S2;HA<VC@H8AUy*}_FiXed|5!UsRZJ~#?1vf}@uf|%s>;$>srAqXI&Zbg}k`(a0fSx6>pAFLj=|(*gu|5gm8cnQ5ejsCguGl%7tg?$sl~1*xz)XHHXD^Nm#8LrFE3W4gKay0}iZ+Yh^Q$v<6z=K%Md@5Fk|zX4pO-%mG;9PF3x}F$r+`t@V~39%R{4oHmf`>hN*A7W2WZ(wJSD>{ycOvXQn!Dv(p|su>nQ)|ZUEVarmwy?BNjG)(hMEE<oEJBbA}6Kqd_wOCL&*AHU#sX7wfZXU=hbURez7TD){=|3S*MWDm#B-M0fG=+d-UtdpC=1+>o=J{<+2>3pHm(c}+>>5mbo!@r;}HZ1r*WeYodY-V?0?lNYZ+Q@D?0s+mX>wY}<Yg=;r0EmI;hWB^1?%@B(jOjEnwNIr#NGE7yuE|`9#pr=iL%BMBH#Iz@2;gEw3+E(BO&^XS1BjXh+P183$EPQF~+A%oaMD8k%SrW+xjL6<EXIDaurnHsJ|E^+vL#Udqrn*%xONa}@m&d7tG?}gS_c9$`_7H0ZS*~Xm;6Y)O`H9stjSJL+tBv(A<Sts}`&O65wg+(A^hMTET=fKfu)?mc<PbJ^Aj595>p%TD!{wG0{(F4Xz5pp~5X(#e>N1wjHW?9}K(RZ-pjab(wZKR+O6_RGl(Djn7mPb*PKckU0TH{_b`}4FY7LPrJr}B*3l;^L+@XPLS_f>rApplyI5XSt4$w<x>&j7M#i9nJOXrx{SNQ6nb3#_S1Cuwr<8EPw0L^+a&L|zl5+k~%2TazzfFQy27DjgN%2f5upm;<rDi~WOBrjsr$L@@ip)UzHV18${a=y~ZU+W?@6>|Q)eQz3g^`bhn2KAs3ZH0_Pt+@tKz{UUHKCY|sr3&Q}vx&UQI9S-Xq$8`h0@c{Eh915`ZzZjID`U0ev);<OZvNg5i%8YIvp$R9Kukbd_CaKeC$@IoWZ{VOx-C6R=alxRt6?bbB^HrPwO;n1gVfT@H=?E+Mge_5ghC2dO)<o1oEcoIu#>ptOUQkdO(2-cRYShxk&(&m#QX;fPK28dgOmLiED!61BCWfB`31C9lLC>EUZt>G!|>pL9JxmN)g{;X+c+7G$Tfy<n5GC4jhVS1^;Qs>Dc9hw2(pTEq|z|RM+M2DSueT~qH(Ontc;+1phr5ii363HgbG0-OSa|<VoBiL6P=w6;h^FbcN3I}Fo~cSWI``#k1?VFc#Pa_uqj=n<5cBvk$030j@VQK|56eS_-!IArkzO2T&+$z!h5F-dmm)_9JLB`#6lgBtC#^FY<)GA9O0#+gE`Tf2&Y3nCq8>GuY#n4TMvX>iB2HSL~2R7>Ji!+LzLPNUbzzgUOx5LZ1%~-Y<x;j7jpX#o7o4)a$e*>BqfoVV03Nv@v&JHmpD?yv4Im%_r?S?*dQ(^w8H&I0lGv+i(vR>nlvb&t9`t=&Li7iFO;Ka%QaX9pNNH7>eoxJcX+LS-5R~SDsmku(;#S}&>tmrrN53lseKn;Z|;tq1M+I>>5jOnWxhCQy2((|h>~6HrCenFBb8cm{iO_4<!jJDRP}Oaz$S@Z^sa8HBb0kEJ3-wPIihcIP7uQVO&cR;)Z*SZI{MX;biZAXDql06TBBbN-&%^3<W>y?t)H!nq5ivZ@$kVoS?2-;e@I-#+--C?j~w49gqk_&qCU)(DCR-SAE#xmT)AqecNBLk>tn~rrS;s>7POLxE+3*b?xi~<+u)HEO2Ak+P9ufMMxxz>Ln*s@hy=Vborv<G?{LqvIt7CjHTww*2qq(iwgbd&tVe$WN(}Xgs-@Yh4N=mYglLF5wy#0g{Feml6YQ!4jb=afm5aEBac*gvFgheGQQS7Bo(%PFCHqXb%7J>=!NL~(3zP}Kh!hKC&?={<Q_E1AYLpapls(}wZb_MmCm9+iI|;)#;Fh@59g~O{7cl)RyXBVI0(IpwwsEB;NW$0BjiGM87!GZ~`U|4SSFD{}Ra1QHBhJi~8#Zr?x%cLog*0afH}n8yQpPPdn0wv03+t?Kov<vZckMi^52hthe1$x;WuL<<`!xAx+tr%1;McpVY0&not7+4A`-)x=lC<h0x1{*?r@fx6qtyMgUxJF-J){eaBr64v9&wn?9z^{_K`eN)4*WKwgCrhmd1CIx(KP45)4ff<p`tQ9iKLejx8F->o?xBwK;8ol5vsPvYz@&kl}{Wg6U-^~@L(C!Q+W`}TPG|uGxD-ng8Ou?$ju-oE9<y0S1u>TT+AYfvL6G)DW-rC#l1}7IBPS-LpRwh)?3vMjkW5a%_!p@?Nt`M;(UpOj52NgzuhMav~O6XRI$R;Gm~|C0wDC|yaT_trA)x%Wd{K-c1=wGBj%vqa0e{?;He(69QADHDaks-Rc+_GAHNi9ZYCffO}<@D>T;3|l6s3x3eS2K>pi!r=VpdV6ejBo2Bw|Y*=I$5+I-Mg{dImt<-s)6EMHMNv9(rvg?qF}n*)=um^Zwf4k|+TV`rK5^f9cblAAd$Y##pCCW}R8KCHe@8>>{*gvnPQse|WsQr>8pyVY#2x(_qN?%%qV%Y0|C(nS*rmsh0b4>rZwKN3)eC$#A=pb*Gx4?Q%H{eq<r^|)*>`h%4fu6(w&Vq#YEHtEQ0wbM?x<%OMVm0E@e<J-KtB~_KId_QZl^EM4>=0c^sOb{2%hBS0$UvUU#K$)tXwfcC{;)xnB)e7d-pGu4Bl&Wc{?U1^&qoze^PrS9C5Tl)1<gv|ReLOZXWC^jcT!R-+QdM_HwyWC4a7NaXEj;nBe5rLL@_Nx0{LY&VE~E}HxXV0P5}b>j7BmTFPGLwzSyb-oB9e~L3Zj0!nrLDVmq)ulfq#O05GhF3)pbPX;I^OyE5zMv4!0eiXxBSjCAAeUTokTl8h>P;gQcb6!HUzPysLyy!Wx0&fACmhI*0<t=>cg77mh%JDc<6;5{J%rN8M+ea1Wqnaapm>E_1OHmy(EUe|h(n0@(~KoEdMPrFv9WPG{P&?^#WHRq6q2x1~huNZPC*O#3#0EFpxP@Z~jYbC*#ax?VmvZTScaDs17<<hhD3YvdZX)8;ZAg>CTK=&HsEsgzUsR46EDtdHd@WbmVMzd3WZ2;RPePo}xR%JtFLuP~ZQn}in<q-+3hBjZ(UZDH$XO=&;13ize}(F`>Fdev*eV%RP&?d$B{i-<X`?MfC~pz2n!82_v-KGwh7Fm7*Gy%kh@@d%9;)2|uEH+ycjMytELxZu<q8k2WzC%4}o!-m!nnpJ!3C<FO(Ox&LMBwf+Y=p17)XDgQ_{Ucfk-5n#cK=x-@r5>xnaX<rr7Id+fc5~Tms-|?#A|QN32<nm|XYr`Z^v4=a)yLG?L}?;ZF(g$_3{^ML-OY&0<WP$jXTcA-G$g9*XwMVDBP`)hI*iDXKFXwt=D>jrww{ykz<#e^8MNRs$5dUnVk4!6<%({eU>bJ#_Ai*{hRi~@^b&p6#v}J{rlA5J2LH<TYj#TK*CQGdrn3IvHD7{0>krIvm5Cd<X;e8(;%T#eslmI-e}DSRWlS6|5XG{j>A0jwTGhKJK369~EmqkRQzvnbeB7~eD6t=v1n#1>D{F3dCPaaz^P#S5p&}Wn=u>rczF?`1%U|s7NQ3hW_Tb=wJ&1Mbyi^gLSaB{-knqFxo>!kj8S|k&^L+7hXQWrmkJr|Tt-uM&k!a1euhX)jrSr_|z&hkR3-`Q#;KF*<r`$!a-`kZ;#!iXlMyX_X^x<2dB9jHo4#Z4a7bzdrzl$Pxy+o`T5Vt4mE4Yf0CkU<FhYK&idPXI@+Ckw8O#(>~NlQxPI%keK9bflstf^`{^wO{~W9Cr(uc(;qdWylH5Z75<u6z<ghS?Z{5gK%c)Eo$<7>V~vW8;JoT1fcG4%&|~$o|)x>_kfn_VgUYG<&Rw>xXa@P<=oE)$LZk^H57PV?j0kcgiAp0|op^zrAR&|6Em8Qto$sp~ZfV^O<t&=M<VJ-CAsJ^^@gj1jt;t8APNT3md%4*a36G{c3~IK3KPpuD#_|(Lj|vA=ii%oi~k1Vg@mh8E#_gA!qJQ5ZDlMvStmHZvS8I-YwL+HBAp1-*Ft~n1?mjT!(+}UAuPes#I51S5>;PkqG6bci!q{@In+qu0#`*(4d%3y6vcRiloybM4O;AX+e|pRfJ$fkcc+9P0WRO;Q<r^;)OSU&-1+BH^!K2u7Cgg--qhXu2qZq&o$?mV~+71-otaS*xM80FN2%3Vpg81TGiL{IjBM%yP4TY&(|LYqt{!j)n1HqcoV}gEP~<eD@a=2auA(iKjJN>o=kU(lC~WEa?BF0j#vx<U5c>R;b{zh9!TgXE78$Jp49@J;W2EN;&mmetC$Dj?4(7eMda@;{FmXqD0V%6ZZ?AlHiL&3EIV#8Wwyu)Yf$}tjX)KjW$lI~5Ncx%z&qGz1Drao1W%#DZcC*yt{ojS27~x#OIX*<7jZ}lN?w)V`zzk4tZ#!bo<KgBQl75sAYpR(3(KU>xS~EU{TCJGfhchP!gw?{xDb{?HA^Zp)GUc=^`w%|#h;%CuEQeQfsu}KzOVA|E7Q7#bSK7L<O;GbK!8SCd3S?&cjM*-hBW2C9rh$q)Dk~98-D_k+z+`$ziE+N1MA0++faHL$=#RWuM=4dutZ6G-0S9p^BPXPcnQ+NIZO78h^0GyE&THgMJ#CgN1DQakgao2E_|lb*|dWceTmyX0PLI_NA~9tiy#6)Luhe1h^T*nYukf=E(b&6JGuTj;CfU=A}-6*S&WNtMCjv{x2M`MC#fFcT{GUaAPqY$fba*DRQ-RmbiKY@P=+IlP<X?Y{Nzbe5J@1n>#o-V{cg@Rqbs-hh5MYTnq7guPbwjCW|rl8ii_~WKrL%5&3QvG!%PcQaCD|diDp+?I$g;+tt>aS2B)|1zH+lSl<aXs$woJ~1mxpprWx$5x2%z5ooeEsL-njj8R>eo>YZnD9VvTSu1|kjnOfa+v^rQr^p4qEXmE*YC124EYox<_Ja*wfel4RSFsZudyfzP?I@i)Esm9AehL0Ocrk5;bS-RCqCX8Oh_8K`=XojPdGRTSAVF;}A%*>$fAWK5zMnb%mrEHiz&3B*&I_y-!z$}IIKZP7&b{NcoLQ&ULHr3fYdwbcRQl7(^o*`BCuuXTdRpPx_1yD-S3GZnhta9viH3JU~{Nj8wHMyM|NfTswy)Nc!DHKlRWT)D5q4d<KEaPPoSW#X06ZgeWyT9K31}LNH$DK&k(;d(LV@7VCnWJa_nS{r5PZ6B*H`Wi4gl28V?7sK-zSxWd<Ko=a+7%a>p3i%8a7R~UCtSUDI6{yBxgjJz2p@>TDddax$c~vCqDTXR6q!hw>v5(gX5y@;o(76~@K<-_*fC9tTwg~s168BQS0C9*4dNKxF|H5$0K`O9=aFB<fw2>K6_fZS0Dma0iryqonNUN%BazF52SK&S3aTGvDAk%(d|CC(1P)JHJAru&qth~=8FTWw^*knHzodvO$gUBcwlJ2QU?DGL777sE8HBO3P|cg-H?!)_{U-Fben@P8i5xz4W8YDco<E7|b{FH!hrN8SkTPe1y8$sKkW8EwXg6|M(5Ep!MWMJ{suLc}x&yvCA+T`jRZ}^1BvqKy(qwVE3uo&aN+;w%V%IDd7S*=R53MfS*_uB3bbA~w+}FKADJN7v%0j_hj;Q_w!uvoSTR1n&C<%C?sHC;8x>iun;ev{E$xn~o6s;l9+_C=6reS18{79jaCU&coA6`LpnF<=4Bhgjf1bs7wdsEGw6(lG}=0w3;s3FtpG=`FozrP6j{BtXT+c(uxu)OnA0Gcc<>Z`)iw>ruACff2$tTdjYc@)5NG(zKI56icXIkHJB1QbHTIY?sMI)E-LbvY|6TLaN3T4B*3+?0NtMl*+(kJY4Ru_w2cauKwX#=mRk=#r0amd+;nqdMYb!i7YbEk)p_CM)wVE~0c=c-BrLA9`~<RQyq0y+Kfn_hrXP79tFw16!e(&>9m1YNkW_EpMmON-;xa&lIgzuXtQF?O-)+0;xzGiuEVc+znG|ZXW^Fu@6yU49plAmPg4Cake|C)8w_PUv*cEVqQe+#*)4vPqr!&6b$5TdXQSy|8E7ES)!oVb($Jpwo(my@(3@F#wJ>amuiEglT~ZRb+yKe<sqF++_;pgezB0hmg!ZBsg4lV`JQQ?TgrE=9P!GNrOXZMI=)&iF0649$9?U4IC+5toPQ5|yVjsV)g9v72K(rS|6K{|281jlq(_Xg?RA&)LL47D$%#rfNM}gcuXKfiStaL{JdpZl51pj60HX)$)2YA3_0+E+!1CHPP$-SVq>n2Sq~{qLzmV-ZR-Gr{vyjdO16%gdv~SC$@Z^^Z5quT6##@rNkyYVxS7~UvK>>TgoWFhu@So}ansE)E>Et>803-LvQrAp=`Qc6kszBa3tG@T7NDB<l9cPfh;Gw=UNZ64~vGRh45NlfiJEQmC!7d<2B}3h7Gd)x?2bs<#N2Zw$Lyug+E#)|W6b%Oh9amo~<E%;I{UV9y&i|le-Fvrs&B>?UK(%Gyp!j_6)&`VXQ}8v<T+tG}K{!$H_6Nr<U{J9-(k}ZO1{o4{C(x7;RX0IvhI_Z~jIHva+O_}PVjOp&6Aj>(%{U;yzY1hGck1ez(%4ob_O+Qjg%)n&_(ZbO_>=55;IKP$%6+6Rw48Gsd(<|>Y5TS}s3*iMlb=sAG&T-;Vk|K5G=>Qf%~@|3^ZyQViPRUdgIKzN`cD-y@}?0$*=>T1pjnPIHE|tbwINFS3q7G+Mdiy<buh6bjH6&`@lgvO{S>SYON7BR1hZ&ovNDk0<0xZ_)QZ%Zb`W3(%LmEu(|5f8fId)%2y3b;*gdOLGiy$v%JZ_-WM#%o|J)NxbzpC@63MNT=u@o75K|#$6_+=$Vmc@U^X`e^{#ZBcOqoDPoXX|Hbuv6b$t|0khpypJ;lOIPmX&(=6{~)fh3iM})<96=`YPr(m>a^{a3c`b(v&>1^$=D?j{yGtLOKBwerX_B_h5tV&XwCGH%<vLg>?ggv#PJ;5^!U7i|2+w71nVZYb9|oB)3SgW7$L|br0;BvTF=?UiONOhJNA=rfNe+APslqi+`XfLto94{kmfSArVAUcf{%&Yy819B;)^Q_arz`r@qvpR0&2`G$Dx!Zot`y8g?Pb_x3GJA+$&Pr9SLjB@59{IbYYS-a-~)B{_5n${8>9WsDZ>TbO{7DVRb-WeW9`DReNVP)M@V^>m+O9k>yMX6^jC&!NU}vFVnY>ri6~jg2WZSQA6f3?lT(vy%1UW9wk^ekZ{}IxfH~g@Q=0#&IP~kk?cqzWB%sVlGwX%JjAQv=$ZgRjTGa)blHXt?K6gtR)Bk&a$=ruq!d^bRkqeG}n<;5qlSL>&PVrmGOYiS*-pcVZ=%(b5OK=bM+p9v0feKuCwA+8EYdz_}ogk*;PDdSt(+V!bvq7>4Xi)SsRm6i&%OcR)o`T<^8#Bb`1Cum5G%P>SeWgN~bwTy$dfx5;#+w__FdK?-cGrwPf-ZYf1`O3s&qq!F!{T5#&lj#yt1jSYMA>ID2|V*g>cyN><tsauxpN55lSl*CEg1RCx^gWfH(bimN-r2=mJ_MVhtcVTK&Jsm<JT%TgOIaCaLRm-j@g=AO#IBr^qi`K3q-JiBuPeKC5uW0Z+9n5zjRaot>28XC-r#HZn3UqG1Obi>mto(ttL4_$s!4VNCe@r~VHEWG!amdXnTc8Sux;Y`XrJS!4qU{dmh^h7+|gJ1+26o`N+5{o}6l)RjU+cQw&iS-VH&@q-dsI2!OOI0p351pj2SZ4zx|NAGaO_db~<orEu8r=W5^n64lU%969zMG=wh*Nrn@DbgBjQv!a0kPtO;5s#vSw`iBi|}^AdX(3*{r8tJ;ry8?>?(h~(B>{&Z$sEqrd9qb;U!OZi(Y$BkYDg2ud-FYq^iTZNg{Omohn+vnr=kXwIo$Y67)<cZ8lWo0Yt@Pxtxj%N#p6vR4_9}cr7d4*WdyH#J+Y*=xB+olqCiEyTH~lkr5`}zpYkn&&{PjgG4yiE{&^euce`p321yh`y`b}kr%R0?;jX?4x^dAWya&TTP5758Vz+&R8n^Y0UD>TKgIm%OK;Ua(@cpjs68=i+!sLHWRe#FO}nrtJXxn9F`Mbh@v~?|>{Io<;Si61AG<gyZ1rY{1%pjUP_u}@_F|4!SXDkcF|VB%&p)2L%&a}_;jn4<!B=^R(HUvF{9MZ83pSFO#cPn<BP5l|c$tw;X!Qp1T`DZ@f?A1Ld<*c+qJO0Dwlmdq{OjW6I)=3o@%gg>Y*ie!<{K14ki~w;(*{xNf_HsL({Pdqtz1}Qw3#=bR)irul;dO7n8mF}Fm4Tu$f6#yVaCVw9|-=>-QWlVH|F9Lh?%9&DsLUCm^&II3{GTQqy{4s_-Q3Q*HM^AD==(EO<AlK|9Je7Lk6dSP<WI#9L)zj^{#N?iF=3=L^<Kg!OXTZ6q1(}o=!>aE6I;AN}q)BI?2rhTv}XELWU={v7}Z*qyqx;k`B(nxWnWgB2~@7*oWfSc<QyNQjCK?>pK#Qb(F6~XGcgX`o%;O2!9_bB+Kg^Y8m?;@UgOj!cv#SRIr9CLazTcD?|SHJ?Wh`A@8Vqw&HUh^36;E3j15PBFZlw)~SKi7)Xq1aj8+kjKeD{c1U_0EHxlwMAA@BQXgvGl?7TEo)Up5c%#hV9WuF-A`&C0Fk>5#<lPzf!g^VF!QSP;+$fT$PnO}yz*`Pme5NzZv_YTGRH@fV(kY}wOHRz9z~>=SNmfZlYZb?N=pvzP^Y7sPc*MY2_<%>=rN`ywpryxPHAye%4*yJ%(}VE5xMw!*jc1HLi^{(Av>(wUv>MwylZ2lQq^nL4APZ)>?DLwee3qeLw>WKSp*t84Y^uno^7@Yn<n(t2o|h)WMu|95{3fx-%W&Ezq+78TXQhV5!BC~m4U*yJ+xdL;Mwf^7imKyHgCbTT1y~`QX=W$Z?HW~@n`RARNXAG~^Tk`2!HHEe8r<E;JnUR%w`kC~B%M8$3`>Flr2%8ksU+#S8+&Qm*K^23Bfk?Y?5&yqTaaNR#lmh%YOj!CrcG$#vhNHITghuTWZ1}E(O_Y+8R)K)f5V5#%*4Nz{5NtwjVC?}D5g%qklx}hKtcZoW$A2azXO_O0h3}Cpa^zZ=~9*Ha^{cY4A5@vJC`<IUj%!hlWm0qdBeI?h1+}C4Q-HQexu-yowk1oCM%<=x8}n97P*mer7~j7iKb<Uy7y8G;NAJUgTFVQkL@#)=QFU1?KV6g_s%?@u;Te__@Y*%_LcC1F#au6pGMRZ+ousbQ=^Rf+O{;^EKzqVv)ma6dJu2-2Ki@$d*N}sKG!XuqAh8~baxx(56fmYHU~psF4WTv1;}p*BvF2LVMPH7Ybxe#zQSVAwwR_h7q%Bv&n-2mF*&d3><iblyMBETM$lKb<!#cDZz4M(Z^`T3%`@>P<Q89?`8By{MQyh&#JL-s^)+6&eh{l3*R<76q6;@T?(Mg8H`wq|P>_#bolGOS09R6dE`CSABR-#2&wKH*fsr6Jd(X)yby0^#I~J%t<o;7Ff4SN=QWwsN@W<LjNhMBHyL0OGYds?H1h?gE_eYa2IjM)^@|V!%7x*N7=peF|>=P09d3zc5_e`0Vw31W`&8bSUDmR`vRKeSFdPlCF2{Ugr6fpjpvVj+!x<XExje&5vuI_3aalLo7+ae;63r*fm1eA75SCBNL3)Qz&9#NB`5Q*P6ufncUmBMO=;K*(NG^Cq1uy8i|7*$B(GG(=|1a~!qHLU0$R0Z$!7#}@}e`jF5D~Y|nv8tCLZ>M)^;OKf*3uCGcXD1AHcSULUE54!BfLz5|EZn*^({MX!ng&P0*duqAbtZQD_}*dRtuJ1SP6olc=HmL7FDP(M_}=e*A*-BBHPimBqHg&Gjz396?{yr1Fk6uLTBycIZjt|A+;Z4al^5c$LhxtIBy}Stj5)kO@UyUj7H$u$=dIXG0wxxf8S<!h+~j+LFPN-(=X|^d?mMxt`2&VnV)Z4uMzV+%?9^{#tvVF|MDyb+(28BZ>#l;UDK4%!&QeV@RKpcUf44F*CV}Bqdz|08mIwII`Weqcn=!5!dkUdlD(;s^+HmIvRmm?Fz>J{+fbV1n*-3kDnyrRykvou3j?Dl`MS(OavF{*dr5>5Gm&#^+;~4NRETeo&?B!P-03>$)G8p~b%l!sSPU+s#BaDSp=&NP%$9X1EAT^xm2SYh*5SRdx?#_Rg;kh@ELrudd%gP(b#%c18ks}m=zm)2`wDZrS4WhxBc!%Xz<@J;GctS(mWPjRqgRnV?Y|H4+qDuvVv_;n}`8cW)9}vDuH$);;BQYL{)*9uX|LGOs0$cs1ZKD(ub`?oDRA_IiaBtn)d&n<m#iTp*@eJvCK}|QYIYARatao`}S`t|s3~mO_5HVvIr3WKHHI#*bInn&|_NT~Xa#nweg=Kp9p+#ljG@VZw^pp@Q*Y8XuhB~Y0Rqe3YpSi3Cg1QW1$UKaiZRQS0mL%palrb07Hi{uT)(Zy~$+c4_3f)+A$AMa*idVs-iwj-WRt@&9%z!3rU+n1dDsebVv^@J#z8zVjQEgpt&<mvWHMZ`GlPt@w|3_butyRA13{YF|hqo$p?zEUUb-dR6fRWCMBm$33JUJ}bycZ6CRi{%9teH~auNYl*EXU9mh-W#x;)E6}+&Xb|2^_>Ot!3XTDeWsrFT7K_-LZ2)3l9qTy2(jDIY{D%eK)p4unwc3KN;x8(dVfb%zNUEO&GQU4UaMwmg`IQNtG~;O8G^xJK`7Be~4c>U<Kp4Wv+fXTj^h0j{GleOy+OGcBDd{>v+7}hLPqw@e;VX)G;VoLNUd|8ZOGcBcD~ywdP%Z?jDH!MYHT#zuCi(*$XR)pTObQ+Meg~&nFFk!v6pl#0&hBP&p<)<LT(~z;^2o&M4|mP$O|>1PoVVo*1`@K>r>jE2-=)09_9M>mPPs4|Dh(u1!7i*3_f%y9h{j{o0ytWysm91e$2x;y1>=I03gY_D$lg*!tRuWZApwPFJy$VQb47x3-*VJ&kKVY=yJ3Jnd?|Oe;JEiVdmWj1J2|1jt~Gtk;x|HG0bkWHFyfV4k{K5tD^SNepXwW`5Ph!)(NIwGsPS;a}o^@FhrZZdr$$4vi>>{Y{lkd{#fWgbf9EU=r(4n9ONo5r(pKaxjgEUM0vA`{)R<CV&|@Bsm7zO81r^aBM1h0|taGA797gYWqM*mddAoaY%$P`-wMfh(dHDC<I{3BsTq{CL&v4L$BVsPsxP+ce@twlg{J)eU@Lh>!)tW6^!j0wUqrER`+u6@8myUF4JB(S;}hupI<thKfea&7aT(UwT_{|O(1`TM$DUR&&@45ILN1iD9hKe{KFNNKN^sKu0Vcw1?2aJml*16uJIDioxMROPPUU9kU!o4@;jZ|B-4|(0{Q0#<o6WA4~C$a7YM&7lPd`SO#}tw#frp32pG2zez_bSqfU&9-sRK#cSG@$wBCUHQ!-Z6YY_h7Yg=)?ga{(6B8YJtL14KVuZQP#>`>l&sP6Wm!F&xO3ifi1P%-oZ{m^#CdmOmoE9fZ4oU^&sDD*%U{nR~kfFBrQK(6cwu!>p!Lr;*9!J#h5_R4B7Q{=|ew;aH~65;(HU%<|hu;i8k+}DisHEYMZP}AX^AQyHWapmHw2M3QwGo?ubt%Ao5`j$mq25><@wa?-1NP8A@S$pa6=&Q$LufnQkIPNH#ZrlhYZ(f}qh3s3+@I=*?#pU)Ui`<*Sj$3)ii3O2!b#A1}+2iEmy5m->Lyo$LB+NRBeM+)Pu9(-oHap<NB_Np<qzh)S3A;D}2s%*MHlC2x5Hd9NuV`v;@?up1@+1QR%=2=5;AK?QysO?K=_|$5{`zOjQtoPr_Ow#f<<G7uQ=0i9;@#oFV2MF0l^xe-iv4@L@FwCUJ;0$x@(ct_)pD+qV1!RG?7P_g&s8uCFFpyFW%82}5{gfF%iIKVJu5F9K68~ue0<ckx1*K0eZFrZhs%oxsg6YKTMo*)Ko~%Sgzf$uZ~rbUz@Zbx)hON2<$a{9-15rhr)SE$V?nb$>4xf->ikFl%<b+BRRMrpN!Q&OD=5_l&GNI~sOG{^NsSLNfXcZY#R{>-sBhhwHK<&jU}BR@&RdeRx|{)O_in6x88#lvMJw0xht*yXlqgf>X3RoSj+JCzC9XTO)zNX1GXyo_yymOKPWAvsjITY|+NX`12AZ1d@G+~xE$#JQzQkHqVm)$4n3${byyB&=x~4BarJD56;6~m{I`etx7K<S1F?;JBm@sd7(BJA4ZWP>VlhY{f?A`Ix!<DGe@-DYFg%UJ6Hwtj01FLr<L)VRn;`IY};{l09zP61FSF>s!Rl$Z8h9J}iZ(#Gtnv<qv$dZa1x+;jbGILsaO08{>s*bT*W+i>zo;Le9&-FT6%VvEXdw`1r;&!YZG&OR0jpEWuZH?{_jX1SFH~))&{ry!FXR7n9RTFm|06DH=;n|O+Ns1}qd#Wa4zz*awtD=2Rgeg@GP1&G|dJJHRS!GvRc<D%376JgkwiDqZnX~{8dD*CGt<Jz%D8Zd5YhXVu@7k$xO4%m{vNAqDJDEkX<iL=?+^49u=mp85){SeT9$u{$>U@zU@7DfehF4t;bJ{FffbO@Grn=I%w)#XKgb<tl=1)R`fw-p?r}^Ske_Sv74P$ls`d61beMc;ef6)TNLtS7#SJUq;rKQ>UKKW&Ji9I^Y<KLya#Qro2Ox$9vuH-^BBJ=Wy<Yvv?xfy$>CRx5lU3pXABeQWY7|Y%wH~?U4!@F<!T0(n%t}59EBFug|bYz^89>q{Dl5e?BD(<))>p@8C=<|U*G@;3Fl^s@Sa#$p@f>mCT4dlI=Vom}oSG_ohoBZy(QS07|SJ$DHkl)IyJA@#)fLq1=%BUNi33c2e)%h){&IB@Pl+2)F>DmgAz@&hvzp#Y$;7@X0mg!9-*mhr=K6yo_OALh*@o|=~_bV2ioO1$fE>)2s@y>-cVGiCbW#Xavswgs&Z-?J=rNISp;Fx&_e*`V7OXG&|hH}z=x$TjGM(l5q+ZwVhNH{Iztuac8%j2(qnY>q2g>Um-_wU4emE;0`H_J7c)pfQRwdA-}XZ)4}t2rPJtnZl^x(yAMA~q`;EaCoQ!uCd43MQMFuF0?iL6~bYtd0gU?8yyW8ygu`+(;0`?w#CQ^E)zOLD>@-cBPv6Y4@kzLy6W`C0gH<XkmuPKS_Z0(p3}+)MqCdcU-KZPLIJbJqQ$pZ*@<7ns`TwM`u(HWkvq68B8G;{hlG6@H~=_av2{jUnvLsSX|G0<9e5gIoy*K()<spk}fesh2s4^(`;Cp<5oepm!~l(+`7n~fSbMED-$)H`6G?xH7*@O2X8h2=9FfQga4%aDJO!a1N8vP7g3O-ohMv6(^FsnJgy$kO%I?87jRucvhxcM5;zvIIm*aAux&n))6JN)y)5-C`F7Y9yf;c>W)xH|rpc~58Qt<a^#)NNY^@??qr4p{mnWpzsEu&sBc7Is8mmhUObbmiw*0e<@W}u$u2w3%^q=KgryP>Fv#a-(QG_!Ta65PA2|O>SXL3tNdJ-DjQa<NA?8PXAnHR@WYj0{mPMiT{Ho-1}LKO5n31YbR*{Ng+eOCVE?l)ao0Mjo4^LM^?!$)!{j`I&lf}ybkC={dv4jRYznn+$C4&1#X%Y4z)v!<gPMuv|^@P(*yEaeTs0!)`9@hjdvJLTPcu^H<P>>hZ~D^d0RfN{knQJF|uPeKK#ye0DZ1ehc7kJTyLAFy^pq>>?>^fWM|E_Jyjqv*{0@DY{(tY`S3I~~wGm1+9U`0tKe6gvjmuI`o>yC_>ikMM7p98Z8LH=6@z)wlPQ)u0y*9{jQ?hsg_|{Qd;m*zmG*CLxzE)bl$kCFn4<G82Z$?G+(N$4yfDu_XIqkm3Xf@p%PpK6+C|sSJWF4Yd=~YFen5yFHDRSLnTLHX_pr5hEtUs>ZaBAsTgFdr5h1bc=G>sil+THPVk+*Nn@TFBjTRX9fm5cwbK7$nFl$;hrKG@xlKHyJ#oiB~2$RI8P5aw>u|YDJnkQA*W`TgAlO{oR0!($YbA}F}NA;5IfuG`<J`_%+0@8b!vVAI}rx=Glc52%Lfx>)9#N^{v0(QF;Jdif68{qpf)oXPEfkba?#P*!v7I!j?<gk+6kt6|7eP|lA!;HOY-OqDFLCpr%L-`)f8LA1)kAjjiwP-MX*hjv@abP(ngQc{OnY0v}YbWlBt}5>xck^F72$2hw0aptw~}u;T(clQd)7?{bu)<UHSnv?#dPapk$UVQGe30zK>ecH<*1)5~h>%3@Y5(gya|&rH~~~R_3;k4iOfUj~SREVV&5oGyNP|4DU_V%Z4l&CkHxpN{n4O;vm^SJtE6YmA&lDZG=m^qXt<Q4hG4J!F2XCCBy;|fCW4y=Rd)8irkW-#yZZw4?+yj=AK+41F2s#B0@8XC@B}4TBaZ2p?hHlVh+N<n*}$+&rcM?P|3yUH_T-s$?YeIQNqs%W>_qyJ`5glL6oy16P@^)>}NThQue}4L0;3i2(_bJlC^KWTY!6DN#Z6B6=1)L6KS#Uz@#RzqDY9^7+wL1>~TE>7}dAg^m;salK3*l$wnWdOf4~gga;i`g)~H|kaqnNzbX?YF4I7zM3h#MgdoI%ua%cTJ%O<zN?GREWjfA!7p<bw%$^pPs6j|jv}ch@l&LkqeHy*fo(!3tOgNcOD<4Gh<xYrVOQ~fFt~h?!xr{~)AeQc5{p@0WR!D{)uw9-|O?oIB-V@-=W2iC1K4f#jz*T{z!IKFTcoo)RGG{9cSVB((WqAo^;-`%1vs9P(_7cG6T5wm*`WH*AaIVTJY^fZizWqq)3vL(R&}YTf4=e~BoqW+T1ugeN1BUWqZ_0dSU_ht=j<Z1L;<uQH(S9%Gb=m^m|NHOne{j3@vKi$D>*<A<KrjA=^8p*rxj7#U=FLjJ;WE(uP#uG`2ncE?=sdIzN){88ehfw|)tFWS2MYv*hXZB;<Zk3nz8E36-10W8LNr2P%H3qriNf1>A(Zf9h@x&93TI-_66F{to<<qpM+}g1Z|^GMY>uABNS*<tyIhv>%?+E4%|q8GQpde$e8K%&pL>Xxz4y_E_+a1&_KWU=HU!-z?60(?!h&N%+?>n?Lmc8=b}447u9{#=dtN_55`KUTv7v+r;QS<II1Ii|JF?UvgAvr-p17r){o<YHPf~^VKi0t^mhKMJnQi2->)+9Y0%xW+i(T2|hSf8YPE>yk{O)oNxYt{UGfuN|+E4$~TX;Y27Vl@i*;XoVYJQ9sFR|BDg3t%k)ah&b*4J)Qs@){$HKfY=O<k32C&T_^OY&H^ltHU3lmxM+xooI=@&c@-qs2-UKDvU|mJT9Ja&cC!jA7LXazc667prpCL+8d?gIeR^I;3*CP%<X%f(a`mTB!D{tfI3+MQq}p0m`mlc)+r$?Q1(loM6YQes!!`_d2T7sCuY0@(NuQY+I4X)^1meEuqnXMDE$VI4m5}ElF(6pkv%T)m;>tI`Nvc=3kQ5j2k2iM`t#Yt$ViSp%HLfKQ~<Yz%G6nVP!t)OitLnN||%Mvhvi`Y0FmdR|FtQcW7g$4G*i~sS=MY`t{Wa$#soZ=bA9VOW#PhrV3%Wy>V6w8>+-uYf1eQKU!s*4}a}_s#*_Bz<r!4q(KX9K93jk`>kw`%u~rzNI7V6#GFS7QzI89eUJ{yvWu-E7T%dak#OJlENMBFw91t_*HKVe_t-Y?IfLs>KJxL8o2d1J-M53vTMxeCS-NN5xlgG8NiK#%vddiVT)mv+QMimURN`Pt=$};cl8}mXcbI3s<{;<lRI5*yyRP)2%jdpPU*p_aw^*;VB0e*u|M{!(ggC0yTJgi(wKw_+VTIdyLj1^jxor_a&J7gU*YbN~NH>ilUfQFt?IL8cgf<SfQH=nA9!^?(BiIW9Umg3JT*h87@DZ3Gr_I({Yc>)w8~uJqjWSnpoaU_dcHaoy;iIEVT=k6z0OFW`x~wBQmDL=>>1rC`jDcTH^**i)B-B~(P$H3zh!kWA>p|XkG3h=hkM(j&mn^6-ZrRULC-2YxlP%Xdy&~7yujD%Y3%SnxLatNKpa*riq1B19mLPfWC)9aSor$j4fB!2Y2_fJeZwYneTY5Wy4Q>r&GMWT-f683ln=(gi${fiIo0{Dwg^_t2q5{i=qW}(rU~jA-(>FJ;Ud_opMj7?uZABoxhKmAO&DLd-{3YET4ctvcv6hCwI~h0FKsPj&+6$79+meJ-%WvdiN1#(#LB<fEV;B+tDq6G{0dZgXlN;ICzoCt}eG-RqJQPta_LlaW*n|-naicVs(-`}1q*<MF)gIE(_#4O){1fa2Ea7JUI9J1fxYFeKi5U@Ed+Cocal4cUe`RT8|NIvu46HiW!z*oT6Oj)wUAL{vw@G)_uvWE)#CW2lSKH9g^j{lW4=cfnV=VeSje@pKYEyy1V41h_PV~O3+D;|`FAp*FqbD#>f=FvD`^-Bx5P8?vY;_9kQ<C4E<13Jn<_21K4eLky>wffZ`pizWF@)omAsqiS`U7Q|{XWxQrc3EWI@5h;9xe(5<>Uf6zYum<#sDShO#Bm2UTUMqXZ|je{8AR`j-)xbdpVr~dpiU1Wk=S@9)(jqRi`{I1qa5LvFey8NoCE{e@wy2G9?}<ILbn^1gK)JdKoF10{gdVxmebSo>6_zg7CAm61vMA-~7ZM>dCSi-`l5;v+H|2E`LC>c!GUM;#a^O8>DZClgV7D@XbylOE9+Db<$?oQRLhINn>sNs1vH%FkFunQmGb8u5zI#h@t1M%Ef1JuBFfzh%zS{o)C7L5bn#eaIseWpdt(UMhHi~12I02MVotQW|_0R<>#Kw*Xh1zx&DB#=G#2@12pu3R~y-rx<LAdYY0==DNriUn}}6lfxrjtV?LD?e=qDHZ8><JamPs~k4JVJb`b%t80A=9v-lvWL<C|S%WN+vk8W+Rpq*Ryzxhr=s|i;ZYtE6@zsE&-7r_Uz5I`j(*T;-*6#9VHc$|QEqkdoLvFaM20mLLvD^w~xryZz7QeQjptE1L%*5=@~o*XII-BUj2fPV@`ME0Da#(he>7-XD;YG&z@0AYwY4<%J9EA^e<k+3v7qaF}BLpJOlcl(Y@TrZ9PvwfXMvRKMHd#2N8ETLXrRRdd}v;1kNZa#$ZV&HyP-E6|Y^V#*yE0zW?IcNee;=K(~V<0{|2FbI6S(I)dl2pZCtUyTb@_s`ZQlvLj(#Bd@b$|tcSMD;9%%zB-M=PH!FxLV+=3S<vDiatnf{;od>JlV{?$8^g>=_Ug`WBjXEgSb<1so{!m!vw<RTTT)L^k-~A6cK-MSl+7gnuK9hM>ydO7(%I%rjX!B@F*tUlcd?7F9OXoWMVLJ9Nx+KC}&AkwV_0%9hCm$(x+;=xS`<x#o;G#Ouu%qPUF+!naq!59>E(c^>#B@N0q}(r}<Q4J(d~2-0((X7z6Jl>!opC>Cqf3r6NbE!{qj)j7~aF4-jvsJCGwPk@p6{vCJmn)}rlFG?3TY%Dl0H&JDYJ#XU4uC{P^b^R^`%(b_aNv%rj6Bd*;Zf3?+iCKfakNI3C75>?e==E8D>fY@GEj3wPD=T3hoVR?LXfP()nf7KR9W!u(EHSmX6*5KF^oXR_HG_m_wikVZ<WVMla3WfFlCey56IV__U8Vm3w1tEn=(wvVdxqz-nH<$xrf^fN>=$pxaT4$L-XyusmhF*>&vsx`<viGW>qGTXVj=>hlQ(tEa?gjA+mvs%Q?b60O>e*A<j9pNm1R47NmjPMhWcXGbDe-H)c=){D8B^}8jNqeynq;ckx?j*YN92zFMBqw!r%DA1P&h1AQ*@$bzy}P29wWV?}K;=vB8D;(qSQ>TP0j2?qE>hH3!|3gPwhr;RFh%F8dWFG+e_Dt4vpGhUM!uLOqr#VRZ;eroYe-wi~uK&|UdH`btu-4v`$xy~zQ2+3|+Pmhe)wFSl}wKjs&=?Sm0%5cpUN#0{rjfRF#9_h%0{42KPSU{83^XRrqd*6FwGf#_N0{|xE?Omr#(KpBRd4MF}BZ-A7(vzDg8iTJ@TzTIS4wFNFo*ua9&e96m-lv7bG0gxLE+ON!Us5X!G*I=ETb_0>h5Irfdzoleh)yVTz!m$zp{37`)uFdV;0V#!$K5Xoe>xJW5rP8ZTW}d`DLUZRU6>OE2_d95|T893)1Y0><UeRo|;!x|*yhXV+Y?WK99(PR_7J)D-qN-5zHvLusmp((hHGWa?){;?q#9VF_TzKJ+HXh*0;`^?03P|uoZ9Lv`DPEg_EBtxg58St9Wh>ztDB&u_=>6xGaQ%a!-&(<@Kf!oB3wl?E{P&!UO>A_O)!|r9FqlQj0`XKCsWS_=GGH$RipAOunECq9jg>wuP<HgjQ-z+#BQ3DYt=@Zqg{4_g2Kbp80XzO_FdZwsfCmZnBa&cy3{#>3T_mWk6BC#^QTX8g>{Yv9tRNo{CU!?i<b(4m<a4KfABd*;E+&J(+PfrJu#;vxvrtn#0t*+jLfBwjiqQ+-9qhAc-cc5q7~&W3p?=9xyGU1q2|OwuHq#U><%wG8tiI;3D3k$outW4QS)PI$GOo9qo@M@Ea3RM9G){Dz<&&z4IEWN7ePpepClqea`HT|=x5Cr^!rsEkDH{PZW=PJ&HzT1kLWq|+I!xe<Mjj-2fd#fdL0tOIY@qbpueYJi52R9pJ5FX4WEh7U0+w%hmsDnPafj*?z&^d~hD{}wEj8+FIfH2oT&PabN-^Q@eceX&W&cZTME37yR6o75OTC9P0M$_85`DYp$W%|W8c||?eb<m<eY7=yF|8L`_e(de4_HBtm1%3f^#-}SwJDUd&8y}kQh7i@{n+iYo1!TTyfkJRm7z$6CZmKteZ?O3@h^RyT?MI(NvHHPy9%Rt+}DMSRac?kYL=>mvFaz}*oqgo`U%3na|yxdxRH-Q6T#w+rM*y#6bIyPOG)B=y9$9_1-B|j<eOcEWX!g!N(2g#fAf8^j3Z4~RP|l2|FT<k0-Vw8A)DK2>!Xn40ze>j2j!y$U3~d*3QVMNfda1L#f+r=%v&*4$w0Zps8uu7rQQs?XC7_f9?R8UHu7eBQdaVwy)zP>_f$zNZy61Yrn)0;EOyQVsLyOT2Z6k!xxRI_$cGgdS#*nv2J+0da1v$+=bV4by~QNpN*-kDX-&iF`elS%BBzKe%kH{~RDn@b&|+UrLd>q7u(<&`L7WAGrpQsC+NSL+Wtk`mOZ?xzf=z@w{FO4^4P=WusDVfeq3pjRWD9Y!SKt;iCVv-j3!Zre-(q!YCk7_LEsIE5ZDQM5z4wlz05>8qS#}&}ri9msm)vnq-vYhFig=M0X9K+)y1_4|kt^KG$_*@Z%|!#5X<2KW-P50~OJw-%?k`dqw~X%}uIjAM<fVkgB622SCvufn(I%L~FwG%Y|Bol!X!WB&Dw?>Fl<0H66io$8Wo=a|gA#)$)Ie2LRYrS}6gt+!y&|I&ObvIiSE9%mc3vb1@9W!D1kD0r8y?y5Pl=_sXhKLbg+jW4zHb!t(eJ!7`v)3HZOf=uD-F`|C7?8_Yz)PHoOLFkM&|ZG?h*X%Nfl7h@1>81vfKK|s_#@*k-b<9f?5((^_WX(wtR^VNET4_Eu>^jt|w}GflCgi>mUEJ<jDfs$Dd1~j2h>(c0E@`zW&*Ieuy<5*k=x)bLFQ_e8Z3KyiWYU`?n_*W1u$Kl%Yg6a9fl^bIEbYUPHVCHu4b<PFe6sXq+C)8hGdAIW@71Ip1|t1P&f&_}_npiNJwk<X4HnMn00O{p~~m-`jElH4E2Sz!ypZUWxz7bHuWotu^FXR&ais2yj>Y0=WRIM#*Z;*XaO4IEhr_oRiXl_)0D?t`Y%yi)ZpElXv}TWzR_5`A>j)cb6!sQpW!P0(`Y8KzP&r$?mtA!hhQ3Q+Ix2yh$+fe~weE(pV6r-OJvC`a*~;F$Io2sC<D&vzKxgpG4F(3ej04;$--{5))2DBa~}&P#p%k0l2%Q$oa=R0x*&>J+e{fJox!!Tkbn+$qy73o>@>45MsV}v_i*7nkxYR5vM4Ijs}ncjL-%-^IgOtmS+wZ{OJVJU}fUmmye5CaG&ym6U*iNM4FAGrKbbVf5u8+|7`dCRJ(!VTYn$BPc3rL#WEVk1T+3Zt%5Qy?z#uD)i^T!QSzf)PEX3#flL^qKe0RnaLHZwG5jRUMa9AQVwN5}AqPHI3AB+0ZJ<qu?inZrd=(jM;PpqrJ-w{zN2#?2yU7QZw8|#>F(db~GL>tFmwB4PnC~n`{u|t960fa2Z#Oy8KrxfLugm;EcJ(>wBV@tIlwyyjH)5es0h$M_;tzV+UUd<cZM`fNga22sG)De>2g5g?Tv=Y>3l(@>^|R~p5z1=k3u!EmUHGm`Z2Dd#l)(}>)LnrA02JkWJoi1HzfY*ql+Qo1G(JyGNQGx!fQT);1YcwcvB`B()yes9o~b&>GF=$`zQ+yxd0zf-(3?SwKYH}D4kesC=$eIaAYEnd4g-v=%jNl)WA04mn3o$s?miNI{TU}l98LFTh3|wwW;CmlCJBPj;J-lYI<kBHeHxN{-_2qf@8DtZ?AZ9YC-uM+(w~?K(q>cfs9Z=fIA?Wy$#<j16?nulp&$`wIx#{u!cdSX@WAB~>{HINz#NQRcZvj#us|pmFc~kHJvZ}rK)O!^rTEz{TEWPP(~gCLb;C?rO^&86&Krgrdfs_S*M5sLa4=AkaRK<%g1S|Fz+Ik5bksH~L8mrdP^=Fm_hDn(t9~dpK9hso35b_5Sek|e(|+&7r^i)ye#bRdD)sCD(Lf^ki?{0Qk<qq)@E@?Pg6Ksr7W<qQ4%n-vMvN!H0nvajaYI#QtmSjQr93$P{^x)*e~hRGLycS=Yh%4>F6Wdwy(ezl!-84`RS9vHoA$sNJ-qB&sRooWvQbX0X&`ePVxrcXvF2w+MU<hbnvw+5#U0pu-6JLdsgo~MO{s@~#E^2IOPA6Ebl8lxRR85{r!h#`%Mw+mt3`dF20GdU4|=igr_^wcxa#7y3ulRdr$jP4OWaKHkBH124Gg4U-2liw7^}XFVd;~4VqZ<0-B&9~Zf+1KC4OwtCzUjOl_*s;hTf#$oyVHcVUVHbY;i>;L4Wm(hCgll<Uie=DT9HLb|w~+g#7$Rc@=BPX(D1|Izo*eC8zTHWP+Yi$~V|>{BS{$6+!173yRu3=-}`L<^Jy<E#92?np^?ya|I8KT#2#;bAC_j-X!6l9`_la%O#_JG`-`?-gZ*E-BaT%ii?SS^sbxR%j6nZqT_>dJG$lwK<muU`HuF)ya)`jgHFa6N+p-bwVB;ZeF9}^WWDK`i~keeh-a|V1^?48t+LA^2bQCk0`o7iClZ*K769E29>y0%oHY)Oakdq4J+17=1%Wol+D^{gaTEChd4(lWhsAHr3|LIlGiw6_7A@VLdAX{&vB62Q`P_)XURIIVIG0trve~2wPpd?tge)pHLKL^w_aNjDU4I20;S#2r%dSl36P_s%)t$5{Ip!C=`Coe{%&h}m8tmx~gbaX`ON^qN_`)S9IbQ65yXQlwt+}Db)La{=+nl=NP~vf{Y~vk0BbW-`bs#ePYA!5mKS)5#C14lPuq^3ro}mX#zB69@z>WIx<jhG)@tY^Bnr*S+gvGOpXaQaIDLlv7UGxYtC-%0%dgK8O#O}~xjU##}his-Sw!L56V>N&xc>+pg=_Eg5M;{smt4^ATCCJ~`z51EeKVg_$>&V_I!Q>)JZ>!BZ_HVyp38k|8i<<i_Kd8|Bpvsc8)1O!c%-(j?z0Bl6o1%vnbg=^Bb>hy-DW6Pxp-lIav!j7y1&=vvwIV<{dc#nfh9}!=6N4CH#LryQ(D&P+r9u!7cD$0N54~*eI+gDSD(|KP3EJKyh^9`?=|1g!pV^~lJ!Md<z?)HC`yncv)Ac|G8P9Fd_7(UwnQ+feSUjI*vjmhxf`J{&gMaurVwa4#bg7Aar<=!B)N-b9ofKMH9b^}1Z4sQ2VRZJU+NIWW<~lRSMWems25DSjZnU$?sc9|EKFEx~yMEDSSF6e?wVT&iT$a!+f-&>59%U7EuCGfZoI9q=?yCKOU&Ct%-`P{H@7Sb(Ue{=MYoiy>DoHdet||c-(u=r<G6l$59;RBeCe(5lsu26IDvnT#JxYr`gF>*;UuQ>2A<m9PN~>0vfrI+zR(YN1O@>Nb+=7KTzJ)knX?*h!x}Oqu`zBx`E#vr(Ko$T2f;XQHj!j>2!pc#Ph$$0W0idL)z}3eH0e&`3pUMz6piG%3M`(XJl0O~vEd}HZRrf}>B6DVDdJk#C<dsXw>PW$?K$(AZyjV)ch0TjX(qNoTcqZuPGgK0OnCN_^O%c`^htSm)mN2)KPTy6$E@2=#r6b=J8QiLR#zL()D~yt)pci~?)*6ct6KCauq;hYh3_)n4Lww$74_pPd^;W`mDuTyK{+HGserH$Z08HROZyY&1HwPa~B~6|lBG76$w`Seu$SmR?gUL(;HUC2UYCN)M05ABolQ%5Z4B0k%HH;aiOM9)Xw)1E^kZ)Ff-WoJYbH4SbHbs&dQTG74SuK(z_-g0p`1BCx54-$`P+@*RT?gSY_w(|5mzi%(9jiy(d_)LU4*wlnma%`zxFwrS1GhyI^pfxPia0>%@ej#MZ=RkFApb)YI0AoJUiJxB_ygN4cyh<9oI3fq3{Z|?uk&mID%z--oMFA$RV|3};Ri>-(vz+YF8qW3gtvF!guf2gP*@1CU0Gf=Ba4o7f{S#OC};HpE=QgLAFnpj*@SYZym?&zD>oD#&I~wiDm)w*DxoXI8VjMt2yxFWl2Ei1b)mGVQ~aQ_L}8G2!9@*sl+t7@-qb$sQMRj63{ps_S_+5c<nt7dcGxFLBR&Y1-y|3C%(Un#;C@~nSGpj~gvvnplrj`!tuyNPGoK7qgQVQ{??|np+nmqS)iD`#e6Z5BC?D}{sV6-wR-{5QPtX7&MvqAk*0D>i&zO{i&;QeVx;CA(cz%{^6Dw}0#5C8YQDtcs6V)Yu;n%dq<yJSx#A(?vHIZEXP0rQ4cr-cgghsmpy-Gd{=Fa3Rh5p)|DVR0WzIrHP>)tQjlj_UVNf8WYI*HYeD9-1`rg3Dsplndj2lHae)r;wYVFxe8>qbm0w#a`Gdc4hoX%q=E5M19{Bwkex&o6#ihX9k|U?Xv`@n_Sm4&kq2=NISZ2dt}J<VsFNj#I<h2HpHAtwK)9Ga0U|Kn>g9L<3OobCe`e{oxzC4~O;)wFmiRRzZ|@3P})=dIw-M!u$DQS5>BBNrPDpi^QEaKW+80JEvNiG}%Nbjn*%QT;pUfz&{@t;LHQ5Tfu)kbk>iKkg^<kCT}<}mOWYfJU{vygBGV%5u46_9}LTr`rUWVRrr5jKVs%o>zNrjk_V@9VP}8YA+wCLApy{27`hZp@aHpr3sS+K__yDU>+@c{*n`laD?ClhMA+dR&`W?G;`q8-tlAM+TpHuYafumGn_B8HUb;OL-EE>BO$egmW;3a?8;4khcU@!r7`Be`9t$h*rAe$?Okx?AG)0KCXh8@=O}Ky4%eLPyJtjTZpi~9O;WcnXvEwY1nlgDgS#rg}aNJ=rHE-Cm)9k&m$(=1;y^v{{-Aq>OPAja;X3^Q(nnH*Swk_I8lK(nL#Ue<y8TGI~|0PS$->n1-S&ADL>6Wc-%iS%l`C~N(T!iKui{0#63|Yo&sQWMRvM5XS+>xWLq@6!W0`9&cEcdeGW1E0&y9TdZL?lNu7{c#Jtt{;+(3)phw`k21xs<nRT;^HfjY_%OLl5pDB7*F<!Y;eDunUBOyZr;&1jFCBLE^07q86)xf5{30fuS*-3`9hzU->8ELsPR1LJFd@rRuvGt&L0zsHl*wgVm8}M!kR?v$P)DGSGW=13R(p%$K(^rdS+C?FIVhT)IvCQ$<F;25TLuqQ1&(mhfaYNj>8}uykWSi!9MpbEm+!^V4IsY!>HAdI9>Y6zXE71d;}XmRpdoN?gE5eWVFb)0BX2k7?zppy(S;spdBouw=h`PUBvu5e#vZWFirzu+pU!_Nk9%>nsG6{;In}8k@oQ@vTAbB*&DO0xt<x*=bAtmrMY!&`G!Q4oS>M;x$}4X{o1JbxyCdzoB-psyOvbCAixAn`VGlplO0m+<4V3^SK%TE{-s_Ad(G9tpSeu)h#5oYyg+~Qm(KYZ?>+k0js_0oom>QAox|rr85zTH4S|5FC4aBBCq|142~Z3RFRQ&neaE6;MFzgjukCuUIEv3Gv{(%zl8;*N^r)fZctUX{2zXEjQlie%H95sbAN;hK864e_y*MGuH3HqEch=~j>>HzrD7)a7-MCyWhHgewZQ87$me??18|VU*)_@jEXrSwD+|jh2bSJ;7aajl!v95X2YO3hdL5aOBb)#J!%H=ZXS~pNbl_%Vu4h}6Xp|1f<^lHv`!lVm=U{_ku6W3(3O_m2&vPdj81$AcKXusvT6p`alY^nLW9X5iY4l#^?vc$CSp1qtWBbAPI&z*%MKqBr%5ty2D54$8Om)>m4Z6s=x(DR{wtFYK=NI654#XBrw-lJdTc`b&*;#IB-@immS7xVc{|PZbO7~g-f~-MM+x+z^;7yr}?YGxZ(!|r7+83*OX(`m(LXhnqB8!pQ7g}*?vk<5!cZuFtBAFG!&?aC3hg+w*G>b~7w-{luC@<4{+7L9OGnv*k5MLgEji8xcA!rUNtagh`+^%2IG1tFq1%Gcrrw=O5Wy(JNo-s98Wq8TdxPy56JM+OSQzPDDYE-&62hpe%T<)n7*tD?Evr}!v@R0?aNkj~@9jK&CbaDcva0p@%|BfL}22F$4n5}HSCTSz*+K1J!w<eD?(?|n!!Z-JsZgRYdVN!qtq}R%2P?4(2LCy-(ow}Bt5iWT5r8#aftJ`uqr1Z*0Mpbg-i%IB+8}>&v1ti&A<i0J5m;PlX9`zF9k|BbNt_gOCJSg!a*K1uND=Z~$fjh>m)XIj33`t1B5W+y@uYKu;W!Y~c4%7uV%MFxea}%3+C9PCzE00YAk|t$j!R2(#(TXo(4TTcY>54ncDXwCTq1(F8y$m#%P^^>4TDEd7m^7p%k*$~YGK1tmqRmy!8mSa`&w>@~?1oLI7-WVcohTAa7{r_CJGCRQUijUjC^IqvX>kN}g}`sSEhH2F?w1el-UxnP?=L5aZ?J0p+TCuOi#*5<SGSiSjCoD*v=Y;axxhTHz}?Ycq>%mz+aNNnwvTMKrKSq9!f_w`HHdrsTp(^v#ba1OxdU~gBsLPgIxz7y1h<sb$~9lNDyhtjo#JHJj+a!<rBVRBzH<MC|M-g8oPYH__m>mk3D-=(#soLv5!+b|%P@B{v7CFghGk|ItO7rY{ihA3?CP}~aMFg7g#Ro1g7ikLaE!fRAOMO{j}Lb6L~I!BHv&<PUPuJ=rtlTG6_(fZ!Yqt9cwBS(Bviyx8iw`O&<#y9p8w_%AP`EngDvT{oA@nNT*7b8tW!6NBECvLWD)e_@~f50uas$sBqTi~QilwxdGtkA&#W~jk-uUzB9hLZbiZoL#m@O}e=!3LPqNSMmH|d^yVul!n+*mOrB*f=JNBa7l_oHkM##;uD-##Xm&n?3?tQLJ=&A`!0v~#2B@<#X$*+Acm_N4+Gtu`#K?!5|aYA6}`nA~$hURY2RxMdzIUg?S?t2+ZkDXb=Kl+DieQ{ii1Fw89Jbf>cS`D->L^A)Yz&2)J8(Dtn=4UtD(?S6S#+bjq62stNIF|W$g13p1Cr_-rp%I;REL7OuKbboP0E|cWlf1pfa9vDkQgz&fjn#b+K`r~5$RE8{`d~g`xS6Wlp$9utYM$M_XS%K<TMM$0wIjfntu}b03eKT=zH>27G-BhVA&#<xA)+@|LIJ$-ap>$kI~vi4;SPpg>YNSF_E$Wagy^ys4yEt887C5NkbpC5r3goG&ZJ=g@B~<xEj`<#z=QtJ&FYF?eOM#EX>5WLJ2&;HGW7C^9PFTyMNI>ki^MDmP9Wla!=ba9?zv9`d8xGY6ry?{M_iaes54i!MXjAo%tOZ+i-k4_XjNb1S%35gj7zVcz#yF@sEY8N%pobVWX)A+HN}elF8_OkIi`OWa$vA3WE2V#$W9puP%5P?llStA6d*_yZlCL^%0>Vy{n>=TvI?*lzc+tak~_S?Fz7Q|PTC~K(B^p{&b5nq5$D3bNCaib)zi;uqoDVtxY46Ch_w?S5P%GJlDXcI+s$SL`E%yq&94tN;NMxQGNh5BF{gyV6N$&h{NvgKWyjx%o}3>1B?5N1@D2>dX8Pj>>pBnB4`oErSy8qP95Z>W7~nXGeC|^8^GTRJx{Z{zG%{B;lkPx(Bfx%iAS-u1=6f07_|d>}xDO}M9?I>6ZBNLwVW)XckoDhQJ}<mF=(YCcGSf=8q+yi&o@jWNi6x<C0#jFXMi9PRF3bc{F*~|%wAIe)%}d6b5~?_U5@J0JV@ZCgtOtGs&aEd32`)q&P>w|0F+%8W4_Gh_P-r`ea(DR_i~@${#*T`<ay+CgGgtm{!N<MT0m_`-)x30IIxo$>@o#=r5`DF2_ZEr1T@@4i94dVbo`sb4FI4)fJ{OPGd4Y;<3iY`aMk-creDo`uZ|ZPb@uq6^rK;7J4C=JnZ(nHj`Kr|ys#ag#RCF14gWe=kvTC`D*j9KIUoFY4l~7-#P~R#HJHDdQ=PJrNtW^5$80(k6T-9uM<vd^5RDEcTAB+nhl^2gaC64c9ZHxS|Y!g6y-5c%}n)JL%5LF^n3<h&t_RBCC8~KKnu%1mItq2|yQU*fOjbH`Pj5YC8q{CQG%bA(N%uIwr1RoR6C+-nQngZzV<)5drqERRiE5eQhJy#ZK$m2&LR|pSyg!yhs?ak*7#>BJzliQu2@nRf-@bt2@Ner$tVR7N}Y@o5QLEtJ@^0L?r5;>yC+r;b5numMcrs|CT+9IBc6NyL()QlVXPiTLT)L$OoNqIEP!Mt%5bx|#^lk%J)8Ol3*b14dat@2<;2?U_k-VEXE15hyhe$|{Z6ZtsE&6US&M~>AQ%Jp<2Uc9JGr#mJV)aihgO%7l4kZn7eJ=J46{dNoRz*o++5R^kTx{|u4VLVbjhbk9i_(W~&tio6|Ra1KP6&m`g0Ulg^Y^I384&~y@Be>NSUcIq;1=-28!?r_tLrpe}hpqALK|^15u6?Pkfz$%VT;A>%Ea&FEW<I5`LO@|71ApcTG-oJXt56-nr3Y?yRI+(;D@SJE?5=!heONgdw2yO}-^(?xiu%{5SLKzjOsTvK1-(_jMIDo>gBf6K?6exoZRHNe<PJ`Bf7t@1KxSy)<?p$&>VXyzu@ugjDsjFm6CCT(EL?Yq1(N*Y)boz{0%w)+4olvVl+S5$S>{GjUc!i(%@gQADL&fpT7!zPGmUZVyi{pmoXt8PGfsPB7nR75>@ZEdGc(Pxan4@&u^5_%cG=1YxUB};QUL-2e*!S2;HuYd50W<bGEqt*6&{bctRH)&x!tfcvD}k0)ewO8g#d=g5i*o}Y7m&)6ghjK572ka$&dG5OmnQFcfKkhLe{mUt&ZS7?Ck2IAw)h1if<8iY&~V|@pm+NDF6D6&#|LjR-_b12LtwR!o}88*#)3Jyl2&2i(nR$D5#!oDo_e@dhTw_x(CuEX&^|k_}-b8rgBy%%mjVFq`K?Oiy|g(bm1L$x4z;P5FZDIi2`K!gC<v&Wq`Ik?xYovk+rWea-kgsS9YGsGri|WJwv+Xqbl^#W;JHWq_^X}6L+_1=p_Cu=w{gzeKu>rM2WE}YvremER3r-cz58x^W*4dFx!shtyMyf(ck*RBqd#g)O<@yS_5(zoWTfhg{SF7czUHH{g&9Ye;J!{3%&|ZwVIHxd#xtDiBOxMbh?gEKa&BdGTK`NrP;f<4ppa>0KLfVSRD7=uoaYEhpM2s{PO$Q2tHzIJ?EP89<^6+P`=?tdf$C)DGX~q4t_E-%3;2l==m!9eaFfY;--q+p7b&S&My_+-EAHi$h^Gf$==oDmO{`}DS8BL+m7rX&DW1WKEm@H>WeHT;(3`HKl0r8MNr?)I*li8E?DCX+>ASYPn>b}jt#<-J9DkVYu-?m6wxQpbtBqHC@ADRO-&~BA333WSwx6(Vb>mfas318Z=NdEcA-V&k(z~F`i_x%@bv{Ls3aL!s);jGMY4W6YiD|u13K)DsLOE)R4i@elKNY-Fk0}TylQfA<q^#|Vf2O22C+HGG&{`D8m(*FOHRh1*NJ<ch!Qq8a2i{2KWj4U){mEGs!EbUXr0v*(rNe#GSOR7XD-C4GbdChp1xD3*W4yGrP~7Q*@=<jm8`dXoteIwArBVP>9RCGR}J~z<i@e-jMVI+HgrcgTkVH*i;g&!IMz<dGo~=1<Oy{#g(&3%DF(T?0TUP$+lNNkX_BY5;{+&$s<LP;YpG;M%L>#E_h#eK2!D)IGx;i28P8s#a+!?c@zEWxDu0u8<IQPrNjzlS<IUNOCpPen_;y{ihP)Hp0qPfnoj;W{I!nj6!Uj1$P-ZH3+M^Zq5)u6CUm#Sm{5!P#n-!Bh*EnTj;5ZtR#MNSYAlWLn6da{vkHRejvBVmkmnMvY^MRLv5aII9^I(ekL7+OcLe!e}r@<h_RyHIrO!u%Hb{@>(1I0R~)aAv`*|aF4w-bm==s%#mros?q<mH4P=ipn~&3eFTUJ`NaWuvH19d8BW|H02Q?-EMe_DbjK9NKYkB`9Lg>fC6_?v<~TqE-I+|9ny0`#aRo#;>M^w)C#wQbTJp_wQ6jBj2lg=VIDg?EYogQl%v0B6h#6t%Y_1-k?6+4Ltmn*!?=Fsg<{DrF$jH`7QM~j`tuDOuwncQ4R6+a$K}p+_06i-!#TsUG5Kp&FUXF((aGB43$s*)<WQ)opN7Fsz00FLZ1*;j6FQ!KrT;CUubwXC985_%jkP9!{o_yi4MJcyz4$Lsp^9*J!e|!Bob>iqRaEoG@u`(tcIGa?Ir3N7#4{azTCQJ2jTmjT+%z_*%Yl6mJ)Nd1j=`3ts^G2=jdFQxKU`BPxw$Itb2a7_(0m9GtCG8XE#bBUy3DJxyLWX8Cfy4fgTr2vgy2~${j0FKQ#IR)!eQv$uK|X11{3An2{M-1%6}+21?2%q(e3hm8QT69C}jUjP8W1E8u$U<wY8LlHLs85*0L%KuWBB^8sy>s^lF*rV;s*AN?{_ATWfs3-ab5FXCgEk`-Cg;O`P*#WGBP!Xljeuk3~-TK9e9i>bS4X`LDW*G%5@qh30ZrFws^q`P&CaEGgO_pXYDyo8`PC~A6vMeix#9adO$Q-E24!{Fgn@nLHWkq~q%&Q=wRUfG3mV+vx989jbMo>JQzW^vicXn=&dp<DY4v3Uwrp+)f9QzGgm;9R)Du(JKw27)Lf4A=N`;KtG|KhXw3e~YW=Z`=l-m){?(s_JDRe6PzNd9@LQ3|ClJ_TD3L=CIE_0pPPElf0j;c4_!?bLQ)Wqqf>{35t8n#t+IuHvpRt!P#g`GO5Q712(J2q1z7tkWVzMkA|;gC`Pj1BjJO%le61vt4Y4KYXyfb`{$ETSvr{#;`Gh%Nu(uaPt<jr^fD<7FfJa<EXYelOCprArUGohFC@!gHh5(ibq6c>vgzRsJ-p;T0beRqjdO8bh+{LFC4Z38>?<@~n3ev2_^K?WPp|k0(NcPsTyUSqReD;ygI2E6w3N0owKJa3+BK-TN{5%0(wx<dOa`|Kq+VDCC8mFCN}=+q*8-`$4WwKRr2M<da_8!Lc!LBopiWt4eoBViy*7}RhJ#eRJk`NvIPF(Jk`=NUvd`YMn6G`Q^)7==Q%+^qpz9R44dH;D5vr0wu|2YdaAL*$k9jNpTW{k3wNW-eZSYGqF7HHTxGpYAX5qE52B^YztR?P6afL7*YXGm%y$w2X8qC~<8_El-DhxN$%_Rk)R9|jYO8{S^cTe3dFY2%c9m_t8t$7=F)~2&@SKhU<szNT6qp!>AtHbS9&@R_%Kli|c^a{nZ1?|L*);&nvpJq~3`)sL|BnOf3)&lW7F=rU%mkw3_B>|$}j6|6@<SHoD;(1`=V)drtUgegM-lTZG?qL2Ob$<ns{7}=G{Lf?LARY(oP24Mrp7^T0^G)aOupwe5nOsN32X_=Q7f~D=WLK5sTx)O&OBN*6ml=dtV~@aVgZRQE-2s2`wkkQw+8BUpV$~-T+{O$})Ov$22hnil5zJv&&geiaGWSMXbW%1Y?W9-Mrf(2xE6Xker#%G)N<Nt4ooSl-3V>Dzv6Y(~$E-?IA4+eHS|}7H?$jiaN$7YszI7%(x8k3?;Pgk@798l;L>ob1D6`eMDpwX#;b_5)s6t>vC{t<=2ox0Cc)`nz)EXEqz-DwFtiNj-cfE)YfD8$t;mkxl5X?%ZdlV=3&_$~paz62HGINfjGhYuTA1EF_IAzSXJ@hPN<$QxIsJ$mjjzdU~f6??ve*Dg9)UA+xW9vL_{Qz?(RkG#;7^<hUx$2Z_bAc{p`G=WTK2uchnFab2?ZA`OBTuNX`$s7}o&71ho${;--1K+IhRm|%kr^a$Hds<0vF=ALTlZ+J>>k`yHjDrAEAMfAaXMWloo;x+r5kGDsAVv6X=y3Ut?t&`z*pLC1}K#dmYxu-6HSn%AEk|g@Dyu!?<9_%D?Zx!+H~TESN6eP9E)t5NFS>W87UN_?T~av!}@N)dQ!Pr)$C3cVT)ot#W3lNAZJG`=GnqwNspn3_E3Vdagn&33@PK9MQT<@Yv@{?JBk};1&FTXT`^W}+;6|Xh1~>p{e~DPCfqIVg7gh??{*xune0&$!whZ?bg|>z-We=b#5lfkf*OP^is;d}VQ1c|h$euc_q?BuM#gT)o=y=lO`T!QNp}EmKRHwVHH$fJ_+}aAEKXQjHReYbt0kRs7?mCgx4tUiUH{l_?^j7`d3ut(*g{7LI<g_d4Th_ztuAyXNEU1`vN4yOsJQs|%#)19bzz3dG;0PWS^a|WBUh_QW_<S+WhQU8l<1Qx&O~Dhq0!?_|Bne<R!CK)X<F5w23roc|5YWn+VB-awv3=%MKq>vk#UOQl~rSJB4dpW>RHLJz;|3Mx6*TxN@MNCRg_KxFLO7`G#%yQ;zX*<YCtJlWiXmo?t=smcGQ2e-L!YL7sO57tdlwg0<P7mh44Lj)4Ca#g0+*Vg4#~4)h-RZfm#O9FMY^*v{t#c=~Az)UEWsOrj{ky*d^{<>emWG<m4<$j4e_Ug`kFCZErDjR(B?v`jmHT1X^&0scR3MKxl0-#VsZk$M;g>wMK#v0-SfcZjkFVag^l!o`fFb3j<nWq83Nn@H=-^`_}w6D_7bKv-j~6g0CPS!)k#PmgdyLeTB=Lc-L+I`5u1)Sxnj|-ld->*6Sm(4fL(cPTkk?w<h8~PP;B#N}|SzI5N4L5GUc190iNQD+x|#vNlizZ6^y;A;GzKb3@Nn%$1PFphn{aDIQc+!yf$q?A5&v?0!m7pZ03b$;RHCsTpR?oMCj4sa-6^lIp7Rzd;aNFvn105{F@;sELY)&lGEgqbNqWl0<ISlJp0VB67uxuJRwK=L!7QN8U67?V}+vBp8_N57;d_o8Z4toL*1L2DK{qMZLYFD#RYcWaw<g7qAJd1prAPbvSPySGKPh8eN*;hu>P5rSDxNzM_&E=l9y&F^W(sh~F*Gpul&%w0O(Ogt4{lrj^CpQc;RaS`Y8mY$m}2HeZ%?oLM4ZM8MN6s4O?I5Wnuf;l+tNZ6liYV!@Ek7Y&n$zxqX+L}tBcHo(4%h2dT}p&+_SSUiAe1OW*<C*hVsIMI=;K`Pow(d<nPlm<ho2c<}dpro0p*{Z&KG@$wy6`fuON<CErg2|549GQ1@Bo~oNA(M2cF^xe*$qI;$QVOBRvCui?0V)?l#GsBs6S<g&>JHIMgdO+I_jc1z4D7v`Gvr0HLwk@r_-Ie^pFD!9yvXG8I_gmZ*GUDGp)O6)l3UO&<@b&_2w&fI;n@<GS?;3+ti8$B#&hTYudke${i=21%Ng}<zKJYszqC#~-nLGB;hQ+fG?BV6R<dx;y=t8pUpl*sA<*Vqu5_-Oe!UEJj<V@OsPcBFt{OGmwoweZdG~s1J}+j9Rg%Ht0;E@%nXhrav&qEgtvt1-&$={Dq)pjlpri4$;(u2MFU>Fl`YuaB>}S{D{&&Aj4Z13Vx{*t#5?!t`$T!63%3Ds({M|(%K9c;l5QeJ^9SLdp=p?ZPFS}er8XhYJrb^F^Rjm+J=G`JdC!=&HNYZ%4VWI$CS@5MkH=6XEBd&0`IKeIyd!0Jt6&dxH!1g9LXHHdbQJfnB#l^yKkI8`r`Cq$@<Gc{ORSx#8=G`k{S^+EL`AmnQV2%n1iKrAT65<G<W_l2k_ebaYPLj)c0nG)q_fMQ!hq74QGj$Iw{}1^Qp!O5PBlr+KSl4E93a#*hM+W>QN(}eauZ*ub5&IO+UT#d1;^2`(eqzbUqOK6%bTZz`ck(aA+s_gSyQd{3Nky69g=nSf^3mOcY9eRZOEyCze!IW_KAp7k{6{cYP41Sh5v55It8N36Tk(gRLBLeq0fxAE8aeYcs%fHdWE4*smCDr6K6}f6%8H$8$A;xPtan*#6?Q|_i8hr^XQ;?UtjsGdGlXIc(#+~Kjzh&Saf@cB`vkGDk3=i5oD4uPC!VDokG!#D(4YfozP6+oX+0>X)Y?0Dec0;%3$zI;en2)c(38iUmBQLZ2|8SqQyDsokkmTOHF=6GXQvmM|3_g7x~139%Oq*|+E>?4x<6qaia(~S(T9+coXYq41vsc+BYXztcxHBlboHT3ZP^y$d!AKmrL7;p(5A=1S`i2NNE^lHdy;1omYkqhmZ7|dbfk$fd1XWx<z;#M;Gu)Z1N=lG2tFUG@FSgsCCT@lvYhN03Q}k}(po5(-~&E)uV<Wz){pj^uY5Aj(LrnWV`uI~`fDbvB$;0Y>K-&LI`RvW5G`SG0>}TCcbd7M#KYjq?)hA2X!&xGB|2kZm9IXT-xv;mlmi8Yxgo^#n(<iKKcFx|@39CIo3+A`8JMBVSWU<(nnfE`H970*KNlTcO<qwCvi_uiuCnVFTe6kbVpI_>T0(Md?a_QaL~%KFYRr_Z{HS72PrglciBN3QU<$c{Zx5X2gZfw@7_36vLV=g<3~_{W#qyRb^1!SE$rykH8()v1`FfO3Zn0BmCFTI5cICD%ChV6pyNYQg?H$!)_3ZYn-95w?SFyxqIyQBezIOMrPv4!q>euAeISQQ|&GiEvn7#xfJxQ(Q!28fZ<7ucFT4$yO>L+rTVA_nSRSW~*XfSSco}wU)$cp#o61s$6>P-&SEDgB@+0iNsv_bck9i`rf6_<5TnYuS3tD_iaImb^WBPd=)FfybmQN&iLZbVRU+Kfbs5T4Z?GOco>p}K`OX$;SH<hY_o`Yro0RC1$@Q?Kf}2Ct8+-wUO7VNM#9y)%5hujEN$Ru)r*O?NMJwW1^iAWco@8b8wu8^3)cJq=Z|@wJnmgXvXPj!47p2UmHg&B7CjXs+1XvKksUHMEb2BA2llR)X~B`YBrX8>iH*?AIy*RkTvcorQ~z7L+X7yFz2D`h}dl@MG)uRbkpx+RWB)xhAf5#$5fKY?lu5@EJJPo`2<<7x00lDXMbd_YUQ{D3y@|M7=~?)H890S*jX7)02h#J@+;I^$r2>147v@uN)%;;6&_oF$u-9(L^}pRRKQ*`39Qqkh~w4d<2(@e>Gl{vJev;zB6%`Sv&ITjU{RsY3!A8_vn>o?zk#kd4F%vS#O)H%U05_zoWChJYT;8omnq%sA`X+P+=swq7m@WO+HAsu>#giv^j8bQjH}4+}F{%$t#16_iNp7ydGN3<Q-c#Rq@<gok2|-##t<q-|E|lf^Wqz>)3=v1ay$&#oL-T*uSiAlU_7!g6xp2VKP;2x<Ud^Lts!qh+|lHY^1|XX@sR?ld9v<@M_1V{ub~h%BfbDLJyXf3$&?MbOUvtZ})2Iitkswn!NOC)=~i#G`%!xeEa&*=zEyxg0uIjwrG}p#d^I^a?8Mrz#XFYX8>L(L5Nh<Uv_2~g8`Av$Vx;^zXmczyDa5KozmBrT!i!OkVDc%&`DnD7O?{p=!sz(Mzg5-tH7gC6eTf&QOzi&JU-zIsS4aP*cb#HQ)aA9fe{Eqd8DHeq*L!FS_!(|uBhEE*3}Fqlo|Rfu}@*}wt%)UL-?`^yk#ET3t40@Fa$&|Qla4>N9jsb{qLb#6{Ojo%n5tiu#!A5(JHk7y{J>RPH1N*k}^aCP??31d2g+>KWZtNkE<v*abNbOa+CuQGul-|ajoDGtKvhG+OMIMdo2jrL_RhC@v9Gt5+*bs7auDv)O9VC3T}Hc`ZzKZ_bqa8BE|8(OZ#OdQLzLwdVM>A#y6}Na1Ci+&e>b0qPQZ;O3B+tTuWVS)hl+kY*2b*0YzGV1Hs}SylbdlCdxM;f?2`|&#f!97D=lCkuJ(G!ocj<$=26imn7Lxtzo#7OS?Im>yd3pD>0d{Qev^9V->SvuDFEZp-Rd)Ny_wQD6Ww^7}vJK6|0_%tF+qnVF%Yd=zP<wamga(jhKuwTZ%iIJ%}@xgce!9)R6Hj4H;kQwzi{G8t!`FuLWdWx1t5Rm1vB`o$=yqQ*`n6Y51*dOSn>W(KxLh7Jj80<6oJVW}@+yPjNQ6!&+9Q9ywfPFzea8455{J%=((Rm5aw)zh=|G(L}7eF{`)uR~HgnnY7fcF7L~?ukO+2cUV88VE-S#4{4MHmCuFudkb&Wh)bV~H#%*5XO%R1ywbFID`Pa(0Mg77*0L6ZT4uF0er=W%+UiN(IyvyowsnD;Z}<&)>696)<}*Z*MG^JzZ5V3@l{n@XEK#nl!)pQ<q<RJI@mCa4E&chLCAz;-!l*wx@*!u?NMCbYLP+-J4?-*LmlqW8dtoYUPr73qwc9AM_ljrJZEbEa?MBEnE^yv*IS;oBlUM5NZt0yZyt>8UrP?;FO@p1f?<2~`d#5G<h;(uCk17OHK0QJ~(!5z@L=^AA5|GXlzTK1JedgGS6=gEsE>aI@%dY3WTcVLFnSQao3Lo)PXt@3e8c!%7f0Lv6NQ`HU`3*r_0%-MwF(3}5B}j=G_oh*W@4Mr2N=iHgRsmq5K_YG-phbdsLH8~gR>@cN0`_kCdZ^46Yx{{?<Rn-{CcwPrkQ7qUU+H%y)0Kf1$`T-v`w~CmWam$=H!R$vW;n5^{*$P$7PD(c)KX@}ryQhLk$~AyXN4F78dRUW+Jf5jDY}i|p$s4IO`k)Nez_+zQXDh^38Mg>5O$#%NxP?4<XoA52X91Sv?A_^nWZcWROU@Sq}n`{eD8NR*2s#0uH2D_+t$dD22yxSh!&L1kr5C+7?oCd)P`L}tf~<K7IFZTq6By2+8TK$CI;JQ*g-J6@&P8ag9102Uc_3FWS2Tj83TPsLVeRc^cA!K?s9Y!ga2b^JXvky%8em|DpfY;_JT~THUA_R(lj_2+A7Tlzd0<9i_|aFo*V|-wB69twsEK}T>5|lCf5rs=8eKYazLPdYOJI&PsB^8%}119c2z(wnzm#4YI}AqEfS$LKErgbx^!qyD0T#aRijW7n#qWi16;haE5qo!Wq*A9yb_RehyX+mfEfjryRgY5)o)`yQ(#f)K-Geb-ZEC%#$*?sM`bGjRiW}Fs_{OEC0c9UOO6?Pt9(fRajcQOD(9HniM0KMzwS)Q%awIU4oc{Mu^lel%1MUlt;)!<9U=4F;;Pz+cUDo4VaYTrhN*_;2C4N@Kd&hjy<EK!d8{0*=q=R<&w{zoYU4|U#{#;mr5Y<lw@S4=4i;aopZCUr5S6zTl~-Dg%o&;};WpxLbhLVW_MJGv`u5dAOKevHl&(E6JsFd0;c<dVB(3xub+jyD#E|PJnrM$?f0m0G?CM3g39p+=l&cv<`)lJjc(WRE%N5vYFRrp3^tpEWTt;3a_Xca7)t%8(i#M@k2p=Fy_wQ)x?Wt%TxgXt&IZ=y19f)pRK(&Q24nE<Tlt`_}2uV~H4i{;?nAQQ7$PrSB(GgNoz7<=&qc%<29hT?MNh`R_kYVTU7?B4_M%J|SD8Y9T{?BFtdlVFSRyPS>@<}fU1QT~)v*j~B<s{=WnoJMYx$^G5dkFlLq&|$dZl!02Za!XyvMrP8T%NyJ$+heRx%xl^DHJi_Itm`YCoWwDr|<sZAS=YB-2F~Wh2v6l`GZmJX05yNVZQuw_fqRtKK*LB+q$hwp?m+O6}sD%G`P;~Lif7L&2AMjvh2}+R;}AH-(1Swkv26INO@iEW**YY-B~~n0=3o^Z*dXszRq&@f4x?*NKXJ3;X8kXg2Y<IB7MSu;oH1Xm|lPgJ<31v9uaC(k$aE_ixYKJWw>AsSLB_D6v+DZ6_sx?<&Jd)Uhf1)TEu{5r8q~k8(}v*n#P(9y{1!#Tm3Y2!z_KV+9}lI7fy=}pA`jWcK+VLF%({7c+oHVW!~sOzFW7F(b*(;!sun4X%F@p=v4T7JT>`PYLk-K4T>I+m=v}3L}qCxq%Tt9rNzEu(mbRCS(nBWbc1NBS)UEW$!m<rZ*lF819&96)#jd2R|rF8clCQYw{0lP?T<4rkw{T?yPZARn^Ai3f9GeY@^4<PpHra>1(&o+-(MD+7OkAmmQju7&wVYUTK2j=zEW?BQn9FJ^3H@9WouNOx&6A*B<D=4H2G^))h46UbpIExWDcCAuJl$_)miH7?@&>iUTUjiNHSXwD^;C+)meUvfX?^-$=vR55flBEm>55M$2Te8FSEgYi<RhCtVE`aw>N#EJp3(IV&1S44aU7`bBCtsWqqT(oo&|Oc7mPVq9pR0YUC#0D2d#c{mtEfL6a}C{Wk)DT2`$AKzNq`Ad!sNZ<vS!&v1XmMC_z7hIj3?V<`U|E3?exI{+bJ7=Rc+@T|M9nveK9xAU3jI_GGb%*n^>h2A{j0h^tkfx_)cV(=W5Pm*uPxC<-=QNa(C{gOyb&lGvkJy!vamD6XQ)S29oEYYc>mDrBrHS{1yJyU$;V`fnL>q)uCy<u}dQJb~dxE(QLMvcB`eP>gGwT<6ogUbEecS~w%XlvvA)n2niFRTC~LtJm-WHr2PJ+=^K743Fz)gr1ful5QT{L%sEtQpLN&Q8+TK4RIfcAaVYShrU*K3;c&BIA$IX{FM1fnSx9D|wD(CVQTqW9~1!6XGkbeuniwY4u#rsodCS20KE3ZJ}8nOD9tQor<54rj^dXV6h1;49hsOX2~N6^N*}&mzy6SD=0t}Zoh(B^_0(B;A9vP&kqvab~EdW&n9xHkljZbf6<~wF7^mreYgBJEe`gLLhVSF{qD}=$*V7z_18N~er9ya>~4qEkF%4(hn7rv{Ud2?eJ@B(9)dK_q-YcW!){%?qmNp@W5w@|+>Q`GKHy%3IU-x=ecTbR0uMk$k=79-|8Jz0(>Zl>h)2b7+|pqu-cu8+6Z2O_cXV(d!ZB8G@+Tr^9%(#83WIb_yz1!tGVTdWR;$CAKu@qGn(<In>9r=dR$(UQ4&T6!<~M<fkZJ{eqPdQk!Xg{f#*qPG;8Zzdjd*6YF_I`n)~o-3CG*GvEWUG<H%v-7?t+Dch72d!W2AL~Dvae^PQi2*%3IDMk`OSP@}c+lc&`lSjEww0epLc<^c1!RY)?zvwXJZfvXL&_R$j>%d>gOX0ki?@z9NXMZo&f@M8g8EXA(i$*J3xTNu?pvNhnEviRF#D&)1rfJVK%%3bfd1j@+BFmt${@+*@Qln3n#^O1O4b{id^O<*?@-qqv;;16h)eBLspDG#5@Olqp(1{Rt&3IiLpRKV?qeX9J7WeH+8MEWG!fbasuDqYLg5pyUaCQE5Y|I~s=3ST*76Y><u?Lyv~VdY|DY3f670Ic`4vO4x8sovqr22UnY@H~Ah-+mL;aB~YdncF8!d*s~)$Jezc^ii98)tFnhz3UoP`ra&IA{I2=rq8v?nKX=G$GVK}`P!Uqz#HGwW*yK&G@d37Z8A@Pdg}ng>xGgv!)jHQDD0f>-lZ8aeblQyF1|Oik{iHSk<>xGU=uIOv%J1B&+Sl@PD{pmMJS~u2i>3CaK(~8~qV)JeFSSC;f5MO3uQjG&^!;^12jahA3-LXt#k**LUAnwYB=e;j_I`f#uZKqqg0=mP&p?@%h^fS2A5rV;Oc=(2dSK_Lk`tTJ#_(j_=2@Cy_!A#IkiI8bT_NS4sCmsup@d@Lp`++q2#-{K{<S5@`=%S7Zg7z2Oo`fOPQo{A;Z{F_Dj|)av8>65%-DXyntu*xasxdGX#h77I4TAW6LFV!ehN@muoVHG(lq0h2<4!x(O5Gh=hYPP`YBZ!PG$!JhQuh`(AUjWq@-eFiwpW9pb!ku<%Ey2^{e4}?GL&8Fza11)3(RLx0P>k*g3Pvw(dScyaP4KP%WsRsHDTxS`i;~Z2!A)Fa*d%2@BwlMk?2(ZuR<VqwXN?Hs5z90$uLfuYQ@5AxAPo*9e#XRp0q=zsSrg0P<Ik^Rb1ELbY6Z%^Tc`TxR6MD2_y|sM!QPC7MQR_}GEG-6TLPv&UojfkcS?5^;bMzzp;z_x99G<S}7fRmtk9h#Xh?ACMC8CfFIrrJI)qD8B$C4e~AS*pas7W>nQ<m6HVHg{i_Ik9dw9l&AiU&(4s_l6GWtpIA9->P=;HIN9?h{+Rc;C&x!jXN8n=xd{g_lxIdTC1i<D3$6^Y*TGdJG1gIE*)3<j@>#rdrq=mj$`N|+$rvy^@}t+mCs5l-`zQM|KM3JsD+~^G0GMHvG`swF4vokH<WSkePfE`0dDX$G$Xx>U5fz)^fPtebbAWvpf+rxBB8i?lIJ7n}g@*FX?=4FAhtFR@etY1;3UWBqBJx;8*0(x^OC6c{#M{&gIbbbtnHadlt7%gO*M}E6>xs0{w9;7@hK0+JLBc>(x*d@mzz%RClqI#i<1L3+roO&H_e;oSfW)o;)}x}gyo4GoB{LqXK}Jc^A=*^qi6OsGTUTHaS8D59F=gm#O$J<-L<2(ZzRTf-bSEg*DidGVh)XIN|Gm#?SYvVx{T<ulFJ1NS%)F*Qs+=cxJDk^uaY$#x%-}6S#Nx1W+Z!7tRK#M|716BFP8GSX=CT13RI;lceTw1+NkCAvt2!(uL7i%Ock+gKKkta_Q&$HFG?czlr<AB%6?2feAYn&mi70f57@DewO0f!Mu!8Km5~9OQkH)}km%*+Ik}I$<V;h39cvxl1ASYoMZd|jUDY&ml*n3*Fj&%R#rACtctEMK&n*3T#vWjYKb&}R<k~;(t8<C_7LgT22;jXK`?B=?dvAI&yh?i}o-o{k<B$LTUmOBa2qdm)BQP$?k3{X^y7}%)AnT&>T6BG%>vYl?Smn#9n5qkz>d=7-J-SL*jZeP~ZRHp=$d@}2|)fd#?@F{5R7Y-;CmS=0`VFKG*I@a?!&~`>az*3wSfnb^ecxmkNwv&H5)9=t57YJ|v+h4h;(pLZV^m@#(wB;0el!bbDsho5bd|W9f-Ht*il|<nR5^oiV3@-x_+E%1m>MdtKw4j92nT^+BEen3c=sGJ@h8HOBC_N-@xlIoV)DE?@yB%*<`8xX`e5v9UL^`qW=HwqH+~_`aRQ|$nU5OiQLD>$Tr53eFudZRSl}#=A&pH=+kH^marR$pGx1a}xGfxBz_J$dSfXptIFN5Od9aVouRG(R!;U(=cF;Foa@%8B&fjlRKc+x6bBAYu(cKGVvA;E879c245QgC|*?nO}1;ovG6h6w1%>=lDVwXy#1G5Q;{O{q~7G`GC?&U+JUpmPCYW}AO9v7p8p8HrZ1lG~zxj)GOuJ&?#5Y}#k6-nl}K=@1U*uX10?seae1&Sa{EWfsnz39PYGfm)P*2<ZXQ(m(;kz*5HUWIe*Fgc#x^Ikk?``Isf6`PWg*he+7b2kTLlKmBiCs0#U({`~0``!N4GJM;d!Ex&L;!m1~~T?G_lA&eMr^yF2MOjeQHH01lPmLt8iA75$63(ge0X_0b_27;!B)zWQ5uBw)1&3U)9g|6$B&NNixs$Gw7-DJ~<GU>e{FzNVq*HUSnBg$UosIVXxdr1jH@q<oHi`h|MJCbQz$Qd?V4;=e$k@vw6{uwep;`h2gcSEr2juF?}j92x~lGMAodY8sGEEUcOb!J>gvn)PqCY3vJ@dA)}^I;M`&mEXMNq(n<5hpb;%3Ds3_6#QHUM`H6lP+I2bNBd|dh8VnR@MxN5vdF$f6)iVB?mm_wg!cw#Q`kVp2tbDgO7Gr?3x)q+CLeB(3IgH*a&r&!i{Wi?D*cfvqB$gTi(ud61}`Svr0#`Y{*!h?z&^@X6Yo}J1YGK>$U&-XJ^Du)*&2D*7!n|_X#oHS@P^klMmfa!S3YFmM~%hPF11_%gdwO0Nn?*6;={V0px;Om{O16&796gOjIchbN^tV#8g4dW7U>Wq76-mgW<xlc3LAIPh3dyX#i-ot~q@Ctib$G8-Pmr7<}}5e%4AN;@h2R<Z3M{-x_;q5S6GKckR=ixtw(MPc_T_t`kv<zggg*tdBq#oe>|(6}>~oJquO%=Rf-{Wof^6`H_`tHgO-En;%M!fN^oGdKTqFXX}RIPP+T*!Nu;^R`UW}4Kpz|x=Xo|7E_Iu<gNuc{0Hs%^5D^b<ZOD3tcjKl_56g2site${)QLL*H{<+fgGDmMd5s5Gl1wg={v7~Ljr{*C!N)f9!RYh3%dYu@Wbu*y1_oq%Z`kZ=cb`+r4Hre;2=#8)*HxwVS~At&_>1X_E@C?fD*5O3&%|95=niCyB_h?D73<}Bm{XM?z;~;I;RR6&rD`ZiUniCXI{%}o42ExdpYa_VoXP(NY%QJ`X{vHyb$T-gH8*<_Cr@W0rjUWD$k~4C&I8XqfAY|^WSs^c`!Uh?`-4Lgl|M$U%?J6cm*~=xW!>jJBZjbw+|&Qc_C^*l1%S9wG^vI8c|lr@{+T9MIzs$9%tw%N~$WG>P|$Lq>F+2u&(^$692-V;D^<7I@AaE#E?h~_zo(onp!jcr^}`Uj|GGvjFF?%rg(W%GznoX$cVcbY@XB<tt5Cy^7^cA(m)<7zP$pK!Kh3!LJKu4aWdwsR?t*tl7q5b2F$m}e(M1}ctcz}Aef?j%T*;4sqiMPU67o4HfKVo>_gGLl2tomLV?`;%6Ynxu=JtHsf+>b2FtrEZQaHcV-6u%rL2i=lI*CRfqjpzUIaN?M<sqtKJ=$dHiI+9UJCy|d++vY-I}KdjrTC#ahPKs)?9NP_PMIMtgf!EZcCvf%6H?HUWk8zml44WqtGTzY}9D52^|ExgBlejNhfG9L1+yTL4*(#a$~N%@Ivpr6NFrNA?W)&&+qq+G3Q!q@9(SHyDFHy>#N0FbIm#Cm}9($-{Co=7RWUx4tvl{ucd+>LA*#(+8Rx5Aw*^py5<JDbX#tdlTht8F(E*WA|2!gY+Qd_v{8oBd{>F)ma8o$QY5?Y8ul!hmxrX~jHaR_sizB>CO5T5>@7uH%sca5#~t}EhR(udR&TORNPBSe{I|dUbiaOkJ-_K+zrDiWUg2-A@VCEydxd|RU*p&FYy2tRUOwcn<r_KepY_*oLx}%BL})KwP`<v;D*qr~+xWrn&0qTKw}bZ83me1F^lSW@el73)YlIq(S_<~-_N?@4`)l}sU#}jA_j;T~FH7(LvwQ6=?aA)L4j5nmnI#*Qyxx=S*GN0OW;)n~^|9Wl6R;;=zzw>U@zz`}?_I3&R(KH*1|S+TI$(A{`cS3={f^9DR7DGCH;e9KEm%FHU#%}Ij&=(6&v@3M{Zp&PJGj<{(F1$(5X_O=+r#Zaj8}(hr}6UNrb*nr^0||f?c(~SZof!7^AxsU=jK!7aBih3eUV^d=}Ep%fx2rFqa>}QUDfTs?)oiPUvuX;K`U8ZpJci{Nqfz!Cmh!kj&2`&^U-dgm(1ud_^r2*@Zy=!U44=EeD7!2w<{k-2E95ZsUy67TiaJ|*IBMZMhT@&8Ya)|9z$bxziK04qANld27AVRC6ZjW?Q3@J8T%RSug*YNpH$^hp+$TA@+Zg7>wmIk@YQ$4+mE~b>#Oe#o3l;!bwap#5Dk2mU;Dl~!u(|){WYJnE=B+HPx1E2>obhu>ilnhwU67r!0&H+u)XPBxPAQUXla2u|H)R~ewAIj?)ds*|DdZQ_^(%|m)^V`VuiMw$T@p;L*KlQ)0@Y9_2a(s%G|zeetp)wdfn=auYL_LUhwuap~((!gln&V`hzQE!QZ)JgM7=$`$jl<<_`BP4*&ac^3F!c)Ba$byu%Al-r$_Pi)34GIC<j>Lf-OoXXE|luNq=+@;PX9XJdzv+4bNW{folu^lD@YzCmMG(*=<ysPQ}o;CXKcSCnZw+EPa@C^S1GqKzY`?vIm9Dj`XPJKq>}DPN5&O6<NltZe5=Qso1sqbdFfa7n!r+*Qe?pe<TQfzv^HDfV&rKZtAKa4B<8Vmw<0kl_Y)zGQox7IR^Rz*)~#X%Bcc35Z<~J}!5o8rOAx>|W@X?7ES7%@g^~98FTAx|T5cGhfOu^93c5Vb)|zo(Xd%d<6*085&A}@l6QD>pYnFE9nW;DGB-w2O_y2=YB-fR@Vt;nY##d$v|pAz1stzZ8-g1Ncm_@`U7=jWMGA>wInu%ftAE9OhO2lo)WcJ(TkoVRYysrgfMy5EQKKZ0-w%67Y8|KL~V&ZNtQ=wbjfTFq|wue0W(G_LWFJ^P0KS5CZ))govRDwEf0k34Nj?nAs$vl;lV?lD>GpP7t4#$OCC=hP0c&As{6a|zu<>DAwL8CuU>)2g}CsocrYC}2V$b2T(;E9Z$4*vZ_+Rer(Dn8KJ6`2KN6KOt<w*E-pL@(;U#foL1Wt;2eGsjmr8+Pux4O3)bmzOm|~W=l|z1oJF@sXDSThtGFYjl#aJ6Fe6UHVh+guRuUf;}5%#9^DT1u=j(VvSyEma!3O}Lj#fZ^}M^bNDva4^W=Hcz`VoAatyy3H1Mi6vE9TRsiqva<?N^>ux)=x7j?D7?a(SZeTVx_+hx$3_J$>blo+%8}~*sOsYsp|&TBj9?b`%p+g0wo5MT)xBgyW-a8;-Zpr2_QeC2<AK}SI0_TCwCT(7IQd-MeqZYV4Q?y4@4!OI~z)ZDw_XCP~o6RfR#V-SCJb9+mMnaxQ+>CN=cY#2pc~~SBJ<VQz?_w>zjj2oV_FpS)ojg_#QfL(TpbJr#$|W<PpLbfLsN$^#iz_V0`D1_VE!y*x2c27uUxNfg4jGIPU?Wi@;n1nw0#Qa9m9BdtzXN9*`&i(FvwBnY0m6!Nr-=0%*I5Cl=scye|?q4Z>fSf9@Ni7mw8CEGCL9^mGtw=!#x^bS*RA$uY-E9BCLcQ-!lgAS@GBvtx`%&T$PNAGCWv<JV7X=s{z<AJn%#b~}P-5W_vk`s++^U6jbng+R!9W*69*o(Pwj9<ZYUN>}&#|K@{N-5+<Kg_r9s$~?B@ZuljGR^8qpY69QH7FQ2SXH!q(^1dy<Cg0Ar<x5szQTMJKC3%sS8%Y6zs#Bxxk#s^0x1mKs{bubQ7}NT)NnE*BU5B$1pM-dbCat@AO3AHWkAarUGI^z)_73*0543lcO=G&?1rLpicfsDf@pF~NPIsTo-0{Z76<e!w^TREb<Qow5|DV5+JnZXbB{W+Kf^%({^e7~)tR&vIRf3`it-bGVQ?YSNMi?2>tRzpI-Zo~A(xgmK73#fQtDKBp;*6Z%hm4S#EYy`JMP0=w){P5Q>M3_clyx+h$0;Sik3sMApgoxf<g_&|s&D5a9O4T;rwgv~ICy2<o2J6!TpeNkHwDusoN!iY8vF&wD0v(>B*l8PX;iT=9T?Fr4Kpb+GIyW)mUsHe8-$<#B1T*e%MZJ9s?l4>7jUv@wwIUQWllk@NaJ&UeuRK~-EfvihlJKq@Z9Z_OGDRibd-)4%~8kre86tmAL6GqW-jI+8DM%3HK_W!>3};AJJ~yc>WLLZqEgrD?}(zY@b%o2zIej)u1mpZ_3dX&W@IY$tCL`TNI)+xeV6y$!*lmkZ*0NKYSf$_k*u8g-jdTeF^hC$=!s|b2~1UyzvRIM^?TF46)-asWPFf@pFEF|){f$WC6YX;0h%vVV@&X<xCBTuokBhg($mVA0MD-dfZ5K+dl+0yK3E5EIOF()uQ>a?tbeUH=TrI`9N=t#56uLL?x2}!!0q`|!$>qM7B`K8%gaavI>)!T>os6LaUB-NARcXc2xcz4X1x-EE$hUh3|GOr#Cs>I8<27e3^;cIy7|Tq)Kg2g!L*?}FJ|T-${-VzDN!!DljudvCvtmHg6^2TQNBNVuo6W>wVDjYy`yMf%(1a9j>dXK)H3gJl?Hxym2yjBj4hdsf_mTr0=L{ZVA8=f7;$G0xGk89BD-;KGT`q74?N(Xf3?e2GRFqABA-8&&#r3(^M=<S4g6d$bspI8t1p9k7<B#cs*}lewn0hBhY%<8K5(I1m$We=?Z&Jr`YW@+lH)4!jC_?Uy7-4m!{{|6H>(?rP#j4w_a%s1xpWEDY0xdbDJe>cZ){FYsWYE|Vq!mnEB8(QUNUvY?rp`&*42{)nKCN-&~yX#PThrWa2%CR9~Q8ASdBh{TO|e)CF_LTRvMRFd0iKw5897X+N}J-fhQNP8>K23&CI$t2NF~E=l2HUx^6>*+kBXL$6#3NypfpYE%OuWTq8bM9tkTVsmDoSA-pi6I~n6S${LwQ1uQFAT?56-#49?6W=9v@JdJf0HV}3(IL3QZBgVGUrz_=xjTstGm4bDsK5$!+?+(f7CR<oodcx=a?IxzZT)6z9yyspU_jRE`P4(0nZ_QXAGlLyi<6r?Tr_61Q);M(NK#4)NRLl{_Am=X11#zKSRt1}wpO`YtHodSOaRn(R4M1bLVtR;2V>fr!sgzg^BnaaaRv{qeh%Rwt3JA2d6Ive;@QKg&EKi6`iQRZMp%I-xvY5+F{%E>USO#Q?gf=+=EaEc5gJpDwqvCSkfp`MlRr`lR47UV^=3pqhxehfs8Hi1Gdg<uzqHgv%xScdT_N1Cps11A?6-#0d7&*Foj#H^c^jL+1{F=uIg^h`FGlg@1v{D6hWQSmJkl9C)T4N%(tEEtsVMlOnT`_^{37r1VuOU{xZ+cF*>D746-KT9$UBFZDo&{z4lZlEda7@XqYT0BiujW~_$uc%CQn({~%g_tTw;7f=dwu<^-OD5^^j_)eTdMW8N{W??awj{I_=Z;7u`|!ERjchw%3L>&ZVW0G_0qXO_Qo97(yXet%ViQd5h!*Fk=IeW0vd4CEXsA%2U)z9jRTNMVJG#3QI26+S4<%wT_txcST~avTvGGwz$x~;?AI1<y>-->@sUB_IwSELrS<-K8_V^w|KR<~B_}F=Byd=+a=kh-cU0ZG9=ujMfec}IDMMH<$GoYYOcR)Js~9|nLLH~_31gzyQJB^xxO)wmp0~cJM$0CJ8)XhA1CVNh5v5#KtRGdgOGE-x!>OB>iwNSj&m->AUONQTlW}?_8}TP++goSuFNb2*ZfLI7FS@6C0b^1yXKAI5S+c9aJ*(<xvKfoq;26c$2gf)F+QM?R^sS>gGGmEUj3zO^UL>O?uifw^|JOIAF0k($UG$m(0JC`*e|^0g0}3$uTdT>pWCmJ$Rod#g(ZwdD`}^!(beUr6k&2^A@nPVI5RzOpTkV-@rzE8{=B&Ay14VOs6y=s#fu#prVib)BX*Z3en^7ymG*Jt!I3jnG7;lx)Sy}FKlZcEmfRKiPeMfz$1d^zu(gjl{!pbl2BJ2ZT)YXAiuhptOuuB$eKYW?Vq&L}!+4#j;P3Hf;`@NbOaf__~{z-=kLFk0E>6*;^Amm@+Xyqojt6MZB(wl*A@^}iB`U&BCXgtOmhAyiwbic8|jTE5MY?t;7J+Ym2iMs%aG<8flR+#SdK17ubIl31!M^5#UPMI`+*N=;04)P#Fu*9j5=bbY#aVCY$qCfN9dOp8|fs>agPH-M1mIJBrRWV!6B+0E27L^+{v`eO|Doww7jQ#H-B?RjlVk`rKH7r9^^Lt=N`L6DX^#ll42s$5bRhd|&nnWvOG1+Z?<&TsKa_bj3A+mfnB&lXGCCjU01$H3Jq#)}PCoTsjZ|mdS{EC7R`?FCi14}ib`OfzB#QxTMEQo&}d7(hLe5?ETmho=(()im(DCrF&6smBA9KXy9rG9E3uBBJZtto8nP~ygTcWZ|dViOZEkvp?PNm%UaD~65VZfca~`1Sju9AEmPBr{&MRnJUOD6|r7+(r7LglkYi_^VJ~3bgM0k=r%Wy8y~+gbXddw=UnySo-gH0Tr{jm_*q8Bz{<AW`u^(3I_V8sw0k5@6|E3=k*rf$iyc1xAb}ow--$?dDJDTh4yu2%)}>{7-aIF^{;d8*j>zfWJXbv9=S2X`Cyl8>Xd~z&Hi?w0!ZVxgZHi`aLlOvjeHC3qHyOwAGoCUSX%W(w7@YRsM|FDItDd~ait1Npg*Xmcfrxn4Z;f`95PYwEsb@4M2SY#U(aLw=;C@O?5j@t#B}W%{^I9L8*<UmVeE@;?Kkd=Q|J90=(zQB^u^h2Z150JXhr?0ZSX$a5eJ*XPh*4E^Ddn*7QVs;uQ}q3t0T?}JDis`c($(T!L=z)mJQw;E;yOmXl(k=Y<q9wJ3dag6;(@eS!0*g4fQw7z_W}St&AX_8~3;4ta|BilU!AShG@;(2K&=Hj+VkDPu@252zSwzUG<Y+c-#Eck3;_B-5+q>{2tmo=a1@S>5wr0q`Rvr@~=sP8G-ox$hCk1mG!|{O^!R6O9xpJKTGgwa7ApFj{ICIP*izN^3P;@W^&jA;^7NDt{poONPU?o`i;KIjGoO&$9Xi(CsTdw;*az^MdwtoKZ^@NSvzbf!&<0-jojp*1%A@(e8u_!ks*xCXa%+|Grm<}Iw77F0GPdbRN+ou@a)WbCJ+~wE<3=NGNpO>eJFELp1%A>w@}=7{K7SB9x>O^B{2BDlrVx-uNN9h*JDid?WP2C=?$(@g6&EWz&o%ogdxusPFGhwYRAl2o)!unT~0C^h|<hJw~mDj9AT$aReGPHziN#NY1qkw_IwCdDxgg%<$&_6(>__9g*sm_<}*uI9#j5>d8DggZze=fdZQ#$J0`09QZi)yj4G$XNZqwlMQ0O&TtKYcVbwm;GwL3#GD@IZ^#_nCpc*X^GpRvHeR0vRM_vkIjgn0O7Zu2hY*q;ou3zD=zb`oT{ln9RnV(|Q!s%~os|x411|#8?C9B022<SDPmtKzGSNS^Om^F<~G?&lUDLd>lxs0O+6J*U}(n?F67;982mjvy@S^!yLL-aQ?{265YtF%}r(-C^5n?}UtBo-8brvkPK8aJrD7_BOlO-wQ}A~J;<AaVJ(u+{s^Cd(oWD-DTgsK}fy&8B3I*m5*ZRXw5p<X%gT@yMLsh%=MJAwSf5?+?DAu|R&*>v@XYhAm0SYlecb{ia@XY{g>)gmnUMvJy9D%uGf$_gwpSX1$~ct|aRwUieUM6d(iLHkirw25E=pSF)v5`SPH0jF#VE!6@sjLC9h2nsNm%42S(zQ%z35#vE-AMy$e?nT4}SBT=okeRMz(tvU(1V0=<<dq&r2FxxP-JWa)M9!%Nz&YZ<?x8vq+FH9)DRH6AU)KL5lh35PEmW@2~4m%P8$LJ!>6D6FR<7$&?#--axHP@%l@Q;vl#bU1v*<g=mY`I@KeFjLZ^KdNihB$KzwK_OM@xnkb0*7h@mNL;s9B?=+@)7UCTf)G4DS)K$%*7zG3Y%1>$;s@$Q`fMq0t7H)lHau~?~``Y7_Cy~ZNt@DMVQSYuGrRXei>h7Xf}hEKABqCY&^QiDxMXIdNYPMH)FNW^2#}hj-%0{VqSRly#H0r_VQ~g7Q^lXJJ^NyKT)cTL?uI=n&=!0L3=1rn``+4??!I`TA-aqKn2CITb{V!vqM;yhR<0Z`S=;u4_3Jz)hZ^Fi^aub7r!{E&TbNyFk(uOz5<#G)^G8N5_Ts6Egta9k)|s_KE264eF&B#$YI=mvMRx8fhcO}U8-<LgATd-_NwD^NvJ98$;#pgJxqc)V#(_)P64v+exn+uF#hjZ#vZOD<H}<g9#}8JxX5f<XUY|4vuMr4PNXb|493`zHu52Zb|IePXxU!FXd!6c^ER{8K$I_W8vE!YW7EQBKCjwaOQeE{lUpQSZ{~ql0I#16GO=`~ZQ69(R&G^X75LH%O}XS-E+ycw+?kkLGB<EX0FYGB8=S6=*pEFkuz&62R9ID6M*Lb%irKI85L;lxC|c%A$zr~9-&qIWgtMi<7Kyci9d-LsNU$bCqoc}M3iCR^p+a0wEMC#fjFqjDc}wy;m0rYOvE!qNuwPT^B3u`VG%WXa%FG6VPf~Zl>s`)W{;g}t03KF>@k20uaO(kv_P}9#gTB796<tX)LM34fTNwkD1G9kC^!I{NlKg*s&4A4t0eOXw2){PgViR_0Bo~1akU;=>iy%|Da_Fd+5h;t;8tD61qlTB-@+3=+$^36`wdF0IL*7M7lLI-0$kfo5)I4*3N=O#%FK-%&F%=(KN9g7E?A>UA6DadH>RNj%dV0@RbYdn_k3SP*&}ja7qbi+}%I}D$ISPi>f!+#Bv$~lFbZVk23v%m;t*AMROA)pL_0Sg_02fTT^>peLm{EN=|H8XD|84jCxW{nt{S{_u4|2Fg*u@&ED@gB66f&{`iP-VLSE|TsUIa)3!{EcSBjtxe<IVCXonk45W0Ym<#2tcavZ&s0KWC`QqV_^iNg_}%4gfGj_Sz<mwInZDmb1820SXxLE|T|5jy1{Vn@jD1%@+xPCLyk(%rjW9G#WS-K7ScM+K(pOU|tUr?IUDkXJ_8&?Q}BM&tRUkomIht8bfp^8F+nq^;TqlOeI~0#E~-iK^M8t5?uC5a1^kFqP&FMs%WIeE*WVE`&yL#u8`4MB@=a`Va1`h19sBWnWK!%`v~Oev#qmONPoAkaZ7e--b)xSa!_9(!f-yGP{d02sHI$<L6_|>Ui1+@<<hCXg*BWq1pQMm4c%ZR`kmUSg-!Mm(@D+>BYkn_i8cr`i+Nlbe}c3n)#W1$j6?@5^|&_Ap}R*VH|9qSpB-C&3+Z#*UA3ne6BF~c_~vt@EfB~r_>|?0$MwK<Vjl_NtgE(ZjdC{`I=fVXHnaJNc&e8S{Sx}YUN*5|RAfcVP8rcm_=d9<{R@gC6Hw6%s_WnPD&AsE{0xzpn+ity3A4XPxJ_98*A-m%V{=(44<02wAY?Ld9c_W?p^$6T&~|o!_kqvUbEz*z=me9V;sKOqozQLy>5+r(fRRhmWOWpuOixtr?)9!>J`*73ic`f-<k|6crmr$ID_!fn6P+W3JLR>pqDI1<*@92Ta>2(9k-lMM@oItKT%Fyr1YfX^{gm}x1cy_d#i4zKRrLr5i@eqt=m|TQRUC`XHmbSXKr1lrM}lO@tf<bkT?5had6m3(G3jKoka(oM@G5b0B!Fw8i|1s!JWbcNl@lB<?UzW?BQm#wNNh<e&n(LHBfaSBXXzjVQN6rkb)m1<us+^*1|uVY1)q|M4XxLDpnpcmyxl__STYx6ZH&Nj43aKqZF=g}MGhm<xfLQNmI(&yzqJwzmad%SO~8?u@_C?|ccQ2JF`sK#PY5-8e|gDiJbMOlpT<vVb$vm#;;hCrNmn25faO$&dSFl<+2T5o^Lu0v4{p}Ne&<MabE1U~=w+nS*)9X>S7f3rECy<Uco2HQp~hHsdqXK%qmN<E59`u%X4gN+M?IY+qfUPU8LB6)7xEa-TqaHgr9?IWu+T`iIuq5lkDnp0LRWb_dWfGGMP@NZ@Got1nBdOm2E6WqYyDs9lKLFBel@+X3xv<oYSEVf|Mz{MLY4T!`+EJ;qLx}_dfEQUkYVA2`jHRol(v7)Jz-_mCq@UWXp7a8GNvHab4D1DGFV#@ZH?f26}p=ccP9>s)uTx-wsi_lII~@(G<osW!LQnMrb*3?^f7Pyfk;UMgf7;$3WMIlkfbPm<GYF(=PF%urd^a<mN1#}QppNl^48+YHQGn>Kabx28YM>EX#wS1S|>eTdDUtI3SGR0(8reY$POz?^gsyt^wMw34k!t6hA<LT+8%@%ao*l6Zzp0C;U=$v$PRaOPJzK{1hF^mBy)k0SC{G5Z->G4SBrjeVq724e!|XSZ5v0cXPa^p?3v9%j~Cab(e@*nmb>*KW8)V@-PXm*QYx9J=fBf7*%}J<eK%k5rN&^zz%)2^y$+5YI6v4Kd(lDa4r}#bMfi0{mMo7YnI35sts8JG`;NSwP&Rw+B8XzY&Z@eCAS@z^Bpp;C4x-1a;WjcJC5*gNf7EErSr!Zi7{Tkg9e>iMZ0g1%R@-rfrW4bk4JfcV<u+6k@$C~oZsLMO{v5N5p>6<VC#%|_6O(*GFmPdE&2nPbX0!+%;Q^XoyrJ;74RVCU(Xzu*qE&@7?}=Z*e$8_pkS@>2JTVGb32eTQ!smCisKAYrvnhGzID?rWdHQmZVT+9sfrly$;b4%`y3bOHq7xj7wA+|O{o>SF=uRCNTTg^mV=3XxrUe_GL5X*#c9hCLSEj^Y<svhm?7{SLz5mLB<?2T+vI4}iu>?uhcv6-L*NC$`D$VFL%cA7T6#qx_g8@<w!>xo9!(Ve$l`W3j#()(MPa3l~nf1AgNy>>7d@jf$vLSJV2OzH?pcJir;(YLIE2XkG@JlkF8m`nczZXP%j$IyXomxV&sIW#q2Xh*!pMNJjUk-6iks1g=-wxkvI48``&Mp*sD)=Hf?{TPqI2)Z6;n8#VPk-5VI<C9rGLqmm`t(PKm$lhI4TDKF0kqavFCDX6B_=Vi&j%VIV%Uz3WzVi2DKv6&tSO%<*%nS|DrNx?qd5;o^WpIawk2IX&qjfN7ON$TEh#}(&ZMo0;OAS!X3vq3Og0}~u5A8Y+Rv~S?VOnuuAfh?&t}QIeOXaOA{VZpdSquVEj%|>3T$T(GD=&kf;qdk?ZPT8-=KL`g~?=(OK1;xS?t!>!JGPD`>bdmWPnJX7{80Ycv=lB{O1-ww7q)k=l1dH0)}oK(~TGx!}Vd`{1!o{r@E}sDuR(K>`>Vr_@(0)=lUk0jOa+ju->)J?b|-@w>xd_LX0oINV1(aTvc=5dJwI)(mp8q<y|3p>-W0RK#Tr3w)%a&PXAK(=L2*|eu9MM{EYrYLJuV`Ka`PTP`#jzGI&K36LC7hOc+Mjgj!_Uw9H2=bmWbO=ehwNE$E!ctg7Gh?m3?Bx@SPxR$G@kw;sqjt%(UsxdBMc6VCA%+S&k6%I+=@_Zcp{03(yg`iEn*qCn&Z1*yn0fcrhGE%Lm{cj$31o#M3IKAQimh>PauJ;X+^sop977M)9=dx9no=rZA51wR+AjnDPdk68W2|GI`sy}D|Bx8o9-9uXlSJjzV|)MBa+?pb$WJcr1fQJ3>)8H9~t=KLRN<ccrBBC$f=kyx<88#^oWlq0AafeGp+Z!#2xYha&w5LFWq9MovNH;i7K&BlIFV8`uzAQlVC1FHG>0p+K}s!q(UqlrH$QVG^@Pj2f2(1dB1i6&le!5p=qH*l(Lj0(B7E2eO3Ic=P#@T682jLKq@3a>0{y)bAMP-(DU;yzI8G>1)L(hfDMf0R{3BvOOds^`b?dHz%7I)rwHdMw~SYl>1c3UppWG=iRVHdsggXTzVvH7;zq)pM!a?NZb4p8HNhAo@v%DOA6~f(^9$LCn7~rW#W*E6WSx&xKITFJk!afZcxVL4n)XxFM&d&kMl-Dr7&0{0}wYhN{oh9D`WF(7ijc8-gJj{s=Kn*w^~Bc!}vJq0Uu_wPrPcYAE%O4D1?l6J$x6ApsOjVvV{!B}FjPtoYXxbPv#L;#dA5ZN<ld^BEl+fC+kQWEs0!H7gzSUbGs5zX+EJB!rUHo2XHSQdN>F-rPCCbEs1atqs1n`=T>c6`IIVO+pO7g=@i%=%NDIvnFL2r0i42%PE9Q6tKa0qwI4JW=M#nSq#HMuvubrhb<MXDGSj>Jgn70GFb+*no8^?-X-#?$qya6uwyOWV*C^u>VO7T;mHDztePA1qi_*vQ(RyU$9F0@q~Nel6vTI66XRPCMCH8$$Q&mo5d>5kWE0CS(jsbCpZ-y*2KQEQ!3%zwWVIlZ(s~nV0>}(55A2Q{4K~Q$sf$PlTeet>>&*YEo>RRDKaAa;{-V<7C?eB$@t(EnQ&(?+xFnP_U^{8-Em;$y=N<1p9x%;acr|M9`7RjaY0ny2{a)|P&M}N@n<>2jkA6+frvJR*YtRo!R}dS<ZmVJa((pB;j?T(B?=YguMSZAHN<cZ0gWZC@i{-mD9~x`M*+=jzdfcBLo^*`XBkqf`G--t8WORLHfdKi``#%U}6PDhe2LuMIdA+NLp7{&9q$nrPwyAK0&cZA(tjN^3s0UesJUHvqLpGyq8jm?fQX;p7I6y7#JKNPv$iOAWG51Gq82*n<;UL?*OsG~)S6q$tmC;yiY4ej(qD+NiSmU)Og3e5ZYdr-R3~^&}DG9TOe*!vITd#0jTueeR!NWg+JO69fiLCqGJC3f~jjWPnw7}En-VQIJFSt$!NgnY<h4t4LQVas%i4;dhmisgA@I(OiA#tfqaYvL@9Y<IShi=+oYX;h-{*2)yg%#IaK+R<aYHmgjiC?FMOjWItDF~>%KM-ga<8JJx8k3Z8=}|qY%NEXA&;i=F&q=z2QVk7{ToE3F<J_Q3h$Ea2xSYe-EjwJ!g)%f#2+fM)a_JhN!bTQMT@eY?Wo!IXYsuh?Fh0EiDq{EHHGZtQD#z<b%<AhUzl2>qg(HA!_$p&K45q8NQ)#G^t$09UUuVdq+9W8Mb)qOUf9Qi(3P^gN>Q{*$V_@Oec@MdOT^EkN3OTeL(l`%`p%frcSp(k@=ERfOy^erq*v+=W9=GnhqfmZ02l4uz>v^73fHGwZ_8?NfkM}xMFX>(#ieE5?(*oE7aDqIUx+z>12rQLgoO3jidc3TzDbEBy)J1-}4<{2rxnAY|6N7<##3^(pCndgpH+sO#pmmx9wjh>B-u2g*(K`yC4B#rh<A{GOaYUC#FIK=;cRBsDP<0~s7wnQr_f5DDOwwr=&_JcnyD;GO#qYT8jpV{owSx8HdW4C3n~V!j0aIeMx;X{&;O0r=R?5xQO-zz*IBYT57fEytM%A{RS@Fn;RY0o+4k4%%ceEY2{!fxem`ap@7H}i5#2CVg86=Ytu>J{p65(CFdn0>U)RmDe3U<X5&nJgNZHQ;}Om>pTq&e|S8O(Zef;S)s_#aU4^(^KFBGFbeRCek$5IBN;OQB4(L2;|$pBSGvpIEaFSkP%7g9GHCR|M)kd0a?mveFRE4@N-jhM-L}PTX5ubUYHsVvU9zs4NA8QPzK{>O_uP@mh>pA<UDQL@-yP_>&<<qg7N5)G+h9${#id0~HHiPaR{vK+pr8XHl8Jh)K~EY}#w|Mgi3W;qaD>^bvps1=&P5NN^xBIkRlYfe&%;a#h1VNLxLo_BB1b(JtzZvYrLkp2YT$EIb{>j=IWp$id6{2>YNBF<VP;xQnvrCXPX&lBVF?;jh`caA8;IJ=cW`I#<{R_tz`J4x9iM`JwJ`yCM)veTW_ybzBsfPS=2Niq1M?=#C(%tqV0%*uPj8F#pN2%bP`kX-iuXHj6^k#EZ$cQ>l=&MIpVmD4@Z~tJ1duqc`rcQtU&obz!%z3qxBM00=M^T=YM!h{$b`hc&);a`a_ngT<mGlCQZ^WJ~nxp8$<suH^S1s5-1mM!lmGx$6eRxc;e+zH24Q$(E9OJ$L_Z*UHA?t$v3n-G#{IIX~yT9M}-(Nu}3a8nAcG>b7#pAQ#KRLL^}#ukX5tKAQZ)5c=6V3Zpeh(8-nt(j)Wva_E*M;UYC>5Nzk;x`UjId$>aF4v5c0C&KjugX<9F6P`@j7P`0JBQP4x7KWyE=RBcjfvb4lhXwZtJ#Oh0p96#j<2_aGRU!pNykWqwO^n!CBzhI37lRo)7+Nf<@TJZxq!NhE;kzUqQ(v>Ao-JaLUh=s?kdTRjMh5632o{jGGxNg#z56{B0*4Dt=bxB%eZSS4Bw8X9@?0iV*PgGP*W(Y@5{)7WEDM7PLhqr3iR3vrUEW)hYYBMpO0F~y>;)dqPfRtV>5;4cV;YidRagZ)c}<@b3uDrW37XdTisp$^Dh*gEk9M^acy;T@Dr3vxy{yCn=YB)VRLOP7P4B_q9vnkqVBIK)ug*{)9?VSc1yn_%cBCG(pV6k-sW;%mJ;{mZ#gN9q6+VOUpB14d15kMLfDQNf>p2YGjIy7>%O%oD;uPLfhx_ITL8{d3-Pce2RTAXVN$6`OX5#2uG3~@|XrefaRlp?mO~v#e`jo>MdT-41ehz(5HYPGQH^={FWx<QO^61I%;~Omanmq#kgcS7?et2WD2eR4warGW=B7#PKPo{aIN@v)-m-Sb?{bHa15#jCa<Q_5V$j0Wi4xF>^6Gah|OcZis!8=>j>-qHy&WMMM*zSz@(0k7%`cJmA10B<XL^@W`<mN5)m@|rv*=R-1#LwPS6AXCvR^^P)GZXY_f6acLSxbqkr=1o3p_!SkxcQ0H{;0C(rm5Lpu;*$qu*xgcY}(X!6GQ{hn?{c`bf<)Q*K>34iwBh*@*P!<g|JYQC5`K$CYFcC+};ve$0vlZdeDA4L!u5pMK_;>Iv49SeD^_FPknt$d^&8=sr_sjkU$Nd1Re2~Z4zYh&cbQ`?&=>Fns+VgK|-!pA&NFPXy|v`_2wWJF>@>S6%-H|W{^d)yuUihW(wdT60$@15vU~?KnXwd^=IKM1j@h(w=_yGX1El=)`)mL;-)$l-ie$rt#Q+0*>GS7Kae@DafF~Oqqc|5T5R`)AI+EH1u993c>azn)IH2mJi^N63HFWvtdS1}dXbD&I;tzsJF5<{7f<bnz)u{Qh2culWCX#W!WB!w>`bQh)9tYeckhT*c5Nh-;Kpc(uEgus6p~O4u?7sAbY@*B88<39iA_(*?xU?whN%zVD5m}oUjlH`Wz&{!;DE?~SrqtO_WXI2u4QXEtq<}YwdwZ;hcm@Ve*jw)F02J0&ggwSmCIr|3;!yBLL?G5d%ry9S@=f`Lkxjr=&ey63R`tcp11m9>;aezA=+V!?*#@tQVMC6&gg!3Knmv6#3;?L#ESbtZ90rZEXi>+Go3(19donMiJ@3Os&|HHM5mhN`;cVZ6P#PhWptz>SdYh3XA<Rkj4GG%qtlptsDc$EY9kLKFjI=7H9uQ`7Y`$+vH>+%e6Unx?NSQ`7s#R3X8mLz5+0bf4^D>r4&uG+rvT6hRsoX`-tnuJG3T1??y;nT4_YJ$!m#KdDmC9t0I@5Bn3#{k!?t=$LDn=ixKj=atu(Ld5bo)9X`&cDexoSdPL-qZj~QjUi(XNFLZFN#*3mU$dn=lS&fFx6n|?;);RTbpF^M}DHO*p{Q=mP#VOX|ZsVR$@XtJJ(vdRg`jV8J1o33z{H)x$MI{_29%jXtm${>;t<cVRL@urv?>H9LlyM;k(y>Ukz+=79uDmC3LjVI>vybf92U>NYd4h>&1NIW>Tdc57lY@9Q>Z3dIiw~R<dqaZMzIsjb?Ch?g>amic3;I)Xxe~SjKfkQl*l{hXm3+%Gx_3eUXOWzMFR+vx3AVJyG;6`k5fJXvLv&0IW;X|ms;UF2o+SC8j{S;9|4+@<{5&ZDCqX>6CU<KtWilAV@ws5k%8b$DuZlZ{{LkObC>aM*6(=J(%#@3zpOQVPuLI{cLLO_Tm_E?hl48Y%oZ3ux|v6#o$##uwX3M#OzQA7t%00U8Kup|h4i<`gq-I*ao8fOqS-cg|E{1x#7e!Z6$N<jy0;itdz4;|d<Y*3AVhky-X1G`1<6l3UUo(k^RXJ}*p)yN_F`MhH{ct8mu)&EO-rx_uguVV%!*ev#1v@kR8`h}73e*1m9V|83V8m$~nclbCVSk1ex9K&eHAcAd<wsdVeWdUwoMO~Iy?`_@t7L>pO%V9MqtS`_Sfy$aZ5l}ihM|QisS>{p1q8NElnNK*GuH3O@#_a{aUUkjbP(7fSxNs|~-)c{E!fC*EJaKC{vtHeE+bx3);RFsn(w-rO$GXS%Sk9*@o(lq!>CAGzq&#iZbA-yDF2;-Mz55_1#?;p#AM&?-ny<A_!{)#)e?3hauyhXIr(xDFE_-X$gd{x=wrcJ+eVV_q0`rN<tvA-fy9UdResAkhzl))Uu?}A979j1`;WT#!o<;feKvWBocXkeIB>Ko2=@7F^n9_YvntVWl)aB~{ED~uF19n1L+#XTu1x5+tb0*iAdls@smWsgWJ4!LX@iDqRl~4{8_CQT#2gLoJn4l0h1+3Ye3ZGRD*;@;v29B89>{6s&;!}!LYD}3~<_WHJi|^%nXsntt4hQauFB>REq546Zo0eJ@qt^8z#hF^w)uQYt-Dfz+5~Hm4JdFbM>_T=?l8VW~vB7AfV(2!4O5EabV=wgqd8#0cIq*szRF(O|4_<HCsUFy8XzOj*uD3nViMQ)*krEa{n`2vbasRIu-X7YdFW27L*WSAqYcJpmFV@~^?v8^kzrrv~FP7iw09S*k1-x$fL)_0)D+%F(&Je2aeOXuFVZd5Sf@ob!!y`BF$0Xh}Q;cJGM%SNgJXq8+cR%6s?-&;xI>8vQ<1O2L_)6WF*Hr>|zgRN-zuf&53=LSqeG*^*aqgy{Ao>|ErsuZYqr^*Qdz|ms7U-eySSQk%EV~S`x_aaD**hpe#9lyJ$rKwyW^@)>2tN<pU1xI?MK-iZh3+Y+Pje#PAkVbhOhH+Def<+Yi}^iA$3o@2e1}*@@Xw3h_~^6}$>}{Jf>h?6oQ{l7e2Vf9ke(mt$dbn~d&3|eE;yN|T(<zpnIV85p(8kwiNU6nfOcl18UOE9^W|4v8#{R-@=0h)j+n}np{=vQvR>9ALN<gHel9eEu8&Dpb{MATJ<2A7+;!-3GRU{aEJO_9E{_uJNINExbSladW!yXGula+~5xRMA_A}J;4n>-;$@oCzs&nlc!OAo?V6b+zirmzrk1mxZ4WuM$-)Qv_0U^60`m0esql*3#i(yhpN|VxP&&IMjnS@4cle-za`nt?XHI0#GIiXipFBCtegv<{{fCNhUH%vW{iV)MNU-y^{`W1u^IL3nkEltwF^mJVkb;Xo5KO6M+YeI-FesJ^vTCxM>kCQ3Ig<B8vwjX(N+_j=n>IdHSu9Yc*@pDO5PVL-O6|lBL+6n+i3VZfe=yvHO*+sJIu%m|!M*S&8(~U5kJZ|WJIds-7;1|fYr`dy>=fC~+r~CEW>-kOp`t23|_6mP{g}?pv+bjIj{2ITWU*k{l_VOWrE#Js#|E$0MoI;3i2kOu9+Lo{Hv&y&E_5<Hueuj_E|KMEPc=c-xKhv-AYx=dk_pg!G31Rc=_N?@4`)l}sU#}jA_j;UVR+--aXZPA$+LPUf9WcKBGn>-EMh&5uCM`;7#8ca^?LqGb#Il1;D`D<Nn<&J!K4Gs!pVzHXq6>4FJ6!_io+WL<Yol}S7lO!AGRmLP4)hgNNs>yuoA%0`&}%jzTv>hH{zWHZz4&MBU)Gq~li;AltJj;?N_geTR}U*Cn47;|eZ-z1EYpPUUY?b{#r7*C6W3i|ydFQ8R@K$z+66P@l0DgL|MYsjccXB1bt&4{+@9yg(AECg^|?Ob_4T3Ko^5JE7`dIW80NWs1&YVYuCTj0=bK;Sdh*7xT+dTlwQt@9srB66rtPl{?rEQrTyZNm)l$|IJ1e!3yh@>Udo1#e3WDud`$?HWIk4#Q_GhO{TI^49*u8y?-G$rdUwsSxT3>(V)yrNx8J)1J;n;WS+`sVpaeV#DhBv>3eV6bR-z9#@dmU}{o-gP^_u@n2?Wf<I_U6}k{i_3lzw9+Pf6~}c_pc3=R@39Zxc#f%0#=28m-Q{%bGSa*b_8CXYJBtDTs`OI3xt{b(l>@z-}u!Zy?y?z$5$87pS=02p4nc&5U(ysJBP1)GREzlef`1BPpmapO|*Za`->mYUVSiIA+hh%edu@SCgB+pl$VzfmapiivK7)=s(@T}B2~@;v))BHARWmJT8ZD$NZn=AMvdDxYQJH94^U93huzJfN>4~+Aqo!Scjl+>rQv}fW4J@-n6MS01+8xyNAoO7GD-u<FGPnrpRb|Lr?p)w%o2W;8rv_dUHUJWNYXz>HdE}D6HKe~bGJ|@sW_%Pi-<@`=KYasFHp;g>B$uPFGqGU*{wO`xWjRvPjS59az1u^Mv6qq5z)j}O!W3j&ln54`piL6OnMpMhHTE{<r1uO8O1OUrxU%#U@74=p9{6!6^zmFYa$Bs(|Xv)d=`7apS)0@u7BoV574d2Hpa~yO*XL0o}wc`xFh$Z{<~Mwk#az1IA1POaBxEzYDk`&<SJw&Ay!j(q6Gk83U|0b(V~QaeJlEh1ByqqN6Zq!APNI5+5`z=Xa@8qr;krRbP|CX*;4hxQk3$D*)?SY#^geY8&i@ZXoX1aSsGGxUAjXPxt`@5S1>bf8njNL)LJH85455q{BqgU9E4p?#Cn6h0^T59askeX4G14-M%3fQgH|ve4Y(P&qQT>A6vRxjkdwZz_(h-?6=IzW)r=+ME~;!DRA?sBQ&T>Raz--Sy3tfiM3{ptBta0f8i815fNL7iqfZA}PV>8yNF8*xCAygcSj}y9t3!-eHA)d4KL@wYp|L^|hf^+z6#oT$()@SiYe1zO(fP(m({jdiOHAW$+M4`X7@s%7giT43-bCZ)<fkp&^y5w-pJjy3$-F?h2Lqvma!PXVIz5JujUNc)PcfNC6RQKyRm|&yyNSAI5$@-~B(B8G+hMsQRN+V@Q_lz7a^PS}L9R~)E;v{;Chi<G0S+riu00^dU&bdHf{+w%>>;X*Pwx+%zdrWn&VqY_6F9g}Dg7ez!TcrL&n!bmp8p9J%>3^E(W^V&s~6Zg%|SSy{Oj6P(kO9CT<IXKdnHrG&U_5T1+^Ct<OGr5{=|dPJb68tiZ5S-$BQfxMIK^~Ge52(gX(6R17|VY;6%kxF++R41^QFKm<X+mPdHI9E8J-L*-uNyblC6cWf%D=!%xo4=<@oreovl;Bm|h1+xY`wF;kqKlNpzot$0YaKyd6N|A(}^IHvua<H?K{^L!^(qO|Um?&b1lO{gf*0_w^L%+yy`7cg34NT{f|em@j|pQTGi)X)f2y0qL~sEC9WjDj!^y!L}x)$30tuz9AwUbbiO0t6uT>wdB&F*-wqE12<P`a3|BaFCIzQ2Rgv6{4SbXYZm7EpO%2j^mbIf|>Mo=bXO73JUFy$mPXyp8ME7-H{V=ZZant1MiF>n$?d9R5#7(LP$ryZ2wA{vN?$0Wad3r25zKT7@9wB0Nxr}J->AReF5Elq_q~DC9Xlc^}_7BiE^sXh48ouDQ+PjbfFPgT{sT1$001YUafgYcaKQ^k^;*e(DE62!{7sr1Nq6xaJXWr1MV8lnK4roVb4jG3CokTo5YC~mz+o+r~|ne#L;y<T|0as4n@ls6qkoC17{y6qGJHv8*0eH?Se4Zg`x^erki7QwbO((MOv0(^VD}wl({?nGu?m481Ih|5_jQ+y(kLG%dZf)7Mw)JEq3PGwL1`$SOaiGgYn^ra}khgtlvqZm6W=Je$f+8|Bl}{ss0B3HH3tZp@!Zyz#r~yA(hcWI-2Ap12*33bA2UdV?8T7jt){^`2_%+%YwHo65RUKb+Hc=kNaM5j2cGruTh!)WA5FH_HXyIFHJen?VKjKlf@IA3_M{M0;-<T+=+aROHU0ehn-QiE2WLrYfUGlqdQp85Vw}n8!S}Md9!o|PRa_WfOC>LaVRTZiXf^!x~8sCyR4d+%(pKC*WD%^foWFs0-dg@$eR<orF}vP8}mdXl6O9s1bZ@*9w{&E^J;EpbTSn-vfL_?tlk4H5kqV`_cC%eH#2gig446C(sfmf)%q>ZQJ!`-3ny%by)=<kNFb7v-e2+7!@JqRGeFD6i|6N3XI3I7;=e^!0yQghvXhHja<pHZ-gJ!pugSFB9f@ccL?-|{A66)PdH={mrmqQ2l*e`*Pf4UAaj!VwwB)WI-8{T=!`>OjKDdBQv`<X2QOpRMjGpdCDeyKhUu?R*rs8m|saun%Zf6?bDc=P*snjCXjepX7K-@hjUo>f5K|^z^?zB(&`5D_fK;U)Venc=!CoZXXgm8yY`qNIqwM4lQM=FWzg9%I^Oa)XDW<p_*YGVMuE12KcFN67vt9yjukjWK*m&Px8?7MsE!4up`IzNDp2T~h)**heD-5A!}D4@HTlBJWs`3cGani<r?foxj6p8-CKJ#54n@nD=T7l=gij;3)RhZ$@MQS&}i>6bTi0gyP&_i4Dp&A5=JD+LX@u~L}g&(!PPpF{c7%&f7fod`S5O&fx{CDh63Z24Tbqq?CR$ha=`BiS1DWRSAnndNJF=tNb=o^c9u^0<-YhJ2zAJWYU5BjG6@q<0}&2rhx3xE@AmNy}7T=`7w0<m%>~)GMgeVChXRtMEiym~a8Il0bQB!#zefB-?DK_5|%;B*B~e+@9yZ(t&-RL6;LzGn0>=ZbV%er--1G#tv#%1Ia%LqkHp8AVy=pd3%?oZS~JzO@<nv91*IC3%=0Yvh-B{`6xd>l1;@oFJxsw47$c$PjKtYk7g|r0IN^sXq?%Fl+Suc&SNOM@LiKevFh(|rgm=%dw=F3S!{t7V@~sPy%Op33)Z|t-sIkFRzQ8Xq{}^rsba*u;d<xvgM0P}z*ay8T0iToi&4MOVzkhFg4F`C;*e>q=kV$FgGiy_t_aoO<pXJQ1A=amj}gJl<jjv7HOWTa7+@s(8hPWo(wL1rUxWHX6iyhy#7tTcE;fseQ}jwB$Q#!+MmF<QMND&d%(Umck(gwev8-iA%Gu_)uOVf>@-)QULW(~_lX@A*j-%w%BQ+)ECx2$~b2>?AG@dicJi$=t9bK|X6rjWWU5(x*Z0Nm(6?kv{v#$u>l>h?6M*B{+ufYWOnHO>4P((E|Q7=^QkenUMNRjEYq~{DGZ*{R_;LeA&5<1=|@di{mG~_pwv}atBWeVeDt}=)Q2Xp{U09De~DeibU`9F}1thAGIFdS+wacV+hD2gpj)Y`=5o60=GnmXTmD{SZ>qQi)EpSi!JCY?`LTrC1hcR6WDu_&s1x!P(9ZbB2Bt`D8?qz%i|ymgS(3=qY;-(DTI?z^%N%L7;UL=mx?06ypECkEYIKw!-zk*5;+6Rg7@q_aDa<W#VQs7L2(Hn+x^s-=t^3motg<UJvGi*N-M_L^y&P%B%kas|T3*hGHDx?zDV6ZW0*lltpOjaX^#AcILpMx-<$muJ>{Yw}2qAnbgHvD-)UbdBKsf<;*W1nW1(8a1LliGg+mHI9QImy1ey#=Bp7xcQyMyQwcgvmsIZx$Z4=Owp$6E*pV=trz5pj}>#|zqTrUT$u4Q&MhwXQFrFiyntZ1w;E_gx$SKofwFkwl-r=(G1;n=I|Sp*MImFp=iKk*3s*Bo>fU;twQ#x114T6GB<2!;Nlw7#OS6~lBC69liE`G}-5qv(^w}%h<-QQOK(jCTZ}rSk2B>eaC?flyOd<Vjm4HmzD;p453TzSsfT;@gLEslhwX9Nf)0q8^<h%^rNFd|OkS0soBNXQiaf>1uumsspE8z$(i%+r;3VL%*{3c4|K`jaQ@IF$=9<_}ybZy_lTk6J96U*dA<#fGsuVpEtHJ5S|7dMh?`q#SuAoM@7K1ku_(EqZ;$m_@peeRAJn_<4teh+LbT%M()A;Vtx0W<UbxE7<*Im>0>n1UE((B7o2<l;S!EXo!ga}uMk!uo!3QrY1N+t{%KvHGxBsxIFf1~RE<1!8wm`5qH!!bIzAncd-o>UFwHP`iMvRYs%&#vfmClBw;9v@x=<Pc;s@aP_Niq29)V8O9t2+U@}v!UYwingPR3c8B}fi}WwG7J4!b`_$}M&Z4usegIbJ-|zlCu6TPabMc9*;1LO@6$MWz4r_>T-qU^VkzWxPGC{VZqxmW)9xH<3(~m7@sSARlKSo?!$L`SBQ$X@L$jA^HC?x&yfGDihYtTQ^b;C-eERL)DL|u9p;loM-es2I<@WqqVRerRN#<HSyFhX$T+27I`#^n2EhK3Ja?yYVXJC`-bDiHHT?lI@HQlp8~MFePICqvl3I4~!FB#CCcvA-C%ZBU{$kuSXjXN!f&K?;S90X)8EEKKE)NV$g`OdAC9_`h|tS&i-mS@$cL$PV1E9$opSGnw!Ex*?3R^`NxP#~2y?5n5FNjCS>5U>|XEAM;4forxuYtmfY(eh0lnzt5=uA@<zWL3PhTmOY~-6FD(^rt3BI)wC7V;hj%LYUbjlCY9Zjyp5DGgX_+amq+c|+@UUs8<)g9)8iRYyd}zaf(fa+DQ_18M_ta{UHg??n6V!Dv3~vd$Q7y1@=rteM9r=vd7PjAO^`3845+2)!8-luvEypEN1gViq<;*2ceYI}$+kF15YMc3B{JNfQmz@J+|rrU%-r3dv<1zfs8KmVeH|^g5ph>Ol0U}^s7cP(?=!_dNzbqbZ%KE%XPnm8t!?6IWgb@eBx*#M-8Y>)(UnM>^s0!FsY*mJF-CfnZl&}<6A!CFOxiXqBEwYP;xVnc+iJX|5X8^nz=N;$V%bfwSYI82XGdGprrtduxn~ZN-@G!%3hv>_#%=Q4GrEy|@{&!jlrm*k*)ruMeJ;%PXdKljyQ>6}9Xb4W-FteOF&ngzQfLhtTkpfO=p&n^nYBmR=*EVBj2`||bAqA9j={c3TrY7Ltd)>v#ukIDhNA4f3#$h`clx{J24tWiyH)*Fu4=kTQogc3rA>X+LJ6xnY#PkLYM3pz-4+Vj$jQO=i#m_9+PkRwoHiC<MssfKf&|BcT;*5)wauAhmmWDM>?7j((N0)p@XS>y$IbJW!~_ZfsdgPD8fyNWEZ*4amae{(nWLKT+j<!n_g`a(8$YT~{?(V!Z`wq^lDf+^AK%!@9tOJW#A~nVt}(bZh)l==4KykwN)t9S=qgK^Sv?)^h1iglyvgK^T73cvYm6bWgO#N3mgsNH*JpGA&5w3M19F+TSML&Yi70;jAd@d>FDKKg=p)Bz*Y~{THHPc~BB<{=Mof;$_}Y;U35G$PU34wi$Vpn)h<lT?GwEWB53MJ9=49o{OxLa4(Z(}S70g;}jIyunnnt;to|7DMPO`O!>ursYA;Xx9$=W7E&(&=b0oqtkm=d~>@Eg(s19em|l#vc2Y?PA1dy{vT6Dr+v|MZt_F5}Cc#f*z-*x{Q?l-qYkXRN;9A;9vXCxoRpxCZu-6wb<TCb(&g2M8Fl!4>;EYzIBMo)|2d!hO^;fpg350ZIo@Gq}g0rr6n{7Ez_-9mdZd?NRJ3`GU}W=u9Z5pSk1Qn5YC_rKPPV3yX2xXjHk{vFBz6ScBEweD|?`Yt|opi75sT&|!0XW!}8Y?961{MN_RVe)o^oplZp$6j?d(URLa0PD~i$=_x;5cprL7b>ou9@_^>v%w6XBv1TlYMV2}Wr+AlPSbkhgaQcy=D#!cqgL-*Bs%cHS+#}1<R`Xdz1ArLebmA1uO}Y8R5lJ(X%o<?dzSfxbR{;}a*8mH!a5Cdy=^OL9r_<)D1a-Hri<1(ER-+`dR(T>YrFcAiVrBe;YKc!>n&j@~|N84f;xX*XwuI=oHyGL?x*MstjBuOXa?}siET;5O?l;B5y1nhtw0*;$#!H9=i}C9v#Fs8L1EpRH6hW}^<ZU65RYYX1*Rn5kGP>`8T8!QZT1$(O;`b$<NoF|DS4#PH!8}Te%L|OlTT1!*H^e&u5L9yf-)=OV;0Gk32jLgORYW4^sPY9z2XUZ+ol)ll!G+Y)!X8zCu}4>t8;Q&h=wKs51%lI-!I>0{ObZ>_RD#<}rg=;Q&`e2gOqAx1dle4$YGR@f&h{=wzq+lG+mIhpmJU~uwiCvLKooFwN>Fqw8+Jgj79~dW#}q-Gh~69OU(ZoCZ?G?nmanLZYkgTsb21aBS6P||pfLCRl)=>3>t+}4i|KkI7&lA69JjNo565ge`quN4D;1OR(e+MfTf{Z9NIqK{kxc<bOKIW`CdQM*v|^fq_t1!k6|n_16K+9xrFwuu(Xq+x9dUViq$az{3MPf+l47zxsb;7CuQ!g}u06?^B)KF$n*lwmC^+8I3HLIyPEsdO`A<J^-@}pW5=^aM#>^S>(@JcIP9KFv!UOgnD)=Tf8&2?{0FYprk$et>fFTU7Ik*)%C<MqRgo=O^J@oEb$0V2mP2En5^f^0Abfn@w(lA-on(T6{c-{aM^zs;EtAfK-!neCt;qFyL9jx|}yv5(FW0fdt8P{PsLyS=sTtOWV7DV|3IZ*GLrQ<T%KD<`Sn|i!jINVC|C^zpU)029Y`-_)EJ@B`K1TQi(x4v}dN|S!amY#hmU${31AV#Fy@ydLD0SXLvvX0YxYq^^nY@H@|MmWJ)tNwA$tZGG$s#GJuxzBRE991spQS6m*UsQvWnyV)+XxO*}B7<6V=$(>;O#}-Mvxwe6Gj-122acV4!7}R-!RjTecr^&5p%SYf=lEowh5fMSIb_KnTQ@hQ3#-Ij7C)k-Y`!zZF&ZsAbEy#Kz07jZ!S2y)N<myeEIQ#{@fMd_MAx)KH-|0`sD%&^>HTIj*br}{$w?4YU0d^i_2HC)AWcgY&(->ayXJM@@4yz{PcPcWx|ov;R?)T{T<5QK+g8!G_)@g3?cq0sgO}U5q}#^0-}?rR-RVj*b5(3RyIdQA_XEL&rq~w4j_OmZTpNs6q184?tL;^xwq2ObBaO6!U#w8ue`XW)$D3kBjna}#T{FS(xNXF!<H=lejz_XHO=+5n$608jE>rw*QcEp_??56w)bxq{#%PrrhVud#73CQtOak#MYei_=Eb_^)1!rd4bu`F;DeYP0U~7gP?iu3B+?2<mOe8kjIj$MMLVmLdUYEhnfwD;ZvKfn0O;9nm+h>&4!`#|o@hd0GCk$6jo8N0w-|U|&U==g(DK`_X&|Kz&=`aTOr0mkh<|8!s;89j%_4Ww|Z^afIy#D~hNX6%$5QLjOIL|@1(PsO@3mOsCo;kzo^yX*x@-RY*2t`mHL4`{-12xHu;`1Z2@;96NbxJdwNN+dymjjj+P2)Str6=OGEgCQEB#vP@v8|tjB$}rteY@*sV$^H+JtVhF;Po#irf-4wX@J0DkWMPd7AE(Z7-^?}e>IQ!kxwLHVIE#HkHOwiN2knVsBe4Wq)6r{9x1Kg;54@GN7n4Pf$z03%V{Qt&%@R#MqM?$4T^*h-6;AwBkJ9_LQKx+l!%$0Q*=ytM$o{LN#H_c9xbue1pQ~R;#&Jq!^4s8-HkiU!(PX!-}pHm#udGTj^z<6e@63;rU?bniCzz1fH^eNnkCD;yWTDjjARTWoYLWgcy{e)Fk4aoIsT776W#7hU@=JJF=KY&O=JuR>oZH9qrqY*FHB4fGvEe`866grRJ4YIY_!S1S(Is+6Y@&N1I&9tWQOgL4H(U(te2sh3B}`{MV)0w;3z^I6yuN4pq>|K_oBB&TqQIOCt6F_&|p%Ip5;UkWw?Tw#(VTgq0?Dq1a+5vmBV>5xy@$8iuWQ8r(2Y%Ob!;wsYI+DReR&f7t)P`7E;V5IMBjeOt8Vm>kW4Nxoxn2@UvD(cAEip2s?Qi+|oIH5r$pe8fFPzm0u7!`)ITo3FD5hQaDk`bP8vDgTFZ<rKy+vB5&IgM+ku;j|D`E_kUs{xKjZnX=tzj5+!}x(IXDwl+bKF3bnZN1Mj@_=O5l;aZX!7f;eq%czEq@hj03B|K(pSXZMv`?VR1oIJ;aaXcUmIcipd0KW?|ZPCt5EQg$9|DUt)o;6sNyqlt=+E8-p`L%8OXEDP@Z&Xd1;c){Q8U*qqdzM8*_?esc?#>d@-pUVvYQxH1-N%#C5M)vw~*3Zb_$loPm;nBLjg>=~DenBHaKSU#ul1F@-0RSG^cM)9S3C9sBK!}LG%jYL0y<})ob{L0+lMMkW(J&8L+2%ROlQO#?@1kt^4tuX)8>2JiYVcne(SyY|!J1&`j6IQPPZg<zoE<f>@U%ys=e|?pE~)$?>Vbi<buvJRW6n=>!A;VEeW1gHowEdZ_~J*vezS8oh&ceXBU!L-NH4@AfAEW)b@9cl8*XQvw57Y{tESxRO!*9FsqK`jZ@lA_qvU@S?6<D3&t%OfvgQYdICa+TH?wZ>S(km*VTcu?_5sGhlsjHex$|pNZubkEa)05&cGQp2ove|$MP|~-KNF~ObE|{6$J|Io31;GpRHj}t-QgIQo)}u)XU}7%wAn}>WSY39GBx`|bj|Q9GyIwYyzo?=ko?5NpekNm1F8n(N2^Y-b&2~7Re90^hXt>>qi5`anT=Qr+E;sT%-8&8%9NuA8ed*;-7aZq#SMRW^H!6vKqYzKQPW5$(`miW-{ejHS3cNVphnA_b6B-x>~`bja`y%{9q^fMe9O*d<0=qt99{0vK40i6lHJQC+T0c&lVSGZwl0-lBGd~_#rrzd!)Y=Xmodfjfan_5)dvh=)}QDba6!Hw7&(=5r!vLBw#XvG7SL>A*fKwE($qipVHfoyq^Up!;Y<Tr0B_U*)>P&;1byW~ZaZ{!)jz#m0Z6d$I_5Vk02YPL@a4D+2tH}O!1$TAjthaW1C~J~H(CZ2aB3MGS?j=vFGlT^D|LO>-9StoLl9GLy2<)~>lad72``E(yDaCnO?1C5N^cccd_{Wgy4DM}+f-JLiQ5ZXP*{RSE33>W(xftuABh1l6izVvx9$29=%%FN%FN<Qavz#ySQng0eYc6QWl}~l^!~<|bTVQ6wRNL8;aX<ZZab6J>JMDq?}cm!ksK}lS$#0YDkuOQPpEu6Sbvi0ygi$oA(|&-9V91ttziAEZ`q;V$jYQON(~h;B*0~+;6=Y2FC%!%G;<CTM}S~niEa&ubf}2+=9F&h!y$1-qZE{~o-Mlurox~wVM3(ueO&fNO;t^%ms2ALbs+{o%|;o(Oc*pQjdsnL&%jhYxva@r|LQ%;?#pE7q)^faYyBK|Xn2O)tOb~`?-09@vK&<)4yNG30<B>_EuH6QqdhoS(Tlz`^;9Rq)}tv)71l2R??^Rh!Jz8}$NHPH7%x8tcRid883$rSAs|*Rp*zyjuK$(i8@`$GtIojL0B?L@`6=J4F3(icinQin=r}^FMi0^jbFbs}(^_o~eQB|6vOz)MVlur&L(H%SED6PIq~1<!lB|E7*OEIErx33~#JkMK>>xfSJ(=;A==?)CExWuU%Y5`?usSpj2qCQeNRc_T#za8q+)F640iIOO;q8j;H1zg-IihLM3u~T`BCw)Im9%<G7DxvPi!iY!cQC*;YN=7WCAkrVB8>6q@I8>8nfM@kcT|(ogiTx=fe41^(u5@b{!bsaZr5|!qbid|0lsYkSL${PUAZdrZO|)T>4SI#hqKY(ii$Ltrh8rpz*y2X4Q@rUba$_oY6_Mo>wiU9_@2YtyJb(;#BhaVnKnq4hZ;0w^vLTKMqruvdRB1`8yJfwt+mElK|QnUSL%WfEYw6$#~GY<7Iik*mV@em$!a`@FX@-P1$Z%=Vg#b^^s{9o9FKS7&%ONfkB9e1|4z9)XEvnW8mF$)2(jx=f|`901)t&eKu$R>gL(yj&hi;{%VO2(DK8>Iz1m(9v9!u}@(FXp-#1J&hT$kWgOp4fq`JMvZj@*m(v!d+7e@;_*v~aP^Qt{$hidSKymdtnS0?EO)3ukyYh9epdp80E>%07MHn^w7bGhkpc4l(BdH4D<xjw}=KXmiP7pJ=6`$xMVelltMO<gy@Ptt5{gRf}*E!K0^o8lWMu)fSc;(gBH_A9i<PTy+ZJ+~f98!GKvM1iiQaI=o#Hh|+sB;oo)t%<Z=?e=l6y?AqHMHyMI&-Se13URWxOYq^B-*>W(<l>IbF<i1am^s=z_*x$nokh_-5g4K@HxmJFr;|+GvkL}~h;klAN8JGU8_|-W^pultXh!B8=whI<#%P`4&RncqxQbJJHj!D`?S;_hvBBDs4GQvkSS`$*;qm1Fntd9@?Np9FeA*-vG(I~hK02!C%66)Wf|vr6d>9otCA#sVNu`nNeRX2sx~nm}T@~DkOkaOYw`y7IK=a^7Iv?6M)_Lz#VSTmjyou}1K|n$47PcAbt4@s9PSh#2E~8wUOKJo)c{)qKWHbNL&BP**DOsgvovGV3@@mOa4@4knR%g~vY!Z47caPyluSJ3DgJM)}3+rdSoO}cWCVIUEbK&;CZkNxds?r75M@b+3PL00i8lZgAEnmEC6U%aJA-_7azH=n>zMqkP8sZe7R8o!;dVvT)jI)>MFK^0k@O-8^nZn-1%;-?@JX}<CP8{+{XsmJ<AIXhG4%wx{9eY`(0p1GVc;$QthMW*s$Ao8=DL(8{@q)E%%~Z$N#Qk1<@}VZ?X+J^AV>iOTG}DtgcX}gUIj}5#<a@!WB*6sQfp<`0sW<1C(o&PX5l1+i>OM6J@6c)k0Xuik1QhPNv_B*Q9O<EM=xsc{ie7%_!-C>Fl%x<2XS6oRFx$k!uU68xMWR>h86oZfzd|;9s{|2YPd@Em)HAkfvv12lT%ost_CmsbPY_WsyH0A(0$tb*W0=bZt{p7Rn|jA>3;)Hq`@G;=2lhL+;q5r9D0f}tNLQ~}{}Fh5a>Owb=^Taum5=<VU!muoQ)G*&j#C!9>insH$`B$sg}H~CYIKX!@{y|tJ+fMfm7cWS`#{7hevaxaHG%kxaZ-yTtK`X9M_zfrTR584#i9Vu$t77M(uugLy?3(H#E^Zo5Hj1jrSTEvo|!K`aO~Fom#2Z}g~XCDYF!1QKcm{}3|_D4Cl#YKr}4}wmkp&ex9Q6Cvpm*uA%FHXKiV8loe8Ywn&VR!;{@7Jnja$B<7vJ~*wL_h`9H3cq-U_Ol&*YEY}Q8<{3)UT0#(<V5X0Z`LWj`~tj}pQ0v>Ui6sXM+aOBw(eHs1p1>jg%k(JjzOR5GCx*!`$6h7cQUswg}9pxI-v<nXXq7!CE>C-x@DEVjigc~ypEW8-UC`r65DJ6A>C&U%Niw9EdRj0{TP6%q_6Vm0GAd-vI-f;Ol?uHm3iO*vRGcJ$rp7_;=9ngNsvF4-i7!)!Bsb9e8Ui^VYUZDCb?q|G<CXfJq0-$R%qmM~;40QI)Xs-w)2w6e%%!E`JN^gQA&Hwf-Ve@k$66<j&mG@k)?p=nZIPYhjn>Br}&+oVj)$>CAs3W!p>s6P|P)F9>sH@g|0R61zQgG>*eci{=$7Nv~96K2eZ~>kIGDDIRAs^UNV8lGL>{6GA!xOpyg;d#k<XJw@EJlEpHw2KxHTqfnIz^<w=r6g|N&kQsoJHgo*((wxIfi3zSZeuH$I0kI^*}Qv)v=^Am5-wdCrDpknrV^X*|ZmjFiMMh5iyjNVbbI~qT;bs<$gU?%>2LgVOvn$WQ4j(8?;QkMquqwL*Fs^UBcVjk-B|ek(oe0#Cm_Qh97N#xg4Fts!i1JGk5H(miR_**XlC3(sghCvfU}7)smr1>Sbi9+^9Oku`uyx;nsfUI6qUl=wwuF*Dng_<F3`2$S31f@8c|GOUhChf|-gaai%=;SJq{ybhK#S+Z1Aw7h;fA?1Hc+%g-5g^>5apG}V3d``z*zuaBcKH6lbtxcEsJj#4NAWT9^y#YC{`p?+}*$!rG^Q#VWCNFGNL*MWvzRB%yhh&Ay*-tEw1K-EwNuqiD^2~=&ANGYkbkY7X%4kjEZ44YgZD&2J`N#i>s(5d6JOem3JD6!QB#TJUn_Ol_R(fba>_H`)tL3s5D0DK*2^`56)tl>^E(|bvl;?}4UQ>aS<Fc)Mm!mf_K0&oty1;|JaC#={zHg4vK!`8iKWZ)8i^J}0Qyk`TKqxLHrxW(wiR}I_=*YCE0`+{5Wehpl1r!npq++Iothg0%4ZcQK-7DrFG*aJMES;C&Xag660IiDE>;#%UfG}8`j<En%SL9xB5jw}oVHcG4b@5f|NeNJX*u;Cax|0|nNi$$_|7L0b}g2#sxV5Ux<=%GeYgJhBl3(Y7CYwY66T79=_VXhCbAjf1D66=4H7dN=m_u5w^wF*Ti`Q>ogVVInI;vu*YaRVnC5PaY@LC!4^E{;onS#z+)ig{L*&eUGVD3^1~UT3?QrqR-O(#P@6&S0mPD2JY@Fiwp&?qKe1(!zNs>8+W$k>|{^2ztd$kG3&yhbC<>IA3rGqT5ANTE^N$nI?XrF+|&e5uFiS(nYbf{NlvUwHbQjR7=~!>nGNiNtA+7ZCUMGzOED7xZPf{8F*=UGO~@gn!~CCq2pv91N}xEp<d{unpJRBsEz`PR>I<2vL6pTRC#e>X{KyCKX9=;Ir}YRVD)-EkB34@uW6%(E44io;)kssF@&90F%FYc4W=|k+0()Z8jC5z)2U^NQ4(LARhyDY>HG>L(+q0DU<Xzi>J^ZB#mRk!YEUZ`J>@-1P`LxTgWgNj{5CQ4Ac4?84UW+$oMWqgC6fq&pIT>S!%-h3txwIQ<m|zyVPviGhY-GK)4P?9(rsC&Y4X~K#^9PTZ<mqMTCQyc-?&z}g0Xk~#i`ra&qZ@H(J-$&?3lY%yd#=ZSXkfEM2(F+X?#OJc-$1<g>kp?TT?vA+nO>ij!89Ml_y(u+XSiYffmbn^L=fB3DK+M*YDaiC;TV(suVkaCT#VH<BL0@isO8(FPxf^HDmqpH~+q(3B_;=ugmF;%Fhhq*jHeKP6$s%DdZH!%>uAI<M9BRix&Mj6a%e%IVmWm4MJ##&~`BS3F3q%5-##a`tvWW6;EB@PweWV?it0j>!!g%At}vFOwr4US2sd^xR+dE7u5Hwf6C18SmsUXn6wrsckER;4~-8S3kdw!ZnZ?#8%l~k15jC-nF>6M>Y|D4cuTd?CaIWXZ9a=eEVmX_elX<#mY~p5+z-lMSg~~>FNx4al8YJ#E_%f#GX0JIvfxG`!C&Sw<mpNo%8xm3j~SG|2JH|CW*UW_M5a;tO~Nfm3lTsF5XPO&+{Gso%|$pqgTNv?5Jq_+(J%nd)Ni^6)F*!4{r0U8alJz?Rk>^E{ZW2?>att0)lq%-<L<LyIw)$NiPtl$GM`deFrK0G%9XuNjT)GpiNuafw11uCntHbLo#_hH@%#}b-@-kWdb$K?5VMDYe?4+%{*GV4L1mj+TJfM#)ZvKJ*wI{J0u;nhCEi>)(i;S@Q}H4x$Uz)HXMQlISim@ANMj%Gn+WO@8Xj$wusNr6{nou9p9CUG<Aq=jO3&7N`Ah7*U92FO^6%bibJq+1F@d`=KT#{EPmsdf?Q#$F2?$lhc0pBQBx`erswF!LGjM>3b9WkT>g8U1YH_-0zLerI(_<vKsw;(bF^V89!8jT4T*HIaPk}K=LI5*n=egJ0J4MOVe5!c+Kp{KSUy(8+<Yv7P;LrgV3DG^oxI2p&?}T+UT~M3}2y*eWV6`x<068hB!HO%vxTlc~%HE_db}{-gLI%1w;7kaixxeUBW>lvR7JPspPXU%rmAiVA?!hKgAyVbmIRDlwHSD|k!1NsR14V*6i^qaE08bghm{|70p6$Vh`r?mBgitZtbO-TZR!RE-g{My$y+B~;!OlYTlfnY__@D}OWXUX*i*(M>e_2@YIFeU3T0z=Op^Apu17#!BZ(wcqz>-Eih;%5t6s@vteZC_{xf=<{8qe0%<c+Oo0vr~du);H|^5rAU((#Dm=j8T7<_&hSUeXaYn^c}yL5EVh6~EPE%)fD)7BUc)*lYOSCRpe_Zf1BxRru_=5c9xd8uSn++Ch5E5oHFzp>R7gmYpK<4iI$ww;23S*b)I-BvC(x&QvOzCxTR!qAk<g%#GCuN@7avD45ek>^=FkxyQte$TI^=G@WTBSDCEiDf;5&UG^-Ugy=0(t5``rr8!7*<55q2Ll}*nxkju273Q=YZUc2|k}!5k-ppNwGAWJI-dr=xKf=`JwINAD#uiV3tsEyAx>Yk*_6*!NIu&4fEwC+V!wU)s+^X0ASuDK$HJAr7n^4-2yI^S4t~sGdYeJVUcr0nYU$6$LYurd4lbfy>S~5E<q|Pd(FUfEKdaSqPrnzWjVv8`6tOwG@e88kmI1FODgHZ_<g+pv0Wjl?o@crz7n2w62nXJrluybUll>F{DM{betk$pB0XTHY3te^w~Yq98=^0||hw9?o5u0Ln9)6%vdNi3R|{L^jq#&8`h9n__e8R<kYuaG5~DC9-<7>EgRCH59>aNL-AIXAOtdE2Ur-m-?ysvN1?A}dm9<}K<ZdX-a-dH&y^nQCT|!EKL;JM#=)Nux;?5jK;sOF}q!;?}h~BD)>+Xi=GfY*d0)Ez9dF6hAd*n;dn&Q-ionQ5TS3l#(9o`l#^IfC^ZCrnt>ZEt%B7uV;8?bIY>bB^gf+mD(xwLU}-b91OnFWV=Qh0wfK_Xkrnqpp<L?_Ps8k%r$X#QyX{D&>9kIjiF6e;WBxpqw7Z53Txn&63h`~P_D>hWrtg*HeaKW;F7t|s{CnX@6qrlUVL*G0J;vSGq_z9EVoRwb2Q~Xnd|OMLugPQai)?vwms_6BVz7LC_iLKP_wc#LDoI>N21ww0xLPQ$9l<q7G_FW4iMS^O!fi3agqIdB09tk=tm}588^h%muTA_NTa>zT{zJFY+>=o(d0Hqr%;}0M*>L%#AQL4#f*Lt?4ly8>(Ay%iUf!g9vAW~mytR+NB(uB9-*u~DOu!si3=~#t9vE~QXwRHo2X60Kj0CMdz~J;+nI5Tgv6nlaN;+;Ad=ZdeB4NAs1&AJIEEGTuYXvwFGtRc_odN@2*YBo*7e%&zC_%B)T&$Oj|O?}AWry-?FZZ^YG#e1*RETO^It9e^Hvc+#d+qXrvj&8ll*C=fLWPpOvmt;tZiliac6=CTEfb)JM*tSw~L({ISow#C<DTtTieVvW3SkCY=6NuH*Dp90D};hvTV4N=^Jg8{qBd2g?oCzWE%zJUOm>Zd)4-3Lh++#H4>wL#>QcH9&V&77c5ZoSUzcaw^n+}Wh-Jq1?1y;pNrpTYRs-aFBHO}u<f3kY+hxOBbvD+M)Kcc)LkjZ3dx44yUY~tYQ=o7L^4V3v;#^KB}<Sttu?rbz7J@e;a|+8gu5pSVE0pT){N~brW3r}V1l?vA!Po0-HVu>O>~bMzAt^VX6SoW-_BI{us%;wXppnY-Ns+>+OK4T`57eO)9fj1tD1--Y$NJ#D!PJ#nQ?M2lZqyVtZgu?_G!MWXrEEpi3uw;1=--l?iyR5-w=^hafX$l_(co?hE0&iMLF87;uh_E9*IYr*IE(Xs5kg~L#4a<pXKGf;qa+l?v>uOiBl+vNd&%LSJ>fckeTF~Cc*y2AprpFPS0bs#sP-lvYsAM!s2ux#WyW!%4T`ClKg(7wzsqfL>F4)>8iCv{0)?LdcQC2II20h2cF>m8u2E&oiSx^j#IXP<UuZ&7?1<7b?i_n5;3HW^=;Cg7oYU1#N;*p(wBj-hwF9?D7EBAY}++^Y~jRbSdyrpW0caLg(FvJSL@4X!)YpM9r;u=II@A;27hrj(wAW0`X~G8a5T>iZLo(Z8&(<JatPDlsJGX5E7OcsVinVN9Nr^`_$;3pLAQA|b5lyrPPNKre%VrHWA?3cg<vt!v7G&tu6Y5G)Su8@aXMC~ro6r^Zvwt8p<vVV*#fV(dX=01wtbAN-b)kUm&WQfp`(3bvgmw8U2l=lX-&sAAF%~7Zx8DdR&@s7^kLeWIR8aBbsZslb1cTyVZaRvI&b@|@NS#UmfL$Txw}SJ#~a#(a&tLznjc{FeaKEGw-mnHgy7yzZhVbk6wZ`bzWT$JMEm2e@4NXBv^SZ^yjd){zfv~tL*lj(G~3`IVa!_dSJH&*K~ckG+Hv^ru!t=8lv7A3{Me-IEQgc*2;3Bo!76kVTf-K=b5Et7<xSdJ3-vm)J+U&JtOd;5h&Y={DsU&qYbKKDYJvw#6z&seatzaB)KZa&2Ptk`gXJD%L=f=mz5zijDhkOhp)a;2z~gzK?^vYoJ)qm^WZuE-u+nsC>ILG%63^&0@w5TH0(y=r@kn4u;!t^kiq>?S&-FeqOcEHQG{k;%?`u14d8pQ001)tnktXx$A=2euObis}aoE8`4FLv=K`9uvF{tkU8?Pr~BQJb#@j69?yRIBSYC$(%y**XOkIcL{waTRv7bF)|wYd~3DT_cTvH?Yj1VRZ*iKExlU~qZjSLBxajC?1Wgf3Q0Ae=6M*T%<S(*8B-tKaoezUnj1ZKC7)Gxdj;yjkFQalTidzkr1Pslvk>;_tdNuPb#TGZlM%F_C~sclmlzmkS->vWTrRWC?PHidw|2_0$w6)m1l!IYdqW#OomMd#Y%k->8lU$ZqXf(Ao#MPv%EM`1TKGKNJN+Wp(^?ul<M+Z4xHfMoi<Qi$Y0yNRFo;Vc$X9=*~FL(hXdYU>mr6kpgsk<$VLSA_%L=!hDtuvSDt{iRJD3{qL=|EtBL02yY`L7?S&*s$rcM)Xg1<i`b)H23_p<Bq%XT=~|Dh244sCqyOn*+zw#o{`D)rq)GNxW|@QvTY=jm#7$#9pVeuFX0M{H<uUY+i0_|v@VkR7_?YG~-l+@A5R>LgF+9d!hP*jzL4<SEt9p*MVC@b3VTyEyo+WMUnT#y1)`*2i;(><6#m5n4rgD~Ak_3>bD>Vi#BcxE(3-e={B%A#Y#A;dhTs8w*|BVfVG6Uy%uuUDS8O{pcV|5{FjyqC5@6;Vy=t+%whM)^(Vr+KP#c-Yyy6m3o9REEenm^{q{y5-<4O&~UuzcQf%|Ikt!Tphu;w%P`6dVRd(cm%QD*{?~iCMeQ$g`Y)*-%CRyCw9p5QIx8at<=gl@2s5g|Tr#f#+}nS2m+16&CRP6uK*Y62x5<0eseBMgmg5XnpZ8p&=p5l;r9MxMWMW6N6uHrOa=ra{3nM6<yk3T1$LpB@<h%&JHejao63Zur~{kY^`zwFCDc^SexKy+4C&Y2JS6_V)g7BNC+V}W*EE6*<xbgW05QV;rkT`=wrV@a-v$l0QCWNtyfhs?*yKG0n46V7u)i}0iv3llF@i2B?CCB%S9s|`ZB$(uQYpz;nIW7u9A_|b?RzXmn$jr)Ni#22prtwfqtits}u?tLxrwcP33Uu!H*9Tx=cXP#XT0}LKf1pk!8Bvir%rO@G9l~=Pw=oS3azE#1-|pH_})?Z$<>i!Y+TgNa_`IXldRb%{cf?1)LZ9mQ0jvAg~h{--kCggCaDt%#p5ja26q_4`^4`Nwwcdape~}IQ0bvDcVSJr593McV8yO^$WY_=`XHA$J=y0kfiyl&@tiHKtw0NL{h$%HBNzs=~qv3EvGCz<vmtcamf+K@aYtr;4G>W?1+fRa1<;T;d7QX*OG7ZK>3F7!;m+i7@3WySs(1RzvY_OoAfbDeb#Z5;NXziKxaA7YxvzJw<P{X7VX(yAmkCM$s-EEOV^GZ$7MafYdu&KadK8XivJ4%P<wd7pzFSv@VEXID;!Apio5iPkmxW7r@R$bu%AY5Y%t;Wv(BV{>MObN$`Y5|H8GwW+Uj9fbI3Z8Xxz&-<fg@6Ry=I0x5T-@xTE;ety_Lz`C_E1S5li8vLeVERB6dO`C~`+m*X<(dke^E+84W6XEI+rFvdre#+G5W@<<xiW)~I(7Hvj$wpIxaBk)ICryRp=4`deKwdQ*4!^SDmwJ)|Z4zasR=gsoN54eg!1!0ZXLv6Y1@%m&!Y=`y!Yu<diAfQ&>xq0y7*VI%4VsvK<rBhpVg}5btuRqNoFFWKQHiU-RKN_kaUa{_DT(9BPh4Sul>Vtc)_<L&%a!S{}k$FR~-&TiQ_<)h!3L?+>r7A^i7s?eXS{*6mE04-{G1h~`8$Atag6MOvt39XaJpXWoYitj~)~ILmbAy?=D*fq64b{a<@89`LS7gVGSUl4f4kBth?%IOn9CM9>mjU5eF7kfCBql$Xvsu`dhV7092&uU`F{K@R@#w<F3Okb{CD-6qqL181E10PqbP6P(W~qkb#fzAcfj-@J2A<v7O>XZbtO7SHHVZK}r_P+71^F5y$@5RF2-W$Y5NQ-Z*yxWf8TBrH4vQ92+d4tyP*Nu=5p|FyS~48~z#{_e-c7^#r$?q*g?--(D^%cbk7QOOtIm{oV-Biv|DAD0SQqM4?agv3&j<t0GJ;d-M$j&%Qgj%_#awX$=cLOkgT=lfRO@&D+qc!ei<SDuO{wp!Fb&?4ZlYfQEmD3qD@ZF4-jVV+qAY{X8@S!Bvl&d0sSs{Z26_~sd??vcX_mCgA3Z;&dKxUYr8pVD3vqT&?KG7JX=5haNz}<yR$xW2D-z$jlM$tPDw-XDBT>rEs(LJfn*syPvT^-baYPTej(Hf>)3bXdOLC&eE+$7ECaFG|nWA)1wWO~nVR2odCPNXnLMWVG3lcHkbYm+94h47srOhHdl&MH+Z$oR&eBIL{3W_REc7<MtbmJx82m*y2sNcjW!NMH^u}q2vCX!L6X110skww7~Ivr@(quH#EO=3B=UgvC%_jNAz+_Xbmk64{@!nHck$3JGqh(GM=00H`3)srl<n2k5$bAEavkcsdItVMUk;4yb!$Zo#eNAVbDE?>+Py94ZKk;v7s_%3wkoaPgXmGuQ51NaAQvjpa906i1o{%|lgtYr^CZJ^}^zG#LSVmwkUFn3Q$fJz6Ka~7av`Go6%Q@y7eCSBaqXuUzL)`1`kf%McHq^k>RsbA17w`7!7@#QWnik+}XBjbM#=fo&=kzz|pihuITXYvxpr;X2KYvSs1KBK6%dkp1cl%4`DO(moxqbot3vOK=(4I82TQ^((#Ra$)s6qK?cT39;1KZA)yA0ODTn>3`=Lq!LbOcG9Zn8E{{YQER&PYDa<8NKpZqB8)4vzuEl-w7^M^)25Ew4uiMi}5KOIE+xFB9oTaH$i6dfIjR59xg4S>+{dyp5zij^Kge}i~q%IL{&;oA$?X24M*<Xkgdq_a}=<O)>QRQ{5zJdeip{(E&q$I_G)z0O!0GG0Lod99SsnFJ-KTubMJydUs&~5J#>6z`8U|F<q74Wj~R~W#cF^qlA3^Shw0KR(%y~|G2(O@wN%<NA34F!T$&^h|Bh=QM$*Z2DNx{$>2kjMH?f6W$a~oSl$<2?nV?caP~>5LvYVewE0VCQFOP$tb2zEWNI7=QT7oR$Ck-H$>5GikK8VdNFOaHISK!nC+r4-5cM<f@xq9J>t7k<d>;D#c<g%`oRY$N^FS3%0#e~E%VT<@!ZJS6)$`C{aDGcFIWl-a)9^!}%Q0!3tiwo39nFx%=EX_$&3ow|0o4jB7d1@Wi)of~gVe8mpJq(n7jHA`rqf>y5pQY;;4e{r3HMX_hT-Mo;7aSt{3uJQdEkgT54_WQtiT*F6g>l*A?JTrv5CQJ`nAiVQ@XR8S(#~B?2fW24U*jfzrfQTaOcl2eirXY6Thmh{zlmjFnY2f*iNuDp^=`F6LYu~2He!YnkkxXF>rQ?4|6}jndTra%>!5xceO%{t&2>3@pE^}89J|UcyNn{Dh%5<-AAsNi9zq@vB7!6k*+PWE3c(>FK!_u-oXCWy0FfghCqY6%JVgP)58&tU5_)Ux>*F%lTx;)r>Rc?Pj<)7mYpyZJ9Jk*4cWIaVO4<|rctODk7`dXy`F6I5-bjyyZO3+QzHc=5HrU`LAkUIq`(M6<0VaxJBg9YxJus)r=fb1iLLL~npeCkYag1He4PM9|t!yY6)2656+Ss|8>0YolbTKHT0EwcpZT8$|^mH4G1mT!>vTL2NEc}xUK%<aLwgLJ!K@bMJSBlZ8f9z%ZqYbK=k4;k6X<w%}`bb(4GONB~j+#>ta<%IX_`c{V9YZ(!lLCPZyvu<#-Ih)JX72OLLXAYgHmrJq6%O37NKbqZM{Vn?86C$l^<}cI6%kO4549VQ2jqcKO#07mbpGzl<tiOxYM1Hnyki>lpyvYZ7j-VwjXRPZV^UA|?7&d-ZZaXD+B2UR9Fn?c{vsuqEJ4i9@(i_iE?Qjfq<KwJxOMDQMvwIH^2Z$`@F4jzeyZe)dz|svx`{lJd&5hd{VYxm1J841x4)}?9u$|M09K|=oWrq|Bk(<TuEKY@U*`esK!yF`5^5m}*<MC_D9T1As0&Dci}Z*mF<a|Vo|!THy)PqDK}~Hh`K78;(XLw?I}r!p@WWi8Vb?18nTj(noiJyWnP943g2Kl3RUZ+*@e#2M3AJpRw^uam$^esqP6Ty>Ya8D;rYY6YLBw=qL{bkc1(^)Fne!I=8W+hJFPVdOu4Q+wYjATe-@5PRU;SwZ-oYp{X*>4zdgfG!V7OMo?4dFwrv0oQNcLI<Jy<X|GM?{@&9#h15Y?<MVG?TWrRT_=)q!0JXYN1*gm6?pqVq3F!QtYv6am=h&m6;v3T$CUrK4{ahcf*3;{47HdB(DrNX(_7`Vht58#Y;PZ%HDYR9X}C0E*ccY+p{~SZ4GG8G*Y4#SN!ejw;#$A$GtYe5&V1mb#i-NyfbFH3lxH?$zc}lV3xqTb_Ocp<aa%@_8%Dy^|OHr|J?aT6N}KTHc&g+J<v)&sn2vd7iM2^*qfIJoil)rmK<Z)Y0!-;M&hr;qHl?xHULm=sCqQILmIo{Vvn^eTVEAC-a#kuH5v+>r$Z&IlmK1aQT4VA{LcByq2s{u=5WYrJS-jJ);mK36D@N!84csXFV1%Lf5a{svdRA%yxLD@Y_I@ARDdBm&#|sQ6NVW>1)aEB8OFrg&%owx!>iT?8adIn~o@9sNprhTA=Kr7#iTG&>9x9JV_|fWY`Y_!S0D1E0Neeatc4TCG~c9fu6b{j1B2@nzalM>{)*c$IkV8R}D>kkKzQ%Dmz!LBdI487~Xb&RyJlRuRZ$i9TxQbz|gV>va38r-MvMc4;Mi)th`nxxu*vs9G8c-tg{mctzkG&y~YaPVdq$5w5|)Zq)2#3O!;h{qcWwLX_pJuM_PsNRPnLGbE{7!;>SkLqp-<gJAoCyo<yGGla)v>J@+t^U&?(OA$wJR+LwbolHXE09F3{ol)261j&e<VQ0KbP;H~`iNVP_ON)~SM@66R!qyNu+(N(o|0lAE1H8r(ywi6b{K4O*E2B!8XVO;R#GNT3Wk6tyB`%59L0g)Bg=%pEl+Pyc#BtBc7&K-}}5G%mB<U2#JAV1BJJ!IO?+NWvHDRq@s9mKWfxTO=6yX@pF{8bRpGZ7k;D*_S_OkvVnVmXsOON!DCkG>U&Td~lC>EU-!@l88}$w%(JOZF{&sLWEcx{{QuAd)u6OVzLs72?MPJlDiKlgcC#RjB;Na#zIvr5t8Wa&hS*WKw_Q27V0wGsKUTahZr8<1}@CvS9i%m&S`1F|vKYcY49ACf_0`$4F~=6|q_!fj4W|9q1D4nn%{YSYRqo=ZVD0&k|F!AXP}%|CC1&(E1a#gVQ$0Nk{`5pdn*-hXuW{&IOA~5~Ay^-FKwJ#*|DM;Lfiw<04|qNi~tC4nwNArw6POag_NVa7a^*cV`ThO9??P@l+<mq-;)<Qj}38{aP0NPfUWF1K(-+tBOZ+20XFWQxf3EsIga8hQ&b~T?{m!8nB~5g}{^gfEl{yLMbnq9pG4Y?;+*p*gOqb7EtybF?nZ+k$~hcT(C0;0c0(G(-|Wg)zvPtdxn!A>jxWy<EwT{)tiJHiw%yP0Fz~kUGGw7)w5X3B8f>^<}(_PwH(KoBnx3$0SU2n*2R=cX)tw}g?rcp84x8tcLqO`m};8mOp(}YhcZ;t^sqFu!wR>s<qy=}=iI}V_zLTUp?0-VF}Yk*qkqVf;5%juRaDLAMYv1(CB%a$Q$Vl*|Jq8%j;K+FZ^7srn1bR;kS<Phr#DrFa*~au+T|%Vl31RL7VTH|QWfG?VcHo5U6;zo8L=X#BvQ6bl*U{>)qPCuB70}`G?%JO0q@VMGL~w=Ehd##qV3;TIf7swRbIF<t2n8c8Dgj{`|Rdr&1m6kErR-8`glXuS6}JJ*_kejiEJ%pz{)#v)n7{NWRn}$H{(e=X(z322PVEmI`Sx*l%&qtbdR$(LeMF=*`{iti#tsgXz|8oQJ`ao0TZ0gWzV))x!pPQGu+kKRm+Lm6e4lF3S|YXGWKLR3DqpM!6>a`dp4YDL9Cq#q-UpMXE#3&!GszbLlPOcFx0D8TTXta<yWIs<B<d;0ei(X$7uY<@{xaP0rPtw?y#mjzY#ElCBc}vLA3X*fR+^4XSP~p&HB84<qR87UMl%<#B^Cccqp$5t<i+WF)jf%sg%#x|Ii#Siw<;1JI2^AqW@<(3N!Y3PGPFip@5buz^j8>J^~8r>L4|-bXIbfXCn;&b|_8m7_&Yrf}nrA+U4rRbRGJ5jM5=m-Ezx4i-*r@g6^#Zn7vqVKGtsgj_dfdSI&+ZzoZQ1u0K<w;KU=GoL%YzKSlgzc{TP}37yNzixBL9Kj}+l>e@2t&ZB>B1add!>t|hr&3<B@>P#8*z7A}?rLL8|X2#YRn(Oxbu5gtfLcgn~h^-a$rCn<i%u8G%q{hD4q%nIv{ufHbpFcDLlrrw2rkGb3L%LAUQQpkAM!<;HJK~C0MnK$-0CC)&?e%IL(D9)Rg~l^heq|`MKuBV@1ig07($MuFNOTOnJr1bxgNVNc#O9Sj5L9TL+-3yy>k*JwsVWg*QyoAPj~N6b#B2UY8dDc+_?DRJ{DH?G)k8?Zx2knf`-~fO-1EHzk2lg3$niAUaC60`w7#7m_KJvl4kblK<`CIZ*2st-9vMRE($^v0P{K|dhqA?mo}j2Q8Zc|G{K&%L8#g1HeyA}KX;uMyi8?IM>bQKUm~ym{k>|Cc*^CLhhgC~iGO$26L}#u!ei<eEd6aM(n1_e}me(VroCF(Wxe;&`-6>VYZw`?*5N$HqC{bWGy&NU%$3WO_J5YKJ6n;^tfFrC5J&HK<aM^3Pa0Q~Em$De(*a9uOJGL5uIeTU3G>n_u#BRxq)2feQrKd;DJyW*DW*$k0509j%On+dRq_e){3dt#J0Dm>SW*{XhyoS|ekGs#;gDk%oWbHi2L<eT;uX}Brk<Na5sFjO0Nq`okZCnB3J=3zwoM%u#V<Wh1mVn@E#3~H<?Upc`-}{n$CzgxgXmBD9qw<}y_)cf3d7)VeSSGE$u^JKSyqAUS0c>1J2^@SiflWYIN#bgtnsE8jX|Vbbog(n8eb!TQ&?CzQTXs@?MM!7mAF8Z`%e~bxs8wf8*jBAlzu0LhOY8(aX)sdFBQ+YXA=5A#AowuLQiZk=Z{Db17+IE5%(N)Ao|(8Yfd#FrTjfgYjiV`6v<os8A8d$RXqCAnf|?^U5@M=Mg}ofwZ&_qrCeSb3^ttaodvoeMGN?H4R`aMaQ?v}38PYywR23q74MPNDw4?m^UTr_x(3h_sPF8XjN)$D|1~ep;$%wP)xB?#gS(qL=6kWzuL0J$j285-!gjB#Gs|%kcp(s#Iwo0TB)oHpWCGCNQO;r6ek;Uq%o)6x0nuSuF(a!0B-bX9#`I!k{Dd=^S5_L)2B>YV0mv}^>MQ$4;n)@Ap-Y=ixzn!0(0pTOko2KSA7Z!KV+glM>wrN=+kp)ESgm~ISb0C3Vg>tvnsgf-9sMbOG0r?E(&kv+D^9tpyZ?|2fVw&Cx<;3JTvRkESu31NOoIF)|oETj$0bMkMkX2Sw@{PCFrZi_YjOmh|9j2qthLQ@oPVcX+N|K8&;e=M10hmA&4@H8+EAUK@DAOq833eucjd|dC#<WX8)o?+WYk0-DklE$Jm1>h|)yYZmY604<7a+u~>u`^_KXWpz3lJlR7oN08iYU^GWyQPe{3rNte8nl>`(N8sl~C>dsIFOg{p@<S0<JnxYRlEe8TwndLbm8kkwBTu9Hwy=L!<OeB4(vyYA!27;dyD4Qusu^4-@9Hc{<AsXQp-=TNzCg+mPdAImwVJs6o+_M>=l-)DBc;*<9VLQ#NQPj?&!(=8D9Pf;LE;QF0Aq4P+wJB+eN#xMWDE6^p~rbI}Uf6&Hs$D0oFQ&t!;#iSMty5fMDiJ#M19Zbt-Ux#z2hU}iu^Ec=-nyma|S&3Q-GeV`Q|YV7+kRti8j1{yelBAH0MN(8EwKaB(<;;#)c1uf+c1*1d}o5n|zZwKrjc1c-~I}p=?x;xo)R%xcAb`dGC<I;TBo6xanSfvXq8;QEeYqLnTwb0vYFUVCT1>&Zqou3P(!f>U$;lap1J+geFGN@6Wvw4RClmC04+;YAEZtzS38btoqtISE#8m^~edu=~MSR^gI=h}G2P~rH=6sPv9A=LQ+x==Inhl6L}t&1<R{6T_JFqcyYx-*Fo6aY#<!-1q{8o>~TQzLc_br7`>a4fM!0KIO``6g{JR>7@A;AqRxDeWw~NSHABa5ZEGF<y&RR5Vqk*7Bqrs{RWmaL<3`^n0YGT~&-NPvudwajK2hR0kXBjCm)OJd@mS<;#>g(g><!?LPlY>MGU#_~#@mz|5B?^jJOQ#AuEFxC@f!!1LS-zys~7@@-{0FSA)-?c7>Qn34RY6X^qORZ2jz#X9nxBy100{K8V9b$wDG%{Hux|GOZw`>wJ2eMiS301Q|F-cN!|;^7@!8i^q8AeBc>f2JA?Jm|s%h9fmGUAXMggPmXl6h=Ob<vHz9q6!B#t??Z8Xg(Ro#+hm>j^yIh@+n``@6c_;og*wdvV9l_mfyV{p|&T(B!u7nx&!8(QbVr=%%Re%J~CjA+kiQ}9xyiym^JaMyQj!@26LDHdKRjH?MbZKM)MT2u-X2KoP~N3_5H;eG)z@wHw2^hY;*w^Jw8i%d(Hz#;_S@=I8bQNg54@NNR+%8?8rumaLPZv)`}{B_?w?R4W3w=R{N%BnP@W;x?Z)h(c;57q$oG}c7Po;C888^9a5B0cgOkA8{bP)V!17=`EV}%)99L||G|t!=GZuFV&kU96EEUnJp~i{!-y&-v}(bqQnBT*R8$W90TXa$C_6*h{hTc^GX*!DI<J}l6DqG=)$}h{Y5=K*2XHjok#;))j$F9l=b_*eYWn6jf@kw5?!U)++5DJO-{2<HtbL+kFYE(;zzbO+e<GIb)xRWOQO<K^>S)T%IYG4m5fO{q@jwV&GQ5e5Jh3JmtJFTHHK`&3TJwb1kN7h)IfiHu8du>vN2+^gO=U6gF+mK}NV15Yv(@6HqZ6|c3yvcGI5BF%L4vthox*%lNcY7UW!GG;l`>>2$N6N;ppp{>c)9s0Q#M!gJSUeYp@&TcIQmmuOCXvj!XE(iQ-YIUS#eidDw~9g?6H3i0tMfd`BxG>9&t1zwq^>y`mO+^P{J8)QGmR7r3aH*H%PqMBoTrW80Tj7WoSXlZ*iQ9_+&&0Y#Ox4=6eBjJil)6#y2IaO`n~(GSD`ftsY>HQ1Kk92J%YJ$~wjrB{%yEQ=iwCotWn#RhOl-63CK5_fQcUex`*7!yX`VV}RI1^K6;j*QMj%NMEbd{*6Fje2+wPHdHUb*=rb)1lgzgdYsj5o-=2Vm61{Xv@uUA+YkCjg$J4u;6xs+K=JuUw4OY~-7szDs@aJ&67kQb5!<}dfI5-VSiWoBfC6+XT4lSj=~V0St^O<0)lSi7daDJCakVX3oUe=Ofju)Iq;D71_3YGMHnK#QnvoCj%hEa{)pB5O)zV#DPtk~Vw<U|YA2pb#5q2m>df??EbqKZe!w0Gsq;XkCpn9uSN<Rw=rjxoVq*EDA+tc)jc$@1IdQ;o_v3|>3nrK#~31q+1>xJ}}Rdkk0${gJu={j=Lx|L;it6=16vlmqVjL*DZbZ=b>=HFbms$93<a=%mK_CH3FF|_}D_h72>0#4>TAl8`BS=^2op|z>L!72qLqs_k^jjj&B4+`{=XN;skPJ;#ciRjWY#UKlwB<4P&S1gP_x0qftaKHFe<GJVn6iKGPz=vbdsuA2Om7s(@6dFrdJ_Witd0AUPj9@Zk)%0Y7FJ;b>RIXH}%fz%lgI=z`Vs9tL+gUNF{c8cNH(ZGjOz~J5coyELp@hGUA~n+;LRq1jQSSfuMKpkfOo%qct@2B#Gg`SkKUWQ&VYdU|q1w<Cpbzwh6ns>64bVWcd6jEuHbpg(&p-<`D$|~pEe#nF@f_}WMkF2wDX}gJr%q^npn=c{p?Xh=)rSs&bE-0}<scwjc*MM2Lig4P2j;Ui63WXs5Ci8_Ne^;o7tOki|6R3|$MQIt^*BWcIk+c!L4v=HK(wXebt1B<JUD|HQy7)4wMCQQi(n<C&Y0omrvb>7GmDx8M|o2Lq=bMJRmI{L>WdM9iuk^A!A%sG{gEixo?}Y`GbtYJY^WnXfckb<g<57rnoEz=%t(tQc{zBkclQh=KC&R6iCb>zu=TPm59=~4552fkgZ;Gx|3{A4v-nfVs7x67L8<~Jkf~sb1U=4WT?<}9ggpb+K++alN+e`N>U3mL^)}+rq28;mg4~p!AB`xAvN=TIqEu*!=8w7wb|(jkG|<+(Y}vAnL#Q*JwU+BzpbKm(N19~zH)t+5rk3NW^4PHIpJXBBgv}xnPtxXQ<6&P-^#eRpirR#H?AZ?9(U-R;LoHFYq#Pb`)MZAf06*ibIm5bfr8v(XAyo*}ZyIez0oFDxCGf@PLG{yzdp^d*3Jbr67Dg}ayU7zWBN4RCYSnCrDdDtAf*V)S7V!^3pZ8ba63Qz7&({*>Z`;ix+|N|f@+?&)Y_^C=H#5g{k&*SrN3TCfc9vSeU8oaHtn}_^X2(;-JTjcclszaKm35V9W^}TuRn#amErQ>|t~aEx5qqPFDtlic5}aEt=wCFkW^E)qaZOjHwpMLfd7+ZyW;Ag>YfZ)aY6|z&8dkbc^&Gu7E3%F1yU94M-kUY6!d9(3%$~0slY<vxPU{bDG|>fMnqjJoka>(-o$m!WoL(NYiEmXq+d36Bsz{_o$1BwHx{}M1Nv*#Y)-nvglCiafT#~kW)w1fYFX5Fq){D!iGffM{ZV~Z{i`TDT88FTFPJ+IjuV%X5&lRySo9Tv?D3`B^g{#Q&7=Q4Ouc8+li=A-ZrdziRM8|M4lT+Z8>LlU4C#gu3sce!AF<|z-RoEa-khq&s`9VXvEo!9+4BkNO6cEWR6A!QeDE-eBwhWMi3=-QY^h_c|;n+bcRE)JOaFJhGrbkm8C@adtks?c;;G02t4hkEr2QtEnX0(^<6W2I7Y(|R>V(b^~cu@D7#Xlf6(hfJr3Au*hZ|{VpNCw`=B*P}2k8`z4?b|4I@<v!|VmQRTSHM<|d*qF^FoR^)!K*dG+lwbO%@1#+4S6DpZ<=T=Asm8)Ek>Y#t7B+nX$q6a#Mi|3Ag@(8g4^g1M<?~4vgm%k2X1K;clIBCD*aSU(<sfBu#mz1r;)+0rEZN3P6}A_79V_WtiI`v)XoL(H`Q+QZB}>#0dlXSWh>9MpeE7-;9Tjag8neTFk(16hiAXyhO^nY=aqiXWppA#{HXkDUh5|r=YjM5tuOBBKL#tZJP{>r5G(035+k4d^k_>hSdqLZ(~h9wRH@U6#K<QiGEk+IR7|vVl1t1H{6oh5*$jTjc4X!AfxPkxeGgSXD6q8zMqQK^A3pxTT4kz40q~2s{R5j#B{jZKVIe>>)QaEQA&Q)LbOUaX_M*hPm&tMvBa9Ow`Q1W>ml^Ry(<0SuTZ+<*VyrkBU}6lE@i$O~Nl69l3E0>iIKu*N;}7_1M7~Jg|K67$c*85B?)0UG+(+mye87tA=3skaMHUHFoJPR5%e2OkMnz%iqGs1--_tJ8^cQT5;h`gihQkaU9Y`?bWsDh6`NBszzQXd(O*nBT9KLN8hWIyd=cPpX$hG=jYObWmI_h%GkH8gBk`cDLwy3ysxk24$a<f?${#}Ateeh8RAQ>rrnfM2>=oE7Ys2e6<dqBb+NKsxsdz3lD9u5NFtI>nvRH_(%i4KM&Uwamn9ypz%DrZ0jJt={z(9(uB$Hh<|Re>)f3Y5kr8>&oi5Z-kyL_@ry>b%1$h7Pm(jk9R^;A$jkWk+=pn!WAQOs>4y)CSXZL?e`yTE>C@&EgRfn985)9m|%>jMX4yno={-jl;<Ri5Q_BI#hipIR?bNc$zO(B7>kzG}oIFim5~jE<XtK$gMBs((cK=&W`$Qum&-IaoIYKEbaw7{n#f<wh=TOU|ADOSEiEHnpsH8$h;wylL=JH1Kb>?M&5aiRBuuq=-1489Vu5ivq%B0)HpNZsv9(w4bU|PvQ3?_M$J&0y3h7&&(1_A5^1&bp8rKE$|u@$$Lh*iy_@K!&H}?<M(?&<*I#1vTSoc=cQ(=$B`T*hCl~T0#b<}HW~N4W)6xaKH(M+YBttHsu7i-30q}u5N!e<Xv7|9`c7)DTkf&io6!xxXI=_^=*q1HwsV7cQ{*l@-8520F<iVN*QGXR|c?v|3aH)L44pHU1uW|vNHDQYbF_W99k<8Z`$h5>ty_2Y+%I?$b1jjyYk|Qfr2Kc3|8F!$ZLD2N~*rZWWrtADjQIUqYHlVG5uW%{WqS<eJ#ipj^OYdKpnht_}bAVA|{6P87GGHH)4A$5L1<a(xZ`PM%B^rzPG|BQ9u<UYg-z6$_Phdi4k~KO-4*)7~%(U=6ZP;gB%x%W-JvJlEy@fugIHQhb=%K`=91jm<pHPvv9RL;+@(VUdokNFRf;29C!6y5OUG<q#e5qj3H+++cb!7FbCbrE|U`f)Whd~r>ZW-7)@rO=DH=1GiRni-1eCSeG9Dy-N=0w;qL-HZdwLB2ER*0_ZfSJ*^6et#9=9xykP-&YL8P{@|$~5I`jLVm(CW=t7dV`PLY?#TZj8u%$FBs$u#p0_9GV%t`6hA>g;pXz6l@-mfF|1_H4WMUI%q>r$rN#Ol#2@NOXRA|Z8)J@Me^?B6s_L{hVJcLfNW3;mM~+4v_SOMOMm>;(GH{i?*%oX^(tlYjC(;FnoY{H9>`K~k>%+?Y+LRZgO8?%46~aa=<Q!%BEo=KozJP0bI}4`RW>IaQQgw@$34d%k)vMm2$UIhGO54~9Y7EzD8^Wq>I<3^!sSuTB*SPPye-jDGj~)834;)ADYC`fvLf!*>hK8MQd*WxDk`SV%%g=X~YW1oBmdE7*E7OU0`n)HthN$KezyRjmV-zDu;jVt^fDJk>)g>x<px#=b0>AZM^{Be=y$ial6KAIf=|Na=JAD4&w7sdnTug7o)_abM{R2e_Ia_xRa`wi2G!Pfik*yoFLAiqe<8{&J9Rm>(3{d|+D1PL_QzFU(Rf?fi%%b{EM$We2HO9p+c@r*=#2SHY2(VR%S>9F@f02G%0Q6;7s~8mOA^77cu!^5lQQ`$IStN=9+zeri1mt>BJES0O`U_}is4Rsp7JKH}o3u|RXAKG@P@H0;@uMj=?wM%<<SZLfLjy|01%VAbMRDZs>h=&Y;kBekrKe{qN$upGmzkxd0UGy;{X9Smd+~Nm^pNYUCgfUrmYPKrpWcY}5gu~STID2DV40x{{l-&jRrzfwTRY+6_n~H^<)Z%iPfHS8lqW7Nc#Ifu_kerPR-jv}p^dQ&n4~n8;g<tA*--w=hpo3vS*wnVQ*pm?D(+$KcgtaDodym-Ka}sk^!WM2t6r{0U()f$1l_v{M3|M6kegS4#ZRV8G#L_MamUo60@Baz;v0h?7obOjhyeun=Re8R3A=ocsQ?YM-Vd4Y$l8U9CNaokV0(23R~vIowR`mAYH5oRTwhadgZ~k8a^^*?I)~HZ*<;OnP}fdxUfK>Efb!5^N_tH!ENs4yD09SCYcOVygUY2N+V~HY-|A)3bjI`AOEHuR{_pEWJ&ky??BkUDR5rN7<39btr%Ol*%;4jlZ*Gg$vBse)##@d^ThY2|lhw0uxPKv9*NJm}rC4|QbT@VRVo@l6m+|XdEEEZ;VXWW867HE+UAt0|?CFR_c|a4Agr~ZPo}J|CSZG3Ytm#4(jVnj2aVuIkye?XozqVS&bXCjv{h#VV80VRa>&8{_s{dfIm?LUiFK$%7(zrTRmq)^tQhd`F&C3Ad#mz6X^9~bplNkhY&!+)3_Xu#E5&%lGmz9*nfS&7mx%oSluz+C+Q`HX*U41&Z%wnG3**!;muthJeT+np4F_`yjmOUlh%VenXz{!6jRjj{sZK?8}&P)5nPvuOYjUUkW1#1`Ljz~eyezt87X0?4z5Q2h?D2mQy1=<D9+$To-gmRF+Q+5uCz%hvT7moK_Qzcdw2%KufNwHZ}NMC`_ILuIbMhi<(3jqnzr78FAET*2rJ%t#kXG@=1Pz=iW94G{Fo?YqYk_}PRi5PHnLTD%i**~ywNANSc(K{!vC@-tkk)@x;O-y*PlyC+XbkMT_fmNn#ka2_pgvG!AX)(cj?4W$xz)+`T(#w>4|6<4ypZ->SK=*+%RgOubK3|Xb++f|9JBACsG2^*@^dsy*IC$VyhVehg3Y6Q%iQF)r>o#<PuJ!T79Q%UoSQ++~(a3Sl0y8O5ZRXw-+U^@KCI7m?-v0$)jLuKKy<;7@-0&Y5VwG}W<Qv3r+=o1bd~(d_gotK@vG;TJ#C)n#=u~&4=7|I?a}JkBqwkirG#?BgD-Cj0gcWWd1F1ZFFFOTgIO3flygaaz!|Iy&h}{JfohXLW$wF2jaRH4g+xxDsOxkjGM=w(DBrF@hz1hngF9=_6x!IW@_o<#2$$fbC58MNNPEn%Sv(2jJ_+R*PqpQ*A;_wJx`vAKhUAAxy6i<6)Xyq3}t5Ov=wvOX*W9Zn|(d9{|DMKqmVV43nhncAnB*CFl)RAGhn)bU&Rm(LJM|J2oKjs<(%iMk_ZdeD6S6BM5iW|CBlsE_AoLf2z4r^CA+zJs+AMj1Z0NW`h1m5n#ThZ<8uSa5j`bxjeY%E6UCmtCYHuT@%ilNF$e?+X^W7bC%SS>M9Lv4U%;qR)qZdt)fKxl}<mgEiSdMbT(`EM@Nz<-{C!9nGApWdr>#VT!CSr6pKk%4ubWaCkl>;~4%%Vr~H--(KWl9(RT0x`C42_}t8L2=$tQuk0^3NS|;TY5-ITs0Vn|LD?b0Q;li>ewv>6w}5`$;3QDWfmTx?ULmDiy!Ff#>EGZo<Y(Oj#zZGuQ=$b+IvY0HTIeTumI~|%Ft_0v|n$kRi20>b{}|w*`jF%ZlkYe&7h=<nrBq#;;d**9y4p{srK(!f!Oh`vK&iNH78ryK+-_~p5_1YTX?(V-^VT9PUbTeayPw%+|9kh8FhzBI|@KP$=pnV3R|x#uLx<^yBsQ>sUpwz{0AqOsRFjx%Nh9Zq<_vN5cORuUv@~K9bI5tU%k|VzH1=tR{(douFahpQr_5|oMI4(FpK;{L9b(@oZ3z8-0Rr*wuH5@qa+{M!2-8a#`SuQRuY~8cx}a^MZdhx|N2w`<)IcXt7?qdoW|MJWBzCMnz0&?3WTRlT6o2JCiwYJk@arA6Dp};LG#wKbwxB+*x6!sxq4@X@T>Nh*NDCPsgc#Ms|y=UCDKr|D_cgBwNzJD$Gq}=)n!?1KzZHG9TJkCc1dgH*c(Xkh2iFG-+A>aJeOVPxu*;gLv$Oz&U#r)M5mgQk~r_|2vr#j%l_3{n<ZfkN@m0#%WjC|L%Fyd$<u%2eh)>D=3jJAq>u_3g7(o5sz$BVP7xtBUMUOKuaY-%;G)8vNyG)b{$MfC5Nu{_4?&wDXhZ4{&X3ljD__^I8iC>-DbiAowO0rgL41}FngYA(XcDM0%mBUwVF%Oq>}-;yB?(HF?uip<cThkHZg`^a{B&X#kllNtfWm<RXvd9Drf#Jp$MNjBXY8Mg1j#SQyYlp@S&SJ@p1;!`-MT>+?Kf{2T%4ifK;lab-v@glgR_Qf52zjtE{HI?CtxD@&&hX4pHUgO{CsgwEa{r3%mv#VorS*go#{nJkhdUjAZVZ$Li=1D8xQVWr$2?z7lDs}nUE!on#+mTKvx|!pmS~e8bkDv=qlAwLHBgbPO)b)4kHY^ldH$(y(!_MIWd~|O$eXS(i1n$o#)EB(2{p{S5>T%p^VIeWa81E2mvKsCH!P*`#!*XAeDuwvmPX4PMU3&e5@=SV`5~>VD3<X(OMzJA5~N8!nIn!!U28Tz4*vvz%`j1lS*WHNSNx8&Z7e4#pgeuO~WNRLrh+6ppw_Mdo}Qx`UIFo^mMaTJ9yx8oY?}NKz=51r;1WP%m9=G;G|k}fPtCyoR?U2OL=JlO?I;)d1oFJCCkaMR>CpFGbxyyKuQELPA*-_`s|J;MYLwBnX24s`xiegFS$cZgC09AZaNy!$C5q|=34tARHhDn2Se$-{52C)6aW{pXt{<*<0}mSa;WDxIls(2THxm|k?Lns;F=Kk^n&6<IX+aXf1+kq8M)mHEr1zHZ2*1haPd_?*PX0iaj$w>pNflB;-)?eaf~LgTwNzl)&2Ur{(~>yGuZhd{Ne5y3^ohxCRmK;S9%6z1K1ij{uEKe&T1F{srpL8pbICC<W>!Xd(P8;?Z(91BJ!Kfhr%uMp)(qmh%IqKdq-W87@n%%7kE18=V1!J_XY+Hu=WJ;{>}h9T8s0_Q2WRdxxa%ks}bz2@z4F=)2C5WviXdKhX>0-l^>99Ox~PHf7=ZDpz3eAMzDh9AgL5xHGgra=1WuwaEo&@lkBq?_$tqE)w+`@JQDUxorcj9eJ}xn>}E40?7U2*2XiTb6<eBZG7i;s=`)_)z1Oa=)co<cGK>|4VCo1P>nhcM0{_m;D>5WsSUpR5Z#42yZQB>e`(R#$i=BJpyIEvF>uQy~^zs0xnf}E4JCWSnneK_yFXR@$h@`Fj0r@==9;z^@>idV3YJe737Wa-tD<-`FZlsNaq6L%2?65s|H6UFdFw52UbH&N<SEhNfeoAfxp&Dv$18R-o;8g%t!Et3du<^9Nc1N$a1m+c4e+>p7h;Am=)B~P>sK(`@K`ES*vV<;mO=Z0I^GB}OK&#g|zK$yz&ioqOjnj!+F3-|$U+plizB;Zf?l(VdU(M5A!^i~HLt1^2rA^oGEZ=*z@l47!w$wsv+H#$ODeSKDPP<TH86BJBtP+5WQvv^Ft3f#bAAW2gAbXB7e820gk)SeVL#kvT^yUJ{=k<C-5KK=*oz*DelTHi0vM{xXawflBk^=SKMq82=xcH~Hv0;jU$PBaLrN<&zzV1xE=`PDK3h~yyp->+)wpJLZ2A?`lG?N)v^<Aw>$D=_|=Zb!=W~-Q&xkyd_4$`xdcl`;>Q|ALO=EY5Intq5WdaU`<5KT>_XF<I=IF<8yDw>Z6pn#4LUZKtBj%vn?rqO#MwCnJo3SemVMrfU!Rr;n{<LgRFb_c<dj>ywqfF7c9&k0M(c_$h=Kz+u#)s~zkliXL%1T#|wx<u~OFGmoD{of&R8p~g8{{WA4zG?(;hb-y_<(7ar2DEVEBlbD{A6FP8e|F7>X!9exVUfMB@+_7Z**~%A$HqNdZL;|Q(r}-U;i|p9>r4%(BoVZtOu!Mrg|vkBksS8u%|H;o<RzOvB|mhMsRsA^NZ)cQm>2`R1ii<hV*3)aRYGN{a2@vaT`l=sqX=RQcI~;|rBn+BGB&T1)sR{GVujIcjR|U8SZba>BhP|mjzoHi@gpp>VU?X=20~xJS5{FB$yqN47iJscXEW50Yl`8se6{R|m1fFv0SwZ}b1UDD0Tav3a&p#T(bDk5Dq`d+?B#2+r3s3#r$qqGsL+jaZ&%W|7G*@74(!RvYLe1X{O{aMp8xD4)V0KUcuAPg1QHHlOhpL)q4EfwG^%48Lp~Zko?*UK`eStqEB~6Y^5Loa*T-9A_#O)~(4!I0eW;(6MV3OYlvK7=3k+#TB13+t62v4p+D$a~=Qa(R>oRZSF}2>P>38L?gpZa($*nsY|J;Q~)<B!3O4Yuo43@;+Q;&0@i-X*3VTFk0{dko{ZQGkpRZff*zw<4{JBL5{X*nn1mAE+>ZRUM=9oeCT6NPXloLt))bQr?WvZP5|cdkf^;YmU+fWw30b#D%M@9u%g%xoe4!Xs;5yff!Vr70Z7k4^@>Q%RWMCV_$n<WBa~KxVH1GbhqDE=LHSLx7W_o2Uj4@t>WWdYAv!r(KWl@VU%{IT1W}yCuj`zZm4Il$Y5Lgl{eTf#txVVC6`9sm(yBhu!M7huUfnSUuiaZl@LNkrg%=;Zpyn><-8!&W-ov+y*rOckW20{aKCmJu;WEHj=A&FuGdt3bR!4D{7ZRZf9^^ZOKTgR944dFT3$if66^XH>zBTCdqD)Rw-S*jaPM))9RTX5bfx(?g#YEgWUD1a$`TsNF3K$JoEac_egQL(~M1Gg7<_+_80E()GE0}RgkG~dFP40p1I8L0+8tkdcCP(h;Z(LSY&i0_h^~F$0`Rm>PYPTJ?Cs<l`@uN=YM;F`uvEcw)YG<jsO|Y_KuUZ9*=3Dvt~Y(<u<W&tF9!)5gwVnYso-pf(JCn6_MSurmZ%Zl-`<%2r3KPz~U=lhaTrdDWbAg_)*9ol?QjG^fpn4q&iDNPZbDeYPW*I)^S4Vm4l&PyO(1vH=ekw@};>}0~83|%R-Yn@$qDz6^_3==-<Kejza}@nYr9WIxS^a2M&y25+zi-Ak4db5&2-3#Gcn#B4ZTv=d>R?I7QuCAAuI5*?jAfyY{4q<#3j&t&kDF{^e^`2Pe~5h_$m;rQEssLshQo{YACJ+Yna*7PyYJor8*>_opqywaHvhJ`UwtZuRt=pEln=k~~m}x?TSUvhfA1kv>N&4m^00YbdKt`DLCy+`xZaLmBHOWRx1znPr(1I-c!7rdU$%Fq9j9p};j&K2ah#d*i+H(t>OW-%hLsuB@5|VHy#F>e3R#IuNKuvDub2?zpokRgw7#$O0nX8Us?5xutAgjts^vEn2+c*S`hqO}+-+pz8f9tnC&|BrM3b+<pKlvPR%w(aoe^9f5v2I_8Xb${gJ>LgN5GlwSi@6Z}k}ucI0Z=lZGRN*IL|hdr~M^7ipRUyvVv%uT{MeW96;$dAsCP?ihI+H$l4L86L>TDrJS12uUDSn!#}(4MR$LXj1AqnuT)N~GnZqXr$J7~=0w?8b<?6)SgR5F*4?xqtvy*-@69pk<a7A{uol7}iDLl4!FjPh_HNfn)u6Cnpy)x*C&CrKfHKx2jCwY=AW_)&k7s66NxESX;>lJy;bv>96I3qq>0JeBq@OM6q@L)pt)(dQ@3uU}A5=Kp@41`ugSVfBTao>EsXO*Wyc#FI?SUBBj^!$-0L_H^{k%Gpq|W=H8B5{Q<bs6%d{vnM;SRfu`Yy&+$;a+i_;d3_=oo;mcGy5#^Cczp+wGnPp3AnBaa=mTM7OEmHg2=8IdN!XGl&cw(*}h{%n6WRp4KB4ymu{B*GDuuLFwqlZ`(YH)<}DV2fQXw_y@5{Ybs*&q+>Fq3xz69BG87U=C6NVGhRDVSu3ucC_bsz#28Re16>FdV^ax+6^vUI(oNtyHL|#9^mr4#QbQM3h+?pvW5wFp)2QC)6G8N(M;nI)1gm;C3ut@N}Y1he{8T$Jt5faEA#yGORYiv~rqlndq=hU%v~%X%J|+zOHGItJhp#vxQ9cS}}f9pD)=4Rj&6(?jO0|!HfdAV1{MG9WUHHi<6;FMf*rmt}?G69;B@UK!o5>0lf=uS-Gi0$EV#@TV!a}M>!_I>ol{uFKRfe7r6L4*1y`QR_ji^6G`LmtvXA&&x&QBC}x={M;5~OLlWT0c1zVjm2yXZwe2cO!>4|GQu~a}n;_+LZyJN!vUC&&)a0Pp?j=wG*mGpUcGy;vV53xWM)UV33<gs}k}(^q#gaS<Tmoeuis2^XUc;oJ3`d`7^-?65=;uA7*=v@{)m=;?QBExjU)hhsk3=)>Eg?!wG6w(@RRuZz$x)A*BAsRbaj3Fk<sAM?n;pMXCet;BjjcfToXU0TeidY!%a5r^-a=^qZ15D=q$5`oh?7T3w8~aZz*;_H^kF5-R~z6WAuKF^-8oZG&h|e3`A$wlo?k&o59Ml-Q3MG{EN|Z1SHP|a$8R4`BkUnAVcB7(;AJ;o-Hek$z(C*=>)f|r151<UURSl}a_y+$A90s^Az8@6jl6gGMjb8DB~N8rkYTZt=}xs@L$_m)9YjCRvl`qlJGIP=fll!f)6|<iMOGyANH7terKBgSBt7W%HmL#<MWyVx;03><`c>5lUL(kAcToT3YG=KrpI3MnAun;QhzIIPZKkNK=FL;H_V{Lg`rMx~9WM0@405<qa+5x4z`rUXh%=&jNNDEfQ8xY7U?hDfy;1$DlWq8ADajK%bQLuscV&aZ$Evw9R38$~CUP~1ej&LVShgXty_#&tI!V)Wx|aWXQ&aU=8-ooR#d{@k!|lONVw{!KRP?r-A<N!oc7Co>fQc$lEiuo_Et}1zQN{ADT*V!J>KfUL^H@=^!fuoP8sg#+T^|EM@=WN>xbw?5G~QyP*wwj77SxHeDx*dqKH#afK}pKXh_rW;UKEb8k#=>eXBwHxmvcN-UIYgj96<iJr62Mma-#0*O{1AnY_}lYkwI}&8|nM1;=ig?r;1W$L{e5U1PUpb!%ewwLMKqQN1*O7E8c4llQeyLS>RA5y7Hswk%+27G|2`Y$*yWe)6jxO4)c-l>F9!iu?3$`K=Aogzq-za*i0-htkAALyv#p{7S!VtX`WJ_jF3$_8JdW_B8YKDaihu6h1J2cZwA(x5G0+nC+3|<#gDoFR6jy1r7o=Q%Yy474skvztF5D1q_tbE<F0BNmsgmi&_l3WQZL0l%aR@HloS7P>*^rn6;X&)f4F-8XTN^AUw?KzzwTduc7=a-g@1O1fA;IouJD)nHGDO{hA;8){3(CUU&~?tw7-5sA;ixf)Nk<G=CAI%@;}ShHhl7D^H1@;>7UgL8~ji8Yxs(O%^&?MiED;()vxQL(y#Mh{U`jo`PqNe&nX*n@uOeet&hxax=-6-xc!>4Re!ADNSP_q86L#;uD{kF>OW`YlX#1zyQ2EyE6|dp-dmQ@Ks5h}UKM6Z12@(jprn}{Mp&p3W-em&NW*$Y6Y#8FMq>EM22RvNSxxX`<jt`u6sy=`H1z7SnN=q@?}#emqA>_#sN$Q^esy{Ip^87QKJGu|*VSizu9ns7!}Ht2iw10sMCjf;qvcnbq6|(vI7xQmhn=s?VyTz<<?{OFQpZ}MUfv1yo%&s-gW>Ipt&hPjOSFH!D%`nX$A9x`s1d##{N?}x&c)9}g3Y1ceCO2-!g4OF+b71z^~DSyddICFfQ1jP?}}?fGcS6B74=1;aH$@f)#=Roo9|ftkz%BAJ_R?wW3SwDbvnzNdS#jZ#`}7$H|t~n%0A2OjX!F)JZ3$Xw@xRxDiwQun)=}6-ag>v@%U2bYaf68a=F_d4=>O019#2a-rnBe>Qd;RlhJYgbv9s8BZ@*^Ugu&zM0fQ>tuNFYZ*C4XeBe-*C-9Yf`cqzqH~#v858is5QnaOHzHaLDUSGOfSLx+DVSN_<)(>I%A*_(;_<4ieeg76eam5^+y@x~3&V4ht8n+@S&Pb)RGp47<>NH5}fWEvFgcn3NyYmEt`-M*5S1ES%KS*lNweLc&+R(OcX;7M|vRNn$wr&Eik;xWl2*C)H$&vJZXFv?OA_B)EkK;UFB<o2<s)hi^>J9cFdHl*sBk{x-h;%#X*<3Rb+N9p)+}>J|*US~G&erL5VqI1EsODVU|043?O^9XwIhs6LSPX2v$nJA1KFr5o%_d$@{CrryQxAR?U-6Zox7x<2h;RICPiu|NHs@PyrE;nxXmcs_SGDeAw=f4q*uXYJT!@FuY0e4}^IA%ti*`sv2wS~jmVb5&*D}^~zovF*d&1<ZU>yw|Rt{Ky#r-WmoPBs-VQKGe3_Y1<5b0iR8haROOP-`B_9M%U9Ml9C4z6kBM`8<gS4QU~z$NJmqV;=#BZF`cGQi<*$pl?NNqw|dZAbg6+*v0)$NDDi#}3*knC-aH)p+To+LYO6>_T+_&()%fqiPN%CU#4WF&wcg%@Wh>l-t<xC;%BU$Y*$p8{0$I)OR9aRREwT|Gi)?yWMGZI-Hl<#)3W_Z5tO!sPvaU*$XK7p<NjP?R{K?bl>m-!UgXHBWM=!T)A!y)X<Pf$pKh3|KyEl0=1=An4JPT83I<8=@FluX!G)_3|%&)!m&($J6Ek_=&{8|ro^4+78(%c#Hpz3#}it`_mq2TD`Kke0#u&`vQ0qFlnE3de>It-{OIsJiYId-R^RV%d!GVzrGDirV7_bl5ZWPC3ViP?>ube=Cq>CTnTUxE)w))bRd%+|jwfXPp^_M>=8WM=;c5L}B}Z%BrX8;?tgCMV8a9EB#AjXe-ei*%+uQQH4O3HL#Y$;!`bb9Gz=xH0<l+>$GC-_UdeO`j`*gvu1(T-GZac~I1j1_1ThGT=nA+FkRqEqc1JTV#X3F+L!4?Rv3#Rd|sd;_PH|CEUhIkM(Pe&WBk9K)y;~ly1=ymUAkLS9Mui54EViA{b3|HS6HW%mRw}&|YZ0F^}qQ-EOhJV9kb3^JkCy~wFk1OofB75c*VXX=oqPh!XfIkb0Xc@yl0QWQZk_90~1!}@++PVCco*tbHFu#BhDApL@(C_5qi$9e#ez=ph2QFwCKkqR4$J5zS6c7p>D1tml;Q$w`4e{v?wl4kx8P|~F@r<vy<Hg?d@fpi(^I5z*``(Hs0=cF#TkPq;lM}#gU+gUawA<A(XdvmgJX7DHY8Rq|2T61X*~fVl>F}vN!%cvFj#ysH5>eLH&yN5O4um-hf+_1P0#y`TK+YroncEU8-xZ=0j)sP)l!xa7)}AvC-+y24yc5!0;R2>ve5Vvk?rdhJ>K1Ay-Gj@<Tco8$nVs%PHvs`O<ww#s1&tzeu)DWuM3tQGF`Pk{jRSMucryH%;T8F?$Z@oLFtMfKAsO_)e8mM0mdTmWd4kFeP)GSOW<k&%6p97WqcGFrPcc1WBF!{Y>MT|RQ8xehCDt)F73lcSd3rTf7*ItyPBPJml(;6=9${0iP(?|?FxDA4k;fq=q0n|b!(jzqB*RcfIN2HK&D>HPI1xZarLE8h`8l3@mP2(l(~&Q!;R!>H?S*iXXH<FQLj{NWIQyuXub6HlKHF-Fu!5ow^8wJ{j1##<n8E6l5?2vP+)H$?PDvqFX+2Ibtwqp`QmBNEubB9z#1bVH6HSpZtP~ELsQ8#V%v<4<RAn7gHF2v}M9aFsVs6b@%ooo7L|5mqD(N|mhTyAPcw6@nmYI3MD0=T#8Gl?#mCn~Wp2tmE2p`b}h!}!WM_(7#dYttu(z1-sZ|YGSk$0Prq^iT4&&C+$8|Q<s_I-9YL4*jbfI2Z;Rymiwruk!FCA+ofkClbimqP2vjdb74i~I78XUrc81Da~$xzwnBVsZgx9(njcSlrWN42;Gnuu^5^1|bX*!(xey;TMT(^H5^njzCJXlqOQbz|Zwy+{^2vCqK7LwZpVh1@`7gR5tEL89*6Dw}g@tp{h_UsTgFq+$E+k3jqvQSE9TaR{=I<y9x@<4PrfzNk-bYB_{}RndBZKF#J8k<*|geun|VKrDYuEfrm1WgwLrG*w7zU?VpKsn{p&$m19QaeFW~+?rvt>{1c=eKjLEX&Ug1JricJ*@(j4r4ZXzHPL#y7LM-J(27B55!8|CDG8}=WkKTZy`2ceLffwL2o)ES?1}&A~#>>+SzIJFUB#~AIEHE8siVOQRU4*`ZGQw0Tx*bjPx?ZSN+I|24O`tOqyCH(X4xHuy^%_P^exi;eS4QYSG79ir=TDRwE=LA%YpdCk+$IRXLNdcsIHZe?atq!(%@X=y=f;vq&B{YnFYaX*^fx|=<?zMI>{62G<!=14$R}VPbZw1?lc^`3-5hn6Ro#o1BT50})Q1(qmD8i>E>p%c*IABhoSshfhzII1NGeP#_F!^VzP=vko=m&hPf)zTitn_asTI_+6w6^>v+??x<!NijQ*9z=dt~ixZ@G9{dO^6KY2kM89ZvJ|r7j~gIXkL>Uva#nH?}@oKH6_jDryg$fBw^r?dKUP4!BLnRiQEPjzK&kH8dNe{s%L>2GxLQY;6#^aU;r(pG=0j9L2!r47+W7AFDE1gp2^g8Zg5bYD$N7<Brz@nw5jf2#iamAiN^6`05hgYx#xXKD<V#jqg<3MXFq{jb>}PEYY@|EEfeA>V&1$zhKb&MGr<?C!7nU<Yz^z^4!7_Be-(*%>|t7G8LBFTc(Dw!F-EznLu+c2VX81R94Cv{B>OTKLVHKOtm=tJAh&bKz>8<pi3eF#C5y!Yee*B!k%UKST-{^NR?dLoXL2XL<QfMjCaR^4N3&%^2sG}XU4dh%WtNsCeI=58K>_P3q=DCTEcR05v%^WP#*9KdO093_I~G0%QMpg0hertlGp?F=H59T>OG#^WAHXU?;+AaDOpQhTgD8Kt(0U20<W+?a|PpR_ADu<dpHH+^uf7?3?TF&m_4M9g=9$_sKUun;U#>lh|^+kzP7fWrw$bDsJKd%#Q)Eh=lAfS{J`=|9wca0iK?Ux>w}N}nRo1Y@Xtt%a8S>F^(wg^O3g|*A&z<<=k#0_^2p9)TRu*6i=cX9c;5WOO!$n|EM}gBc(Bt8Rgh=a_Mv`I-cPJ`c~j|?H>AY*%l1%GT^*z@mbKp%5Xb|eq!c^EpF0-ApS>(=d^g7j%A&f^rl8RMm~bDSsYucC@Nhr(HhCL41f&bAneSxAWQ})zBNdUJX+3%1pC(>0XyWoyQeSzl7M}yn(90ZDVhHXBU)pjZXi=Jiar85_8CyDt*fzEkdtUNXlcrF=QP*nTtRBO&8C}7;y(Ejd>TAk=MX;0$D84Tpk8n}X?#k%u8?-z6x7_bk8vP&DlvFt>-z6P2r%c_dX6=KJ;B$xszp;xAGjB3(f>`pL_PaB)jYOIeH&fBLtk3%$b_jXXKx%$2d3~BR^MmWkjiDg!&vb5_W>yO%RQxoUcyXh7`Xc@3G_|NrHl5f@X?lm6NXHo)6VoG=VJw{TWrW2B+8dx;euw+9J{la45Fv8nE3^6>u$O4+^npoXQYpJUJx`hr^zea5&q;xgOJh&l^`wx=gT|zXnhM0FZ_Eqaex4eFrUP8>?dv>2U|uYvu`J8bq4Q?r`_?o;#g1+kM0j(K=&$Dpn;-^G5V;QfIzceb>%vY`1NsT!7|f%*-OLeDve>BVQ_O6dNq{yKOFj`h+Kjc;Q`Tl%F5m}PGrToZT*~!s7$-qvJ&e`=d*IdRczy199m=zk)ok&&@`@w8tnY%RHeDZa7qRovWBM?jU|j>=oI#*Dl@3rSAuZE9oZfRP+1NO(=aCNC$0=^y@?aE3PHJrC)__%nz5(ARJZyh)6JlPRhC-ya!C8Z5L~xm(<S7qMr>z15gh`T2UH~Y25nqPd*KWvOn{X?jq^(~|8d-v|r)t`+*@5BLG?~G<e*l#^$O`3wc05&)Jg2Jw9=U+ugoC!_l&)e&%0L9w-sT8$`$}<!I6(#}ajXl;7*r^*Fc&L*-n()gD&OAsFt%rHq09}?|1plc@2c-JPcS}yY_})SKxN(Sk#$N~5i=9KY*;c{b$b@J>#T0e=t|<pnMz!pc}sLsRan{}wfxAuwrTt#P8_YMpRSreD(7=oi(GMi^)I?ZKGynxs)kD!2nD^cs$ebMq_pb5Z1#Dp<&w6o`}M}jTr_+=U-W;pWwY(cywX|H6<&XPSbh6~C%bA!-8|+EaG?62ho!^jw}Oz{&#u~H$=?!+Uhcv|1WhZ!;2G|=I_tG6^U}uIHonX${l)3{r6yPRzdE)VT6a~Xw0CruO{3cT7vtMXh0e;q(Ej{8NC3)w^s9KNM-<**eHv38E=@XjBuF1IL`)KhlAQTq0zg`ZfUun)IA=1$<s)Z9m}hTQ54a+ZIJ$Q;317!`N2M7KHH~vVaTUc<??b!(NcDr4!-X!xY$~+(^?5%!H4XK3aen$%_i%nvVil0bJCLz5gL!Lfd5F%1$*y0BhL7!~8av;m4ucpYUM_faf{IjV9i$2{vL_P6a`v(2anenUIfRuWplI;8>nD}q%`a;wLiS`iX)-xJn~~XY3*LNappf~ywvMPIte!~zBkYDqwZN~sArb8lWDezOwh3^83cE@s@M@3!j;9Xz@ZJQbu;mdY(W~xkL&QtwH490IGEKNPANo3!sIUcYcc1`ptPnw2*r`8>JKo@gQ=@K$yu#_ttuDT4CfGb<N)dSj4_{$ys_htoRjrZSgEWM;UCxy#x>~n{WEj-WCN+rzn+idNc$r1IIXqPXDovMF>eu?)LL@cnm=I%94ykEs|F<Td%Os_CK(BluK$C9nYb=rr^E5HfW7cKx6abrjkaU8HH#Z3bZ5a8;ClP0iHm0VJW%VlY7XkDfOjzIRo>A#(w%45ScDu35#BAND=x4w+k7T3kZVzfLNShW!`RbPHz-n+HaNZ%@j>hMYHTSPb<W^!jF@~xQX<`&1{B4^Me+i0F)1!xbW?yH+o{hoac4e-4LWnbHDm)`zL+A2|<rs<x#XEC@K&1)gQdHYNca*uLH%x|hg@0ehr|fndo@pG{9o<l2U9UOIn{)k$Nh$J~)GDGsm2j!4))X~%v%aF&(-BSJ*{AATH!pKaWt=VKfvOm)A1dXX>%>d9igzgo4eQ!)o6H!2GSyfNLZf+YDFe^7aDl$Yk^>w#cpXN0v>b!TIQBMTZ_8ylp`J}PI}Gl>QS)%=si}C3yMS)N$z)OeuY5IeVg&}(X^U}Ud;#A{H8%`Z6lz8Y1q%&wvWSv4GOK`b9pKpgwdgVnsIY=d`V~4PT>(4hSW*g7eicimtx(D;HcS?HT5EX~QSz{ju3~-|iwi|r!kSH>svsq-yek&tidFdOUxsoOg2`@=;Q{S@>k)@n!qquoyp1sm{uOl5Dnwm}nQ<MxZoMdKj46RJg#mtr*O{ZXE2xcsEfCgac^L*Son!A`;D=sh1Ad*e)p+&|gxT_(Y{uoSz<dUNh1HQP?j6?~zw%mk`|q2>@gIc(_w<AoWp9m^RA$>=rEA$TVC}=9OnbsiGsM9BQMyKfB{`s1fF?Y6;Z3qoq-rW1gLZX+z9Eg(o}dH<#kZq{t0sKIN#misPZzwd<u(^zdkfUEcg6_GcXB|WTN`Ka&P+zJ|4Ci8d;5sl`w;4Kl!)a$nvG_P#|B?l%^4c~x^gAL)N|(z1<R&~9?AUspA0aihAq{_*i946^k7kyVNCZ<=%yDiQ%+u23bzEC_5_<kYdlp^N-nV0Hik$ryh1lf(;bv&uXSz{VWw2ZHf!;hN|nNx`m(4CW?Ds8A*4yA^PakmXDXe0{}2sVs-e*z+*z&(o<`z$3UC)tZ(>0w-n0!L{SXX3wZC!*pT2Q>@W211Z+rMsw|#nf+cQFgX%RN&onHwX_rynB-TaQaQ@Z)-&6}S$H{XQ2b@SObMaonDbmQhzBXI{oZ?DR&Jq0LN>OtTvFh2_!18jK^=Gx;M&q8ZAd}ubc$8YCZ_>(q~KD(zA+nD!ILd~-T=MPtNX;RAxGvv6JqXwqaT(W#rnlX#+4s@y^*j;EC2oe)_76=kNomq!u1_Qa!v(3^Mcs7Q+1KPt~6Q%=Q*vs>nB?X+O3zzZ8{^yAg2#rVa@eA}6fv`V8AZ&_tT6XDt#~{1R_b13I>qNRcgX04{O52a)PP(l={bZp(eD`%b5-ND-&p?0ZFZ8r{;BKJ&=i)_c0-mkuu6hK7Z~)E1=f`j)Uk4fe+0TN+4RK*Tj4Cm?m?WtS#~q%SC<(Iih@8R`UD&JhIXES7vYeoGrt|KoM+zm!J9DybodGC?-8l0Az}LXz%lyfypfA|HzhlnC;;Fgqw)a5?&@%+QyNfNV&2H%Y&n1aE<4Dkvpf}Da1lbsY{f|b7-8_8%#V5;pN7LQQG<R>>Dyi;Gta<ES%s)^Zr?Pjlo;!ey6jn!_ffC>4=P?3ku-5lJQr|nqS3TgPW|#zfmIHWMb@F*d<vT1g$zhkEt=^HLaG}W$fCLa<msL2<s7cmKybKgsA62uUcrRln_*vo2aBiran8JB)Xs?6xNTV^1OW=|_zhWli96eE}?SSOGC1SMytGFS*`Vlrf<@GaQ=_Ir$J{qQi6I?A1&hN`?P#)(Ix$8MXY`Ujzan62d(J#vOn4-Us2R7Cd(qMF%CYPvJdterCbG*#piOgb#PX7n`S?w8jp%@06AzEkzR>F8)j~T}^!0bu7jgEeaxb~`Ml^_820Rv2ZG7s`S`Tf+PMcJfj@TKJ}_9LeABh@ugJ{j1W%QzTS(Ha?+wn#4l$0%V<heZ!iizY}_5bFQ19<YrYlkVl4gwg`ocZV?-MQ{IepSo1@B#`-n1vG*Jq$dW~Bl~fBF+vV2;d|T)F@LHwsY_*6S#-j^)oJp1Efwz5CrX8vXY`5vj+XksO(&O1*tGR*+>T8cBpZ&!+qVQn$Wj-T4Z1h9m#u#I;7az`w=6q#;W%=(@&5Urd^~7W4e0nI8bT<M0oI6N4_nV_P~x9TOG43!xJbd=XL8HRuI|Z^M=#TX%=t_xC`ltRbIb1$Hbp3rpO@pZL77nZx$Fm4M;%eokNi|Rp<hf)A}(aFT}}Rb9v3^uS`aL6UN_jV{rAz_DOXNyIqdd5_t43XyJDluS@ag{qPNG10fr;<VLuWv^C#veFEM3UC6aF@RfGW(duCqw%*y=8MlJTha$0#jp9zI{rguc-eny5s2%_##WGK5;P*g_e#juHy{a>tX+8cr;tH*uq{y@{edmSd-F-%Ig!laA|<WiH(@rbphJlq!=0CrUD7!?#HQ;R)4;UiOxg-#7l^mJ$Z#*QZ)FKOcTREkgM1Hc>|VQ3}zY3VClX5EQ6Y9yF@9En-)$r0Qcm#*Wp*&mD~$>7)GgAy7MM}}ErVo(xfq0>Ub8$U<;RBB{Sh&P*HHE$`5clLA2|G>uHXDn}h2>;P{ESyo_zx#}s?Uw6Cm66C=z>WmU17?Zw2B1bmga>>_Zo<A$8p*8D0`NsgF#x{6T|r^A%xs5-6#@dXlF8eW@Vx`{dRQP`Hp?9~Bnak0shA%O`icglkthw%z5-$*7K(#Ffg)*<x4|IU^t*9X4b##xj=J8-sjZW;IvxMU6P?>DM+$g8dL=Z(`7tme1ii#07s1WKxrCuR46N2MDkrC;oOz54CU{%gz@3<%&(}DLn%{;Nayjr{S=CM-32q=)fML>#tM7F>DZlf5CE)<B$EtY{6-&bA9b+dd88^OGXirrkN4@8B0G>Qp)gef3Cj+^!*3mQz0CUuZhE9rY==+ckz@MWnz(6ahh#o8*VnH3#wRP)!EwKxZiH1_3CVNQsrheeWyQbJB-2ZF@d-Gas(uyyt2Z!>*V*bd`NEE?j_Q|!!!oTuo$RQIZ6jbK715;JLt0MgbeURqj^6zbsZ4qGvJz~7woZ%YQR%W(-GQ$m|9D~8gV8$Q?YH3j2!$Cn{lFSsvXw}hQI#$VW0hzt9c3yI~sbP&P+ouv!pfUqbToyXb2ps@B__wkxCLqiUSBLjUq0oi2bGn>BRGkr2<fe8z1-z9D+QH9mm)7@imRVsbo8V>{*y%F?q%uX_dwp-<#liD<M<5s%Nh1Lo-N~x0IP8I>x(BaTtq4$3sYj{)NO|&rZL+a+eC*Y9!=jq1`WpSugSDu%Z2l*okk8)vEGMoKN1d2%eO6xMbYgZ+k?l^Y>xGsL1Vbm?Mp=EFU`g5OxOPaox>TKfyd}AQc1&TvE*(n(6V+aU&DhB`4G`l`<>!0ktp}y@mbCirVmt=qry>E|+u46lb(6rd>%DpB1=*jIkybv7BZ=5gIfW5+X|os;S4G)!l{JCev=^LUBkNqX=gU!@ol&@6rnLF1gb@W!bW;-XNUb9OlBF!_Z>r^07D#hi13+*<GmjoYXjdJ(DQAD7;6X<#(M)kMOsJA0OR^QIaDGm1Q$>DsYP8lC%nBnDvazGBD`C1GVev$-IvxH>v*V37=ibEf=FB3DezWCOH|J{mo8S0CJ)|DV7BRH$^{ntdZz72nw(~-OpZB)n`Cor3-Ujt-<WAOjoZ9G_@jLYyu-8?SXz3O$pGvdE#0)nJ3rSnO`jtici|<`KbGX?t*Z&U-bt92a1|1MlH%fREF>g+lTUJ&LRm9jR1f+Mgs8vv0y!no#Xb~p(bxn^+7%+xJx5g3=Uvv)WcML4-;lOv?KG6rp&(uO}pGzQpG}bSP8iG30D`wKS7<yum6NhYj(7~y`2yo}6Nh2+n24@jUI&gX?Pc}&xkcKAVj;kZPMHvUq^;x8*GYRTsRCxCO!$FZHB3empF>6GJpSB`sP~_yJ*#h}^qG}UmEtJO7Mh&f~135e#@Fl)v#H=7+#Gv5CENLVb$Pk1D3Y>xn1vtgOeuGjz;V6<k7mjpYs}cTrM=rt<cz7sr4E~8o=(8r?do`Y8C$e(69uK&30<lj_y}L78-eG>lqxh~0<fKaweq_&U`o!JxL5S&&`C+Qa(?C`kUD(sktZ9O=(A3&cs>uWHe7Sq&gBM;r+~-ThU{Ims2>u!U&Sd{Ye0G*AheH(8kw2dqdWN7UPDVt?#)x1=@#0YLo3Fl3Y(gRvPPXQ2VZzeJV`EkJ3E@4iTjL0fjlx4=pCGiw{8vh_-TW9;YUJh*=xE6!>x=TZTzI1zpUYy`g5p-rH8b|fL=xvrQe1+~2m@GxjE}@$Nc)T6(saa9h!IvkIvRHYD-6s;O*Tg+w?|XrO<wD-7}c0JAQaGea~rWaEegt>(!R2PgSW}sU<2}ON_B~eqB+O_u+qAjbm_Vw$<UOx>=4OfqW0F25fvIZ#I21&3nBPgU|%7<7gDP1f27djLYrd2EEsVmGJr}Q%giGrE8;J>U;b($gFtj~Pxwf`>aQEpY9+t1Mi+~JSCzLU^1Bw5A!H<UY}xQvI>KnM$>$4(CW`CAA}g{1HZS;(NZ@g@QlS-kYpkFkW(}sTIt0!b`4!$#zhdphv<0coXB4i$m+M7$vwT+Ig}%cr*bDx{6tLOzR>I^ObL(I3e~VJC{HH~ztXo#@P%+Po_)6M<Kf>Bq>J6NVTM&60#h3M^xV4AiRw7}}a3uaJ{#al%b<2teUi4$u8Z+SvCVe9Uo4=^)vE9Cm)hv$?nU{gfMndLQu!upICC>M!79p7n8X_hnlgZhw_++#LPi4MNm?0yeePv!bFu9Jrz}+F_Ck%yqz?gmC`tN|R#Kyjd?W_kfBTh$iM9U@MIJ$-<;`Yu!$h{zDW#mJ6B#qt#0yTX-KnO*dI=#}Fj)LrU#+w}lY0$<%cA)$lx9X8Lwvoo{@Y5})bH-oLSXZW%mKZN2tM~1^F|^8s5^b~OGaqaKm4%Qcd*k1Tn8g|AHaF{pQ;{ohd`ZmeRa~!SJ5KFagw4LBSk}^22@hdRcCV7L@`uP+=?yZLMurL$B4g1^Z{cGZ;|fQzOI`$d<6|XJlqwVJH5wM-n4~nxJQHDOnSXI(qOna6-km?h)}%@XD*zK(>Zc$MmeHzIp_dp?i-?M}Ff}o@Of3Hj6N^!^$XFJK&wQ-@!;H=?GG;@=0%Oe35RL0PUkm&w?W6QT!P^xS;%ml1{NzSJd$&Zh>18zgQ053MatUJ+H}L0)x?-u8LF~n%fh@K*Uy)msae1ggtTSC~5Ew25Mb}wf?J$`nEBsS^m=i3PW-zBuUdRD$|GC1;vT@J2qPIs_c}7s1g7qO2ee`najcM->y}k(V^!n6J{Bnne<)f5MW4br-o8DL7<0rnqM|y`bQLYK2ckt35#L^ZtqLx|y(d>pdz3zrL*^DEU^vVry$N0!s`h2Y(O5D-F+`wN10Z@D00jLGi6E6!rEigrxE$oaSyZ18dWPQ}vk8685VcR4^qicN}(ODLDBp8EoPN0PyFK3$(r!o$TUT%0e+mU6KY8)pDH-Y>1LG&ojtBaFoy?3w0C?x}5(O6H674zy9%sol8<Or33PLOAQktvKPGqR)QJ0~XXO3Os&OuvPvl)7Nbv&_0>r=6&KU@@aYOC3)XAi)BwmfQ1shE5%aJOky83uA7=Y;<)0%C+d$kFa7}{4veg{k83;$<jt6v)L0wSzV?GJ(ajJ>=iB4j!U!=qv>}o<(Y9-Qc5$GU@nvRb<CX>h%UF9kIKn=WMfe}!@9SUgI3h7g_f6C=CBH?lpk(I0vFO+Q)6pkJtn3Wje>Yqh6cY?R_1HxHwB@ngNb#|^#B5I=1jhjUxfGS5)+@oUz_>OVDt(sZ!DWcieZ=*jd#_dwT9sJk-^RLHRxnHJI&W{a(=cxh;}@t=wkVZ5pA{<6?-$z#D*$(8#b51Hcs`Os9QgOd+)B@9(=e7LMLNP_S&l61bNnb&Ys4^s>)s^;SO%=5z$sPF1ON`bSBZT6b9$VpoYBqYhGmzah!qOHi#y-akgE9_+P#gq)1COt6;*6QsArrf0ZugT(tFSmCW|L0}+Fm=k}I=4mN^A`2CMm8%E%HF_Ed>>;hc8r`oUwSQD>}W<Z}0-bAvc<rGoqZ%8@nB@rb-9_G9XxJ*YzqQ0ybP1&S|vNwK`P2!Amn-YDGtc*my6S)9XyalHTM2Ka%2j18oB^H{@slrURb;+02!d849d2(wp=`iO+v2GddU`SsKp{f=GJ?5en{d;Q{`G#X<b}R*q2IUVEIwl*V>z19g+)0U?lbBn{7=zInNwrC4HD1=R`^;E~;2-rbQG=x7461^`0+lvN*;qnKh6}j=2*6oMuQJQQeYK&tyuz1v`n8H%j}ypCGZ%v`orRPnh)IR4(GNWv{=wQr(Dm9eDoB8W`2i3yw9tvJ>2&29xZ0W@EC@;ANVPVsp8N7gYvaS@mQVRnb6km~Mz&B67M**B^5vS0*?KEP581dfmPvAr(G&?2A~!RV!#PAYY4=W?R_M1;pea`*R7owu9io3=O8EFRJ4h>G-udzEI+Q#_&fvd6wZw0P$S{z5s9A1|ig$F#@ur!dX3c!osusR_rErg7spQibd?UY~&3imCJ&^(LEWL<6cdj$r-STR&*sQ%D2{RWXYI4@G&8D0YBnZ0ap<U*MzN_S5UixXqw|TEf%7iIJmk^6r@GBsnT?lpNuWg(#vmj-VE$!eme@mrdrP?2}&KN6;U5yQ9b^S^S+Lu4~@<@^Akcs@4$!k#f5m&97w58gt={WVTYt>($u0LDleB&JFtQ?USx&9T|e)U7x3ibQNROVJO%h<0=^DxYw;8$%o{drA;UpPq{g3)zR=|$meE)s<mflPX#VWkfJl5}+y<AoPIsw#rIagDd=(d0lEg=!ane*bA@;VI?)jcRa+t0r+=IJvd$S4+W09hBa_afp`+u#%#KrJuT)W}Q^8cMi7*V>PrS`N3b6WS6HPthsq}P{~mnSA4&)Vj&xaIn2HgwR9XB^K%GuEp+7zu`yD(DjqIv%WaEvsX4D`cz(^03|AG%upIWS#;P%@<E{N%$#Gm=($(>-Q=D+4=eo^Bma@5ppR22V_3N!06j#^8)Dvd{>00361*vaC#jJGptN$cF7}jW~^@x9^gu9lB{p}JnOy$Y_A?pU;Wv>*)Q)VH%G;5RQeFBd6-lDKb6yEN_b|S<C2>LsU&dx`yJhrWYzL+iHQ&_I<!ptEA#|J1VwNt2Q8f;PN$%z0KlfUL#Ubujnoh)1-MFT~TK)N>DSf6v}J#?$xIV;qa^ou|A@PLua%(2AllV-e{aRCx%%6kK=gi#Q0BDIr>0MySt3YRoFb#EHh^Mb9*WS0A2n%<Etcg8Kf<<h_mCN6lOKyV?ntc;LQBA=}F+SG0ddUyYq`(1*^ewoOz#8Mjh_4$ZN&8j<=hV$Qn?<B+?<twH+mMDQ#lM*GWaA)6R;T{+_OLaA|t=<5c4+;`m+iYv0m6vMtw>0G#Ot&G63lgn%W|^8oXyG{9Fg7mEV`+Zw(JKvP!r{Cmn}D0y7^5LjtS_JhCkQ!zU2;GUq-?v&Ecs+NqXm~%N>tkeRCWl;ri!nTAdAn-@D5P7_Zy-9Oz2mz87HUt2UCun&0@l=jIthbfYR1vv)b86^s!v`Hkx|I>`W0>tlW}p^=P@;2KrNNZq;|{1W~8{x|#Mfh}RUf8h!u&26#l_<lYZYzWFtjiicJ{8^{p-Q;8Xg{20>M`ExCM*}tCdhAO!?l+@}i=iV@xL*1T}MG4>cU3EX;lsG!8ROJxIu4Y5TR+_RNp{iCaFrkPgnhEnearN{3<<&d^oStM(4zc#&q7{n$THA?vHs6=Lu5>__Zy^YkyZ%KmjD?<7{XR$}L1MQ|w@ko+uTlz0=gEs|abKC><=r^hZ4}_~LNF>o4^Hq%icyotQ(>v5q&q~5YRnIh70fd6DRrIekG@LO`C1Y+r=!oUE}5!`xPC|#^SJz+oQaMn?iP+rE=Wy_=%EC6qvl5@Av=}F`nx`T4xQDB&G0c05y9h0RdPY<K<UI{LlolQH@$BfQ}$&=!Jk+`2dS>*2EpckVoB!=#~qn}M^MMv8Gz>m@Dj*yN5NGIehz4yU`(Ar1rbDrlqb{9=~;8>f~|2R38ZrZ3u{sd!3*<J7h`;>>TZ}oDJU)t9##=TD4#v*>MH!}Fuk|s2H%4o3n~KSEz411;k%TFb$~KUlHHU<V@Q<+dI-HH99}tvPN))2d|gXp3S6rY{_e+7n<&%E$T%;gM<4HeBNlSEWdTauS58M%6S`$~bc2Gv4_qwdceExV!;pdHftiRLH$=dNf84&wdg@XC2HmU+-B@-DwL&yt9>~*&EH61u6Au1?eLxihdr^%Wu#?YS?X0QHv?K5s44ZJ-w%AT{f35r*)Letiz_+HATCVLsK$orY%^eo=_=}e230YY3<vv?nfbM%4S{>>|Vf)W`T&s6beiBwXLHX-JYEqMLyBIt6R1VhaHe-m%{ebgjuCro{Rij2KAttJ%<=19Zw9^mL=&m#NoRu)cM>@PCFpwzvGEjffZ1>RK)_Os|7eMcN&ec@L77ir+JT(~_lUYVc2UJqRJ|!hs?#>-U)M&QErVuh8PtrS8%cTtc?{d{`t37Aim9wBv01Eu6XTxd)$-zB2JEe+FpVh~lIngrIL#So1Mq2T6w8Eb(AUZB9e=^l2ytdqz0wQer2cN7$z&U*A7HZ?QyBQ#AZ!1r5%qJ~JQl22q|25@_vP|t4{eip^pNMbj55(8SCnEK`b{>?YT_E+;R}}(G3bPP_Tu_`Q)yLzt97Wu!5KQj290i6nk2%iL`H-V<T`(tr%eO5@k$%g_CgtC+mHE6}k}9Ljp0>4uTO?#<G?-Hb6nUwk%)zY~WoDgBdxjm-h}#K7LzQ*GH*1yB=tQ;CQtn;OVUR*R#sa1MO$`-;_+0l8&YY;&i7&INfu+0!MrgXti0`tuT@W6a^;JqO*A4`N>rBgRmNXQ%BSB0S2BT<Q&h1X~yak;}l&~FgJ4x=flojY*!h~{y>S-s7ay1g@%Sa<pl*Sw2{16hw6Rs!f+5eAI$5lz2y7IcH_bdrV9x^F?)AuRnxA%K+hWt6XxaOLAxpnvkE7j(G)<F%hNBp7vDVjrs|6yl;THYs>JyM<rgzp{R={PCn>W1pg4Fi9Aa-=+o1hp8AA_Pg?;OLC$bY)oDGN3H;5--hsY!b0!y?~_^nrdM`pSwkYPp?vz)iK8kvy5{=ruJ@Tx)+fIN!6ifO;>t>uKXIJF5F(N6HEsKLIcD*(m;!KV?HlzvI+WZU^RQhl*oFJN}-EQMLp#^czlFE*n#r`RF|n?UR(66YEzrnD}B+$E-C!C8|vrzlVt^BmGuUImT|8}@`FHQoRwZkc|*awv%U}deZY$K*7})LyQhawqN>A%9zJse=y@ix2Y$B9=RI;4^?>#gRDzr}kY2ke$;}G<s(wCu?GO^=XbBC;*h@Ram$B=xH+*m>KUZT%-NXN&#4OqgR0inm;AB+=#~JZ88=VxqG88(sF`UbdrK5wWOSAGrG)G~J0+r{3Y}}c0Y3!K-(CxmQ{`hC?jy;hm|H0eUV;MoDKUD1B`o5_YGr@(!kbc0atDXdjnCE1ys_wMhA0WzTMq5Ip$**C1xH-@D=1?dd@&RSDU78_zexjfNmt4CK&s=hQY5fH&%N!rATXg8S(Cu-x&ODMnn<3M9DqmNE{F3_MuVtKE%EAafn`+V=s|=yrjtknK{y-zUaZ{6~&qWq-{defyku~eO!^L+%6qRj!+_{m3sEGk>m(((ZQckE3;z(U2CZ7a@iDVUkB+aC3$*MxbhL9N)bs7fCN64UteaCgIah)O|3Y1PgQP2ZKH9D4=V4m1PnQX_vcwfd{Px0BtHNeJ}uoA&jd1s#kq<Th1(G9&C%bTR$06UrZM6xA~o@Mrj-?68yjE65=xiH;lZ$52DR$s3shn8?sPLNM}!Wi8R(i|a-f8Vd#zR?dSoNHRQeVb55B?dlgW7hWVt?et?ETkARMRbBaUONr*IikyC7W08VCjNC|M<v&?q8GJR2qGt$UnV4I`<S$A5)L8stdvYvU8;Ybe_*e&w|AH#mM1$|y~O_2wwU><HfUIuKs4?3y`X90>Ur~*o`NCAOl4EJsEQZiuc~0g{7*Nt#MglqrngV>)sf~8Ibb+c--d~^)9cm^kUMc(_lA!|3s<Nx(+CI#ehH{>q_7k;p3u=>pu&C)6%N=>YxWTq2YeJ%I1q>28{wgokv%sX-oOb{euveJk}7=^R5+u|`$9F%(872UP9|gfwdE`Ojibp&;^iNC>~3~9x?yB8kB=;O!WcE1+%Phs1hVdY@>kK%>hV`2N{@esZ9eRA^y2Y9e8l75ixu91LcDe^nXQc`J^m3oIA8wp2j;?^`CVPajHV@B;p@i?g5#ochU{;k>#mPC#=$+Sw3!H~wCxqhVP`!i;;Tj`x`uChnN$Vw=Sq-&cGZZ*Nw{Yg7R2m)H9nfPs$gfj@Fzj7R)G3po7m@XDzVT1p8LBDaDL4_y~6?uHZOG?@@IZ}qL$4g5}NagAp;^vGB_XbbY!K$v#O5LW-rzwGIIn2&alUsUTLbRrm9p=r%2QWmGj?`)t=5(HI;5y<%i=#m6l-5e7YEJoURyD^())-=nIrbxV^Woq43N{2Q7?9wT4(Bo`F=<@?DUw=?n)fp|n6-<nu*HZ|#bGfk&rIq&*VV^cOz4Hb%qDsM=VS=iJoBc4nD&qc+Cy-|FEVt72EeoZG@!sH&X(sw#$?^P(!2_tzz{{8~w@1l}D&r;ccS6yD%>#pGr{K_k*;wQZ{yXL<irLQi@ZNTY!jJ}ZeQ9uF-}JAih>3CWR_M9R~G(CmNx3a;_X6670~`8Dy|H!t>;1nO5-g3M_5@AB%BTL}^)3MI$}7P@V-zV^4YP-_Wtz7^+r*2+tRA}$jb?~Ee=)%@I?EI@IWzV%w<zq*LUJ$^(Ed~uM%IlMrn?ku@|SScYA)yu>LMJxa^V_4-T&i7Bo`*|R@`*dbrMQLfwR}V<%C(7jKJNVBli^=bNbHF3^bdL-ymk9*QTtJu{?;v`kWk>Zye{z@d6-PQ|3ROS)t2)ic1~d!X3yN;9*|MEPz{cX#cONin+=lUH#n#J~&1yLdlJ|BfGkR5Ao|}-~j^tep9oBY@1U-}y*rg!cLdi~Vc{Q>)ltP;-9GJOui=K^Qj_a7Fk<!-7uqMQg@_T}#9666D){&3dha4NprC*T6q_eYXdGL#S;{|2Un^<EB^$9>=)xg1YMx}J9@E$cMrS6913?Jpm7A6BJx5Q6rE?_5Y8|2Srs-2DVh=~BSv1KlRR0XE-j&;?O7w6!cm=uQTV}}TF${W~vs@H>2*M~<*>-w}EB`S0_2r1IG(784&{Mjh^lu?4Vf(?}T>L_VGI7%d8xg8~KGVzEHc%KT)aciJ-tAVn6b)aBn92IL^Et-8$5#<|RI){J#)0WOBK}7gZw2oMZLRr6tH&@R{u1~*NJ%=;YetRyU-5xIBSUu0^=SU-1{LO^q!hHe%LWTDs?ff{F+%Y5&e=)g~fa^$g%W?skxKkbY#34et$EWfL^Vf1b?;`@=a_95^w81?FcF`hhvfZn=$HaaVagwPQxP|8mmw51#(0h+hDO4CKs&q#fgzu{wqRi9##;BRmbYd8vC6XT*PDj9k&@Sjo5WrAnQh6^UtgupF!-gZTN;hlDRl4GAJC#kU1KP-mI^TlIL4PM!hz?8Tv0HG7k!Ce<qSrR(a3E5nBPfaS2<2vX9F~2sLV0wRoN|S7WD^6sZENY2^ut~few`Ua3Z>a_Icua-9V@W2-3nL?glKjGe{maO$~1Ub3OkWf^7Cb2|DPKgv%1j7g{<2dlevU(U>vK1J+%-Do*DvO$27$S&183S<_|Y;?<Jm+A_TxxCVy8_2G>!{H`8(z^8mD~CHoxYnKlzS8ev9hQ6i~+)&CQpacZ0jlngE`G7-R<$pKHKG#m5A{Ng2xI#nN?L1beR?ixsX<7omXj(F9~vQ<{O+`(bIqhwwpa2cEh)bNncx73<Wl{Kvxu%vxmhjqR@Ze3C}5zh{$KB8e-qM42Owg<zvXS&qO{mNtTXQ{nci!%zpyDFwiDgh_iB>uCi(L`G(C^bU@USFZSFEu8>*HW>lYb0x<Bo&A^0E?M%dIA1`7(xyJg$7DrHWbjx$t<55N=mf<##fMToXeovrW<>6<@!*%fvNKNWF?M=Gy0(&$FS~sI)``G3zzP207KtF=0J^`exz~E!S{eDTGCM_&nFgnFi$nWrHLb-+i*c&!%aI5o$Ss%pOpXklN-hRlI6U(3<pf-{Z*IvtrVjY1k17we}ynmu6bz`-{J_CU3G)R;8u|ke5(K&zv>ku076HSE0WCIYhN<Gh<MZ`X6+B2$yQUySM6eSt2S|dhiSGIr_6wS#$ZZ*X$OfY*RWx(PBJQ)Dav}*@KCj%+~idsiRtD}6+}#@R(6DULELP%{EG%wiBV0YFiuO8x&MtDQX4HAkZ)<nJ*M)Im$5lCRsezin}^^=maf_(AHJ#=SGLqJn<`y?FECa4uKViB$y<tm&=fZ8&56=;rj^l9DekB`qr~5^4owe6B7Pz@DqlD}SiYQ`os>B^u|;;|%5#FV6Kd31QX$o112rP(dyr);Xxtt9C&9MtIs6V3HD%6EEH}PXvZXHnWg9~8@lnK^Pn(+7T-G|%JvvC#4y8}u)flWim;-$X%F#}=^0<G%?%6O5-33Q?K)_D@@jDDD5Gmz@^<eXZ#Mpn%3w^bM|8yqx&{fG36RXuWN7KwJpM4MQ{(zZCx5Z>jjJKvHYx&AadL&|5P!AFJ9Cs&5O|aYqMZU*i`o>|T1__X+v*K|;g;t6t(m<Ryo}>;*v^C%Kdt8CD$)8A3cD38`#t+=T_OWcfajWnaSA;&{-Fne4uvSaT+b4y{vz{A*%GvhM<Pau<Geu+kG40~^6Qfwb@-yeHw3a>HXi;e9h$~r7L5U`}hyZEP3<Or0P8vTIf}8P9RWA-xO^hL=t+1OB=r(k)jhNU<j5RDAQ*$--5*Z|Jl8W0V&gEC~&+`wns6*JuLd;~`l~MAoZ?ELhwMN1Wi(1hSP5IU?*VQpBKdeMM7A?Yx)UsGbJWX*At|VW@NU4O8+YZ!zwLw^MaXxrFZbb$%d&0HENDVPxs?e^b<U-ioh?QvU?XTV<$HMm87Y6Y5dx=(dw?4I~Vl3~>Ldofs!?*!>yYWMCTe&$ct^e<Whq!-JW4jE&A5ov>(bki=G80J$;jUwe@lP{FIhv)&33CvQ7D%RPSOh}$T9)u58e2U>ySQ=^Dc?N}un}pYxQYTv#|A$$K7_HT@l0^0>Emqwf$C9NgztFG1}Y(xgZTj;e@3i;eo9e2NmDl&$80irzp$s$X^AkJU67naCI!a?Um#Xcra};^W|Es>%`;lKSUGFGI#|6#oTr%6q6c}V)Mc#B^R<5-B}r6%J#ptET^fxTT_P4~XhG5}6&g8faks(H3@XW>PMR&23Tz9b>=Cf+?Z|n&SeF%RB5G6}l7;k*IFjT)_sRBIgipXYtMP3k?2n6geoR)b+PG%*zybHOGtfwn#*%1tRM%*#Syr%yU^*blBxbMbfLypj@Y<JO(-88CAhYfRX7#0pu$x$U2=KgW;9XIoeN+!0do%0~2$fME>Jq$yTKWo<<fb9NB3Hw!QIql6Kuq(iF?7q<-4ibIUoBzN`9nij_|(T*&V?k#8|7R@CxS11py@IB*T5UB<(6%_H<24`4l1HTvL_vrr88)(y5q?JZ8J?5P|*>PjOqVx?@M}R+0v_GH?gD5=H$uK+*|k6d#);Q*)B|BMn?B<AjANP83Q9`AQ@pX0fCHZgoHdnfIzkcVqggdmOx@)3o&8Bp8<&pd#&~D9T9o*oZGynO88tI<;^xSa!178U$YwE{LJJYMTNbW&afwsZ>JV`f{V#Wvn=$mdDX_fJ5qllk81~MA18|=N=q}KB!%p7S{W2Xt7IN%(2#l<f~CD5f;Ib(`rf|{-e-buHnOh=7jIb|snR5@Bi!V)d~D`NRX1VjW^!!<%2GpQ=oDD@NqK8bbsA2ao_cX)E=EGrB8yXP#FRxwvwzI*=_qs-C0uTBtDGF{rNDMHch&FT8wL~EbPEeKfff?i!XGVeAe<(Mc}bW$;$uN-Be<hzO#bnYJ$DQ{vrKnm#2MsC`p!SHWkv&Qf>eY#db*~K`Yu~<1DOGB?}~V7o(=%07MnlymevAw@E`JccM4m{4u)v7rUFE~;AJ1l%Q{ge4;-x!vE9h<{E?JxhOj&%c@Q4lUczr4dB<$hTM~qG>DHdX&?c0h@+q4FRiaH>&g6qzR+{Ew#hy<Glq-Ao%NuJpMAP}>IWj8!^c}IMH|j>*0OY_loRtZZl=Z2+f64R^eJa-m>Q?M4bhwgHepZy(HfAV}@V^t8+VldUrRPewo7&WnV>Pur{+1{Vs0dZ0K+I&=W646G6iL|BM<O)_wDL%52s_wv_oOi?kv}vHP|1u3{It$&NAS}+(Xk>x+FeUeci>E@Dg<eAPhL5z#QAN%VMv`n*E~KVxeq6vruo1=tc<Ph+`F8rj1Ux9a5*}#`E0&J={hIc@ZD+6d^i%XGj@eN2Lu;*s*eMUyV1&Mp`h?FZQQF~qI5e7kanDyDh}2d%Ex2AvyPQoT>v)knlv;;C<uc!-`hjFTKMr!Zx*tG5lO)qsf={ULvwZ<dwx5pyvxN5O>-u?nh4G}W?W=1{jn`32V9TuzXwS3`wgVo2sEJmCz4td*OMdmI*=Vy>sgrHkJf)32pB9c5%l5NPDGqT^EifEIEh=9sJ0GQ*aCr4d)9#81NCOES$OkIk13|rEa>3lGO%l9bwEF^eBHjcR-VE4-s5Z|f)8H0Y~t;7B^c4HZ7j0gIRO<pf0ExbL@y1=_rczSJA*aE5~n+L<b=+1{EdZ3<du>NXE)TOlQ8#+tn525*WVNARr_h7hHwQv_Z}575KP8sqpk0~Q5-lM9`MF3y}NHMqT4?FOW!~#A+G8OgUl%{zm2PGJQQu9$Vx%#E!Rp#aFo*U*5aYwT@iLy@Gf~E3E42XilM5>h@W7(%0aB!wL;CJYG?t6y~?@QZz~Q<sUj{4mhnQo!j%MGX?d+dM8D4Mw{-zuKeaANm^MgwQV6(Ach{2cRpNYA1$ZIveUfauX5$Itn<vgN#ry4J<ltT0+-|gW)?Zz|BIv_Z9SMFBvD}Cytw(#Mf2DP2eTVDJMvZ7Q8Ya%(cy~EIaa$1x7elcg2jA53Ng~Pcw)N7ubsIUP)yQAouD(6gop-ClvD*3Tb%(GmSD8AMjnbtglPgS)W?RZBQn+>~gFpYz=0XbhS17M?BW@wLF|c>&$|3UQoo!5_ZBVEZ^pKu~e%9I3U<o4ThC*F!$pDR{%u9tbR7pRT%M|BO_S2~gJlH!Z4%S4I*;__2tksbH%7l0){b4(HdIN%~(GR>LQ?uL#C)#DXUI*zrn*@@t60olEZV755>A(5AI_Te<>=xH<EP*XsAMOCeyX{7>DAI~=PO8_^!SlXo^fJx0ExYPUHTgL-ertY^bLe2RU^IFu`!<pA1$=h0^%DI-592f38JfKTHrU%ps}W2lr6DOqsy>yM0>WFPZQNU>GLZOZ2}Y43w!ELwE{*B%tKvUJHQ^^50EPZ{>R>ljR?Er?E&mb-UQ%NnDclWjR7GS2Q5bObT-B|ySS2s%TSUr{Al)N*X)_TINZ<CxzGLg#^+$vpXpB$J)Td#ol5<e7FMX>f8pTg&zX;uhJf_of4Ehmg(7cmIPg6x`I(XJJs$47vUM+Zuy^8+D<hvGrqZLPx4`AiviBI(v%uq8~+*IAc(4qhjS-zE_BxzQXTUkpM=C5NSWtEq;`xeEmOiXCB#GS3jyobN{X_X85UA(7snPD|A@Tx0(=9T7Y+;&a_d!{`|fat%stDb4+#vSPFW|_Vw*Amjf!h~_AK)ma;%F{)4&9_S&S_PZPWn3&2TcILe>Y~Pl8+D9yMRg3BDT55Po7QRW7_B(sCq8qe7)azy-iPJHcu!UBL6e##xk%<p?G^>af{kossi(5yKz;$(y}@|BwS^i=Ijc9BQXsIQvelrOFS<yeX?RcF*7@&$3|n%YR{(tI$ha7u^vNfgIWp}UFgAO5R?>EAl}iK~R}qVD>Nx#g$q}DqtqCT)QTYSyK&1{`Qi#5|r40<OaFzDx8FjS8g)=QP2b8(TYI538;GVS@;r&e1haFw&^g;V-T9&+gWbQx<tCF4TcJ!9K!>aL~1hF{dd=LC=SI~E(r3$#FgIO1umhM2*V$NprQG%)a?|kfpIr4yPXUoLdQpqUn5wyZ%!lbN|U@RThsGimaGaIkS2LgnR)cfBR1%CS5T5gEh@<txq(i`-@V7+cmFD<pCP};)B^Y7+?Qt!aOb;#w^l3l5=QaKKEYi}r+qRg2%;jt@A2uwiD#e_o5Hp>eggU}#65nZ#1j>VLL;zzzPG%8<;6%%n(foP`ElS5O(Ks~l8aP5utk0BPuCnu<XxCmSPGD<*;-NgMf!WK8UKEK+kT1eJmD`}xKl4%wpp<w(k??>e#|M!c%@N$a^1}zGqwg3e*Q={<UT@xrqb3nw9LlL29sl3&CRnNF@{FGn7c)o4%{662w@2_eUI$v8t2T`pz7o#eTv6FZNyU0Iov_Y%L<vV@9_)@R$)bDNOS6y^2s+vZ-5;m1AKcEjVC?o`>#{wRRWic0J{$U!N8n^b@qEF4#_<g5JwB1VW0)@EN?LxC@8;56&pj>mQbLib#3fP4|xO6K2@*_mae?HOOD5@{$?)6gqtpL1<?&vmh7{qu>5yL-&^uEgR6wG@io-Ua8jxcZk9L$?@Nl(!15$kwf_TAA#%f+2R<UFzpi92VUDMz+5j<gPTrss~lzvq{7(E*s`_{X0-ckG?quJah&qd|c6D9?+2+Gyc$HsO@9Tuzr0#}E3Az)VZ`fSZ7W$>G5TIhBc^ZzZl{nS58SMt!_34$S<5%@iORkhGG?(M*>XnH**zi&73A_R{Y`U6$%3-gYULxxj$A<y-P`?wEHB*VT8h!}OYQr?70wno(A`!A5$J#xTd7(UC!beS`8jPOEn39?+y@mb1f;{ZjQ^Z-(AuW7*qDIZ(uGj%hBU8+z_)dF!Kq0B#K-**d8RGZ9yJY)t;jGQXUkom{3mxx8V~uRt8F68JqrjTN5{^g7^}q3w6J(rGRFhS`n%BBD|)4&GDfB22L2IW`7X#H6spl|Q%F#4Vt*f@}T|(GJc>@^Ek}rsjRfrvxx<14%<>B1-1wjp9*6yk}NhyE6kRMo|kO@Gm^)NC2>DUJ{?PBS1(|0QJ5&5_rxzg=4660e;wc)r?1gfZhqrZWblCB^Y+l(P+>WEqy0f90P#RhP0gVN9GE~SIlvP=Vug+ob;Ddb(`Kud^fJzxv&nBN}*_05u->or0Pw?>#S4<ef4lkMYPx#pn9o|Ev3X@9%I#}U@g!c2<@~Un$&AswTv8*%zjbrb<x6OXWVwi`8<+7UKk=Rwg9eZ4_6If86$)X9eBUiF(*8AE%sh&9V?U5m4&wR{!(f@SV*by^-@Q}?-FcQ<a$>fu;R7|XY&6R(bTG;m;fq*nUL<<pdiS%OW$~<G<fNBnN~%<rG&LICJI#}xx^{HC{@=&Y`6-VDjCogv&6!?+Z-&{RGTAzF_C%YPzIXFpZl}2w9^s!JC`<^=bTYvH9V;U(ZN7-%4^~wwt(4)1_Ao2tiIwNlZC3H<0QJ3+2-(?^Q@Wycl2(S#)4UcwG<@(3QT@qgc+Rbyx?B2MLIH8g14G{w&+LjHqukDx?J>i@l}5#D1vW^pFTJ7M5QOD<+e^GwsIZ$2aeF0f#^`=vh-Qe)mEx~2)8`pK;0mHQya)J-+i#cG^koScaPv>Bx)5qvNP3~p<*>m9Uu<;pDW=+vt*70+N!F2V=~<+?79_1;zxG4rxtTBI-RYhcaf>K<e;H3-g}i-gQ4Zvm_|kyRnQPO18CVKqZ`I&!VZVx-bUvY$jnhxG|z^IBSdkf)-`)+z_UZd`?_^JNPQ`LJ;<F3*aUw(=5X2X`7Ka=oPoMha`7Pbb&8(mvq`9tMQ-mFYF1`>XFVOBXf3{!CaVT6Q#mkH+gdnLH*}IW6(#9MhY|<x$`s7guQ))68R#_G3xnjNn!1!NRV9(&08`EztKXcj-Xem|7)YRoZ~5qt#4n=8)zd;4)ug7o#o|Hb8{dA4l<G=Hxn()k)Km|g_AeBaFLVrs=S2)e<jIN5O2MF2A$TR9+<%OSLHE%js>$yLge`|)$POwPu*xhE)uFDZ5NXNb$yP+QNmW6$g_>$d2w+-7S1{*SDb;XQzQFtZrCsMJruQ?JF9`oBp9tvT99{e9x}V~AbP4Xpb{708gvTNc238{~o!b=FkJKv9W3UfX-@I#p1vM42t|8lmlc(HliesN|3#meu5N3@KlB`q)W?C|k<5l#A9T>G@4ALJgSPM*nMibOzAl=zDrhao>u?HeiHA}N-i>8n*<8k8wo*#Z?L6Bsd9XU3|u+TSd6|rlY@4YlK^N)>hH7zG=H%jk0B=eomZx|t@4M7H{N?Nc9VusiYF5D1os9lkrm4<v6k!jMN9(v4}ZJ8WvQs~yw`whq}JVy9DvHT_-YQoY4OGsB0>q->xs%VSmFaAH4fZVaZd;4)Z4=q*q(j`7cmkqQZQ$ae8>w+?3r2CdmDaj<~+0$nf)lx*0!kjWQV9pYhq0B*U@gVbIng~{aKC%24WFp#xm^MM5;v}-SNjwOKdhBK5JhLiM6m&6D5b`Xjo8dx1vt;tVfLw5GFI9|!bBPkvCS4_umx8oN2B729>Z=_|c2Rks{RriP)_^pHZO>FIfJxpKh~z!5n`!UJnbahRYRkmz0>3>%*{E&oBoR*qNROa6+xixV#ZVH2GKq0_Ml6EYn>zI(OrJQF%mo?~*8=iwvjz;T@wA~aIdatw*#%zDfMnu+=aXQ+B30ghM5_G>q{_mm<TczM#Hb`<sj|?Eh6{*h!3tUT_r_z+Bk`jXW{P|*kHLy^N9wtZgibSabmxQL_ac!&Co4bm2+e8S9#fM}ZcfHOKeJ$UO3mry@;vo8lhBpF>;HaQgYYd%3|7k|N9)72%mKr&sbzNhAaTt+C!XM%S<duDkdd3^U|g$W?wkoEd{CppcGCCmNeOczpf`$Dj-ud|5+*w!cFnU%b@Y<@{B(_qv}!$KaCmt$y_-KMP!TQ-BGH&!VbVsh8_d2P?M$;0V}`{1WiYLH+ots<M>aeC#yIu^vW%iX>`U{~RW0(Z7KLUS6Kx6at8R;jAfsLLMqz1+jqkU3+0TEZ6bVq|pEND~GaXrLW*ELQ81G1p7iw;nEMP+yD!GRNWQ$?bGM7j`M}9IDyhRdVn2r5LO?~v%sC7u+Y_j!8kM}(TTqRI_qrBAh`%s_(o(*M=aU{0F0hfO=Ic0SenZBD8zL%M{Rjeq0*9&o+clrPXwR~m<;#3fz=Q&~mi?I`-J+K7Jm`C;7WbU>iAbYbz$2tzpVrp41yX}d}+lxR5GNF~3vF4f$yOT{iU4WxAPGDm3r8RT|$wT5Y^90&EPKT&_6HGyiT;y(8KH>8ftDjJ3hN2!m^G<xtG3V=(Aqu>3EkJj>{1y`UBT*hWDCVx=obeUS@6lFFd4wS04x#_u&mk$_#}fgE@F?3m(Mr<^M<&l12t)3Sd?C^-vCTl0C$K758;FK=OXS~@Kobl;#_)QQUZLE5@`1b;;nqMz3E%}5G<J;&Sr!5DgY*XqiL)b2fm@z3qTSxfhz!vx6S0sw78{PpcNxVr;k=;pI-}8GO6kwG4`z|-j03FqFW^2t>E(Fiz#RZDP0^Yojq0{B=PEglaO1Wcvr_?RXsiqc|30#goygRf)<e3HPgY1J#2^3Trz`xSL_&kNB`tPeCoMK@Kc2)}dB1NoImSXW><OGtMR1<i?Xict^%+55F&yd;$+m`p1s0>*uhL@TDXOuEXG1?-sQT@To*x&KWkskVV*~*E21o4YASeFUpJOr38802#DUx)|sSzxeMSqtL#dgFOBE-#dnn+Is$QUS|Li*x3aO!hKzN#V=8{-=o0NdIza19bIDbK_3*huQR>B&Yu25^AkEEW@020YiJ-rtL|S42#E?G?+D3~>Ed>Q4-d_jsN{-XZ~2W=wLmFWd=z+*Qz_tCi;b{~LAiL({gxYZzl`A5}9hR~467u37$Z<ds~s4?-*!vrJVZIDlLb4TUKk4D9e-Csvc=3Fyqk{eLZ$(VYulV&%stj_46q3zWL@FY-$Xn*6>kQcQCbEz@Ga<P;>3m(!ut+T%3vac7Hs)XK~T4-4aDGT}aEA2y_XuNAMX`C(^_(*zz>r7n^DG?9%2NL3K#MvieOBR287K;p?kir3=rOuu5a{yX-$BKL&80EKy*^Gn19LumtgUoD@Z%+ETDgDMfrVnfud?7hHUsIGhU)Fikt$YX=fQc(*#zDtrjUT3jyeG5BN>_g8PFm+z)H+_e?d19pCgon|29VAIq%zv<q2LY1P#G(>B5g@b+hVV?^ES?>mGdx><|DO4{griy}+KNr0K?~`_6KF%$dY#uOm~bdM#!aYjwS*j(x~(t#0QxCF!D`GA%ALD_X8#hQ*|%G0_Eb7!tR`Ev4gQ^&dJLC6fJdh@v7O0%^VmTcL^$(y_Kmz^qAw=X#cL8re`Tla$hNf(kFHphcnjj(%dL;KH3dUa7B}MBC?;#ImTlJO{Nbs15MWR{%Lq7cNYTk3$~RisO+C+WX>MFiyH%8D!3%32cMk_)EC3xfWjbBHGfy-oBdsb6N8tl-Viw*%a|}hFy50H@i{j0?Jx<B46fc~S5=%>f5M>-JW_-T&sf0F6ea)ZQ6|c6m%B_0V)`B?pjbC-!7N&tK+>%g*2dr^veR^U{vE~reSJ8N&wQhT@PK{Yn8Dq0HLAP7;julq@$^L}3_jPD?6<1y@+Dd|9$Yh=>vFf@w3e>c^FK_cI9Ae;f`(Dyx<ux4U(h>cKX8V<=%Rj>s%-Z&g76h2iWc!th?N{f9wz@jAUrWG9p0_ZG1DS3nd_5g4a_pE4JLiQci>9)n>4t8vU}Dm!OCOY17q+IQJkBGRq{eK#kPsckH^=SS7X_9i=VvZ+T8o3#^svEQd<-gwno2Sj$HZ(gSlB?)1qZLCl2B`J?mT^Vgx@X~pBlX|3-d)?T5PNxAiuN13EkIs?eMmqQ)lR~WSdsH%8WP7aEE7b8vf;l%J}_{D4@OLNMB%8Zq0b@n0$`;0#W3KRY5IzT{oi`>2ZTqK_tDQvAg4qG`gU@D4e(|m+8@`2SZ=@2lM3KKUj4}wYdJFxr1yO_UCkm@i_2##1nVe`GJa{5BHEC$~)FEQ%V9t{Kapen)p-^`r{<p#z*^=`%+dsJ(|ta>EypkRsuZUHTvBL@9$6f_xZQMqPMT|sN`1zH*y2&#M_*wPz!R-3-S)%{>Tk_3Wxg}pn1+aXo^{^`ENcM8Clh#t4hLCx<P?LUOIZUPjHZ~8hJl~KfWN;Mg_w@d;rwAA{{&ttCdpi%ZhFBsV;31rR`pnolVaPGOu)IFQk}*i7=}v;0nuNynUjvTqp*UL>6}99Th>g0jZwNw1i;If1~+*<jIIO-=XIdZVUTcCJlFv3@S7Z=Od!$))@I%CLZsZd8lgPk@#CxLDcVj)X!G$vB=iJ0^#vM6^4>n^l~ck`Bb)d22#IqqPH}#r{-Kxd*tYbPHQn9LKUqED%VQ?L#~!N<jv>HF~4+Q&;eyt(@G3o#s@I5fN?wpZ!4B&K~_Rgl(#*xO3MKg@W2W<e%cN;wUjDjy&~WF_n%yINTuLF5OFncaBEkA4!Q=P?ka%q8?EMmyngE{K>vo1G!}TN?0}ksC<asGcU}GiOvL;ILTSbKZo<T0Jp_>Dc8-1cP@3@2*JMMZI+-$My<!WrIGLhNpaf|Dvvv;%f0#p>HoEqwlng;qOoUYaI|N`B#mB=R4kaR=oQDiSI;3M@tfFair1|g|(?o7oAaNuVfnUr>5*(*GM`za?G-X<<$4<B!<3OdlUXUA0vc0AVNe6-vLhX~@#P#~JojHd+I~7G)VenRbM2Rpe3l)4WXoGVTtk>8x29rrUFV|=l2E#!0qRM)Kca&M#w<uKWo8aP#y34TBz~zOKEKn`t3e_JlDHR2`V81j`gu@qYr%`i{U4p!mXgp1D5iaJw2(HMGIzqxwcJ(T8Os;%|FqbN8#sxc!0&>*#s+X9(;W3mqfO~BKlfyjxcQH-KYxSYhhj3J>enp|iI$sP=_?9~cbOF#O+S1t4nr?*cDfmRvF9Fv`aFL(cNk{}3L@PL&S!Q6P0l#F1VoLqUiIHX?1CwGQWdcH(1Jgl!K#C?{-$^UmK#Gny!Q=>ez>u4E?<H30MFHGfF$6*k%>DAF?4YrjJOF0a#EDG7V9ztT#{dU`8YX>#WlFF>imF&*a>T5(6Uf)9(}r%#4}Q7%dkc&ap(;&s1!D{pXdd$P%wzDNrfi(=*{Stt>gAw%q>RvX=M7{!F?VL(;iwXnckCBgOmQdog`C{EA4&OAfP0~5Z_{()<OuS$vq8dQDA+Jw0LVv!dhQs(dv5Jq+{!WBH^x{#Fcr(0I!?~nGzxayB^KM_@!oym-JN&8>e1>Z6FVZGI(S)%`@+q}yb(<IwD5;9+`A@!8;0`1VN-!Xwa8_MB~vZNJdmP3oPp>$*|p<DAiCjP{=@vlFMR`Y7Y47P=mq9Bie6NXwzsm{qN15L5}LhfU96SR2={F%bP>&A)4NLUcbmcn%NarFXy|P^AFmMJYN?`#4U`Yc#TZl?0-=JPO~%tGD3!h-kV9Odc}=Qet6|X98Fx{xT*0TGXg`Q(XA^=XTb<|=&M%*>Y7?AimD=LTK3vE%tYF6GL0m-|te6tK39)YlD%SgXxswtQY^_PC0=%sf>tE_O1h3_{dmC`m1hzTBbOD+zcmGmd<H=anaJB%sH}o>^qwQ^y_+T`!>c#o9Jmh!P#VWX!j6{*~tXwxrn_Qe->#~{^u9M%&X2b>fT@d)V(0}bogXEd0byn1RW>Z{Z`bBwvIjy4NEyk1c!r5yj%I|Gzs5?beAm;XN9o$Zw`}lKv8v5dVObBcDc~ToF;!gmSl4Z$S=4&@n&Y>{gsQ8|rpSdJ@;F9|iXGC6Y!vSIKEbHWvC2wT_u>ilgpL6ebATFDbngnr@fQxK?=UMochU5ay55PbZh>)`~RtP&rd%Us*AxBadm};8iH%qc@6<`<Li2?ADz_p18VMV`lhdHt;&O{EQG_HogN>yA6QuA-2nH@~t3z5W*W#^kbS~2xjdYa%t=PO4bC3j4&6|R#k0YEYb!zZ9=t$jZm*mLIO*i((1xm>hv1iAd94EoT@MJm;ji#Bua9tq5g(PWMdq^GGL%`7L+<zCZ`gdB*boSO*syNP`o1Wf$YY>BN9kkFz$GMaTJL4jnvsxq{;1Bi7JISTrU)^;FI;_+4}1xeCz%iMTRi3q8B#D4k4yarDBsXM&6|KH{Z;z%I8Skxq?;kJMHnN($Qj6pWcCX4GFcY&HMT<oSuxe|<S&d1P%Y(N^G2SG6CR#13Mcj7S(IhA%UTGTX_5=Bx#%ix0f2~%n0&p3eW^~h4eb#tNGuzZ{!O_d|i6n*9=x<pan$GB3TuF@M}E%I!l)3m>)oov5+o!{IspzTfJLs#WtXEFPV`LD%&Elm@wiB=*TBLt*Ev?*xf#;w<GT0QP*1GuK%B>QQ~OILGpv!VWYQ#2zV-Xsr<X=S4Uf|SuR9Su?>eYROR!o|wIUEE8|(=BRS%cnN~TAWC>*}Bb87WyY_>B7KjLfH^<p1+zS={&UQC(LFZ8A%t?-fWRtem*{)K^&PLaen2i{V`amzGtD;_rivlV(fxQSBI2p-#M<ujN@^w<~RJ5I>r&2FCMn8Y{0_?)irlq+)}jFNBSyi^qd&lKp`K6VfUCPz&p+n-u);wKg>T7=F{${kN$icq9q^h*BwRaS@-G+c)qjUV@Hp<YwS6bcaBkG^Fua*9{yR^6dEX|+o%G5xpVRS>%-4`_&T27_QTf^ejVZ05q^F6I>Mjx(0?-z{bzhUeafrpTiNZe`|vvoAzn|^?{I9>H}_rXPx9FMPyTHB8s8iLqz<fiU+ba&h90Jmeh83h<!SQadav}bzUn^V;pV>ksQYpqHKy`M-8R=gQlD%-ZG-;$t#BI~wPKY~0}GzAyVApYr?orU2fOdxTEKacbTNP}i`tY+1ke;^-USaUBP)}hF)?-tut!HJA}1}Ou@oVpbVgG(Q*3FfsIqCZ%ZN{6I;+2i9TQ6M5HcQ|{rPAAWR9ml_Iy__4bA$YOWTLN5e1%Z)0ZcgJ45+Yv}fGZY#ye~K08;GR?O?qzHalUGU2!#pKbt4syxJ}oV)VpO&V$0=VANX^->u??Vb&+Xcl$H+_iBi`?l;@%ZeeGfTlaW>||;#_SU(}_tf1kR)l3dEAw-E4y^Cg17|z@bUY>7#E!K|ku04WavLZiZH0M`K$N2R>Ne<(w>z6#zMorebbozo$guS@&pdp3$F^(;lglmJo6Ae;u!gep7k8fBh`WCK?2mQ!UC-`Mzx{RYrH7lJ`OE<7_S#FNXTA7a>VbRi_TmloCoe~Qb<0Mn4UTC6ZJq&@*@mvQp{Td@&uzD$zs=Z+CHUM9_g7!_#w0BJ`SP#6`jbEYR=@h{Ib#(0^_Yw={e1Z+Tz#f-TUA2;M7?3#Cf{P&{?>wynb5boM91u!w98M#^i~U9yu0@%90%WMNtcNaAgzl6T%}qTisWxdc!f%5<4|WuVO^BS2Zy%X=uA)sX!w!SO&hpsxIIO+!qD`Eu|RY!{Fc5*ja)m3p>y}dRrYh42|IU&a!Wkjy8|Jq$9r@y4?h2vW*?;i*g&r{h53Yy-*Kvif+)cM*z-S6_2_huCE~5<$Xt0Tt&W{JtuP7I{!++Nc)AgT3Si~mY<>?&(bP6Gq|?|je*>5uB%0*BB?*;0G2Nq`Jv&Mw%rqu5q?mzlXPPEqYzW{(JN8b9ar4iORaalW#2kY&L3^;=y8*AW8a)AGe<qjSn~sS;$UP0%y1_VS0Q}5%deRB2+uzHHPV11_x11ZF?wu%AXiYyTTMKmP^U$MV!_NyvbV~_ylAb!g&65fM<}%uxh}b|%-toeduT={!ZFhEx2+O+b)4$u`8s1$8HH>|nCF$}LAhHxi5qZiruW!!Y-43pjn(~PW2HiwBfa11Jm;!$Pl$UTXbb6#@O@6HlZaUz}k-xYXHeqt}Xs||{%}0P?2d=;nd=BmmoC{@YC?Gb7ojCbZONpDVnP|-euIL2hS3ZC<M3iw|q45>i8RKrx#5>3|9FgrLy?SV=cG3-)V00}?h-Zfx@Y@6NI$n4?s$YrkODx$j|K2l|e}KA$I*oZ?PE_>(AP$K19oGUXu6~Qa+x8!T1Pa`xYyUJ`?LP!+05)V(q*X^b@^3JG;XqCjs{=_epKt;@Q71Qo)3uL*0R1_+_DF0YC$aI2fgCJack^CSU|6rpF*lehAQgr_Xym2RqLoi51h3H{nvxhKe|ChTalU^80v<8BqZEKJ*fWEZ7RN0PM1(}j0qGpHb&^U3W6OT=$V7oEf}wD?&}gO+pHMnd*Uy{oO+p=f2)w7WPCoDhQ6ee)6?^nM0W^&;put7k(*K2X;EuMUx&kFGhOFiHFOWsp(wmP27Zv9x<F|5R8A%$*<2^21>mZ=}(d;&A!#_ELXc&%2N*sQH63v7XiD|k<6D1)y#Q>f@2T(MA5KzQbaqgP7^K>%7G~RhLL#4nyRH(7<vrVC+_XF3O3ND&CLrsfY4v?vnGh$Jf1o)?&deKSq1N|flvPfPB)VK0w#`bkRb22G3zNEoSTVYtG)KHb7CSis+EWh*lXfh_Yw1X3B-My#cM!N^@`F#)0`-TG%@{`irwSx>dyzsGjvAnVO&m3X6eoP;Akl$ZF$UM%mpvGu=k$R{r=c{+p!Q^k~EmqEVz?tev2FzD}o}C7HDdqDb`EjPFEwvfMf=u(m`pI*|K}WK<Rtz0kKMUmt@TsFS)n!~U|HURu#vhY_Ny#O78WzfNGRq%A%|dJkAUX2<kk6_y!Fv^=rNTfWq;rR8@SZ)98TqWr?-yIVl^m<bIy2q~W&^Z@#QPMpiT8xPin0q5aK%`%`B#!ILT4an^II?v1}M6X23z6@)fq_N3x7oqdUDBqD2!S!fwExW;hsKPp+Jm05zPkgluD>7ITSRi`oPi<x2Qq7=h1YGt0So6Ocu(k{Oqy?z9D$?+bx^2FVaWsZ3|e4HhiJFc5~QG*NvZQqr_0fNx)f9w?o$jN(4y!G1TZ(D_{_!G3jm4E({{Uhc88VkHr?u5vgrTsc)PWFjVpKRn1yPWGgJ2)T|pVzjTldG)alYx3ge%@ZV4rlZ~w$Hx5Z#xYHJAMKeO27prIbN>3IQK03GX(_5-gMp8eF!l24sqY0;JU6pFZzZ-)OYkDOQtAfUg4z<6aT3>wcN*#RBX{>K6pflBQ{EA0j-{uRaO}erp>sAs3^Ck{qN*%uN+zD8uoUX|~3u`4<q_ml=Y8hCp<TTIuYgrn&k-a<`MG5B>S<E^m<m8Iibdkq5ng~_&D0*SPzp;-H*&Pdig_WmL6>WjZWSRi+JWgRGZRYn(CLVn(u+F}~)AHOJdKJbD)juAMlb~A}*(ccq5a`!aAOdoU0J-{pg_Vv)8~~SlAg*%&1E!$iR&V2feb0?Vev7K%2SLRb+d5xhm3Zd24K4aBB$#`mMJ20sq|9>UT<lj0CV`S=o>vdSuGACCs{<He`8ppSjV73bh^~0-jnzx;1~%(c3p#R3<<#NmysTA7m`(DvVHRiui0TQ*f_X@XK@Js8OxPn$;W_6T@G{Aq5&4h|JaAEUC%oEmU?8Cj?+D`5`Ods7PB*?l>fN!$-oh>Vh!eJ@w_De{R06uLv$e<kEAmB2t!`A#NuMw`93{k$v_)a%#hbmO-A1?6{8h;p=(lT1+~nNjUl$D;Fh?rcfVagQ3&E(@k)a((;*kLp(^$0m08AaHu>B%zapoQc-X5hTkPi{`V%<A29ca$uOzajGJssbPptcpk5$_yTB#~%*g^~wu<Pl$V)Eg)Y{8kry4hJS(sHQE6C+{iLEq#ImQiJ^E?;hRvT55OGeY&TYN*su^CFSg0-i^^4l+_zVx)WntXztshDk8zWe{9C?KjtYu5saSC>w~3eLUcnQrzOR0k0@iJ?TC{M6Oiku4CGv-J&S39Qi-Z8Vn|{#*I<~4Ha{++HM?FoXKtk*!F&#)b_@!01~b{Fjwro((^NWmUBibwhujmH&yDP>8b&_gz4?Ul<2ael7HbrfmqvDA;7xV>7*uw4rXFc~)kFwVwDN>O&j(KLj!$ZIk<m20N=kyro;c^z2rLG(JE4h~RpS!lQ5~6hKt@~N=33LLNEA2BU)aL~k*B~v|Fkgvt};Tn%rb5dv@L5{SZe20=pLZ>0K{%*n12wLdkfcTIAUIlOVA#R5($@~v<li2Q{SF|->4WgP%a=Yal6SRI{1Bp$IPH-?r9YU?GQ%qJVo<d_gIW^@}#k&8b~5rRWyGHww{XB9Fy}=r9FySF!-aW2&9iO^%>tRF^8jmCw$VhsN)$hWAgayBPNW{VLGj*#F08``3F9hz<%H1qUn<v1xk?mh9w$$uDkZPK3xjF=)kl0^a)b%6c322qgT}Ks?;40k<{+;OOFhWBy~5eIOiyXRL;3_;5|xQqnWuZwDa_w6uk4hp-?nTyaDQ4J-;Gf!!2{&Q|E@9Fb%Bs9o!V8m+J2G1=&K)HlKE<1AYY(IB3H0L|zFh>`Gn*H$XggUF#n6ML_QNa}>t6EB+!h$FEQr$LiS4M2W9*spEPPC5ZvnC056!Jq)P1AIrL)2W&hxGSALC_k}Bpb)#{GQlRT!L|l}Ez%MBJq2oDnAHtC52X;^bbUCHrz=vGCqqCHV(P3xO&-knrl!~33(JvTNsRC{p54}8tE4fQB>u<fG(;K*&IB&Go4M{?*5$YNhQqGFv5Sur8L)`8Ow^{U7#Xge|X|pi%%3nUt4<yhmB$etr{*o2c`nGv`yQx?H*Q!`I?_BzlC(C*9Napz><>(bPXy%jcDgw-J-^ICz){Q1zXG+slH;S?=#T?>ckU8E`Jno2RMkig?8a2B;96XwKq*f_2!<p5iWLx&K9l`=1$>+jKBF7b8*v{-Lqg1<e9nzRBh9Z%aCx|3JTds1vcDo!jb*%a`kwVzqd6C1bJK7k{quQQl(b0=?#TsQkNe|SILnQ*L&k%`=g>~7DTya=A(Mi!!Z+0LDRVl43E5R4>Ii$g7&47oDHWe2KT#JZbym6&0+;OEPuJcR!Dj5FO=@P6?Nuw0&*rh>)Nm-783nv|keN7FS3<X-mqOsKdz<nK-=0+Ec<(N`bUH<jW);krfz%^a8z1+@rn<Gx@i~8K<KOQkpX)bS`-A}I{EqxX>eM}i|sROL|pEorwc=4YdMw*7~;*(Ne-kqI=3}L&eK7F9Pd-bn{A0X~@^s9DU*Pfd-EI|oAglk(1kU^12rsRc&@~OU7idA}u#R|<T7tMw}%;F-_DTEcasZa61yLP9?HfI_dcWe92i@$y$xXwYYYR?W`akhH-_Cpi2HLNHTQ;XM9JrP}YYZ<F`TxFBHYqpPUjE*MsMs0ELPW`2KETlaz4Q08MuY4h0P`L&#zoBT0-&#h>f9O<~V9aQGp4N^0)AM~1KNFZBfBs#+SPHr7y~vL%QCl0whSlwCCa&hyBFS(zl|0<opKQF1Qj5?>WJYOTmVvKg_f+#zqNMs|Q__CkI=DJw75>sSHRO<H1W40!`I(fr@FZVTgaC5k)UaXP8r8pYoM9Vjf|?WE${Wq@tZ%Qsx-xte%;8^sYKqie^tEPow2qrlyS)->zmzDMp7gqHb+Sft?P%o7a9*qF@twyTs-FcD%tA^t6^(-E)z9~gzg2&y!W>0iwQIeJcUt+7{i`EII#DbhEN=6&d0@13yzoVer7Uw^=~Ah|;&4q0U^ye$^Aj2KwFt^W;|(P4i@-;3E=I)>+`>lu+lkwZv7Nx-G<{~Pspe#wbZ;&F;lL(Xa_#^4+%A^6Hv){Zvz{e<iU{jcbc2I@Fs;n?>7gd(V^|+;M-R%#QhU$23H7V84l=QlhM`fp9r{b2ej-s)hx4+=9ad}Hz~pFPJk|$m7S5&-Rr2E^$fFcFZ<&I+c1GNw_bgF0=-x$%9`m%yKl3<K%#;SfSg+&K%N!x(DP2HhRe=&Xl97zmD}G>F+!D@^hdZ&QhHS1(D~PLZ%&l&wy5m|P?6wMo_4$j;phCc_MIemjgxG$!GGV`Qg)U8%DGTc(tN?>T|1aaiW1J%pRVW?wq#Mu8oi`_^w>cq(%`q)yeCUt<C=02^#6*aB!Ws8Ym+6sqao)rv6$_js>_uPI{x*cW5UKK>Ben12ENa>gr&uuglhBp?E=RAwfWjdYVlm@mbIfPgnL0r|H2KiPlLXk_)`1%d3@F>GnHP5nX-D3O>@sFE>h)c73(o|npgCVo@n61FD(|1KljoO?F?9${23C^u5;4l=D>4T$2Q#O}QO}e*G8Sm}ZrZE!fHHMDl%^)UZV}a+@KzBLS|lt4$Qc;<-??sLZ<4`uwKdO&tAoP0wKjWVl>Oqss$v>rVr6X;G?;x6U+J7xbfYWH!lQxA@a;qsvDH_o{=FsEdNPJ0k>FQ~48AtjfJf4b8fvOt{1dCH+n~0no(v^%S7&#nSrZm?0n@8;7UT_o@!!6|DK`Oah4ZCOw(06*+x<MvwCil*g*jF##oyc<JC!+B0ylMz?KQ_9WkGjkjy<mC*tz{#J3U-4eAd$kih4Z-BEHY%e`eM7*Ql?X&>Pu1iRdy{zo!iYTvl;8oKE=2kJ*-yc2ttk+e*5}(PYZbCIwIT=JcSk?ENa#r#1yQZmMwe=2g6bgV#8dL5<rtFm*QXKWlx_W7UG^)h%X}xm3%}?6mor6I^5E0RV)~Ryo3?dyl+1|B!dcajLKi|5#!^-{aLsJ#%!Azlp|Jo_l{4Q!x}TZ?UGOvGl_N5qJ$n49#Daf`}(nka9XaCGJSxDRr3g&OUN7_Yk6$;~vy??kHybh}%62;Bkk|jSb@Ae9bGFeAlomduz%cw*t?pu+w9%?5feSr829;sJE-`v4xO-e(o`#(G3k96?P<DgcdrD7FiIxbFS#l@U?-tx3f9ZCRG9hjf<2=cb4!<iDp}xS)@gKrRQ0e6LJn6eg*pBdCL2vuZ6Dah^y)a0%3Coy-R3vCHdp7XULJlhk^x1;F$26OY$MzP;Uhp3BjRDGpHA}M=DD}Z_K@i(a@FC6GYWeT-w`pr3Jy>lPNK&x&klyIv?(c-si*xO)i3w*rU|Avxhfw>RvPedH3L(u1<^wxdLQW@XprfZvpB`5URd0SmU6AWgfHH+|eSFmBdK(W;;C|>h!p?E$lWPiSUOubxm3jw++3pzALfX_Sdg#F3Kz=pGxVvHWe=HInwpOfTGDxWIYMl#mHZk*sdigA*MaBB+54B2a{}^e19@|eP43Uy><2QUr+nGz09oGSoT8wLld79AV+U1dG#D1`d>=ACYUsHn59}ZmC3Nw3|IE)e$fhbt0>62ape?t>$)$y1MSxDT@xw6SC}(>V~R%AwILK&c23VIOus9;(|PyQ+H~0&X<zZDNv^3k>ED$z{Do|x?U+uhDkW%rlV$sUqhwj!=H*MjGM_h~vGbS8mgU!x3Q>l_g_YQ0T#!-K%KmAEcu`wi0>`*ws;mKB8;vm{al%R{(U%z7Ai*mks|%-$SVXqAgCicG^r-4byp757y}YfoIz1GlPfEwnl+68VPn;Rn`U~`zkPP`({<Y?Jv1C9pIG-<Xti=;f<m4#d8Cdt)u|nC$mdOba7J1ovq*PU2bL9dbeZEA_MBvO4hRr9@trMN*%xOra@o<Bh`#zt}XDq~L74Y&JJ^NdB3qlZ=!RP5=YE%{y-W8MbUMpa5X9p-n&l%H|hXeK6rgIaiBB-T5Q3<f8M|8gL&xUS`rsjpfE${PNmUPf`II=?J3babyMd7OQocnKImA77%w_Y`MULU@W@aqV_j_|AU)~oW?tMb;X^46>J)~oW?tMb;X^49+^%3Bw*TZQd*p}aNMvXMbrqBx$c^bm>Vl7LEt+YjDI1F|4+Dld4G-STVorsB`CmE9r}ZzZHuZCu<&e5+{VH_xhY`O7y5q-TEj^~vo+aqBkERL!TAD%Hh%n$<>VG=To+TGK1g3u67FICLM96DvT=s#s=1BpSe-C_+XYT(qxTb8%;*(Y4)Gjnb6?DLeLbC;e&!E+nt69OaIFjJ3nR6%TX%ik8^2|Mk@}$g6|pFVxGNfAOJvqAOO$Hq_EB{HTbGW_8^8jX;+#ico9uB>#dmmw#TG>q4#S#fMjAx30Y8*eEGdUe~|c&h6`RTn4GQB3{Lzeoma}`ThBzs@Bz=c|nfL_Hd;=w%vli9J;TkI8}$D-mx>mJ(1%o+EMk^>|BCdYjM3S%C#2#+U&*)ifB(XvFfg}pW1we{#I!uG%pN@dvfREw7GT`nJb8WMO=w>4Ida5|MZ!<!7XUnFD6Y-@yyO$QcC{GhE{nduB<oG{UaqDu;iu&em`LJ&=y`!fIZlykxfq7@C4dZOL!`fdVvj%yrcx%Z%HBS(IZvVlh}_PXRV^X6E%sL7y02uZ>-(CLywg9=*`^&?{9mOfm?a``1_tMhrGxO>)QY<du-xqhe6J-0?%5Z7yQQC)_Rvy;YPW_tlx1C;Vesq9{z->e6}}#5HuI3#I6FbN+%0M!aRfoez$xhe;p-!@O3j96`c(iPUP>|JI#Y7vU|}vgYd?G^wjz>j~IL51*k$g@tmK0W1un#H-%f8KHd>I+VX(UO>&DSf*c=ZD%;<fbMaVBA3@}!1{9cUT*>zMCQ*SplG=N`fhedJI5cQ_L4%Y`aD4=-Uy%I)B%>!@h9pM<Xn~-bT69M9s~zpE1MS+yWbG;Q<)c|ndeWz9zDz(sD4Z@ZfDDLGe;RFgu(yDX6)VWn_-tBxPC_9j&xAt_H%bYsvK#D*7yKfM<lVtkZOBI_+3Pnyll<Dkx!pZbw5D%lEZ7o_mM*{*dr|@#LKmLO)eH;61%Qgqb@M`Onb?9oG-L+*OPJYwQ$Q36y|{bYr-__G*DPEQ)Sv}PBwxl9cfe(udeBLvu#k_y<RucujxVoI9Izv?lOAxzmei&F5e;=T*NI`tJJ3P-1)rPY+ADfaaqT^#0eDOV8_@?9o$^1ZbU5J<;;9kaYO#OxWyp`fP%eDQe9G=|vIcPk5dMHx!&5O<<&9Rtu~cW%5fJUI?*ZRHueJeC;0JjKXAc}w?{6qY1kguXy4Jx{UMZjDZIpAaH?uI4w$O?iX_EO+=C@OxBzvB7QNDr2;hXKx7!5Wtk^&aIw$LP{am;00S&+dUO787r{=J60*9pxO#4ZYRo$MeXln2D7gVI(O>d2RT3miI<F~pTH(T~#95A~rZfL(T!WUf#i!&B;xd7C%vMA#xIpxUq!L<u7-$;U<_zRtZf<U#ArG!TM|`JDRg&j&e0f}D8CMY@gy<kTaV%ZtqB3hV`M;x*<8Z;C5;(>1c$&=kky)z!GKG_xMN+W9N8QNx976m{h;;Z0RJico|d<d=NU-)Z7eT@jB$NaROCk%8~@?j5L8RI($I=?HZOF*0!WjlechIVwOPFO8InpgLckt*$Fa5i}w3C?Iq4MZ0no9RJ0~9-okp&ovy{0=_ALw4N$oBM58YYNRJnG-o6j*@1nm#FzGZe@)_RwAJIohwCaD?Kz<@))u7o)z!m=b;wI96pXyM9JE*t+C--@2^raOBQGx&(J$by@<PB1Zq1=<3xN(m|FuKpP69wY+5_hKd<=WSfam{iTy@U3vv6N|2oIzokl^N<dPoc1>>kk>mr{(X2;=xk(*|!7D-E3B?+~eP!+8WGrTogV=+yAGGtQdLEpy;Y!fwIeo3wNe3+)wUQ4aG>VyHQUJ$TE~I2nzpTeQ217OW=*Fs;l0rLCD??YP`obQ+fYek^AnK(N>o*<a(RR-e_uz6I0YEI_+-xdeRYtf(#P<3!tvHb8XCM$-$s+7f#>iu+py!=lN3Fvo`uPM~bju<+(YZ-<UgD)2NO9R|ZoMZ#W%G8q?0ED)44YDF{<Jdg5V@^40A)1Wq(<XapjN6e!qdsy-o%w_){4tfj?'
_V92_P_INDEX = [(0, 24351), (24351, 23453), (47804, 25995), (73799, 23384), (97183, 16234), (113417, 17537), (130954, 22124), (153078, 11768), (164846, 22007), (186853, 18184), (205037, 21673), (226710, 16105), (242815, 17743), (260558, 25579), (286137, 19595), (305732, 14257), (319989, 21574), (341563, 20658), (362221, 21185), (383406, 31913), (415319, 18530), (433849, 25386), (459235, 22171), (481406, 19768), (501174, 21173), (522347, 17644), (539991, 29906), (569897, 26025), (595922, 18397), (614319, 32350), (646669, 15249), (661918, 16105), (678023, 16332), (694355, 20165), (714520, 15688), (730208, 22362), (752570, 15957), (768527, 23124), (791651, 16137), (807788, 14851), (822639, 18035), (840674, 23725), (864399, 19752), (884151, 13858), (898009, 29738), (927747, 27298), (955045, 14888), (969933, 26842), (996775, 18337), (1015112, 18811), (1033923, 16243), (1050166, 12205), (1062371, 16791), (1079162, 18399), (1097561, 27007), (1124568, 19223), (1143791, 27568), (1171359, 15692), (1187051, 18199), (1205250, 14269), (1219519, 27888), (1247407, 19941), (1267348, 20908), (1288256, 31571)]
_V92_P_RAW = None


def _v92_p_lib():
    global _V92_P_LIB, _V92_P_RAW
    if _V92_P_LIB is None:
        _V92_P_LIB = {}
    return _V92_P_LIB


def _v92_p_pair(shops):
    lib = _v92_p_lib()
    if shops in lib:
        return lib[shops]
    global _V92_P_RAW
    names = ['BAKERY', 'BRUNCH_SPOT', 'FARMERS_MARKET', 'ICE_CREAM_SHOP', 'PET_CAFE', 'PIZZA_SHOP', 'SMOOTHIE_SHOP', 'YARN_STORE']
    out = []
    if len(shops) == 2 and shops[0] in names and shops[1] in names:
        if _V92_P_RAW is None:
            _V92_P_RAW = _v92_zlib.decompress(_v92_b64.b85decode(_V92_P_BLOB))
        start, length = _V92_P_INDEX[names.index(shops[0]) * 8 + names.index(shops[1])]
        raw = _V92_P_RAW; pos = start
        n = raw[pos] | raw[pos + 1] << 8; pos += 2
        for _ in range(n):
            m = raw[pos] | raw[pos + 1] << 8; pos += 2
            ev = {}; last = 0
            for _ in range(m):
                d = raw[pos]; pos += 1
                if d == 255:
                    t = raw[pos] | raw[pos + 1] << 8; pos += 2
                else:
                    t = last + d
                ev[(t, raw[pos])] = raw[pos + 1]; pos += 2; last = t
            out.append((-1, ev))
    lib[shops] = out
    return out


def _v92_p_update(obs, st):
    player, step = int(obs["player"]), int(obs["step"])
    race = _V9_RACE.get(player) or {}
    prev = race.get("prev")
    if not prev or prev["step"] != step - 1:
        return
    inv = obs["market"]["inventory"]
    draw = _v9_town_draw(prev["shops"], prev["step"])
    for i, item in enumerate(_V92_P_ITEMS):
        if prev["prices"].get(item, 0) <= 3:
            continue
        sold = inv[item] - prev["inventory"][item] + draw.get(item, 0) - prev["own"].get(item, 0)
        if sold >= 2:
            st["obs"][(step - 1, i)] = sold


def _v92_p_forecast(obs, st):
    step = int(obs["step"])
    shops = tuple(obs["town"]["unlocked_shops"][:2])
    cands = _v92_p_pair(shops)
    if _V92_EP is not None:
        cands = [c for c in cands if c[0] % 2 != _V92_EP % 2]
    seen = st["obs"]
    lo = step - 240
    scored = []
    recent = [(tt, i) for (tt, i) in seen if tt >= lo]
    for ep, ev in cands:
        m = f = 0
        for (tt, i), q in ev.items():
            if lo <= tt < step - 1:
                if (tt, i) in seen or (tt - 1, i) in seen or (tt + 1, i) in seen:
                    m += 1
                else:
                    f += 1
        miss = sum(1 for (tt, i) in recent if (tt, i) not in ev and (tt - 1, i) not in ev and (tt + 1, i) not in ev)
        scored.append((m - 0.5 * f - 0.5 * miss, ev))
    scored.sort(key=lambda x: -x[0])
    return [ev for _, ev in scored[:_V92_P_TOP]]


def _v92_predict(obs, action, st):
    step = int(obs["step"])
    _v92_p_update(obs, st)
    if step < 150 or step >= 700:
        return action
    if step % _V92_P_EVERY == 0 or "best" not in st:
        st["best"] = _v92_p_forecast(obs, st)
    best = st["best"]
    if not best:
        return action
    native = _IMPL.chassis.players.get(int(obs["player"]))
    if not native or native.get("route") not in _IMPL.chassis.routes:
        return action
    tape = _IMPL.chassis.routes[native["route"]]
    market = [list(o) for o in action.get("market") or []]
    already = {o[1] for o in market if len(o) > 1 and o[0] in ("SELL", "BUY_PRODUCT")}
    stock = projected_shed(action, FarmView(obs))
    changed = False
    for i, item in enumerate(_V92_P_ITEMS):
        if item not in _V92_P_USE or item in already or len(market) >= MAX_ORDERS:
            continue
        votes = sum(1 for ev in best if ev.get((step + 1, i), 0) + ev.get((step + 2, i), 0) >= _V92_P_K)
        if votes < 1:
            continue
        ours = 0
        for t in range(step + 1, min(len(tape), step + _V92_P_H + 1)):
            ours += sum(min(100, int(o[2])) for o in (tape[t] or {}).get("market") or []
                        if len(o) >= 3 and o[0] == "SELL" and o[1] == item)
        qty = min(int(stock.get(item, 0)), ours)
        if qty > 0:
            market.insert(0, ["SELL", item, qty])
            _V92_P_REPORT["pred_units"] += qty
            _V92_P_REPORT["pred_fires"] += 1
            changed = True
    if not changed:
        return action
    result = dict(action)
    result["market"] = market[:MAX_ORDERS]
    return result


_V92_P_PARENT = agent


def agent(observation, configuration=None):
    player, step = int(observation["player"]), int(observation["step"])
    st = _V92_P.get(player)
    if st is None or step <= st["step"]:
        st = _V92_P[player] = {"step": -1, "obs": {}}
    st["step"] = step
    action = _V92_P_PARENT(observation, configuration)
    try:
        return _v92_predict(observation, action, st)
    except Exception:
        _V92_P_REPORT["pred_errors"] += 1
        return action


agent.telemetry = _V92_P_REPORT
agent = globals().pop("agent")



import json as _v92_json, os as _v92_os
_V92_Q_ITEMS = ("MILK", "WOOL", "STRAWBERRY")
_V92_Q_H = 48
_V92_Q_K = 4
_V92_Q_PF = 1.0
_V92_Q_PM = 0.5
_V92_Q_CACHE = {}
_V92_Q = {}
_V92_Q_REPORT = dict(pred_units=0, pred_fires=0, pred_errors=0)


def _v92_q_streams():
    """List of (ep, {(tick, item_index): qty}) over MILK/WOOL/STRAWBERRY (item index into _V92_Q_ITEMS)."""
    if "streams" not in _V92_Q_CACHE:
        path = _v92_os.environ.get("V92_SELL_LIB")
        out = []
        if path:
            for x in _v92_json.load(open(path)):
                ev = {(t, i): q for t, i, q in x["ev"] if i <= 2}
                if ev:
                    out.append((x["ep"], ev))
        _V92_Q_CACHE["streams"] = out
    return _V92_Q_CACHE["streams"]


def _v92_q_index(parity):
    key = ("index", parity)
    if key not in _V92_Q_CACHE:
        evs = [ev for ep, ev in _v92_q_streams() if parity is None or ep % 2 != parity]
        index = {}
        for c, ev in enumerate(evs):
            for k in ev:
                index.setdefault(k, []).append(c)
        _V92_Q_CACHE[key] = (evs, index)
    return _V92_Q_CACHE[key]


def _v92_q_new_state():
    parity = None if _V92_EP is None else _V92_EP % 2
    evs, index = _v92_q_index(parity)
    n = len(evs)
    return {"step": -1, "obs": {}, "evs": evs, "index": index, "m": [0] * n, "f": [0] * n, "near": [0] * n,
            "score": [0.0] * n, "best": 0 if n else None, "done": 150}


def _v92_q_update(obs, st):
    player, step = int(obs["player"]), int(obs["step"])
    race = _V9_RACE.get(player) or {}
    prev = race.get("prev")
    seen = st["obs"]
    if prev and prev["step"] == step - 1:
        inv = obs["market"]["inventory"]
        draw = _v9_town_draw(prev["shops"], prev["step"])
        for i, item in enumerate(_V92_Q_ITEMS):
            if prev["prices"].get(item, 0) <= 3:
                continue
            sold = inv[item] - prev["inventory"][item] + draw.get(item, 0) - prev["own"].get(item, 0)
            if sold >= 2:
                seen[(step - 1, i)] = sold
    evs, index = st["evs"], st["index"]
    if not evs:
        return
    m, f, near, score = st["m"], st["f"], st["near"], st["score"]
    best = st["best"]
    rescan = False
    while st["done"] <= step - 2:
        tau = st["done"]
        st["done"] += 1
        for i in range(3):
            hit = (tau, i) in seen or (tau - 1, i) in seen or (tau + 1, i) in seen
            for c in index.get((tau, i), ()):
                if hit:
                    m[c] += 1
                    score[c] += 1.0
                else:
                    f[c] += 1
                    score[c] -= _V92_Q_PF
                    if c == best:
                        rescan = True
            if (tau, i) in seen:
                touched = set(index.get((tau - 1, i), ())) | set(index.get((tau, i), ())) | set(index.get((tau + 1, i), ()))
                for c in touched:
                    near[c] += 1
                    score[c] += _V92_Q_PM
                    if score[c] > score[best]:
                        best = c
            for c in index.get((tau, i), ()):
                if score[c] > score[best]:
                    best = c
    if rescan:
        best = max(range(len(score)), key=score.__getitem__)
    st["best"] = best


def _v92_predict2(obs, action, st):
    step = int(obs["step"])
    _v92_q_update(obs, st)
    if step < 150 or step >= 700 or st["best"] is None:
        return action
    ev = st["evs"][st["best"]]
    native = _IMPL.chassis.players.get(int(obs["player"]))
    if not native or native.get("route") not in _IMPL.chassis.routes:
        return action
    tape = _IMPL.chassis.routes[native["route"]]
    market = [list(o) for o in action.get("market") or []]
    already = {o[1] for o in market if len(o) > 1 and o[0] in ("SELL", "BUY_PRODUCT")}
    stock = None
    changed = False
    for i, item in enumerate(_V92_Q_ITEMS):
        if item in already or len(market) >= MAX_ORDERS:
            continue
        if ev.get((step + 1, i), 0) + ev.get((step + 2, i), 0) < _V92_Q_K:
            continue
        ours = 0
        for t in range(step + 1, min(len(tape), step + _V92_Q_H + 1)):
            ours += sum(min(100, int(o[2])) for o in (tape[t] or {}).get("market") or []
                        if len(o) >= 3 and o[0] == "SELL" and o[1] == item)
        if stock is None:
            stock = projected_shed(action, FarmView(obs))
        qty = min(int(stock.get(item, 0)), ours)
        if qty > 0:
            market.insert(0, ["SELL", item, qty])
            _V92_Q_REPORT["pred_units"] += qty
            _V92_Q_REPORT["pred_fires"] += 1
            changed = True
    if not changed:
        return action
    result = dict(action)
    result["market"] = market[:MAX_ORDERS]
    return result


_V92_Q_PARENT = agent


def agent(observation, configuration=None):
    player, step = int(observation["player"]), int(observation["step"])
    st = _V92_Q.get(player)
    if st is None or step <= st["step"]:
        st = _V92_Q[player] = _v92_q_new_state()
    st["step"] = step
    action = _V92_Q_PARENT(observation, configuration)
    try:
        return _v92_predict2(observation, action, st)
    except Exception:
        _V92_Q_REPORT["pred_errors"] += 1
        return action


agent.telemetry = _V92_Q_REPORT
agent = globals().pop("agent")

V9_RACE_DEFAULT = 40
V9_RACE_MAX = 48
V9_RACE_MARGIN = 12
V9_RACE_GAP = 3            # a sale this soon after our previous planned lot is a late fill
V9_RACE_WINDOW = 30        # turns of tape searched for planned sales around a rival sale
V9_RACE_ITEMS = ("CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL")
_V9_SHOP_ITEMS = {
    "BAKERY": ("EGG", "WHEAT"), "PIZZA_SHOP": ("MILK", "TOMATO", "WHEAT"),
    "BRUNCH_SPOT": ("EGG", "WHEAT", "STRAWBERRY"), "YARN_STORE": ("WOOL",),
    "ICE_CREAM_SHOP": ("STRAWBERRY", "MILK", "WHEAT"), "PET_CAFE": ("CARROT",),
    "SMOOTHIE_SHOP": ("STRAWBERRY", "MILK"),
    "FARMERS_MARKET": ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY"),
}
_V9_RACE = {}
_V9_RACE_REPORT = dict(rival_sales=0, leads=0, race_errors=0)


def _v9_town_draw(shops, step):
    """Units each shop instance and the town centre remove after `step`'s market."""
    draw = dict.fromkeys(V9_RACE_ITEMS, 0)
    if step % 4 == 0:
        for shop in shops:
            items = _V9_SHOP_ITEMS.get(shop, ())
            for item in items:
                if item in draw:
                    draw[item] += 2 if len(items) == 1 else 1
    if step % 24 == 0:
        for item in draw:
            draw[item] += 1
    return draw


def _v9_planned_sells(tape, item, step):
    """Turns within V9_RACE_WINDOW of `step` at which the tape sells `item`."""
    out = []
    for t in range(max(0, step - V9_RACE_WINDOW), min(len(tape), step + V9_RACE_WINDOW + 1)):
        if any(o and o[0] == "SELL" and len(o) >= 3 and o[1] == item and int(o[2]) > 0
               for o in tape[t].get("market") or []):
            out.append(t)
    return out


def _v9_race_update(obs, st):
    """Recover last turn's rival sales and record the leads that prove racing."""
    prev = st["prev"]
    step = int(obs["step"])
    if not prev or prev["step"] != step - 1:
        return
    native = _IMPL.chassis.players.get(int(obs["player"]))
    if not native or native.get("route") not in _IMPL.chassis.routes:
        return
    tape = _IMPL.chassis.routes[native["route"]]
    inventory = obs["market"]["inventory"]
    draw = _v9_town_draw(prev["shops"], prev["step"])
    t = prev["step"]
    for item in V9_RACE_ITEMS:
        if prev["prices"].get(item, 0) <= 3:
            continue
        sold = inventory[item] - prev["inventory"][item] + draw[item] - prev["own"].get(item, 0)
        if sold < 2:
            continue
        _V9_RACE_REPORT["rival_sales"] += 1
        if prev["left"].get(item, 0) <= 0:
            continue
        planned = _v9_planned_sells(tape, item, t)
        after = [s for s in planned if s >= t]
        before = [s for s in planned if s < t]
        if not after or (before and t - before[-1] < V9_RACE_GAP):
            continue
        st["lead"] = max(st["lead"], after[0] - t)
        _V9_RACE_REPORT["leads"] += 1


_V9_RACE_PARENT = agent


def agent(observation, configuration=None):
    player, step = int(observation["player"]), int(observation["step"])
    st = _V9_RACE.get(player)
    if st is None or step <= st["step"]:
        st = _V9_RACE[player] = {"step": -1, "lead": -V9_RACE_MARGIN, "prev": None}
        if step == 0:
            _V9_RACE_REPORT.update(rival_sales=0, leads=0, race_errors=0)
    st["step"] = step
    try:
        _v9_race_update(observation, st)
        horizon = min(V9_RACE_MAX, max(V9_RACE_DEFAULT, st["lead"] + V9_RACE_MARGIN))
        _V9_ITEM_HZ[player] = dict.fromkeys(V9_RACE_ITEMS, horizon)
    except Exception:
        _V9_RACE_REPORT["race_errors"] += 1
        _V9_ITEM_HZ.pop(player, None)
    action = _V9_RACE_PARENT(observation, configuration)
    try:
        stock = projected_shed(action, FarmView(observation))
        own = {}
        for o in action.get("market") or []:
            if o and o[0] == "SELL" and len(o) >= 3 and o[1] in V9_RACE_ITEMS:
                n = min(max(0, int(o[2])), max(0, stock.get(o[1], 0) - own.get(o[1], 0)))
                own[o[1]] = own.get(o[1], 0) + n
        st["prev"] = {"step": step, "inventory": dict(observation["market"]["inventory"]),
                      "prices": dict(observation["market"]["prices"]), "own": own,
                      "left": {item: stock.get(item, 0) - own.get(item, 0) for item in V9_RACE_ITEMS},
                      "shops": list(observation["town"]["unlocked_shops"])}
    except Exception:
        _V9_RACE_REPORT["race_errors"] += 1
        st["prev"] = None
    return action


agent.telemetry = _V9_RACE_REPORT
agent = globals().pop("agent")


V9_RACEPX_BASE = {"WHEAT": 25, "CARROT": 35, "TOMATO": 60, "STRAWBERRY": 120, "MELON": 250,
                  "EGG": 50, "MILK": 160, "WOOL": 200, "FERTILIZER": 100}
V9_RACEPX_MARGIN = 0
_v9_racepx_report = dict(racepx_skipped=0, racepx_sold=0, racepx_errors=0)
_V9_RACEPX_LEAD = Chassis._sell_lead


def _v9_racepx_lead(self, action, view, projected, route, step, next_sup):
    prices = view.prices
    blocked = {i for i in V9_RACEPX_BASE
               if prices.get(i, 0) <= V9_RACEPX_BASE[i] + V9_RACEPX_MARGIN}
    if not blocked:
        _v9_racepx_report["racepx_sold"] += 1
        return _V9_RACEPX_LEAD(self, action, view, projected, route, step, next_sup)
    nxt = step + 1
    unlock_period = 3 * self.cfg["turns_per_day"]
    if nxt > LAST_ACT_STEP or nxt % unlock_period == 0 or step % 4 == 0:
        return
    tape = self.routes[route]
    future = tape[nxt] if nxt < len(tape) and isinstance(tape[nxt], dict) else {}
    planned = {}
    for o in future.get("market") or []:
        if o and o[0] == "SELL" and len(o) >= 3 and o[1] in PRODUCTS:
            planned[o[1]] = planned.get(o[1], 0) + max(0, int(o[2]))
    already = {o[1] for o in action.get("market") or [] if o and o[0] == "SELL" and len(o) > 1}
    for item in PRODUCTS:
        if item in blocked or item in already or planned.get(item, 0) <= 0:
            continue
        qty = min(projected.get(item, 0), planned[item])
        if qty <= 0 or prices.get(item, 0) < self.cfg["min_sell_price"]:
            continue
        if not self._add_sell(action, item, qty, self.cfg["max_orders"], merge=False):
            break
        projected[item] -= qty
        next_sup["suppress"][item] = next_sup["suppress"].get(item, 0) + qty
        _v9_racepx_report["racepx_skipped"] += 1
    if next_sup["suppress"]:
        next_sup["due_step"] = nxt


_V9_RACEPX_PARENT = agent
Chassis._sell_lead = _v9_racepx_lead


def agent(observation, configuration=None):
    if int(observation["step"]) == 0:
        _v9_racepx_report.update(racepx_skipped=0, racepx_sold=0, racepx_errors=0)
    try:
        return _V9_RACEPX_PARENT(observation, configuration)
    except Exception:
        _v9_racepx_report["racepx_errors"] += 1
        return {"farmer": ["PASS"], "hands": [], "market": []}


agent.telemetry = _v9_racepx_report
agent = globals().pop("agent")


V9_RACEGATE_BASE = {"WHEAT": 25, "CARROT": 35, "TOMATO": 60, "STRAWBERRY": 120, "MELON": 250,
                    "EGG": 50, "MILK": 160, "WOOL": 200, "FERTILIZER": 100}
V9_RACEGATE_MARGIN = 0
_v9_racegate_report = dict(racegate_reserved_units=0, racegate_errors=0)
_V9_RACEGATE_RESERVE = _r36_reserve


def _r36_reserve(obs, action):
    step = int(obs["step"])
    if not 192 <= step < 696:
        return action
    prices = obs["market"]["prices"]
    glutted = {i for i in V9_RACEGATE_BASE
               if prices.get(i, 0) <= V9_RACEGATE_BASE[i] + V9_RACEGATE_MARGIN}
    if not glutted:
        return _V9_RACEGATE_RESERVE(obs, action)
    native = _IMPL.chassis.players[int(obs["player"])]
    tape = _IMPL.chassis.routes[native["route"]]
    _v9_hz = _V9_ITEM_HZ.get(int(obs["player"]))
    end = min(695, step + (max(_v9_hz.values()) if _v9_hz else _R37_HORIZONS.get(int(obs["player"]), 2)))
    if end <= step:
        return action
    commands = [action.get("farmer") or ["PASS"], *(action.get("hands") or [])]
    view = FarmView(obs)
    if any(len(c) > 1 and c[0] == "PLACE" and c[1] in ANIMAL_STRUCTURE
           and view.inv(i).get(c[1], 0) > 0 for i, c in enumerate(commands[:len(view.positions)])):
        return action
    stock = projected_shed(action, view)
    market = action.get("market", [])
    blocked = {o[1] for o in market if len(o) > 1 and o[0] in ("SELL", "BUY_PRODUCT")}
    blocked.update(c[1] for c in commands if len(c) > 1 and c[0] == "PICKUP")
    blocked.update(c[1] for queue in native["pending"].values() for pos, c in queue
                   if len(c) > 1 and c[0] == "PICKUP")
    debts = native["sell_state"].setdefault("r36_debts", {})
    for item in PRODUCTS:
        if item in blocked or item in glutted or view.prices.get(item, 0) < 2:
            continue
        available = max(0, int(stock.get(item, 0)))
        if not available or len(market) >= 10:
            continue
        reservations = []
        item_end = min(end, step + _v9_hz[item]) if _v9_hz and item in _v9_hz else end
        for due_step in range(step + 1, item_end + 1):
            future = tape[due_step]
            work = [future.get("farmer") or ["PASS"], *(future.get("hands") or [])]
            if any(len(c) > 1 and c[:2] == ["PICKUP", item] for c in work):
                break
            if any(len(o) > 1 and o[:2] == ["BUY_PRODUCT", item] for o in future.get("market", [])):
                break
            planned = sum(max(0, int(o[2])) for o in future.get("market", [])
                          if len(o) >= 3 and o[:2] == ["SELL", item])
            amount = min(available, max(0, planned - debts.get(due_step, {}).get(item, 0)))
            if amount:
                reservations.append((due_step, amount))
                available -= amount
            if not available:
                break
        qty = sum(q for _, q in reservations)
        if qty:
            market.append(["SELL", item, qty])
            for due, q in reservations:
                debt = debts.setdefault(due, {})
                debt[item] = debt.get(item, 0) + q
            _R36_SALE_REPORT["sale_reserved_units"] += qty
            _R36_SALE_REPORT["sale_reservations"] += 1
            _v9_racegate_report["racegate_reserved_units"] += qty
    return action


_V9_RACEGATE_PARENT = agent


def agent(observation, configuration=None):
    if int(observation["step"]) == 0:
        _v9_racegate_report.update(racegate_reserved_units=0, racegate_errors=0)
    try:
        return _V9_RACEGATE_PARENT(observation, configuration)
    except Exception:
        _v9_racegate_report["racegate_errors"] += 1
        return {"farmer": ["PASS"], "hands": [], "market": []}


agent.telemetry = _v9_racegate_report
agent = globals().pop("agent")


_P_ctrtable_336053 = agent

CT_TABLE = {
    (979.0, 9989): ((7, 0, ("BUY_PRODUCT", "WHEAT", 5)), (7, 1, ("SELL", "WHEAT", 5)),
                    (8, 0, ("BUY_PRODUCT", "WHEAT", 5)), (8, 1, ("SELL", "WHEAT", 5))),
    (33.0, 9990): ((3, 0, ("BUY_PRODUCT", "WHEAT", 20)), (3, 1, ("SELL", "WHEAT", 20))),
}
_CT = {}
_CT_REPORT = dict(ct_fired=0, ct_errors=0)


def _ct_apply(obs, action, st):
    step = int(obs["step"])
    if step == 2:
        rival = obs["farms"][1 - int(obs["player"])]
        st["plan"] = CT_TABLE.get((round(float(rival["money"]), 3), int(obs["market"]["inventory"]["WHEAT"])))
        if st["plan"]:
            _CT_REPORT["ct_fired"] += 1
    plan = st.get("plan")
    if not plan:
        return action
    items = sorted((slot, list(o)) for t, slot, o in plan if t == step)
    if not items:
        return action
    market = [list(o) for o in action.get("market") or []]
    for slot, o in items:
        while len(market) < slot:
            market.append(["SELL", "WHEAT", 0])
        market.insert(slot, o)
    result = dict(action)
    result["market"] = market[:MAX_ORDERS]
    return result


def agent(observation, configuration=None):
    player, step = int(observation["player"]), int(observation["step"])
    st = _CT.get(player)
    if st is None or step <= st["step"]:
        st = _CT[player] = {"step": -1}
    st["step"] = step
    action = _P_ctrtable_336053(observation, configuration)
    try:
        return _ct_apply(observation, action, st)
    except Exception:
        _CT_REPORT["ct_errors"] += 1
        return action


agent.telemetry = _CT_REPORT
agent = globals().pop("agent")


_P_overflow_338343 = agent

_OV_REPORT = dict(ov_turns=0, ov_units=0, ov_errors=0)


def _ov_fields(obs, action):
    farm, private = _PLANNER_NS['_clone_state'](obs['farms'][obs['player']], obs['private'])
    commands = [action.get('farmer') or ['PASS'], *(action.get('hands') or [])]
    demand = {}
    for c in commands:
        if len(c) > 1 and c[0] == 'PLANT':
            demand[c[1]] = demand.get(c[1], 0) + 1
    blocked = {p for p, n in demand.items() if n > private['seeds'].get(p, 0)}
    for actor, c in enumerate(commands[:len(private['inventories'])]):
        if len(c) > 1 and c[0] == 'PLANT' and c[1] in blocked:
            continue
        _PLANNER_NS['_apply_unit_action'](farm, private, actor, c, 10, int(obs['step']) // 24, 24, 100)
    return farm, private


def _ov_same(a, b):
    return all(int(a.get(p, 0)) == int(b.get(p, 0)) for p in set(a) | set(b))


def _ov_apply(obs, action):
    if int(obs['step']) % 24 != 23:
        return action
    orders = action.get('market') or []
    if len(orders) >= 10 or not _r97_budget(obs, orders):
        return action
    _, private = _ov_fields(obs, action)
    stock, _, _ = _r97_market_stock(private['shed'], orders)
    original, loss = _r97_delivery(stock, private, True)
    if not loss:
        return action
    remaining = max(0, 100 - sum(stock.values()))
    tail = []
    for bag in private['inventories']:
        for item, n in bag.items():
            n = max(0, int(n)); take = min(n, remaining); remaining -= take
            if n > take:
                tail.extend([item] * (n - take))
    released = {}; best = None
    for item in tail:
        released[item] = released.get(item, 0) + 1
        if item not in obs['market']['prices'] or released[item] > stock.get(item, 0):
            break
        if len(orders) + len(released) > 10:
            break
        proposed = list(orders) + [['SELL', p, n] for p, n in released.items()]
        after, _, _ = _r97_market_stock(private['shed'], proposed)
        final, _ = _r97_delivery(after, private, True)
        if _ov_same(original, final):
            best = (proposed, dict(released))
    if best is None:
        return action
    _OV_REPORT['ov_turns'] += 1
    _OV_REPORT['ov_units'] += sum(best[1].values())
    return dict(action, market=best[0])


def agent(observation, configuration=None):
    action = _P_overflow_338343(observation, configuration)
    try:
        return _ov_apply(observation, action)
    except Exception:
        _OV_REPORT['ov_errors'] += 1
        return action


agent.telemetry = _OV_REPORT
agent = globals().pop("agent")


_SL_REQUEST = _v233_request
_SL_WORKER = _v233_worker
_SL_REPORT = dict(compact_days=0, confirmed=0, collect=0)
_SL_TILES = ((5,5),(6,5),(7,5),(7,6),(6,6),(5,6))


def _sl_dist(a,b):
    return abs(a[0]-b[0])+abs(a[1]-b[1])


def _sl_path(pos,targets):
    return min(_r53_permutations(targets),key=lambda path:(_sl_dist(pos,path[0])+sum(_sl_dist(a,b) for a,b in zip(path,path[1:])),path)) if targets else ()


def _v233_request(obs,action,state,native):
    result=_SL_REQUEST(obs,action,state,native)
    pending=state.get('pending')
    if result is action or not pending or pending['initial']:
        return result
    farm=obs['farms'][obs['player']];hour=int(obs['step'])%24
    tiles=[farm['tiles'][y][x] for x,y in _SL_TILES]
    if not all(isinstance(t,dict) and t.get('animal')=='SHEEP' and t.get('yield_units',0)==0 for t in tiles):
        return result
    ready,spawn=_r62_input_start(obs,action,0)
    path=_sl_path(spawn,_SL_TILES)
    travel=_sl_dist(spawn,path[0])+sum(_sl_dist(a,b) for a,b in zip(path,path[1:]))
    mandatory=sum(not t.get('fed_today') for t in tiles)+sum(not t.get('cared_today') for t in tiles)
    available=min((int(obs['step'])//24+1)*24,719)-ready
    if travel+mandatory>available:
        return result
    native_hires=sum(o and o[0]=='HIRE' for o in action.get('market',[]))
    saved=_v219_fib(farm['hires_today']+native_hires+1)
    delivery=_sl_dist(path[-1],_v219_home(path[-1]))+1 if int(obs['step'])//24==29 else 0
    possible=max(0,min(6,available-travel-mandatory-delivery))
    if saved<=(6-possible)*obs['market']['prices']['FERTILIZER']:
        return result
    out=copy.deepcopy(result)
    assert out['market'][-2:]==[['HIRE'],['HIRE']]
    out['market'].pop()
    pending.update(count=1,targets=path)
    _V233_REPORT['sheep_hire_requests']-=1
    _SL_REPORT['compact_days']+=1
    return out


def _v233_worker(obs,actor,targets):
    if len(targets)!=6:
        return _SL_WORKER(obs,actor,targets)
    farm=obs['farms'][obs['player']];private=obs['private'];step=int(obs['step'])
    pos=tuple(farm['hands'][actor-1]);inv=private['inventories'][actor]
    needed=[];hungry=0
    for target in targets:
        x,y=target;t=farm['tiles'][y][x]
        if not isinstance(t,dict) or t.get('animal')!='SHEEP':
            return _SL_WORKER(obs,actor,targets)
        if not t['fed_today']:hungry+=1
        if not t['fed_today'] or not t['cared_today']:needed.append(target)
    home=_v219_home(pos)
    if hungry>inv.get('WHEAT',0):
        return _v219_walk(pos,home) or ['PICKUP','WHEAT',min(hungry,private['shed'].get('WHEAT',0))]
    if needed:
        path=_sl_path(pos,needed)
        current=farm['tiles'][pos[1]][pos[0]]
        if pos in targets and isinstance(current,dict) and current.get('fed_today') and current.get('cared_today') and current.get('fertilizer_available'):
            travel=_sl_dist(pos,path[0])+sum(_sl_dist(a,b) for a,b in zip(path,path[1:]))
            work=sum(not farm['tiles'][y][x]['fed_today'] for x,y in path)+sum(not farm['tiles'][y][x]['cared_today'] for x,y in path)
            delivery=_sl_dist(path[-1],_v219_home(path[-1]))+1 if step//24==29 else 0
            remaining=min((step//24+1)*24,719)-step
            if 1+travel+work+delivery<=remaining:
                _SL_REPORT['collect']+=1
                return ['COLLECT_FERTILIZER']
        target=path[0];t=farm['tiles'][target[1]][target[0]]
        return _v219_walk(pos,target) or (['FEED'] if not t['fed_today'] else ['CARE'])
    remaining=719-step if step//24==29 else 24-step%24
    tasks=[]
    for target in targets:
        t=farm['tiles'][target[1]][target[0]]
        if not t.get('fertilizer_available'):continue
        dist=_sl_dist(pos,target)
        ret=_sl_dist(target,_v219_home(target))+1 if step//24==29 else 0
        if dist+1+ret<=remaining:tasks.append((dist,tuple(target)))
    if tasks:
        _,target=min(tasks)
        command=_v219_walk(pos,target) or ['COLLECT_FERTILIZER']
        _SL_REPORT['collect']+=command==['COLLECT_FERTILIZER']
        return command
    if inv.get('FERTILIZER',0):
        return _v219_walk(pos,home) or ['PLACE','FERTILIZER',inv['FERTILIZER']]
    return ['PASS']


agent=globals().pop('agent')


_VE_ELIGIBLE = _v233_eligible
_VE_REPORT = dict(ve_day11_checks=0, ve_day11_budget_declines=0, ve_day11_ok=0)
_VE_SEED = {'WHEAT': 10, 'CARROT': 20, 'TOMATO': 50, 'STRAWBERRY': 100, 'MELON': 80}
_VE_ANIMAL = {'SHEEP': 500, 'COW': 400, 'GOOSE': 300}


def _v233_eligible(obs, native):
    step = int(obs['step'])
    if step // 24 != 11:
        return _VE_ELIGIBLE(obs, native)
    tape = _IMPL.chassis.routes[native['route']]
    private = obs['private']
    held = int(private['shed'].get('SHEEP', 0)) + sum(int(i.get('SHEEP', 0)) for i in private['inventories'])
    pickups = 0
    for t in range(step, 12 * 24):
        for c in [tape[t].get('farmer')] + tape[t].get('hands', []):
            if c and c[0] == 'PICKUP' and len(c) > 1 and c[1] == 'SHEEP':
                pickups += int(c[2]) if len(c) > 2 else 1
    if held > pickups:
        return False
    clean = dict(private, shed=dict(private['shed'], SHEEP=0),
                 inventories=[{k: v for k, v in i.items() if k != 'SHEEP'} for i in private['inventories']])
    if not _VE_ELIGIBLE(dict(obs, private=clean), native):
        return False
    _VE_REPORT['ve_day11_checks'] += 1
    prices = obs['market']['prices']
    spend = 0
    hires = {}
    for t in range(step + 1, min(len(tape), 13 * 24)):
        for o in tape[t].get('market', []):
            if not o:
                continue
            if o[0] == 'BUY_LAND' or o[:2] == ['BUY_ANIMAL', 'SHEEP']:
                return False
            if o[0] == 'BUY_SEED':
                spend += int(o[2]) * _VE_SEED.get(o[1], 100)
            elif o[0] == 'BUY_PRODUCT':
                spend += int(o[2]) * (int(prices.get(o[1], 50)) + 10)
            elif o[0] == 'BUY_ANIMAL':
                spend += int(o[2]) * _VE_ANIMAL.get(o[1], 500)
            elif o[0] == 'HIRE':
                d = t // 24
                spend += _v219_fib(hires.get(d, 0))
                hires[d] = hires.get(d, 0) + 1
    if obs['farms'][obs['player']]['money'] < 7000 + 3000 + spend:
        _VE_REPORT['ve_day11_budget_declines'] += 1
        return False
    _VE_REPORT['ve_day11_ok'] += 1
    return True


agent.telemetry = _VE_REPORT
agent = globals().pop('agent')


_VT_REQUEST = _v233_request
_VT_WORKER = _v233_worker
_VT_RESCUE = _v234_rescue
_VT_REPORT = dict(vt_no_hire_days=0, vt_single_harvest_days=0, vt_skipped_care=0)
_VT_TILES = ((5, 5), (6, 5), (7, 5), (5, 6), (6, 6), (7, 6))


def _vt_wool_tiles(obs):
    farm = obs['farms'][obs['player']]
    return [xy for xy in _VT_TILES if isinstance(farm['tiles'][xy[1]][xy[0]], dict)
            and farm['tiles'][xy[1]][xy[0]].get('animal') == 'SHEEP' and farm['tiles'][xy[1]][xy[0]].get('yield_units', 0) > 0]


def _v233_request(obs, action, state, native):
    result = _VT_REQUEST(obs, action, state, native)
    if result is action or int(obs['step']) // 24 != 29 or not state.get('committed'):
        return result
    pending = state.get('pending')
    if not pending or pending.get('initial'):
        return result
    wool = _vt_wool_tiles(obs)
    extra = result['market'][len(action.get('market', [])):]
    if not wool:
        state.pop('pending', None)
        _V233_REPORT['sheep_hire_requests'] -= sum(o == ['HIRE'] for o in extra)
        _V233_REPORT['sheep_feed_buy_requests'] -= 6
        _VT_REPORT['vt_no_hire_days'] += 1
        return action
    out = copy.deepcopy(action)
    out['market'] = list(out.get('market', [])) + [['HIRE']]
    _V233_REPORT['sheep_hire_requests'] -= sum(o == ['HIRE'] for o in extra) - 1
    _V233_REPORT['sheep_feed_buy_requests'] -= 6
    pending.update(count=1, targets=_sl_path(_r62_input_start(obs, action, 0)[1], wool))
    _VT_REPORT['vt_single_harvest_days'] += 1
    return out


def _v233_worker(obs, actor, targets):
    step = int(obs['step'])
    day = step // 24
    if day not in (28, 29):
        return _VT_WORKER(obs, actor, targets)
    farm = obs['farms'][obs['player']]
    private = obs['private']
    pos = tuple(farm['hands'][actor - 1])
    inv = private['inventories'][actor]
    home = _v219_home(pos)
    distance = abs(pos[0] - home[0]) + abs(pos[1] - home[1])
    cargo = [item for item in ('WOOL', 'FERTILIZER') if inv.get(item, 0)]
    last = 717 if day == 29 else day * 24 + 23
    if cargo and step >= last - distance:
        return _v219_walk(pos, home) or ['PLACE', cargo[0], inv[cargo[0]]]
    sheep = [(x, y) for x, y in targets if isinstance(farm['tiles'][y][x], dict) and farm['tiles'][y][x].get('animal') == 'SHEEP']
    tasks = []
    if day == 28:
        hungry = sum(not farm['tiles'][y][x]['fed_today'] for x, y in sheep)
        if hungry and not inv.get('WHEAT', 0) and private['shed'].get('WHEAT', 0):
            return _v219_walk(pos, home) or ['PICKUP', 'WHEAT', min(hungry, private['shed']['WHEAT'])]
    for x, y in sheep:
        tile = farm['tiles'][y][x]
        command = None
        if day == 28 and not tile['fed_today'] and inv.get('WHEAT', 0):
            command = ['FEED']
        elif tile['yield_units']:
            command = ['HARVEST']
        elif day == 28 and tile['fertilizer_available']:
            command = ['COLLECT_FERTILIZER']
        if day == 28 and not tile['cared_today'] and command is None:
            _VT_REPORT['vt_skipped_care'] += 1
        if command:
            tasks.append((abs(pos[0] - x) + abs(pos[1] - y), (x, y), command))
    if tasks:
        _, target, command = min(tasks)
        return _v219_walk(pos, target) or command
    if cargo:
        return _v219_walk(pos, home) or ['PLACE', cargo[0], inv[cargo[0]]]
    return ['PASS']


def _v234_rescue(obs, action, state):
    if int(obs['step']) // 24 == 29:
        return action
    return _VT_RESCUE(obs, action, state)


agent.telemetry = _VT_REPORT
agent = globals().pop('agent')


_CA_FROM = 6
_CA_TO = 28
_CA_MARGIN = -15.0
_CA_DROP = 0.0
_CA_BUFFER = 8
_CA_FEED_DAYS = 1
_CA_CASH = 800
_CA_RESCUE = True
_CA_MOVES = {"NORTH": (0, -1), "SOUTH": (0, 1), "EAST": (1, 0), "WEST": (-1, 0)}
_CA_CROP = {"WHEAT": (4, 6), "CARROT": (3, 4)}
_CA_STATE = {}
_CA_REPORT = {"ca_swaps": 0, "ca_rescues": 0, "ca_harvested": 0, "ca_sold": 0, "ca_seed_bought": 0,
              "ca_wheat_seed_saved": 0, "ca_carrot_seed_saved": 0, "ca_feed_block": 0, "ca_errors": 0,
              "ca_min_wheat": 999}


def _ca_tape(seat, t):
    native = _IMPL.chassis.players.get(seat)
    if not native or t > 719:
        return {}
    tape = _IMPL.chassis.routes[2 if t >= 648 else native["route"]]
    return tape[t] if t < len(tape) and isinstance(tape[t], dict) else {}


def _ca_spawn(positions, board):
    half = board // 2
    access = [(half - 1, half - 1), (half, half - 1), (half - 1, half), (half, half)]
    occ = {a: 0 for a in access}
    for p in positions:
        if tuple(p) in occ:
            occ[tuple(p)] += 1
    return list(min(access, key=lambda a: (occ[a], access.index(a))))


def _ca_visits(obs, action, pos, t_end, start=None):
    """Non-move commands issued on tile ``pos`` from this step (with ``action``) until ``t_end``."""
    seat = int(obs["player"])
    step = int(obs["step"])
    farm = obs["farms"][seat]
    board = len(farm["tiles"])
    half = board // 2
    positions = [list(farm["farmer"])] + [list(h) for h in farm["hands"]]
    out = []
    for t in range(step, min(t_end, 719) + 1):
        act = action if t == step else _ca_tape(seat, t)
        units = [act.get("farmer") or ["PASS"]] + list(act.get("hands") or [])
        for i in range(len(positions)):
            cmd = units[i] if i < len(units) and units[i] else ["PASS"]
            if cmd[0] in _CA_MOVES:
                dx, dy = _CA_MOVES[cmd[0]]
                nx, ny = positions[i][0] + dx, positions[i][1] + dy
                if 0 <= nx < board and 0 <= ny < board:
                    positions[i] = [nx, ny]
            elif tuple(positions[i]) == pos and (start is None or t >= start):
                out.append((t, i, cmd[0]))
        for _ in range(sum(1 for o in (act.get("market") or []) if o and o[0] == "HIRE")):
            positions.append(_ca_spawn(positions, board))
        if t % 24 == 23:
            positions = [[half - 1, half - 1]]
    return out


def _ca_decays(mls, a, b):
    """Decay events at steps s in [max(a, mls), b) with (s - mls) even."""
    a = max(a, mls)
    if b <= a:
        return 0
    first = a if (a - mls) % 2 == 0 else a + 1
    return 0 if first >= b else (b - 1 - first) // 2 + 1


def _ca_yield_path(crop, planted, visits, y0=1, fert_until=-1, watered_day=-1, now_step=0):
    """Return (harvest_units, best_rescue_units, rescue_step) for a crop following ``visits``.
    ``y0`` is the yield observed at ``now_step`` (decay before that step already included)."""
    myd, cap = _CA_CROP[crop]
    lo = (myd + 1) // 2
    mls = (planted + myd + 1) * 24
    y = y0
    best_rescue, rescue_t = 0, None
    for t, i, op in visits:
        day = t // 24
        age = day - planted
        dec = _ca_decays(mls, now_step, t)
        now = y - dec
        if now <= 0 and t > mls:
            return 0, best_rescue, rescue_t
        if op == "HARVEST":
            return (max(0, now) if age >= 2 else 0), best_rescue, rescue_t
        if op in ("PLANT", "DIG", "BUILD_COOP", "BUILD_PASTURE"):
            return 0, best_rescue, rescue_t
        if age >= 2 and now > best_rescue and t > now_step:
            best_rescue, rescue_t = now, t
        if op == "WATER" and lo <= age <= myd and day != watered_day:
            watered_day = day
            y = min(cap, y + (2 if fert_until >= day else 1))
    return 0, best_rescue, rescue_t


def _ca_wheat_total(obs):
    priv = obs["private"]
    return int(priv["shed"].get("WHEAT", 0)) + sum(int(inv.get("WHEAT", 0)) for inv in priv["inventories"])


def _ca_feed_need(seat, step, days):
    need = 0
    for t in range(step, min(719, step + 24 * days) + 1):
        act = _ca_tape(seat, t)
        units = [act.get("farmer") or ["PASS"]] + list(act.get("hands") or [])
        need += sum(1 for c in units if c and c[0] == "FEED")
    return need


_CA_PARENT = agent
del agent


def agent(observation, configuration=None):
    action = _CA_PARENT(observation, configuration)
    try:
        step = int(observation["step"])
        seat = int(observation["player"])
        st = _CA_STATE.get(seat)
        if step == 0 or st is None or step <= st["step"]:
            st = _CA_STATE[seat] = {"step": -1, "tiles": {}, "spare_wheat": 0, "spare_carrot": 0, "credit": 0}
            if step == 0:
                _CA_REPORT.update(ca_swaps=0, ca_rescues=0, ca_harvested=0, ca_sold=0, ca_seed_bought=0,
                                  ca_wheat_seed_saved=0, ca_carrot_seed_saved=0, ca_feed_block=0,
                                  ca_errors=0, ca_min_wheat=999)
        st["step"] = step
        if not isinstance(action, dict) or step > 717:
            return action
        day = step // 24
        farm = observation["farms"][seat]
        tiles = farm["tiles"]
        priv = observation["private"]
        prices = observation["market"]["prices"]
        p_c, p_w = int(prices.get("CARROT", 0)), int(prices.get("WHEAT", 0))
        positions = [tuple(farm["farmer"])] + [tuple(h) for h in farm["hands"]]
        units = [list(action.get("farmer") or ["PASS"])] + [list(c) for c in (action.get("hands") or [])]
        market = [list(o) for o in (action.get("market") or [])]
        changed = False
        if _CA_FROM <= day <= _CA_TO + 4:
            _CA_REPORT["ca_min_wheat"] = min(_CA_REPORT["ca_min_wheat"], _ca_wheat_total(observation))
        for pos, planted in list(st["tiles"].items()):
            tile = tiles[pos[1]][pos[0]]
            if not (isinstance(tile, dict) and tile.get("crop") == "CARROT" and int(tile.get("planted_day", -9)) == planted):
                st["tiles"].pop(pos, None)
                continue
            here = [i for i, p in enumerate(positions) if p == pos and i < len(units)]
            if not here:
                continue
            i = here[0]
            cmd = units[i]
            yu = int(tile.get("yield_units", 0))
            if cmd and cmd[0] == "HARVEST":
                if day - planted >= 2 and yu > 0:
                    st["credit"] += yu
                    _CA_REPORT["ca_harvested"] += yu
                    st["tiles"].pop(pos, None)
                continue
            if not _CA_RESCUE or (cmd and cmd[0] in _CA_MOVES) or day - planted < 2 or yu <= 0:
                continue
            visits = _ca_visits(observation, action, pos, (planted + 5) * 24)
            harvest, later, _ = _ca_yield_path("CARROT", planted, visits, y0=yu,
                                               fert_until=int(tile.get("fertilized_until_day", -1)),
                                               watered_day=day if tile.get("watered_today") else -1,
                                               now_step=step)
            if yu > max(harvest, later):
                units[i] = ["HARVEST"]
                st["credit"] += yu
                _CA_REPORT["ca_harvested"] += yu
                _CA_REPORT["ca_rescues"] += 1
                st["tiles"].pop(pos, None)
                changed = True
        pays_now = 3 * (p_c - _CA_DROP) - 20 > 4 * p_w - 10 + _CA_MARGIN
        if _CA_FROM <= day <= _CA_TO and pays_now:
            seeds_c = min(st["spare_carrot"],
                          int(priv["seeds"].get("CARROT", 0)) - sum(1 for c in units if c[:2] == ["PLANT", "CARROT"]))
            wheat_ok = None
            for i, cmd in enumerate(units):
                if cmd[:2] != ["PLANT", "WHEAT"] or i >= len(positions) or seeds_c <= 0:
                    continue
                pos = positions[i]
                if tiles[pos[1]][pos[0]] is not None:
                    continue
                if wheat_ok is None:
                    wheat_ok = _ca_wheat_total(observation) >= _ca_feed_need(seat, step, _CA_FEED_DAYS)
                if not wheat_ok:
                    _CA_REPORT["ca_feed_block"] += 1
                    break
                visits = _ca_visits(observation, action, pos, (day + 6) * 24, start=step + 1)
                wu, _, _ = _ca_yield_path("WHEAT", day, visits)
                ch, cr, _ = _ca_yield_path("CARROT", day, visits)
                cu = max(ch, cr if _CA_RESCUE else 0)
                if cu * (p_c - _CA_DROP) - 20 > wu * p_w - 10 + _CA_MARGIN:
                    units[i] = ["PLANT", "CARROT"]
                    seeds_c -= 1
                    st["spare_carrot"] -= 1
                    st["tiles"][pos] = day
                    st["spare_wheat"] += 1
                    _CA_REPORT["ca_swaps"] += 1
                    changed = True
        new_market = []
        for o in market:
            if len(o) >= 3 and o[0] == "BUY_SEED" and o[1] in ("WHEAT", "CARROT"):
                key = "spare_wheat" if o[1] == "WHEAT" else "spare_carrot"
                cut = min(int(o[2]), st[key])
                if cut > 0:
                    st[key] -= cut
                    _CA_REPORT["ca_wheat_seed_saved" if o[1] == "WHEAT" else "ca_carrot_seed_saved"] += cut
                    changed = True
                    if int(o[2]) - cut <= 0:
                        continue
                    o = [o[0], o[1], int(o[2]) - cut]
            new_market.append(o)
        market = new_market
        if _CA_FROM <= day <= _CA_TO - 1 and pays_now and len(market) < 10:
            have = int(priv["seeds"].get("CARROT", 0)) - sum(1 for c in units if c[:2] == ["PLANT", "CARROT"])
            buying = sum(int(o[2]) for o in market if len(o) >= 3 and o[:2] == ["BUY_SEED", "CARROT"])
            q = _CA_BUFFER - have - buying
            if q > 0 and int(farm.get("money", 0)) >= _CA_CASH + 20 * q:
                market.append(["BUY_SEED", "CARROT", q])
                st["spare_carrot"] += q
                _CA_REPORT["ca_seed_bought"] += q
                changed = True
        if st["credit"] > 0 and p_c >= 2 and len(market) < 10:
            view_action = {"farmer": units[0], "hands": units[1:], "market": market}
            stock = int(projected_shed(view_action, FarmView(observation)).get("CARROT", 0))
            selling = sum(int(o[2]) for o in market if len(o) >= 3 and o[:2] == ["SELL", "CARROT"])
            q = min(st["credit"], stock - selling)
            if q > 0:
                market.insert(0, ["SELL", "CARROT", q])
                st["credit"] -= q
                _CA_REPORT["ca_sold"] += q
                changed = True
        if changed:
            action = dict(action)
            action["farmer"] = units[0]
            action["hands"] = units[1:]
            action["market"] = market[:10]
    except Exception:
        _CA_REPORT["ca_errors"] += 1
    return action


agent.telemetry = _CA_REPORT
agent = globals().pop('agent')


_OR2_CAP = 30
_OR2_SN_K = 0
_OR2_SN_H = 24
_OR2_SLOT_H = 6
_OR2_SLOT_MARGIN = 8.0
_OR2_SN_ITEMS = ("MILK", "STRAWBERRY", "WOOL", "MELON", "EGG")
_OR2_ITEMS = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL")
_OR2_ONGOING = ("TOMATO", "STRAWBERRY")
_OR2_ANIMAL = {"GOOSE": "EGG", "COW": "MILK", "SHEEP": "WOOL"}
_OR2_SHOPS = {"BAKERY": ("EGG", "WHEAT"), "PIZZA_SHOP": ("MILK", "TOMATO", "WHEAT"),
              "BRUNCH_SPOT": ("EGG", "WHEAT", "STRAWBERRY"), "YARN_STORE": ("WOOL",),
              "ICE_CREAM_SHOP": ("STRAWBERRY", "MILK", "WHEAT"), "PET_CAFE": ("CARROT",),
              "SMOOTHIE_SHOP": ("STRAWBERRY", "MILK"),
              "FARMERS_MARKET": ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY")}
_OR2_STATE = {}
_OR2_REPORT = {"or2_reordered": 0, "or2_changed_vs_v39": 0, "or2_rival_harvest": 0, "or2_rival_sold": 0,
               "or2_errors": 0}


def _or2_draw(shops, step):
    draw = {}
    if step % 4 == 0:
        for name in shops:
            products = _OR2_SHOPS.get(name, ())
            for item in products:
                draw[item] = draw.get(item, 0) + (2 if len(products) == 1 else 1)
    if step % 24 == 0:
        for item in _OR2_ITEMS:
            draw[item] = draw.get(item, 0) + 1
    return draw


def _or2_tiles(farm):
    out = {}
    for y, row in enumerate(farm["tiles"]):
        for x, t in enumerate(row):
            if not isinstance(t, dict):
                continue
            if t.get("kind") == "PLANT" and t.get("crop"):
                out[(x, y)] = ("P", t["crop"], int(t.get("planted_day", -1)), int(t.get("yield_units", 0)))
            elif t.get("animal") in _OR2_ANIMAL:
                out[(x, y)] = ("A", _OR2_ANIMAL[t["animal"]], int(t.get("placed_day", -1)), int(t.get("yield_units", 0)))
    return out


def _or2_exposure(observation, item, qty, batch):
    if qty <= 0 or batch <= 0 or item not in _R37_MARKET_PARAMS:
        return 0.0
    params = {k: dict(v) for k, v in _R37_MARKET_PARAMS.items()}
    for k, patch in (observation["market"].get("params") or {}).items():
        if k in params:
            params[k].update(patch)
    inv = int(observation["market"]["inventory"][item])
    return float(sum(_r37_market_price(item, inv + j, params) - _r37_market_price(item, inv + batch + j, params)
                     for j in range(qty)))


_OR2_PARENT = agent
del agent


def agent(observation, configuration=None):
    action = _OR2_PARENT(observation, configuration)
    try:
        step = int(observation["step"])
        seat = int(observation["player"])
        st = _OR2_STATE.get(seat)
        if step == 0 or st is None or step <= st.get("step", -1):
            st = _OR2_STATE[seat] = {"step": -1, "stock": {i: 0 for i in _OR2_ITEMS}, "prev": None}
            if step == 0:
                for k in _OR2_REPORT:
                    _OR2_REPORT[k] = 0
        rival = observation["farms"][1 - seat]
        tiles = _or2_tiles(rival)
        inv_now = {i: int(observation["market"]["inventory"].get(i, 0)) for i in _OR2_ITEMS}
        prev = st["prev"]
        if prev and prev["step"] == step - 1:
            stock = st["stock"]
            for pos, old in prev["tiles"].items():
                kind, item, born, y = old
                if y <= 0:
                    continue
                new = tiles.get(pos)
                got = 0
                if kind == "P" and item not in _OR2_ONGOING:
                    if (new is None and not _OR2_WEED(rival, pos)) or (new is not None and new[2] != born):
                        got = y
                elif new is not None and new[0] == kind and new[1] == item and new[2] == born and new[3] < y:
                    if step % 24 != 0:
                        got = y - new[3]
                    elif new[3] == 0:
                        got = y
                if got > 0:
                    stock[item] = stock.get(item, 0) + got
                    _OR2_REPORT["or2_rival_harvest"] += got
            draw = _or2_draw(prev["shops"], prev["step"])
            for item in _OR2_ITEMS:
                if prev["prices"].get(item, 0) <= 1:
                    continue
                moved = inv_now[item] - prev["inv"][item] + draw.get(item, 0) - prev["own"].get(item, 0)
                if moved > 0:
                    stock[item] = max(0, stock.get(item, 0) - moved)
                    _OR2_REPORT["or2_rival_sold"] += moved
        own = {}
        if isinstance(action, dict):
            orders = [list(o) for o in (action.get("market") or [])]
            proj = dict(projected_shed(action, FarmView(observation)))
            if _OR2_SN_K > 0 and 24 <= step < 694:
                native = _IMPL.chassis.players.get(seat)
                debts = native["sell_state"].setdefault("r36_debts", {}) if native else None
                for item in _OR2_SN_ITEMS:
                    if debts is None or int(st["stock"].get(item, 0)) < _OR2_SN_K:
                        continue
                    if int(observation["market"]["prices"].get(item, 0)) < 2 or len(orders) >= 10:
                        continue
                    if any(len(o) >= 2 and o[0] in ("BUY_PRODUCT", "BUY_ANIMAL") and o[1] == item for o in orders):
                        continue
                    selling = sum(max(0, int(o[2])) for o in orders if len(o) >= 3 and o[0] == "SELL" and o[1] == item)
                    avail = int(proj.get(item, 0)) - selling
                    take = 0
                    for t in range(step + 1, min(694, step + _OR2_SN_H) + 1):
                        if take >= avail:
                            break
                        tape = _IMPL.chassis.routes[2 if t >= 648 else native["route"]]
                        act = tape[t] if t < len(tape) and isinstance(tape[t], dict) else {}
                        planned = sum(max(0, int(o[2])) for o in (act.get("market") or [])
                                      if len(o) >= 3 and o[0] == "SELL" and o[1] == item)
                        planned -= debts.get(t, {}).get(item, 0)
                        q = min(planned, avail - take)
                        if q > 0:
                            debts.setdefault(t, {})[item] = debts.get(t, {}).get(item, 0) + q
                            take += q
                    if take > 0:
                        for o in orders:
                            if len(o) >= 3 and o[0] == "SELL" and o[1] == item:
                                o[2] = int(o[2]) + take
                                break
                        else:
                            orders.append(["SELL", item, take])
                        _OR2_REPORT["or2_sellnow"] = _OR2_REPORT.get("or2_sellnow", 0) + take
                        action = dict(action)
                        action["market"] = orders
            if _OR2_SLOT_H > 0 and 288 <= step < 694 and len(orders) >= 10:
                native = _IMPL.chassis.players.get(seat)
                debts = native["sell_state"].setdefault("r36_debts", {}) if native else None
                sells = [o for o in orders if len(o) >= 3 and o[0] == "SELL"]
                selling_items = {o[1] for o in sells}
                bought_items = {o[1] for o in orders if len(o) >= 2 and o[0] in ("BUY_PRODUCT", "BUY_ANIMAL")}
                best = None
                for item in _OR2_SN_ITEMS:
                    if debts is None or item in selling_items or item in bought_items:
                        continue
                    avail = int(proj.get(item, 0))
                    if avail <= 0 or int(observation["market"]["prices"].get(item, 0)) < 2:
                        continue
                    plan, take = [], 0
                    for t in range(step + 1, min(694, step + _OR2_SLOT_H) + 1):
                        if take >= avail:
                            break
                        tape = _IMPL.chassis.routes[2 if t >= 648 else native["route"]]
                        act = tape[t] if t < len(tape) and isinstance(tape[t], dict) else {}
                        planned = sum(max(0, int(o[2])) for o in (act.get("market") or [])
                                      if len(o) >= 3 and o[0] == "SELL" and o[1] == item)
                        q = min(planned - debts.get(t, {}).get(item, 0), avail - take)
                        if q > 0:
                            plan.append((t, q))
                            take += q
                    if take <= 0:
                        continue
                    b = min(_OR2_CAP, int(st["stock"].get(item, 0)))
                    value = _or2_exposure(observation, item, take, max(1, b))
                    if best is None or value > best[0]:
                        best = (value, item, take, plan)
                if best is not None and sells:
                    def sval(o):
                        q = min(max(0, int(o[2])), max(0, int(proj.get(o[1], 0))))
                        return _or2_exposure(observation, o[1], q, max(1, min(_OR2_CAP, int(st["stock"].get(o[1], 0)))))
                    weakest = min(sells, key=sval)
                    if best[0] > sval(weakest) + _OR2_SLOT_MARGIN and weakest[1] not in ("WHEAT", "FERTILIZER")                             or best[0] > sval(weakest) + _OR2_SLOT_MARGIN and int(weakest[2]) <= 2:
                        refund = max(0, int(weakest[2]))
                        for t in range(step + 1, step + 49):
                            if refund <= 0:
                                break
                            owed = debts.get(t, {}).get(weakest[1], 0)
                            back = min(owed, refund)
                            if back > 0:
                                debts[t][weakest[1]] = owed - back
                                refund -= back
                        orders.remove(weakest)
                        orders.append(["SELL", best[1], best[2]])
                        for t, q in best[3]:
                            debts.setdefault(t, {})[best[1]] = debts.get(t, {}).get(best[1], 0) + q
                        _OR2_REPORT["or2_slot_swaps"] = _OR2_REPORT.get("or2_slot_swaps", 0) + 1
                        action = dict(action)
                        action["market"] = orders
            left = dict(proj)
            movable, fixed, bought = [], [], set()
            for idx, o in enumerate(orders):
                if len(o) >= 2 and o[0] in ("BUY_PRODUCT", "BUY_ANIMAL"):
                    bought.add(o[1])
                if len(o) >= 3 and o[0] == "SELL" and int(o[2]) > 0 and o[1] not in bought:
                    movable.append((idx, o))
                else:
                    fixed.append((idx, o))
            if movable and step >= 1:
                def score(io):
                    item, qty = io[1][1], min(int(io[1][2]), max(0, int(proj.get(io[1][1], 0))))
                    b = min(_OR2_CAP, int(st["stock"].get(item, 0)))
                    return (-_or2_exposure(observation, item, qty, b),
                            -_r37_quote_priority(observation, io[1], proj), io[0])
                scored = sorted(movable, key=score)
                new = [o for _, o in scored] + [o for _, o in fixed]
                if new != orders:
                    v39 = sorted(movable, key=lambda io: (-_r37_quote_priority(observation, io[1], proj), io[0]))
                    if [o for _, o in v39] != [o for _, o in scored]:
                        _OR2_REPORT["or2_changed_vs_v39"] += 1
                    _OR2_REPORT["or2_reordered"] += 1
                    action = dict(action)
                    action["market"] = new
                    orders = new
            for o in orders[:10]:
                if len(o) >= 3 and o[0] == "SELL" and o[1] in _OR2_ITEMS:
                    got = min(max(0, int(o[2])), max(0, int(left.get(o[1], 0))))
                    left[o[1]] = left.get(o[1], 0) - got
                    own[o[1]] = own.get(o[1], 0) + got
        st["prev"] = {"step": step, "tiles": tiles, "inv": inv_now, "own": own,
                      "prices": dict(observation["market"]["prices"]),
                      "shops": list((observation.get("town") or {}).get("unlocked_shops") or [])}
        st["step"] = step
    except Exception:
        _OR2_REPORT["or2_errors"] += 1
    return action


def _OR2_WEED(farm, pos):
    t = farm["tiles"][pos[1]][pos[0]]
    return isinstance(t, dict) and t.get("kind") == "WEED"


agent.telemetry = _OR2_REPORT
agent = globals().pop('agent')


_CH_SHED = 90
_CH_SELL = True
_CH_ANIMALS = {"GOOSE": ("EGG", 4, 4, 1), "COW": ("MILK", 6, 8, 2), "SHEEP": ("WOOL", 6, 6, 3)}
_CH_MOVES = {"NORTH": (0, -1), "SOUTH": (0, 1), "EAST": (1, 0), "WEST": (-1, 0)}
_CH_STATE = {}
_CH_REPORT = {"ch_collect_swaps": 0, "ch_care_swaps": 0, "ch_saved": 0, "ch_sold": 0, "ch_shed_block": 0,
              "ch_errors": 0}


def _ch_tape(seat, t):
    native = _IMPL.chassis.players.get(seat)
    if not native or t > 719:
        return {}
    tape = _IMPL.chassis.routes[2 if t >= 648 else native["route"]]
    return tape[t] if t < len(tape) and isinstance(tape[t], dict) else {}


def _ch_visits_today(obs, action):
    """{pos: [(t, op)]} for non-move commands from the next step to the end of today."""
    seat = int(obs["player"])
    step = int(obs["step"])
    farm = obs["farms"][seat]
    board = len(farm["tiles"])
    half = board // 2
    access = [(half - 1, half - 1), (half, half - 1), (half - 1, half), (half, half)]
    positions = [list(farm["farmer"])] + [list(h) for h in farm["hands"]]
    out = {}
    for t in range(step, (step // 24 + 1) * 24):
        act = action if t == step else _ch_tape(seat, t)
        units = [act.get("farmer") or ["PASS"]] + list(act.get("hands") or [])
        for i in range(len(positions)):
            cmd = units[i] if i < len(units) and units[i] else ["PASS"]
            if cmd[0] in _CH_MOVES:
                dx, dy = _CH_MOVES[cmd[0]]
                nx, ny = positions[i][0] + dx, positions[i][1] + dy
                if 0 <= nx < board and 0 <= ny < board:
                    positions[i] = [nx, ny]
            elif t > step:
                out.setdefault(tuple(positions[i]), []).append((t, cmd[0]))
        for _ in range(sum(1 for o in (act.get("market") or []) if o and o[0] == "HIRE")):
            occ = {a: 0 for a in access}
            for p in positions:
                if tuple(p) in occ:
                    occ[tuple(p)] += 1
            positions.append(list(min(access, key=lambda a: (occ[a], access.index(a)))))
    return out


_CH_PARENT = agent
del agent


def agent(observation, configuration=None):
    action = _CH_PARENT(observation, configuration)
    try:
        step = int(observation["step"])
        seat = int(observation["player"])
        st = _CH_STATE.get(seat)
        if step == 0 or st is None or step <= st["step"]:
            st = _CH_STATE[seat] = {"step": -1, "credit": {}}
            if step == 0:
                for k in _CH_REPORT:
                    _CH_REPORT[k] = 0
        st["step"] = step
        if not isinstance(action, dict) or step > 717:
            return action
        day = step // 24
        farm = observation["farms"][seat]
        priv = observation["private"]
        prices = observation["market"]["prices"]
        positions = [tuple(farm["farmer"])] + [tuple(h) for h in farm["hands"]]
        units = [list(action.get("farmer") or ["PASS"])] + [list(c) for c in (action.get("hands") or [])]
        market = [list(o) for o in (action.get("market") or [])]
        changed = False
        visits = None
        for i, pos in enumerate(positions[:len(units)]):
            cmd = units[i]
            if not cmd or cmd[0] not in ("CARE", "COLLECT_FERTILIZER"):
                continue
            tile = farm["tiles"][pos[1]][pos[0]]
            if not (isinstance(tile, dict) and tile.get("animal") in _CH_ANIMALS):
                continue
            product, cap, first, interval = _CH_ANIMALS[tile["animal"]]
            since = day + 1 - int(tile.get("placed_day", 99)) - first
            if since < 0 or since % interval != 0:
                continue
            y = int(tile.get("yield_units", 0))
            if visits is None:
                visits = _ch_visits_today(observation, action)
            later = visits.get(pos, [])
            if any(op == "HARVEST" for t, op in later):
                continue
            fed = bool(tile.get("fed_today")) or any(op == "FEED" for t, op in later)
            prod = 1 + (int(tile.get("pending_care_bonus", 0)) if fed else 0)
            overflow = y + prod - cap
            if overflow <= 0 or y <= 0:
                continue
            quote = int(prices.get(product, 0))
            if cmd[0] == "COLLECT_FERTILIZER":
                if overflow * quote <= int(prices.get("FERTILIZER", 0)):
                    continue
            else:
                if any(op == "COLLECT_FERTILIZER" for t, op in later) or overflow <= 1:
                    continue
            carried = sum(int(v) for inv in priv["inventories"] for v in inv.values())
            if sum(int(v) for v in priv["shed"].values()) + carried + y >= _CH_SHED:
                _CH_REPORT["ch_shed_block"] += 1
                continue
            units[i] = ["HARVEST"]
            _CH_REPORT["ch_collect_swaps" if cmd[0] == "COLLECT_FERTILIZER" else "ch_care_swaps"] += 1
            saved = overflow if cmd[0] == "COLLECT_FERTILIZER" else overflow - 1
            _CH_REPORT["ch_saved"] += saved
            st["credit"][product] = st["credit"].get(product, 0) + saved
            changed = True
        if _CH_SELL and any(v > 0 for v in st["credit"].values()):
            view_action = {"farmer": units[0], "hands": units[1:], "market": market}
            stock = dict(projected_shed(view_action, FarmView(observation)))
            for product, credit in list(st["credit"].items()):
                if credit <= 0 or len(market) >= 10 or int(prices.get(product, 0)) < 2:
                    continue
                selling = sum(int(o[2]) for o in market if len(o) >= 3 and o[:2] == ["SELL", product])
                q = min(credit, int(stock.get(product, 0)) - selling)
                if q > 0:
                    for o in market:
                        if len(o) >= 3 and o[:2] == ["SELL", product]:
                            o[2] = int(o[2]) + q
                            break
                    else:
                        market.insert(0, ["SELL", product, q])
                    st["credit"][product] = credit - q
                    _CH_REPORT["ch_sold"] += q
                    changed = True
        if changed:
            action = dict(action)
            action["farmer"] = units[0]
            action["hands"] = units[1:]
            action["market"] = market[:10]
    except Exception:
        _CH_REPORT["ch_errors"] += 1
    return action


agent.telemetry = _CH_REPORT
agent = globals().pop('agent')


_SR_MARGIN = 8
_SR_HOURS = (21, 22, 23)
_SR_PRODUCTS = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER")
_SR_REPORT = {"sr_turns": 0, "sr_units": 0, "sr_errors": 0}


def _sr_tape(seat, t):
    native = _IMPL.chassis.players.get(seat)
    if not native or t > 719:
        return {}
    tape = _IMPL.chassis.routes[2 if t >= 648 else native["route"]]
    return tape[t] if t < len(tape) and isinstance(tape[t], dict) else {}


_SR_PARENT = agent
del agent


def agent(observation, configuration=None):
    action = _SR_PARENT(observation, configuration)
    try:
        step = int(observation["step"])
        if step == 0:
            for k in _SR_REPORT:
                _SR_REPORT[k] = 0
        if step % 24 not in _SR_HOURS or step >= 717 or not isinstance(action, dict):
            return action
        seat = int(observation["player"])
        farm = observation["farms"][seat]
        priv = observation["private"]
        view = FarmView(observation)
        proj = dict(projected_shed(action, view))
        market = [list(o) for o in (action.get("market") or [])]
        left = dict(proj)
        night_shed = sum(max(0, int(v)) for v in proj.values())
        for o in market:
            if len(o) >= 3 and o[0] == "SELL":
                got = min(max(0, int(o[2])), max(0, int(left.get(o[1], 0))))
                left[o[1]] = left.get(o[1], 0) - got
                night_shed -= got
            elif len(o) >= 3 and o[0] in ("BUY_PRODUCT", "BUY_ANIMAL"):
                night_shed += max(0, int(o[2]))
        units = [action.get("farmer") or ["PASS"]] + list(action.get("hands") or [])
        carried = 0
        for i, pos in enumerate(view.positions):
            inv = priv["inventories"][i] if i < len(priv["inventories"]) else {}
            held = sum(max(0, int(v)) for v in inv.values())
            cmd = units[i] if i < len(units) and units[i] else ["PASS"]
            tile = farm["tiles"][pos[1]][pos[0]] if isinstance(pos, (list, tuple)) else None
            op = cmd[0]
            if op == "DROP" and _shed_adjacent(pos, view.board):
                held = 0
            elif op == "HARVEST" and isinstance(tile, dict):
                held += max(0, int(tile.get("yield_units", 0)))
            elif op == "COLLECT_FERTILIZER" and isinstance(tile, dict) and tile.get("fertilizer_available"):
                held += 1
            elif op in ("FEED", "FERTILIZE") and held > 0:
                held -= 1
            elif op == "PICKUP" and len(cmd) >= 2 and _shed_adjacent(pos, view.board):
                held += max(1, int(cmd[2]) if len(cmd) >= 3 else 1)
            carried += held
        cap = int((configuration or {}).get("shedCapacity", 100)) if isinstance(configuration, dict) else 100
        overflow = night_shed + carried - cap + _SR_MARGIN
        if overflow <= 0:
            return action
        need = {"WHEAT": 0, "FERTILIZER": 0}
        for t in range(step + 1, min(719, step + 25)):
            act = _sr_tape(seat, t)
            for c in [act.get("farmer") or ["PASS"]] + list(act.get("hands") or []):
                if not c:
                    continue
                if c[0] == "FEED":
                    need["WHEAT"] += 1
                elif c[0] == "FERTILIZE":
                    need["FERTILIZER"] += 1
        prices = observation["market"]["prices"]
        cands = []
        for item in _SR_PRODUCTS:
            spare = int(left.get(item, 0)) - need.get(item, 0)
            if spare > 0 and int(prices.get(item, 0)) >= 2:
                cands.append((int(prices.get(item, 0)), item, spare))
        cands.sort()
        sold_now = 0
        for price, item, spare in cands:
            if overflow <= 0:
                break
            q = min(spare, overflow)
            for o in market:
                if len(o) >= 3 and o[:2] == ["SELL", item]:
                    o[2] = int(o[2]) + q
                    break
            else:
                if len(market) >= 10:
                    continue
                market.append(["SELL", item, q])
            overflow -= q
            sold_now += q
        if sold_now:
            _SR_REPORT["sr_turns"] += 1
            _SR_REPORT["sr_units"] += sold_now
            action = dict(action)
            action["market"] = market
    except Exception:
        _SR_REPORT["sr_errors"] += 1
    return action


agent.telemetry = _SR_REPORT
agent = globals().pop('agent')


_HD2_FROM = 192
_HD2_TO = 360
_HD2_RATIO = 1.3
_HD2_MIN_GAIN = 600.0
_HD2_LOOKBACK = 3
_HD2_OPTIONS = ('COW', 'SHEEP')
_HD2_CARE = 0.8
_HD2_FUTURE = 0.0

_HD2_SPEC = {
    "GOOSE": {"cost": 300, "first": 4, "interval": 1, "per": 2, "product": "EGG", "structure": "COOP"},
    "COW": {"cost": 400, "first": 8, "interval": 2, "per": 3, "product": "MILK", "structure": "PASTURE"},
    "SHEEP": {"cost": 500, "first": 6, "interval": 3, "per": 4, "product": "WOOL", "structure": "PASTURE"},
}
_HD2_SHOP_TYPES = {
    "BAKERY": ("EGG", "WHEAT"), "PIZZA_SHOP": ("MILK", "TOMATO", "WHEAT"),
    "BRUNCH_SPOT": ("EGG", "WHEAT", "STRAWBERRY"), "YARN_STORE": ("WOOL",),
    "ICE_CREAM_SHOP": ("STRAWBERRY", "MILK", "WHEAT"), "PET_CAFE": ("CARROT",),
    "SMOOTHIE_SHOP": ("STRAWBERRY", "MILK"), "FARMERS_MARKET": ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY"),
}
_HD2_STATE = {}
_HD2_REPORT = {"hd2_decision": "", "hd2_ev": "", "hd2_rewrites": 0, "hd2_credit_units": 0,
               "hd2_sold_units": 0, "hd2_errors": 0}


def _hd2_daily_shop_demand(item, shops):
    total = 0.0
    for name in shops:
        products = _HD2_SHOP_TYPES.get(name, ())
        if item in products:
            total += 6.0 * (2 if len(products) == 1 else 1)
    return total


def _hd2_future_demand_per_day(item):
    """Expected extra daily demand of one more uniformly drawn shop instance."""
    return sum(6.0 * (2 if len(p) == 1 else 1) for p in _HD2_SHOP_TYPES.values() if item in p) / len(_HD2_SHOP_TYPES)


def _hd2_schedule(animal, placed_day, day_from):
    """Units an animal of this type produces on each day >= day_from (daily care assumed,
    scaled by _HD2_CARE)."""
    spec = _HD2_SPEC[animal]
    out = {}
    for d in range(max(day_from, placed_day + spec["first"]), 30):
        if (d - placed_day - spec["first"]) % spec["interval"] == 0:
            out[d] = out.get(d, 0.0) + 1.0 + (spec["per"] - 1) * _HD2_CARE
    return out


def _hd2_ev(option, k, obs, st):
    """Margin value of k new animals of `option`: their own revenue, plus the price change
    their supply causes on (our existing future units - rival existing future units)."""
    spec = _HD2_SPEC[option]
    item = spec["product"]
    animal_of = {"EGG": "GOOSE", "MILK": "COW", "WOOL": "SHEEP"}[item]
    day = int(obs["step"]) // 24
    seat = int(obs["player"])
    market = obs["market"]
    params = {key: dict(v) for key, v in _R37_MARKET_PARAMS.items()}
    for key, patch in (market.get("params") or {}).items():
        if key in params and isinstance(patch, dict):
            params[key].update(patch)
    existing = [dict(), dict()]
    for farm_index, farm in enumerate(obs["farms"]):
        for row in farm["tiles"]:
            for tile in row:
                if isinstance(tile, dict) and tile.get("animal") == animal_of:
                    for d, u in _hd2_schedule(animal_of, int(tile.get("placed_day", day)), day + 1).items():
                        existing[farm_index][d] = existing[farm_index].get(d, 0.0) + u
    shed = (obs.get("private") or {}).get("shed") or {}
    carried = sum(int(inv.get(animal_of, 0)) for inv in (obs.get("private") or {}).get("inventories") or [])
    for _ in range(int(shed.get(animal_of, 0)) + carried):
        for d, u in _hd2_schedule(animal_of, day + 1, day + 1).items():
            existing[seat][d] = existing[seat].get(d, 0.0) + u
    native = _IMPL.chassis.players.get(seat)
    if native:
        similar = _r37_similarity(obs) >= 0.9
        for t in range(int(obs["step"]) + 1, 696):
            tape = _IMPL.chassis.routes[2 if t >= 648 else native["route"]]
            if t >= len(tape) or not isinstance(tape[t], dict):
                continue
            for order in tape[t].get("market", []) or []:
                if len(order) >= 3 and order[0] == "BUY_ANIMAL" and order[1] == animal_of:
                    for _ in range(max(0, int(order[2]))):
                        for d, u in _hd2_schedule(animal_of, t // 24 + 1, day + 1).items():
                            existing[seat][d] = existing[seat].get(d, 0.0) + u
                            if similar:
                                existing[1 - seat][d] = existing[1 - seat].get(d, 0.0) + u
    ours_existing, rival_existing = existing[seat], existing[1 - seat]
    new = {}
    for d, u in _hd2_schedule(option, day + 1, day + 1).items():
        new[d] = u * k
    shops = list((obs.get("town") or {}).get("unlocked_shops") or [])
    unlocks_left = max(0, 8 - len(shops))
    base_demand = _hd2_daily_shop_demand(item, shops) + 1.0
    extra_demand = _hd2_future_demand_per_day(item) * _HD2_FUTURE

    def path(with_new):
        inv = float(market["inventory"][item])
        prices, revenue = {}, 0.0
        for d in range(day + 1, 30):
            opened = min(unlocks_left, max(0, (d // 3) - (day // 3)))
            inv -= base_demand + extra_demand * opened
            inv += ours_existing.get(d, 0.0) + rival_existing.get(d, 0.0)
            prices[d] = _r37_market_price(item, int(round(inv)), params)
            if with_new:
                units = int(round(new.get(d, 0.0)))
                for _ in range(units):
                    price = _r37_market_price(item, int(round(inv)), params)
                    revenue += price
                    if price > 1:
                        inv += 1
        return prices, revenue

    base_prices, _ = path(False)
    new_prices, revenue = path(True)
    swing = sum((new_prices[d] - base_prices[d]) * (ours_existing.get(d, 0.0) - rival_existing.get(d, 0.0))
                for d in base_prices)
    return revenue + swing - spec["cost"] * k, revenue


def _hd2_decide(obs, action, st):
    market = action.get("market") or []
    buys = [o for o in market if len(o) >= 3 and o[0] == "BUY_ANIMAL" and o[1] == "GOOSE"]
    if not buys:
        return
    st["decided"] = True
    step = int(obs["step"])
    if not (_HD2_FROM <= step < _HD2_TO):
        return
    farm = obs["farms"][int(obs["player"])]
    if any(isinstance(t, dict) and t.get("kind") == "COOP" for row in farm["tiles"] for t in row):
        _HD2_REPORT["hd2_decision"] = "skip:coop_exists"
        return
    k = sum(max(0, int(o[2])) for o in buys)
    k_plan = max(k, 3)
    evs = {opt: _hd2_ev(opt, k_plan, obs, st)[0] for opt in ("GOOSE",) + tuple(_HD2_OPTIONS)}
    _HD2_REPORT["hd2_ev"] = ",".join("%s:%d" % (o, v) for o, v in sorted(evs.items()))
    best = max(_HD2_OPTIONS, key=lambda o: evs[o]) if _HD2_OPTIONS else None
    goose = evs["GOOSE"]
    if best is None:
        return
    gain = evs[best] - goose
    ok_ratio = evs[best] >= _HD2_RATIO * max(goose, 1.0)
    extra_cost = (_HD2_SPEC[best]["cost"] - 300) * k
    cash = float(farm.get("money", 0))
    if gain >= _HD2_MIN_GAIN and ok_ratio and cash >= 300 * k + extra_cost + 50:
        st["mode"] = best
        _HD2_REPORT["hd2_decision"] = "%s@%d" % (best, step)
    else:
        _HD2_REPORT["hd2_decision"] = "keep@%d" % step


def _hd2_rewrite(obs, action, st):
    mode = st["mode"]
    spec = _HD2_SPEC[mode]
    item = spec["product"]
    seat = int(obs["player"])
    farm = obs["farms"][seat]
    private = obs["private"]
    positions = [farm["farmer"]] + list(farm["hands"])
    market = action.get("market") or []
    cash = float(farm.get("money", 0))
    seed_cost = {"WHEAT": 10, "CARROT": 20, "TOMATO": 50, "STRAWBERRY": 100, "MELON": 80}
    for order in market:
        if len(order) >= 3 and order[0] == "BUY_ANIMAL" and order[1] == "GOOSE":
            n = max(0, int(order[2]))
            affordable = int(max(0.0, cash) // spec["cost"])
            order[1] = mode
            order[2] = min(n, affordable)
            cash -= order[2] * spec["cost"]
            _HD2_REPORT["hd2_rewrites"] += 1
        elif len(order) >= 3 and order[0] in ("BUY_ANIMAL", "BUY_SEED", "BUY_PRODUCT"):
            q = max(0, int(order[2]))
            if order[0] == "BUY_ANIMAL":
                cash -= q * {"GOOSE": 300, "COW": 400, "SHEEP": 500}.get(order[1], 0)
            elif order[0] == "BUY_SEED":
                cash -= q * seed_cost.get(order[1], 0)
            else:
                cash -= q * int((obs["market"]["prices"] or {}).get(order[1], 0))
        elif order and order[0] == "BUY_LAND":
            cash -= 4000
    workers = [action.get("farmer") or ["PASS"]] + list(action.get("hands") or [])
    for actor, work in enumerate(workers[:len(positions)]):
        if not work:
            continue
        x, y = positions[actor]
        tile = farm["tiles"][y][x]
        if work[0] == "BUILD_COOP":
            workers[actor] = ["BUILD_PASTURE"]
            _HD2_REPORT["hd2_rewrites"] += 1
        elif len(work) >= 2 and work[0] in ("PICKUP", "PLACE") and work[1] == "GOOSE":
            workers[actor] = [work[0], mode] + list(work[2:])
            _HD2_REPORT["hd2_rewrites"] += 1
            if work[0] == "PLACE":
                st["pending"].append((x, y, int(obs["step"]) // 24))
        elif len(work) >= 2 and work[0] == "PLACE" and work[1] == "EGG":
            workers[actor] = ["PLACE", item] + list(work[2:])
            _HD2_REPORT["hd2_rewrites"] += 1
        elif work == ["HARVEST"] and (x, y) in st["sites"] and isinstance(tile, dict) \
                and tile.get("animal") == mode:
            units = max(0, int(tile.get("yield_units", 0)))
            st["credit"] += units
            _HD2_REPORT["hd2_credit_units"] += units
    action["farmer"] = workers[0]
    action["hands"] = workers[1:]
    if st["credit"] > 0:
        try:
            stock = projected_shed(action, FarmView(obs))
        except Exception:
            stock = dict(private.get("shed") or {})
        planned = sum(max(0, int(o[2])) for o in market if len(o) >= 3 and o[:2] == ["SELL", item])
        extra = min(st["credit"], max(0, int(stock.get(item, 0)) - planned))
        if extra > 0:
            for order in market:
                if len(order) >= 3 and order[:2] == ["SELL", item]:
                    order[2] = int(order[2]) + extra
                    break
            else:
                if len(market) < 10:
                    market.insert(0, ["SELL", item, extra])
                else:
                    extra = 0
            st["credit"] -= extra
            _HD2_REPORT["hd2_sold_units"] += extra
    action["market"] = market


def _hd2_confirm(obs, st):
    farm = obs["farms"][int(obs["player"])]
    keep = []
    for x, y, day in st["pending"]:
        tile = farm["tiles"][y][x]
        if isinstance(tile, dict) and tile.get("animal") == st["mode"] and tile.get("placed_day") == day:
            st["sites"][(x, y)] = day
        elif int(obs["step"]) // 24 <= day + 1:
            keep.append((x, y, day))
    st["pending"] = keep


_HD2_PARENT = agent
del agent


def agent(observation, configuration=None):
    action = _HD2_PARENT(observation, configuration)
    try:
        seat = int(observation["player"])
        step = int(observation["step"])
        st = _HD2_STATE.get(seat)
        if st is None or step <= st["step"]:
            st = _HD2_STATE[seat] = {"step": -1, "inv": {}, "decided": False, "mode": None,
                                     "pending": [], "sites": {}, "credit": 0}
            if step == 0:
                _HD2_REPORT.update(hd2_decision="", hd2_ev="", hd2_rewrites=0, hd2_credit_units=0,
                                   hd2_sold_units=0, hd2_errors=0)
        st["step"] = step
        day = step // 24
        if day not in st["inv"]:
            st["inv"][day] = dict(observation["market"]["inventory"])
        if not isinstance(action, dict):
            return action
        if st["mode"]:
            _hd2_confirm(observation, st)
        elif not st["decided"]:
            _hd2_decide(observation, action, st)
        if st["mode"]:
            action = copy.deepcopy(action)
            _hd2_rewrite(observation, action, st)
    except Exception:
        _HD2_REPORT["hd2_errors"] += 1
    return action


agent.telemetry = _HD2_REPORT
agent = globals().pop('agent')


_CS_FROM = 144
_CS_TO = 192
_CS_RATIO = 1.3
_CS_MIN_GAIN = 600.0
_CS_OPTIONS = ('GOOSE',)
_CS_SHOP_RULE = 'nomilk'
_CS_MOVES = {"NORTH": (0, -1), "SOUTH": (0, 1), "EAST": (1, 0), "WEST": (-1, 0)}
_CS_STATE = {}
_CS_REPORT = {"cs_decision": "", "cs_ev": "", "cs_rewrites": 0, "cs_broken": 0, "cs_credit": 0,
              "cs_sold": 0, "cs_errors": 0}


def _cs_tape(seat, t):
    native = _IMPL.chassis.players.get(seat)
    if not native or t > 719:
        return {}
    tape = _IMPL.chassis.routes[2 if t >= 648 else native["route"]]
    return tape[t] if t < len(tape) and isinstance(tape[t], dict) else {}


def _cs_spawn(positions, board):
    half = board // 2
    access = [(half - 1, half - 1), (half, half - 1), (half - 1, half), (half, half)]
    occ = {a: 0 for a in access}
    for p in positions:
        if tuple(p) in occ:
            occ[tuple(p)] += 1
    return list(min(access, key=lambda a: (occ[a], access.index(a))))


def _cs_plan(obs, action, k, mode):
    seat = int(obs["player"])
    step = int(obs["step"])
    farm = obs["farms"][seat]
    board = len(farm["tiles"])
    positions = [list(farm["farmer"])] + [list(h) for h in farm["hands"]]
    end = (step // 24 + 1) * 24 - 1
    builds, pickups, places = [], [], []
    for t in range(step, end + 1):
        act = action if t == step else _cs_tape(seat, t)
        units = [act.get("farmer") or ["PASS"]] + list(act.get("hands") or [])
        for i in range(len(positions)):
            cmd = units[i] if i < len(units) and units[i] else ["PASS"]
            pos = tuple(positions[i])
            if cmd[0] in _CS_MOVES:
                dx, dy = _CS_MOVES[cmd[0]]
                nx, ny = pos[0] + dx, pos[1] + dy
                if 0 <= nx < board and 0 <= ny < board:
                    positions[i] = [nx, ny]
            elif cmd[0] == "BUILD_PASTURE":
                builds.append((t, i, pos))
            elif len(cmd) >= 2 and cmd[0] == "PICKUP" and cmd[1] == "COW":
                pickups.append((t, i, max(1, int(cmd[2]) if len(cmd) > 2 else 1)))
            elif len(cmd) >= 2 and cmd[0] == "PLACE" and cmd[1] == "COW":
                places.append((t, i, pos))
        hires = sum(1 for o in (act.get("market") or []) if o and o[0] == "HIRE")
        for _ in range(hires):
            positions.append(_cs_spawn(positions, board))
    chosen, tiles = [], set()
    for t, i, pos in places:
        if pos not in tiles:
            chosen.append((t, i, pos))
            tiles.add(pos)
        if len(chosen) == k:
            break
    if len(chosen) < k:
        return None
    plan = {"builds": {}, "pickups": {}, "places": {}}
    buying_land = any(o and o[0] == "BUY_LAND" for o in (action.get("market") or []))
    unlocked = list(farm.get("unlocked_quadrants") or ["NW"])
    next_quadrant = [q for q in ("NE", "SW", "SE") if q not in unlocked][:1]
    half = board // 2
    for t, i, pos in chosen:
        x, y = pos
        tile = farm["tiles"][y][x]
        if mode == "GOOSE":
            quadrant = ("N" if y < half else "S") + ("W" if x < half else "E")
            locked_but_bought = tile == "LOCKED" and buying_land and quadrant in next_quadrant
            if tile is not None and not locked_but_bought:
                return None  # already built (or occupied): cannot become a coop without extra turns
            prior = [(tb, ib) for tb, ib, pb in builds if pb == pos and tb < t]
            if not prior:
                return None
            tb, ib = prior[-1]
            plan["builds"][(tb, ib)] = pos
        carrier = [(tp, ip, q) for tp, ip, q in pickups if ip == i and tp < t]
        if not carrier:
            return None
        tp, ip, q = carrier[-1]
        plan["pickups"][(tp, ip)] = plan["pickups"].get((tp, ip), 0) + 1
        plan["places"][(t, i)] = pos
    for key, n in plan["pickups"].items():
        q = next(q for tp, ip, q in pickups if (tp, ip) == key)
        if q != n:
            return None  # a pickup that also carries unswapped cows cannot be split
    return plan


_CS_PARENT = agent
del agent


def agent(observation, configuration=None):
    action = _CS_PARENT(observation, configuration)
    try:
        seat = int(observation["player"])
        step = int(observation["step"])
        st = _CS_STATE.get(seat)
        if st is None or step <= st["step"]:
            st = _CS_STATE[seat] = {"step": -1, "decided": False, "mode": None, "plan": None,
                                    "broken": False, "sites": {}, "pending": [], "credit": 0}
            if step == 0:
                _CS_REPORT.update(cs_decision="", cs_ev="", cs_rewrites=0, cs_broken=0, cs_credit=0,
                                  cs_sold=0, cs_errors=0)
        st["step"] = step
        if not isinstance(action, dict):
            return action
        farm = observation["farms"][seat]
        positions = [farm["farmer"]] + list(farm["hands"])
        market = [list(o) for o in (action.get("market") or [])]
        if st["pending"]:
            keep = []
            for x, y, day in st["pending"]:
                tile = farm["tiles"][y][x]
                if isinstance(tile, dict) and tile.get("animal") == st["mode"] and tile.get("placed_day") == day:
                    st["sites"][(x, y)] = day
                elif step // 24 <= day:
                    keep.append((x, y, day))
            st["pending"] = keep
        if not st["decided"] and _CS_FROM <= step < _CS_TO:
            buys = [o for o in market if len(o) >= 3 and o[0] == "BUY_ANIMAL" and o[1] == "COW" and int(o[2]) > 0]
            shops_now = list((observation.get("town") or {}).get("unlocked_shops") or [])
            shop_ok = True
            if _CS_SHOP_RULE:
                no_milk = not any(s in ("PIZZA_SHOP", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP") for s in shops_now)
                if _CS_SHOP_RULE == "nomilk":
                    shop_ok = no_milk and "YARN_STORE" not in shops_now
                else:
                    shop_ok = no_milk and any(s in ("BAKERY", "BRUNCH_SPOT") for s in shops_now)
            if buys and not shop_ok:
                st["decided"] = True
                _CS_REPORT["cs_decision"] = "shoprule@%d" % step
            elif buys:
                st["decided"] = True
                k = sum(int(o[2]) for o in buys)
                evs = {opt: _hd2_ev(opt, k, observation, st)[0] for opt in ("COW",) + tuple(_CS_OPTIONS)}
                _CS_REPORT["cs_ev"] = ",".join("%s:%d" % (o, v) for o, v in sorted(evs.items()))
                best = max(_CS_OPTIONS, key=lambda o: evs[o])
                cow = evs["COW"]
                if evs[best] - cow >= _CS_MIN_GAIN and evs[best] >= _CS_RATIO * max(cow, 1.0):
                    plan = _cs_plan(observation, action, k, best)
                    if plan is not None:
                        st["mode"], st["plan"] = best, plan
                        _CS_REPORT["cs_decision"] = "%s@%d" % (best, step)
                        for o in market:
                            if len(o) >= 3 and o[0] == "BUY_ANIMAL" and o[1] == "COW":
                                o[1] = best
                                _CS_REPORT["cs_rewrites"] += 1
                    else:
                        _CS_REPORT["cs_decision"] = "noplan@%d" % step
                else:
                    _CS_REPORT["cs_decision"] = "keep@%d" % step
        if st["mode"] and st["plan"] and not st["broken"]:
            plan = st["plan"]
            units = [action.get("farmer") or ["PASS"]] + list(action.get("hands") or [])
            for i in range(min(len(units), len(positions))):
                cmd = units[i] or ["PASS"]
                pos = (int(positions[i][0]), int(positions[i][1]))
                key = (step, i)
                if key in plan["builds"]:
                    if cmd == ["BUILD_PASTURE"] and pos == plan["builds"][key]:
                        units[i] = ["BUILD_COOP"]
                        _CS_REPORT["cs_rewrites"] += 1
                    else:
                        st["broken"] = True
                if key in plan["pickups"]:
                    if len(cmd) >= 2 and cmd[0] == "PICKUP" and cmd[1] == "COW":
                        units[i] = ["PICKUP", st["mode"]] + list(cmd[2:])
                        _CS_REPORT["cs_rewrites"] += 1
                    else:
                        st["broken"] = True
                if key in plan["places"]:
                    if len(cmd) >= 2 and cmd[0] == "PLACE" and cmd[1] == "COW" and pos == plan["places"][key]:
                        units[i] = ["PLACE", st["mode"]] + list(cmd[2:])
                        st["pending"].append((pos[0], pos[1], step // 24))
                        _CS_REPORT["cs_rewrites"] += 1
                    else:
                        st["broken"] = True
            if st["broken"]:
                _CS_REPORT["cs_broken"] += 1
            action = dict(action)
            action["farmer"] = units[0]
            action["hands"] = units[1:]
        if st["sites"]:
            product = _HD2_SPEC[st["mode"]]["product"]
            units = [action.get("farmer") or ["PASS"]] + list(action.get("hands") or [])
            for i in range(min(len(units), len(positions))):
                x, y = int(positions[i][0]), int(positions[i][1])
                tile = farm["tiles"][y][x]
                if units[i] == ["HARVEST"] and (x, y) in st["sites"] and isinstance(tile, dict) \
                        and tile.get("animal") == st["mode"]:
                    n = max(0, int(tile.get("yield_units", 0)))
                    st["credit"] += n
                    _CS_REPORT["cs_credit"] += n
            if st["credit"] > 0:
                stock = projected_shed(action, FarmView(observation))
                planned = sum(max(0, int(o[2])) for o in market if len(o) >= 3 and o[:2] == ["SELL", product])
                extra = min(st["credit"], max(0, int(stock.get(product, 0)) - planned))
                if extra > 0:
                    for o in market:
                        if len(o) >= 3 and o[:2] == ["SELL", product]:
                            o[2] = int(o[2]) + extra
                            break
                    else:
                        if len(market) < 10:
                            market.insert(0, ["SELL", product, extra])
                        else:
                            extra = 0
                    st["credit"] -= extra
                    _CS_REPORT["cs_sold"] += extra
        action = dict(action)
        action["market"] = market
    except Exception:
        _CS_REPORT["cs_errors"] += 1
    return action


agent.telemetry = _CS_REPORT
agent = globals().pop('agent')




_RACE_PARENT=agent
_RACE_HORIZON_CLONE=8
_RACE_HORIZON_ESCALATED=24
_RACE_HORIZON_MIRROR=24
_RACE_ITEMS=('CARROT','TOMATO','STRAWBERRY','MELON','EGG','MILK','WOOL')
_RACE_SHOPS={'BAKERY':('EGG','WHEAT'),'PIZZA_SHOP':('MILK','TOMATO','WHEAT'),'BRUNCH_SPOT':('EGG','WHEAT','STRAWBERRY'),'YARN_STORE':('WOOL',),
             'ICE_CREAM_SHOP':('STRAWBERRY','MILK','WHEAT'),'PET_CAFE':('CARROT',),'SMOOTHIE_SHOP':('STRAWBERRY','MILK'),'FARMERS_MARKET':('WHEAT','CARROT','TOMATO','STRAWBERRY')}
_RACE_STATE={}
_RACE_REPORT=dict(race_clone_turns=0,race_horizon_turns=0,race_lost_races=0,race_escalations=0,race_errors=0)
_RACE_ORIG_RESERVE=_r36_reserve

def _race_positions_equal(farms,player):
    own,rival=farms[player],farms[1-player]
    return len(own['hands'])>0 and own['hands']==rival['hands'] and own['farmer']==rival['farmer']

def _race_clone(observation,state):
    farms=observation['farms'];player=int(observation['player'])
    if len(farms[player]['hands'])>0:
        state['hist'].append(_race_positions_equal(farms,player))
        if len(state['hist'])>6:state['hist'].pop(0)
    return len(state['hist'])>=4 and sum(state['hist'])>=4 and _r37_similarity(observation)>=.95

def _race_town(step,shops):
    out={}
    if step%4==0:
        for shop in shops:
            items=_RACE_SHOPS.get(shop,())
            for item in items:out[item]=out.get(item,0)+(2 if len(items)==1 else 1)
    if step%24==0:
        for item in _RACE_ITEMS:out[item]=out.get(item,0)+1
    return out

def _race_lost(observation,state):
    """EXP293: True when the rival sold a race product at the previous turn while we held it unsold, the common tape
    has no sale of it within the lineage's own lead/reservation window (5 turns) and sells it within the following
    24 turns: the rival pre-empts the plan's own sale ahead of us."""
    prev=state.get('prev');prev_action=state.get('prev_action')
    if prev is None or prev_action is None:return False
    step=int(observation['step']);player=int(observation['player'])
    if step!=prev['step']+1 or step%24==0:return False
    inv=observation['market']['inventory'];pinv=prev['inventory'];prices=prev['prices']
    town=_race_town(step-1,prev['shops'])
    sold={}
    for order in prev_action.get('market',[]):
        if len(order)>=3 and order[0]=='SELL' and order[1] in _RACE_ITEMS:sold[order[1]]=1
    native=_IMPL.chassis.players[player]
    for item in _RACE_ITEMS:
        before=int(prev['view'].shed.get(item,0))
        if before<=0 or item in sold or prices.get(item,0)<=1:continue
        rival=int(inv[item])-int(pinv[item])+town.get(item,0)
        if rival<=0:continue
        def planned(t):
            future=_IMPL.chassis.routes[2 if t>=648 else native['route']][t]
            return any(len(o)>=3 and o[0]=='SELL' and o[1]==item for o in future.get('market',[]))
        if any(planned(t) for t in range(step-1,min(719,step+5))):continue
        if any(planned(t) for t in range(step+5,min(719,step+24))):return True
    return False

def _race_snapshot(observation):
    market=observation['market']
    return dict(step=int(observation['step']),inventory=dict(market['inventory']),prices=dict(market['prices']),shops=list(observation['town'].get('unlocked_shops',[])),view=FarmView(observation))

def _r36_reserve(obs,action):
    player=int(obs['player']);h=_RACE_STATE.get(player,{}).get('horizon',0)
    if h>_R37_HORIZONS.get(player,2):
        saved=_R37_HORIZONS.get(player);_R37_HORIZONS[player]=h
        try:return _RACE_ORIG_RESERVE(obs,action)
        finally:
            if saved is None:_R37_HORIZONS.pop(player,None)
            else:_R37_HORIZONS[player]=saved
    return _RACE_ORIG_RESERVE(obs,action)

def agent(observation,configuration=None):
    state=None
    try:
        player=int(observation['player']);step=int(observation['step'])
        state=_RACE_STATE.get(player)
        if state is None or step<=state['step']:
            state=_RACE_STATE[player]={'step':-1,'hist':[],'horizon':0,'level':_RACE_HORIZON_CLONE,'prev':None,'prev_action':None}
        if step==0:_RACE_REPORT.update(race_clone_turns=0,race_horizon_turns=0,race_lost_races=0,race_escalations=0,race_errors=0)
        state['step']=step;state['horizon']=0
        if step==1:
            try:
                farms=observation['farms'];rival=farms[1-player]['money'];own=farms[player]['money']
                state['level']=_RACE_HORIZON_MIRROR if (abs(float(rival)-float(own))<0.5 and _RACE_HORIZON_MIRROR>state['level']) else state['level']
                _RACE_REPORT['race_mirror']=int(abs(float(rival)-float(own))<0.5)
            except Exception:_RACE_REPORT['race_errors']+=1
        standard=configuration is None or all(configuration.get(k,v)==v for k,v in [('boardSize',10),('turnsPerDay',24),('shedCapacity',100),('maxMarketOrdersPerTurn',10)])
        if standard and 216<=step<696 and _race_clone(observation,state):
            _RACE_REPORT['race_clone_turns']+=1
            if state['level']<_RACE_HORIZON_ESCALATED and _race_lost(observation,state):
                _RACE_REPORT['race_lost_races']+=1;state['level']=_RACE_HORIZON_ESCALATED;_RACE_REPORT['race_escalations']+=1
            state['horizon']=state['level'];_RACE_REPORT['race_horizon_turns']+=1
    except Exception:_RACE_REPORT['race_errors']+=1
    snapshot=None
    try:
        if state is not None and 215<=int(observation['step'])<696:snapshot=_race_snapshot(observation)
    except Exception:_RACE_REPORT['race_errors']+=1
    action=_RACE_PARENT(observation,configuration)
    try:
        if state is not None:state['prev']=snapshot;state['prev_action']=action if snapshot is not None else None
    except Exception:_RACE_REPORT['race_errors']+=1
    _RACE_REPORT.update(getattr(_RACE_PARENT,'telemetry',{}))
    return action
agent.telemetry=_RACE_REPORT
agent=globals().pop('agent')


"""Fund urgent grain at the first quote slot; avoid unwatered last-hour plants.
Original safety contracts by Ahmed Berat Ozer, EXP258.
"""
_R127_PARENT=agent
_R127_STATES={}
_R127_REPORT={}

def _r127_fields(obs,action):
    farm,private=_PLANNER_NS['_clone_state'](obs['farms'][obs['player']],obs['private'])
    commands=[action.get('farmer') or ['PASS'],*(action.get('hands') or [])]
    demand={}
    for c in commands:
        if len(c)>1 and c[0]=='PLANT':demand[c[1]]=demand.get(c[1],0)+1
    blocked={p for p,n in demand.items() if n>private['seeds'].get(p,0)}
    for actor,c in enumerate(commands[:len(private['inventories'])]):
        if len(c)>1 and c[0]=='PLANT' and c[1] in blocked:continue
        _PLANNER_NS['_apply_unit_action'](farm,private,actor,c,10,int(obs['step'])//24,24,100)
    return farm,private

def _r127_last_hour(obs,action):
    if int(obs['step'])%24!=23:return action
    commands=[action.get('farmer') or ['PASS'],*(action.get('hands') or [])]
    if not any(c and c[0]=='PLANT' for c in commands):return action
    result=copy.deepcopy(action);changed=False
    for _ in range(len(commands)+1):
        farm,_=_r127_fields(obs,result);original=obs['farms'][obs['player']]
        positions=[original['farmer'],*original['hands']];drop=[]
        for actor,c in enumerate(commands):
            if not c or c[0]!='PLANT':continue
            tile=None
            if actor<len(positions):
                x,y=positions[actor];tile=farm['tiles'][y][x]
            if not (isinstance(tile,dict) and tile.get('kind')=='PLANT' and tile.get('crop')==c[1] and tile.get('planted_day')==int(obs['step'])//24 and tile.get('watered_today')):drop.append(actor)
        if not drop:break
        for actor in drop:commands[actor]=['PASS']
        result['farmer']=commands[0];result['hands']=commands[1:];changed=True
        _R127_REPORT['last_hour_plants_dropped']+=len(drop)
    return result if changed else action

def _r127_prefix_bound(obs,quantity):
    inventory=int(obs['market']['inventory']['WHEAT'])
    return sum(_r37_market_price('WHEAT',inventory-(2*j-1)) for j in range(1,quantity+1))

def _r127_priority(obs,action,state):
    step=int(obs['step']);player=int(obs['player'])
    if not 144<=step<695:return action
    orders=action.get('market') or []
    if len(orders)>9 or any(o[:2] in (['BUY_PRODUCT','WHEAT'],['SELL','WHEAT']) for o in orders):return action
    native=_IMPL.chassis.players[player]
    future=_IMPL.chassis.routes[2 if step+1>=648 else native['route']][step+1]
    commands=[future.get('farmer') or ['PASS'],*(future.get('hands') or [])]
    if not any(c[:2]==['PICKUP','WHEAT'] for c in commands):return action
    if not _r97_budget(obs,orders):return action
    farm,private=_r127_fields(obs,action);night=step%24==23
    access=((4,4),(5,4),(4,5),(5,5));positions=[tuple(farm['farmer']),*map(tuple,farm['hands'])]
    if night:positions=[(4,4)]
    else:
        for o in orders:
            if o and o[0]=='HIRE':positions.append(min(access,key=lambda p:(positions.count(p),access.index(p))))
    need=sum(max(0,int(c[2]) if len(c)>2 else 1) for pos,c in zip(positions,commands) if pos in access and c[:2]==['PICKUP','WHEAT'])
    stock,buys,_=_r97_market_stock(private['shed'],orders);before,loss=_r97_delivery(stock,private,night)
    shortage=max(0,need-before.get('WHEAT',0))
    if not shortage or shortage>100-sum(private['shed'].values()):return action
    cost=_r127_prefix_bound(obs,shortage)
    budget=dict(obs,farms=[dict(f) for f in obs['farms']]);budget['farms'][player]['money']-=cost
    if not _r97_budget(budget,orders):return action
    proposed=[['BUY_PRODUCT','WHEAT',shortage],*copy.deepcopy(orders)]
    stock,after_buys,_=_r97_market_stock(private['shed'],proposed);after,after_loss=_r97_delivery(stock,private,night)
    if after.get('WHEAT',0)<need or any(after_buys.get(i+1,0)<q for i,q in buys.items()) or any(q>loss.get(p,0) for p,q in after_loss.items()):return action
    state['pending_grain']=(step+1,after.get('WHEAT',0),shortage)
    _R127_REPORT['priority_grain_orders']+=1;_R127_REPORT['priority_grain_units']+=shortage
    return dict(action,market=proposed)

def agent(observation,configuration=None):
    result=_R127_PARENT(observation,configuration)
    try:
        player=int(observation['player']);step=int(observation['step']);state=_R127_STATES.get(player)
        if state is None or step<=state['step']:
            state=_R127_STATES[player]={'step':-1}
            _R127_REPORT.update(last_hour_plants_dropped=0,priority_grain_orders=0,priority_grain_units=0,priority_grain_confirmed=0,priority_grain_shortfalls=0,priority_contract_errors=0)
        pending=state.pop('pending_grain',None)
        if pending and step==pending[0]:
            if observation['private']['shed'].get('WHEAT',0)>=pending[1]:_R127_REPORT['priority_grain_confirmed']+=pending[2]
            else:_R127_REPORT['priority_grain_shortfalls']+=1
        state['step']=step
        standard=configuration is None or all(configuration.get(k,v)==v for k,v in [('boardSize',10),('turnsPerDay',24),('shedCapacity',100),('maxMarketOrdersPerTurn',10),('farmHandCostMult',1)])
        if standard:result=_r127_priority(observation,_r127_last_hour(observation,result),state)
    except Exception:_R127_REPORT['priority_contract_errors']=_R127_REPORT.get('priority_contract_errors',0)+1
    _R127_REPORT.update(getattr(_R127_PARENT,'telemetry',{}))
    return result
agent.telemetry=_R127_REPORT
agent=globals().pop('agent')


_PG_HOST=[v for v in list(globals().values()) if callable(v)][-1]
_Y_HOURS=(21, 22)
_Y_ITEMS=('MILK', 'STRAWBERRY', 'MELON', 'WOOL', 'TOMATO')
_Y_MIN_DAY=1
_Y_MARGIN=-6
_PG_REPORT={'preguard_turns':0,'preguard_units':0,'preguard_errors':0}

def _y_preguard(obs,action):
    step=int(obs['step'])
    if step%24 not in _Y_HOURS or step//24<_Y_MIN_DAY or step>=696:return action
    orders=[list(o) for o in (action.get('market') or [])]
    if len(orders)>=10:return action
    farm,private=_r127_fields(obs,action)
    stock,_,_=_r97_market_stock(private['shed'],orders)
    carried=sum(max(0,int(n)) for bag in private['inventories'] for n in bag.values())
    needed=sum(max(0,int(v)) for v in stock.values())+carried-99-_Y_MARGIN
    if needed<=0:return action
    prices=obs['market']['prices'];extra=[]
    for item in sorted(PRODUCTS,key=lambda it:-int(prices.get(it,0))):
        avail=max(0,int(stock.get(item,0)));qty=min(needed,avail)
        if qty<=0:continue
        if item in _Y_ITEMS and int(prices.get(item,0))>=2:extra.append(['SELL',item,qty])
        needed-=qty
        if needed<=0:break
    if not extra or len(orders)+len(extra)>10:return action
    _PG_REPORT['preguard_turns']+=1;_PG_REPORT['preguard_units']+=sum(o[2] for o in extra)
    return dict(action,market=orders+extra)

def agent_v44y_preguard(observation,configuration=None):
    action=_PG_HOST(observation,configuration)
    try:
        standard=configuration is None or all(configuration.get(k,v)==v for k,v in [('boardSize',10),('turnsPerDay',24),('shedCapacity',100),('maxMarketOrdersPerTurn',10)])
        if standard:action=_y_preguard(observation,action)
    except Exception:_PG_REPORT['preguard_errors']+=1
    return action
agent_v44y_preguard.telemetry=_PG_REPORT


_RACE_HORIZON_CLONE = 9

_V44Y_HOST = [v for v in list(globals().values()) if callable(v)][-1]
_V44Y_REORDER_GATE = False
_V44Y_REPORT = dict(v44y_reorder_turns=0, v44y_reorder_gain=0.0, v44y_errors=0)
import itertools as _v44y_it

def _v44y_price(item, inventory, params):
    return _r37_market_price(item, inventory, params)

def _v44y_params(obs):
    params = {k: dict(v) for k, v in _R37_MARKET_PARAMS.items()}
    for k, patch in (obs['market'].get('params') or {}).items():
        if k in params and isinstance(patch, dict): params[k].update(patch)
    return params

def _v44y_lockstep(orders_me, orders_opp, inv0, stock_me, stock_opp, params):
    """Replay the engine's per-slot / per-unit lockstep for SELL and BUY_PRODUCT orders (money-unbounded).
    Returns (revenue_me, revenue_opp)."""
    inv = dict(inv0); stock = [dict(stock_me), dict(stock_opp)]; rev = [0.0, 0.0]
    queues = [list(orders_me), list(orders_opp)]
    for i in range(max(len(queues[0]), len(queues[1]))):
        rem = [None, None]
        for p in (0, 1):
            if i < len(queues[p]):
                o = queues[p][i]
                if o and len(o) >= 3 and o[0] in ('SELL', 'BUY_PRODUCT') and o[1] in params:
                    try: n = int(o[2])
                    except Exception: n = 0
                    if n > 0: rem[p] = [o[0], o[1], n]
        guard = 0
        while True:
            guard += 1
            if guard > 5000: break
            quoted = [None, None]
            for p in (0, 1):
                r = rem[p]
                if r is None or r[2] <= 0: continue
                if r[0] == 'SELL':
                    quoted[p] = ('SELL', r[1], _v44y_price(r[1], inv[r[1]], params))
                elif r[1] in ('WHEAT', 'FERTILIZER'):
                    quoted[p] = ('BUY_PRODUCT', r[1], _v44y_price(r[1], inv[r[1]] - 1, params))
                else:
                    rem[p] = None
            if quoted[0] is None and quoted[1] is None: break
            committed = False
            for p in (0, 1):
                q = quoted[p]
                if q is None: continue
                op, item, price = q
                if op == 'SELL':
                    if stock[p].get(item, 0) <= 0:
                        rem[p] = None; continue
                    stock[p][item] -= 1; rev[p] += price
                    if price > 1: inv[item] += 1
                else:
                    stock[p][item] = stock[p].get(item, 0) + 1; rev[p] -= price; inv[item] -= 1
                rem[p][2] -= 1; committed = True
            if not committed: break
    return rev[0], rev[1]

def _v44y_factor_margin(opp, inv0, stock, params):
    cache = {}
    opp_schedules = {}
    for i, order in enumerate(opp):
        if order and len(order) >= 3 and order[0] in ('SELL', 'BUY_PRODUCT') and order[1] in params:
            item = order[1]
            padded = opp_schedules.setdefault(item, [[] for _ in opp])
            padded[i] = order
    def margin(cand):
        schedules = {item: [] for item in opp_schedules}
        for i, order in enumerate(cand):
            if order and len(order) >= 3 and order[0] in ('SELL', 'BUY_PRODUCT') and order[1] in params:
                schedules.setdefault(order[1], []).append((i, order[0], int(order[2])))
        total = 0.0
        for item, schedule in schedules.items():
            key = (item, tuple(schedule))
            value = cache.get(key)
            if value is None:
                mine = [[] for _ in cand]
                for i, op, n in schedule: mine[i] = [op, item, n]
                theirs = opp_schedules.get(item, [[] for _ in opp])
                a, b = _v44y_lockstep(mine, theirs, {item: inv0[item]},
                                      {item: stock.get(item, 0)}, {item: stock.get(item, 0)},
                                      {item: params[item]})
                value = a - b
                cache[key] = value
            total += value
        return total
    return margin

def _v44y_reorder(obs, action):
    market = action.get('market') or []
    if len(market) < 2: return action
    orders = [list(o) if isinstance(o, (list, tuple)) else o for o in market]
    blocks = []; i = 0
    while i < len(orders):
        o = orders[i]
        if o and o[0] == 'SELL':
            j = i
            while j < len(orders) and orders[j] and orders[j][0] == 'SELL': j += 1
            if 2 <= j - i <= 6: blocks.append((i, j))
            i = j
        else: i += 1
    if not blocks: return action
    view = FarmView(obs)
    stock = projected_shed(action, view)
    stock = {k: max(0, int(v)) for k, v in stock.items()}
    params = _v44y_params(obs)
    inv0 = {k: int(v) for k, v in obs['market']['inventory'].items()}
    opp = [list(o) for o in orders]
    margin = _v44y_factor_margin(opp, inv0, stock, params)
    base = margin(orders); best = base; best_orders = None
    for (i, j) in blocks:
        blk = orders[i:j]; n = j - i
        seen = set()
        for perm in _v44y_it.permutations(range(n)):
            key = tuple((blk[p][1], int(blk[p][2])) for p in perm)
            if key in seen: continue
            seen.add(key)
            cand = orders[:i] + [blk[p] for p in perm] + orders[j:]
            v = margin(cand)
            if v > best + 0.5: best = v; best_orders = cand
        if best_orders is not None:
            orders = best_orders; best_orders = None
    if best <= base + 0.5: return action
    _V44Y_REPORT['v44y_reorder_turns'] += 1; _V44Y_REPORT['v44y_reorder_gain'] += best - base
    out = dict(action); out['market'] = orders
    return out

def _v44y_clone_gate(obs):
    player = int(obs['player']); step = int(obs['step'])
    st = _RACE_STATE.get(player) or {}
    if st.get('horizon', 0) > 0: return True
    if step >= 696 and len(st.get('hist', [])) >= 4 and sum(st['hist']) >= 4:
        return _r37_similarity(obs) >= .95
    return False

def v44y_lockstep_agent(observation, configuration=None):
    action = _V44Y_HOST(observation, configuration)
    try:
        step = int(observation.get('step', 0))
        if step >= 216 and (not _V44Y_REORDER_GATE or _v44y_clone_gate(observation)):
            action = _v44y_reorder(observation, action)
    except Exception:
        _V44Y_REPORT['v44y_errors'] += 1
    return action
v44y_lockstep_agent.telemetry = _V44Y_REPORT

_Y_HOST=[v for v in list(globals().values()) if callable(v)][-1]
_Y_CFG={'yarnsheep': True, 'yarngeese': True, 'days': (8, 11)}
import copy as _y_copy
_Y_PRODUCT={'COW':'MILK','SHEEP':'WOOL','GOOSE':'EGG'}
_Y_STRUCT={'COW':'PASTURE','SHEEP':'PASTURE','GOOSE':'COOP'}
_Y_COST={'COW':400,'SHEEP':500,'GOOSE':300}
_Y_SEED={'WHEAT':10,'CARROT':20,'TOMATO':50,'STRAWBERRY':100,'MELON':80}
_Y_STATES={}
_Y_REPORT={'swaps':0,'pick':0,'place':0,'harvest':0,'boost':0,'errors':0,'coop':0,'declined':0}

def _y_new_state():
    return {'last':-1,'pending':[],'credit':{},'sites':{},'sale':{},'coop_swap':0}

def _y_target(kind,shops,cfg):
    yarn='YARN_STORE' in shops
    egg=('BAKERY' in shops) or ('BRUNCH_SPOT' in shops)
    milk=sum(s in ('PIZZA_SHOP','ICE_CREAM_SHOP','SMOOTHIE_SHOP') for s in shops)
    if kind=='SHEEP' and cfg.get('nosheep') and not yarn and milk>=cfg.get('min_milk',0):return 'COW'
    if kind=='COW' and cfg.get('yarnsheep') and yarn:return 'SHEEP'
    if kind=='GOOSE' and cfg.get('nogeese') and not egg:return 'SHEEP' if yarn else 'COW'
    if kind=='GOOSE' and cfg.get('yarngeese') and yarn:return 'SHEEP'
    return None

def _y_fib(n):
    a,b=1,1
    for _ in range(n):a,b=b,a+b
    return a

def _y_cash(obs,action,market):
    farm=obs['farms'][int(obs['player'])];prices=obs['market']['prices'];shed=obs['private']['shed']
    try:shed=projected_shed({'farmer':action.get('farmer') or ['PASS'],'hands':action.get('hands') or [],'market':[]},FarmView(obs))
    except Exception:pass
    cash=float(farm['money']);cost=0.0;hires=int(farm.get('hires_today',0) or 0)
    quads=len(farm.get('unlocked_quadrants',[]) or [])
    for o in market:
        if not o:continue
        op=o[0]
        if op=='SELL' and len(o)>=3:
            cash+=0.8*min(max(0,int(o[2])),int(shed.get(o[1],0)))*float(prices.get(o[1],0))
        elif op=='BUY_ANIMAL' and len(o)>=3:cost+=int(o[2])*_Y_COST.get(o[1],500)
        elif op=='BUY_PRODUCT' and len(o)>=3:cost+=int(o[2])*(float(prices.get(o[1],0))+10)
        elif op=='BUY_SEED' and len(o)>=3:cost+=int(o[2])*_Y_SEED.get(o[1],100)
        elif op=='BUY_LAND':cost+=(1000,2000,4000)[min(2,max(0,quads-1))]
        elif op=='HIRE':cost+=_y_fib(hires);hires+=1
    return cash-cost

def _y_controller(obs,action,state,cfg):
    step=int(obs['step']);day=step//24;seat=int(obs['player'])
    farm=obs['farms'][seat];private=obs['private'];shed=private['shed'];inventories=private.get('inventories',[])
    shops=list((obs.get('town') or {}).get('unlocked_shops',[]) or [])
    tiles=farm['tiles'];n=len(tiles);center=n//2
    gained={}
    for p in state['pending']:
        to=p['to']
        if to not in gained:gained[to]=max(0,int(shed.get(to,0))-p['before'])
        got=min(p['qty'],gained[to]);gained[to]-=got
        if got>0:
            key=(p['from'],to);state['credit'][key]=state['credit'].get(key,0)+got
            if _Y_STRUCT[p['from']]!=_Y_STRUCT[to]:state['coop_swap']+=got
    state['pending']=[]
    result=_y_copy.deepcopy(action)
    market=result.get('market') or []
    result['market']=market
    if cfg['days'][0]<=day<=cfg['days'][1]:
        for o in market:
            if len(o)>=3 and o[0]=='BUY_ANIMAL' and o[1] in _Y_COST and 1<=int(o[2])<=cfg.get('maxq',2):
                to=_y_target(o[1],shops,cfg)
                if to is None or to==o[1]:continue
                trial=[list(x) if isinstance(x,list) else x for x in market]
                for t in trial:
                    if isinstance(t,list) and t==o:t[1]=to
                if _y_cash(obs,result,trial)<cfg.get('margin',100):
                    _Y_REPORT['declined']+=1;continue
                state['pending'].append({'from':o[1],'to':to,'qty':int(o[2]),'before':int(shed.get(to,0))})
                _Y_REPORT['swaps']+=int(o[2]);o[1]=to
    workers=[result.get('farmer') or ['PASS'],*(result.get('hands') or [])]
    positions=[farm['farmer'],*farm['hands']]
    avail={k:int(shed.get(k,0)) for k in _Y_COST}
    seen=set();occupied=set()
    for actor,work in enumerate(workers[:len(positions)]):
        if not work or not isinstance(work,list):continue
        inv=inventories[actor] if actor<len(inventories) else {}
        x,y=positions[actor];tile=tiles[y][x];site=(x,y);op=work[0]
        if op=='PICKUP' and len(work)>=2 and work[1] in _Y_COST:
            kind=work[1];qty=max(1,int(work[2])) if len(work)>2 else 1
            if avail.get(kind,0)>=qty:avail[kind]-=qty;continue
            if not (x in (center-1,center) and y in (center-1,center)):continue
            if any(inv.get(a,0) for a in _Y_COST):continue
            for (frm,to),c in list(state['credit'].items()):
                if frm==kind and c>=qty and avail.get(to,0)>=qty:
                    work[1]=to;state['credit'][(frm,to)]=c-qty;avail[to]-=qty;_Y_REPORT['pick']+=qty;break
        elif op=='PLACE' and len(work)>=2 and work[1] in _Y_COST:
            kind=work[1]
            if inv.get(kind,0)>0:continue
            for to in ('COW','SHEEP','GOOSE'):
                if (to!=kind and inv.get(to,0)>0 and isinstance(tile,dict) and tile.get('kind')==_Y_STRUCT[to]
                        and not tile.get('animal') and site not in occupied):
                    work[1]=to;state['sites'][site]=to;occupied.add(site);_Y_REPORT['place']+=1;break
        elif op=='BUILD_COOP' and state['coop_swap']>0:
            work[0]='BUILD_PASTURE';_Y_REPORT['coop']+=1
        elif op=='HARVEST' and site in state['sites'] and site not in seen:
            if isinstance(tile,dict) and tile.get('animal')==state['sites'][site]:
                units=max(0,int(tile.get('yield_units',0) or 0))
                if units:
                    prod=_Y_PRODUCT[tile['animal']];state['sale'][prod]=state['sale'].get(prod,0)+units;_Y_REPORT['harvest']+=units
            seen.add(site)
    result['farmer'],result['hands']=workers[0],workers[1:]
    if cfg.get('boost',True):
        for prod,credit in list(state['sale'].items()):
            credit=min(credit,int(shed.get(prod,0)))
            state['sale'][prod]=credit
            if credit<=0:continue
            planned=sum(max(0,int(o[2])) for o in market if len(o)>=3 and o[0]=='SELL' and o[1]==prod)
            if planned<=0:continue
            extra=min(credit,int(shed.get(prod,0))-planned)
            if extra<=0:continue
            for o in market:
                if len(o)>=3 and o[0]=='SELL' and o[1]==prod and int(o[2])>0:
                    o[2]=int(o[2])+extra;state['sale'][prod]=credit-extra;_Y_REPORT['boost']+=extra;break
    return result

def _y_agent_shopherd(observation,configuration=None):
    action=_Y_HOST(observation,configuration)
    try:
        seat=int(observation['player']);step=int(observation['step'])
        state=_Y_STATES.get(seat)
        if state is None or step<=state['last']:state=_Y_STATES[seat]=_y_new_state()
        state['last']=step
        return _y_controller(observation,action,state,_Y_CFG)
    except Exception:
        _Y_REPORT['errors']+=1
        return action


_E334_ITEMS={'CARROT','TOMATO','STRAWBERRY','MELON','EGG','MILK','WOOL'}
_E334_REPORT=dict(changed=0,removed=0,errors=0)
_E334_BASE=_y_agent_shopherd

def _e334_compact(obs,action):
    market=action.get('market') or []
    if int(obs['step'])<144 or len(market)<2:return action
    segments=[];i=0
    while i<len(market):
        if len(market[i])>=3 and market[i][0]=='SELL' and market[i][1] in _E334_ITEMS:
            j=i+1
            while j<len(market) and len(market[j])>=3 and market[j][0]=='SELL' and market[j][1] in _E334_ITEMS:j+=1
            if j-i>=2:segments.append((i,j))
            i=j
        else:i+=1
    if not segments:return action
    _,private=_r127_fields(obs,action);remaining=dict(private['shed']);new=[list(o) for o in market];removed=0
    for start,end in segments:
        quantities={};order=[]
        for o in market[start:end]:
            p=o[1]
            if p not in quantities:order.append(p);quantities[p]=0
            quantities[p]+=max(0,int(o[2]))
        kept=[]
        for p in order:
            q=min(quantities[p],max(0,int(remaining.get(p,0))))
            if q:kept.append(['SELL',p,q]);remaining[p]-=q
        replacement=kept+[[] for _ in range(end-start-len(kept))]
        if replacement!=market[start:end]:removed+=end-start-len(kept);new[start:end]=replacement
    if new==market:return action
    _E334_REPORT['changed']+=1;_E334_REPORT['removed']+=removed
    return dict(action,market=new)

def _e334_agent(observation,configuration=None):
    if int(observation.get('step',0))==0:
        for k in _E334_REPORT:_E334_REPORT[k]=0
    action=_E334_BASE(observation,configuration)
    try:return _e334_compact(observation,action)
    except Exception:
        _E334_REPORT['errors']+=1;return action

_E335_ORIGINAL_COMPACT=_e334_compact

def _e334_compact(obs,action):
    market=action.get('market') or []
    if int(obs['step'])<144 or len(market)<2:return action
    if not all(len(o)>=3 and o[0]=='SELL' for o in market):return _E335_ORIGINAL_COMPACT(obs,action)
    _,private=_r127_fields(obs,action);remaining=dict(private['shed']);effective=[]
    for o in market:
        item=o[1];q=min(max(0,int(o[2])),max(0,int(remaining.get(item,0))))
        remaining[item]=max(0,int(remaining.get(item,0))-q)
        effective.append(['SELL',item,q] if q else [])
    new=[list(o) for o in effective];i=0;removed=0
    while i<len(effective):
        if effective[i] and effective[i][1] not in _E334_ITEMS:i+=1;continue
        j=i+1
        while j<len(effective) and (not effective[j] or effective[j][1] in _E334_ITEMS):j+=1
        order=[];qty={}
        for o in effective[i:j]:
            if not o:continue
            if o[1] not in qty:order.append(o[1]);qty[o[1]]=0
            qty[o[1]]+=o[2]
        kept=[['SELL',item,qty[item]] for item in order]
        new[i:j]=kept+[[] for _ in range(j-i-len(kept))];removed+=j-i-len(kept);i=j
    if new==market:return action
    _E334_REPORT['changed']+=1;_E334_REPORT['removed']+=removed
    return dict(action,market=new)

def _e335_agent(observation,configuration=None):
    return _e334_agent(observation,configuration)




_V11_ENTRY = [v for v in list(globals().values()) if callable(v)][-1]


def agent(observation, configuration=None):
    return _V11_ENTRY(observation, configuration)


agent.telemetry = getattr(_V11_ENTRY, 'telemetry', {})
agent = globals().pop('agent')


V13V_SKIP_DAYS = (19, 21, 23)
_V13V_REPORT = dict(v_skipped=0, v_blocked=0, v_errors=0)
_V13V_ORIG_REQUEST = _v219_request


def _v219_request(obs, action, state, native):
    try:
        day = int(obs["step"]) // 24
        if day in V13V_SKIP_DAYS and state.get("committed") and state.get("requested_day") != day:
            farm = obs["farms"][int(obs["player"])]
            tomatoes = 0
            safe = True
            for x, y in state.get("targets", []):
                tile = farm["tiles"][y][x]
                if isinstance(tile, dict) and tile.get("crop") == "TOMATO":
                    tomatoes += 1
                    if int(tile.get("consecutive_unwatered", 1)) != 0:
                        safe = False
            if tomatoes and safe:
                state["requested_day"] = day
                _V13V_REPORT["v_skipped"] += 1
                return action
            if tomatoes:
                _V13V_REPORT["v_blocked"] += 1
    except Exception:
        _V13V_REPORT["v_errors"] += 1
    return _V13V_ORIG_REQUEST(obs, action, state, native)


_V13V_PARENT = agent


def agent(observation, configuration=None):
    if int(observation["step"]) == 0:
        for k in _V13V_REPORT:
            _V13V_REPORT[k] = 0
    return _V13V_PARENT(observation, configuration)


agent.telemetry = _V13V_REPORT
agent = globals().pop("agent")


_ALT_MODE = 'HybridOpening'
_ALT_RAW = copy.deepcopy(_IMPL.chassis.routes[0][:96])
_ALT_CT = dict(CT_TABLE)
_ALT_STATE = {}
_ALT_REPORT = {}

def _alt_install(mode):
    global CT_TABLE
    tape=_IMPL.chassis.routes[0]
    tape[:96]=copy.deepcopy(_ALT_RAW)
    CT_TABLE=dict(_ALT_CT)
    if mode=='Original': return
    if mode=='HybridOpening':
        tape[0]['market']=list(tape[0]['market'])+[['BUY_SEED','WHEAT',1]]
    else:
        CT_TABLE={}
        tape[0]['market']=[['BUY_PRODUCT','WHEAT',5],['BUY_SEED','WHEAT',1]]
        tape[1]['market']=[o for o in tape[1]['market'] if not (len(o)>=3 and o[0] in ('BUY_PRODUCT','SELL') and o[1]=='WHEAT')]
    for step,command in {2:['WEST'],3:['WEST'],4:['WEST'],5:['PLANT','WHEAT'],6:['WATER']}.items():
        assert tape[step]['hands'][1]==['PASS']
        tape[step]['hands'][1]=command
    assert tape[29]['hands'][2]==['BUILD_PASTURE']
    tape[29]['hands'][2]=['WATER']
    commands=[['WEST'],['WEST'],['WEST'],['WATER'],['HARVEST'],['BUILD_PASTURE'],['EAST'],['EAST'],['DROP']]
    for step,command in zip(range(49,58),commands):
        assert tape[step]['hands'][0]==['PASS']
        tape[step]['hands'][0]=command
    if mode=='TomatoInsteadOfCow':
        tape[0]['market'].append(['BUY_SEED','TOMATO',1])
        cow=next(o for o in tape[1]['market'] if o[:2]==['BUY_ANIMAL','COW'])
        assert cow[2]==2; cow[2]=1
        assert tape[2]['hands'][4][:2]==['PICKUP','COW']
        assert tape[3]['hands'][4]==['BUILD_PASTURE']
        assert tape[4]['hands'][4][:2]==['PLACE','COW']
        tape[2]['hands'][4]=['PASS']
        tape[3]['hands'][4]=['PASS']
        tape[4]['hands'][4]=['PLANT','TOMATO']
        tape[5]['hands'][4]=['WATER']
    assert max(len(a.get('market',[])) for a in tape[:96])<=10

def _alt_sell_extra(action,item,n):
    if n<=0:return action
    orders=[list(o) for o in action.get('market',[])]
    sell=next((o for o in orders if len(o)>=3 and o[:2]==['SELL',item]),None)
    if sell is not None:sell[2]+=n
    elif len(orders)<10:orders.append(['SELL',item,n])
    else:return action
    return dict(action,market=orders)

_ALT_PARENT=agent
def agent(observation,configuration=None):
    seat,step=int(observation['player']),int(observation['step'])
    state=_ALT_STATE.get(seat)
    if state is None or step<=state['step']:
        mode=_ALT_MODE
        if mode=='Mixed':
            import random as _opening_random
            seed=(configuration or {}).get('seed',0)
            bit=_opening_random.Random('productive-opening:'+str(seed)+':'+str(seat)).getrandbits(1)
            mode='EarlyCycle' if bit else 'Original'
        _alt_install(mode)
        state=_ALT_STATE[seat]={'step':-1,'mode':mode}
        _ALT_REPORT.clear()
        _ALT_REPORT.update(selected_opening=mode,temporary_crop_seen=0,temporary_crop_harvested=0,
                           restored_pasture_seen=0,delivered_extra_wheat=0,tomato_seen=0,
                           tomato_water_requests=0,tomato_harvest_requests=0,tomato_units_harvest_requested=0,
                           extension_errors=0)
    action=_ALT_PARENT(observation,configuration)
    try:
        mode=state['mode']
        if mode!='Original':
            farm=observation['farms'][seat];private=observation['private']
            site=farm['tiles'][4][2]
            if step==6:_ALT_REPORT['temporary_crop_seen']=int(isinstance(site,dict) and site.get('crop')=='WHEAT')
            if step==54:
                _ALT_REPORT['temporary_crop_harvested']=int(private['inventories'][1].get('WHEAT',0))
            if step==55:_ALT_REPORT['restored_pasture_seen']=int(isinstance(site,dict) and site.get('kind')=='PASTURE')
            if step==57 and len(farm['hands'])>=1:
                if tuple(farm['hands'][0])==(4,4) and action.get('hands',[[]])[0]==['DROP']:
                    n=int(private['inventories'][1].get('WHEAT',0))
                    action=_alt_sell_extra(action,'WHEAT',n)
                    _ALT_REPORT['delivered_extra_wheat']=n
            if mode=='TomatoInsteadOfCow':
                tomato=farm['tiles'][4][4]
                if isinstance(tomato,dict) and tomato.get('crop')=='TOMATO' and tomato.get('planted_day')==0:
                    _ALT_REPORT['tomato_seen']=1
                    units=[list(action.get('farmer') or ['PASS'])]+[list(c) for c in action.get('hands',[])]
                    positions=[tuple(farm['farmer'])]+[tuple(p) for p in farm['hands']]
                    watered=bool(tomato.get('watered_today'));yield_left=int(tomato.get('yield_units',0))
                    for actor,pos in enumerate(positions):
                        if pos!=(4,4) or actor>=len(units):continue
                        if units[actor][0] not in ('FEED','CARE','COLLECT_FERTILIZER','HARVEST','WATER','PASS'):continue
                        if not watered:
                            units[actor]=['WATER'];watered=True
                            _ALT_REPORT['tomato_water_requests']+=1
                        elif yield_left>0:
                            units[actor]=['HARVEST']
                            _ALT_REPORT['tomato_harvest_requests']+=1
                            _ALT_REPORT['tomato_units_harvest_requested']+=yield_left
                            yield_left=0
                        else:units[actor]=['PASS']
                    action=dict(action,farmer=units[0],hands=units[1:])
                stock=int(private['shed'].get('TOMATO',0))
                scheduled=sum(int(o[2]) for o in action.get('market',[]) if len(o)>=3 and o[:2]==['SELL','TOMATO'])
                action=_alt_sell_extra(action,'TOMATO',max(0,stock-scheduled))
    except Exception:
        _ALT_REPORT['extension_errors']+=1
    state['step']=step
    return action
agent.telemetry=_ALT_REPORT
agent=globals().pop('agent')

kaggle_submission_agent = agent

_CL_INSTALL = _alt_install
_CL_REPORT = dict(cl_harvested=0, cl_pasture=0, cl_delivered=0, cl_errors=0)

def _alt_install(mode):
    _CL_INSTALL(mode)
    if mode not in ('EarlyCycle','HybridOpening'):
        return
    tape = _IMPL.chassis.routes[0]
    for step in range(53,58):
        tape[step]['hands'][0] = ['PASS']
    commands = [['EAST'],['EAST'],['WATER'],['HARVEST'],['BUILD_PASTURE'],['EAST'],['EAST'],['DROP']]
    for step, command in zip(range(84,92), commands):
        assert tape[step]['hands'][0] == ['PASS']
        tape[step]['hands'][0] = command

_CL_PARENT = agent
def agent(observation, configuration=None):
    step = int(observation['step'])
    if step == 0:
        for key in _CL_REPORT: _CL_REPORT[key] = 0
    action = _CL_PARENT(observation, configuration)
    try:
        seat = int(observation['player'])
        farm, private = observation['farms'][seat], observation['private']
        if step == 88:
            _CL_REPORT['cl_harvested'] = int(private['inventories'][1].get('WHEAT',0))
        if step == 89:
            tile = farm['tiles'][4][2]
            _CL_REPORT['cl_pasture'] = int(isinstance(tile,dict) and tile.get('kind')=='PASTURE')
        if step == 91 and farm['hands'] and tuple(farm['hands'][0]) == (4,4) and action['hands'][0] == ['DROP']:
            amount = int(private['inventories'][1].get('WHEAT',0))
            action = _alt_sell_extra(action,'WHEAT',amount)
            _CL_REPORT['cl_delivered'] = amount
    except Exception:
        _CL_REPORT['cl_errors'] += 1
    return action
agent.telemetry = _CL_REPORT
agent = globals().pop('agent')
kaggle_submission_agent = agent

_PG_PARENT=agent
def final_price_guard(observation, configuration=None):
    action=_PG_PARENT(observation, configuration)
    try:
        if int(observation["step"])==91:
            price=float(observation.get("market",{}).get("prices",{}).get("WHEAT",0))
            if price < 31:
                orders=[list(o) for o in action.get("market",[]) if not (len(o)>=3 and o[0]=="SELL" and o[1]=="WHEAT")]
                action=dict(action, market=orders)
    except Exception:
        pass
    return action
final_price_guard.telemetry={"sale_price_threshold":31}
kaggle_submission_agent=final_price_guard

V9_RACE_DEFAULT = 44
V9_RACE_MAX = 48

_E402_PARENT=final_price_guard
_E402_CACHE={}
_E402_REPORT=dict(cut_units=0,saved_cost=0,changed_turns=0,errors=0)

def _e402_remaining(native,step):
    route=native['route'];key=(route,step)
    if key in _E402_CACHE:return _E402_CACHE[key]
    need=0
    for t in range(step+1,719):
        tape=_IMPL.chassis.routes[2 if t>=648 else route]
        act=tape[t]
        need+=sum(1 for c in [act.get('farmer') or ['PASS']]+list(act.get('hands') or [])
                  if len(c)>1 and c[0]=='PLANT' and c[1] in ('WHEAT','CARROT'))
    _E402_CACHE[key]=need
    return need

def e402_agent(observation,configuration=None):
    action=_E402_PARENT(observation,configuration)
    try:
        step=int(observation['step']);seat=int(observation['player'])
        if step==0:
            _E402_CACHE.clear()
            for k in _E402_REPORT:_E402_REPORT[k]=0
        if step<624:return action
        market=action.get('market',[])
        if not any(len(o)>=3 and o[0]=='BUY_SEED' and o[1] in ('WHEAT','CARROT') for o in market):return action
        native=_IMPL.chassis.players[seat]
        remaining=_e402_remaining(native,step)
        remaining+=sum(1 for queue in native['pending'].values() for pos,c in queue
                       if len(c)>1 and c[0]=='PLANT' and c[1] in ('WHEAT','CARROT'))
        units=[action.get('farmer') or ['PASS']]+list(action.get('hands') or [])
        available={p:max(0,int(observation['private']['seeds'].get(p,0))-sum(c[:2]==['PLANT',p] for c in units)) for p in ('WHEAT','CARROT')}
        out=[];changed=False
        for o in market:
            if len(o)>=3 and o[0]=='BUY_SEED' and o[1] in available:
                p=o[1];qty=max(0,int(o[2]));keep=min(qty,max(0,remaining-available[p]));available[p]+=keep
                if keep<qty:
                    cut=qty-keep;changed=True
                    _E402_REPORT['cut_units']+=cut;_E402_REPORT['saved_cost']+=cut*(10 if p=='WHEAT' else 20)
                    if p=='CARROT':
                        st=_CA_STATE.get(seat)
                        if st is not None:st['spare_carrot']=max(0,st.get('spare_carrot',0)-cut)
                    o=[o[0],p,keep] if keep else []
            out.append(o)
        if changed:
            _E402_REPORT['changed_turns']+=1
            action=dict(action,market=out)
    except Exception:_E402_REPORT['errors']+=1
    return action

e402_agent.telemetry=_E402_REPORT
kaggle_submission_agent=e402_agent

_E410_REPORT=dict(skips=0,covered=0,capped=0,errors=0)
_E410_PARENT=e402_agent
def e410_agent(observation,configuration=None):
    action=_E410_PARENT(observation,configuration)
    try:
        step=int(observation['step']);seat=int(observation['player']);day=step//24
        if step==0:
            for k in _E410_REPORT:_E410_REPORT[k]=0
        units=[action.get('farmer') or ['PASS']]+list(action.get('hands') or [])
        if not any(c==['FERTILIZE'] for c in units):return action
        farm,private=_PLANNER_NS['_clone_state'](observation['farms'][seat],observation['private'])
        positions=[farm['farmer']]+list(farm['hands']);changed=False
        native=_IMPL.chassis.players[seat]
        expected=max(len(a.get('hands',[])) for a in _v219_native_day(native,day))
        reactive=set(_R51_INPUT_STATES.get(seat,{}).get('workers',{}))
        for i,cmd in enumerate(units[:len(positions)]):
            pos=tuple(positions[i]);tile=farm['tiles'][pos[1]][pos[0]]
            if cmd==['FERTILIZE'] and isinstance(tile,dict) and tile.get('crop') in ('WHEAT','CARROT') and private['inventories'][i].get('FERTILIZER',0)>0:
                until=int(tile.get('fertilized_until_day',-1));covered=until>=day+2;skip=covered
                if not skip and i<=expected and i not in reactive:
                    visits=_ca_visits(observation,action,pos,min(718,(int(tile['planted_day'])+6)*24),start=step+1)
                    kw=dict(y0=int(tile['yield_units']),watered_day=day if tile.get('watered_today') else -1,now_step=step)
                    old=_ca_yield_path(tile['crop'],int(tile['planted_day']),visits,fert_until=until,**kw)[0]
                    new=_ca_yield_path(tile['crop'],int(tile['planted_day']),visits,fert_until=max(until,day+2),**kw)[0]
                    skip=old>0 and old==new
                if skip:
                    units[i]=cmd=['PASS'];changed=True
                    _E410_REPORT['skips']+=1;_E410_REPORT['covered' if covered else 'capped']+=1
            _PLANNER_NS['_apply_unit_action'](farm,private,i,cmd,len(farm['tiles']),day,24,100)
        if changed:return dict(action,farmer=units[0],hands=units[1:])
    except Exception:
        _E410_REPORT['errors']+=1
    return action


agent = e410_agent

_IG_CASH = frozenset((
    "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL",
))
_IG_REPORT = {
    "opening_repairs": 0,
    "queue_changed_turns": 0,
    "zeroed_orders": 0,
    "pulled_orders": 0,
    "pulled_slots": 0,
    "errors": 0,
}


def _ig_standard(configuration):
    if configuration is None or not hasattr(configuration, "get"):
        return True
    return all(configuration.get(key, expected) == expected for key, expected in (
        ("boardSize", 10),
        ("turnsPerDay", 24),
        ("shedCapacity", 100),
        ("maxMarketOrdersPerTurn", 10),
    ))


def _ig_guard_opening(observation, action):
    """Restore the parent pasture command if the temporary wheat never exists."""
    if int(observation.get("step", -1)) != 29 or not isinstance(action, dict):
        return action
    seat = int(observation["player"])
    state = _ALT_STATE.get(seat)
    if not state or state.get("mode") != "HybridOpening":
        return action
    farm = observation["farms"][seat]
    site = farm["tiles"][4][2]
    valid_wheat = (
        isinstance(site, dict) and site.get("kind") == "PLANT" and
        site.get("crop") == "WHEAT" and int(site.get("planted_day", -1)) == 0
    )
    if valid_wheat:
        return action
    hands = [list(command) for command in (action.get("hands") or [])]
    if len(hands) <= 2 or hands[2] != ["WATER"]:
        return action
    hands[2] = ["BUILD_PASTURE"]
    _IG_REPORT["opening_repairs"] += 1
    return dict(action, hands=hands)


def _ig_close_queue(observation, action):
    """Turn final cash-sale no-ops into holes and fill holes from the right."""
    if not isinstance(action, dict):
        return action
    market = action.get("market") or []
    if len(market) < 2:
        return action
    projected = dict(projected_shed(action, FarmView(observation)))
    remaining = {item: max(0, int(projected.get(item, 0))) for item in _IG_CASH}
    revised = []
    zeroed = 0
    for raw in market:
        order = list(raw) if isinstance(raw, (list, tuple)) else raw
        if (isinstance(order, list) and len(order) >= 3 and
                order[0] == "SELL" and order[1] in _IG_CASH):
            requested = max(0, int(order[2]))
            executed = min(requested, remaining[order[1]])
            remaining[order[1]] -= executed
            if executed <= 0:
                revised.append([])
                zeroed += 1
            else:
                revised.append(order)
        else:
            revised.append(order)

    holes = []
    pulled = 0
    distance = 0
    for index, order in enumerate(revised):
        if not order:
            holes.append(index)
            continue
        movable = (
            isinstance(order, list) and len(order) >= 3 and
            order[0] == "SELL" and order[1] in _IG_CASH and int(order[2]) > 0
        )
        if not movable or not holes:
            continue
        target = holes.pop(0)
        revised[target] = order
        revised[index] = []
        holes.append(index)
        pulled += 1
        distance += index - target

    if revised == market:
        return action
    _IG_REPORT["queue_changed_turns"] += 1
    _IG_REPORT["zeroed_orders"] += zeroed
    _IG_REPORT["pulled_orders"] += pulled
    _IG_REPORT["pulled_slots"] += distance
    return dict(action, market=revised)


_IG_PARENT = agent
del agent


def agent(observation, configuration=None):
    if int(observation.get("step", 0)) == 0:
        for key in _IG_REPORT:
            _IG_REPORT[key] = 0
    action = _IG_PARENT(observation, configuration)
    try:
        if _ig_standard(configuration):
            action = _ig_guard_opening(observation, action)
            action = _ig_close_queue(observation, action)
    except Exception:
        _IG_REPORT["errors"] += 1
    return action


agent.telemetry = _IG_REPORT
agent = globals().pop("agent")

kaggle_submission_agent = agent


_CXTB_PARENT = [v for v in list(globals().values()) if callable(v)][-1]

_CXTB_MIN_REVENUE = 9000    # coins the 80 units must be worth before committing
_CXTB_THEIR_UNITS = 0.75    # units a day per rival tomato tile (measured)
_CXTB_DRAIN_SLACK = 2.4     # units a day the town does not take after all (measured)
_CXTB_OUR_UNITS = 20        # ten tiles, days 26..29 (measured: 60..80 units in total)
_CXTB_HARVEST_DAYS = (26, 27, 28, 29)
_CXTB_REPORT = {'cxtb_calls': 0, 'cxtb_opened': 0, 'cxtb_blocked': 0, 'cxtb_errors': 0,
                'cxtb_features': []}

_CXTB_BASE_QUALIFIES = _v219_qualifies


def _cxtb_their_supply(obs, upto):
    """What the rival's tomato tiles will put into the market, day by day.

    TOMATO is an ongoing crop and yields from planted_day + 8.  `planted_day` is on the
    public tile, so the start of each plant is read rather than guessed; the rate is the
    measured one and runs to the end of the season, because an opponent who is growing
    tomatoes at day 18 replants as the plants die.
    """
    supply = {}
    them = obs['farms'][1 - obs['player']]
    for row in them['tiles']:
        for t in row:
            if isinstance(t, dict) and t.get('crop') == 'TOMATO':
                for d in range(int(t.get('planted_day', 0)) + 8, upto + 1):
                    supply[d] = supply.get(d, 0.0) + _CXTB_THEIR_UNITS
    return supply


def _cxtb_expected_revenue(obs):
    """Price our 80 units against the inventory they will meet."""
    inventory = float(obs['market']['inventory']['TOMATO'])
    day = int(obs['step']) // 24
    shops = float(sum(s in ('PIZZA_SHOP', 'FARMERS_MARKET')
                      for s in obs['town']['unlocked_shops']))
    pending = {22: 0.25, 24: 0.25}
    last = max(_CXTB_HARVEST_DAYS)
    theirs = _cxtb_their_supply(obs, last)
    revenue = 0.0
    for d in range(day, last + 1):
        shops += pending.get(d, 0.0)
        inventory -= 1.0 + 6.0 * shops - _CXTB_DRAIN_SLACK
        inventory += theirs.get(d, 0.0)
        if d in _CXTB_HARVEST_DAYS:
            for _ in range(_CXTB_OUR_UNITS):
                revenue += _r37_market_price('TOMATO', int(round(inventory)))
                inventory += 1
    return revenue


def _cxtb_qualifies(obs, native):
    """The author's qualification with the shop count and price floor replaced by the value."""
    farm = obs['farms'][obs['player']]
    if len(farm['tiles']) != 10 or set(farm['unlocked_quadrants']) != {'NW', 'NE', 'SW'}:
        return False
    if farm['money'] < 12000:
        return False
    if _cxtb_expected_revenue(obs) < _CXTB_MIN_REVENUE:
        return False
    if any(farm['tiles'][y][x] != 'LOCKED' for y in (5, 6) for x in range(5, 10)):
        return False
    if obs['private']['seeds'].get('TOMATO', 0) or obs['private']['shed'].get('TOMATO', 0):
        return False
    if any(isinstance(t, dict) and t.get('crop') == 'TOMATO' for row in farm['tiles'] for t in row):
        return False
    for tape in _IMPL.chassis.routes.values():
        for a in tape[432:719]:
            if any(o and o[0] == 'BUY_LAND' for o in a.get('market', [])):
                return False
            if any(c == ['PLANT', 'TOMATO'] for c in [a.get('farmer')] + a.get('hands', [])):
                return False
    return True


def _v219_qualifies(obs, native):
    """The name the agent looks up at step 432."""
    _CXTB_REPORT['cxtb_calls'] += 1
    try:
        revenue = _cxtb_expected_revenue(obs)
        ok = _cxtb_qualifies(obs, native)
        them = obs['farms'][1 - obs['player']]
        _CXTB_REPORT['cxtb_features'].append({
            'opened': bool(ok), 'base': bool(_CXTB_BASE_QUALIFIES(obs, native)),
            'revenue': round(revenue),
            'shops': sum(s in ('PIZZA_SHOP', 'FARMERS_MARKET')
                         for s in obs['town']['unlocked_shops']),
            'price': obs['market']['prices']['TOMATO'],
            'inventory': obs['market']['inventory']['TOMATO'],
            'their_tomatoes': sum(1 for row in them['tiles'] for t in row
                                  if isinstance(t, dict) and t.get('crop') == 'TOMATO'),
        })
        _CXTB_REPORT['cxtb_opened' if ok else 'cxtb_blocked'] += 1
        return ok
    except Exception:
        _CXTB_REPORT['cxtb_errors'] += 1
        return _CXTB_BASE_QUALIFIES(obs, native)




def _cxtb_agent(observation, configuration=None):
    return _CXTB_PARENT(observation, configuration)


_cxtb_agent.telemetry = _CXTB_REPORT

import itertools as _cxd_it
_CXD_HOST = [v for v in list(globals().values()) if callable(v)][-1]
_CXD_FIXED = ('HIRE', 'BUY_SEED', 'BUY_ANIMAL', 'BUY_LAND')
_CXD_BUDGET = 800
_CXD_FROM = 0
_CXD_REPORT = {'cxd_turns': 0, 'cxd_gain': 0.0, 'cxd_evals': 0, 'cxd_budget_hits': 0, 'cxd_errors': 0}
_CXD_MODELS = []
_CXD_PARENT_ORDERS = []


def _cxd_candidates(orders, slots, sells, fixed):
    """Orderings of `sells` over `slots`, fixed-price orders filling the rest in their own order."""
    for positions in _cxd_it.permutations(slots, len(sells)):
        out = list(orders)
        rest = [i for i in slots if i not in positions]
        for i, order in zip(positions, sells):
            out[i] = order
        for i, order in zip(rest, fixed):
            out[i] = order
        yield out


def _cxd_reorder(obs, action):
    market = action.get('market') or []
    if len(market) < 2:
        return action
    orders = [list(o) if isinstance(o, (list, tuple)) else o for o in market]
    bought = {o[1] for o in orders if o and len(o) > 1 and o[0] == 'BUY_PRODUCT'}
    slots, sells, fixed = [], [], []
    for i, o in enumerate(orders):
        if not o:
            continue
        if o[0] in _CXD_FIXED:
            slots.append(i); fixed.append(o)
        elif o[0] == 'SELL' and len(o) > 1 and o[1] not in bought:
            slots.append(i); sells.append(o)
    if not sells or len(slots) < 2:
        return action
    params = _v44y_params(obs)
    stock = {k: max(0, int(v)) for k, v in projected_shed(action, FarmView(obs)).items()}
    inv0 = {k: int(v) for k, v in obs['market']['inventory'].items()}
    _CXD_PARENT_ORDERS[:] = [list(o) for o in orders if o]
    models = [m for m in _CXD_MODELS if m] or [orders]
    margins = [_v44y_factor_margin(m, inv0, stock, params) for m in models]

    def margin(cand):
        return min(f(cand) for f in margins)
    base = best = margin(orders)
    best_orders = None
    evals = 0
    for cand in _cxd_candidates(orders, slots, sells, fixed):
        if cand == orders:
            continue
        evals += 1
        if evals > _CXD_BUDGET:
            _CXD_REPORT['cxd_budget_hits'] += 1
            break
        value = margin(cand)
        if value > best + 0.5:
            best, best_orders = value, cand
    _CXD_REPORT['cxd_evals'] += evals
    if best_orders is None:
        return action
    _CXD_REPORT['cxd_turns'] += 1
    _CXD_REPORT['cxd_gain'] += best - base
    return dict(action, market=best_orders)


def _cxd_agent(observation, configuration=None):
    action = _CXD_HOST(observation, configuration)
    try:
        if int(observation.get('step', 0)) == 0:
            _CXD_REPORT.update(cxd_turns=0, cxd_gain=0.0, cxd_evals=0, cxd_budget_hits=0, cxd_errors=0)
        if int(observation.get('step', 0)) >= _CXD_FROM:
            return _cxd_reorder(observation, action)
    except Exception:
        _CXD_REPORT['cxd_errors'] += 1
    return action


_TL_PARENT = _cxd_agent
_TL_PRODUCTS = ("WOOL", "MILK", "EGG", "MELON", "STRAWBERRY", "TOMATO", "CARROT", "WHEAT", "FERTILIZER")
_TL_SEED_COSTS = {"WHEAT": 10, "CARROT": 20, "TOMATO": 50, "STRAWBERRY": 100, "MELON": 80}

def _terminal_liquidation_agent(observation, configuration=None):
    action = _TL_PARENT(observation, configuration)
    try:
        step = int(observation.get("step", 0))
        seat = int(observation.get("player", 0))
        farm = observation.get("farms", [])[seat]
        priv = observation.get("private", {}) or {}
        shed = priv.get("shed", {}) or {}
        money = float(farm.get("money", 0))

        if step < 24 and isinstance(action, dict):
            market = list(action.get("market") or [])
            CASH_BUFFER = 15.0
            changed = False
            for i, order in enumerate(market):
                if order and len(order) >= 3 and order[0] == "BUY_SEED":
                    seed_cost = _TL_SEED_COSTS.get(order[1], 10)
                    qty = int(order[2])
                    total_cost = qty * seed_cost
                    if money - total_cost < CASH_BUFFER:
                        max_affordable = max(0, int((money - CASH_BUFFER) // seed_cost))
                        if max_affordable < qty:
                            market[i] = [order[0], order[1], max_affordable] if max_affordable > 0 else []
                            money -= max_affordable * seed_cost
                            changed = True
                        else:
                            money -= total_cost
                    else:
                        money -= total_cost
            if changed:
                action = dict(action, market=market)

        if step in (623, 671) and isinstance(action, dict):
            orders = list(action.get("market") or [])
            fert = max(0, int(shed.get("FERTILIZER", 0)))
            if fert > 0 and len(orders) < 10:
                drain = min(fert, 10)
                orders.append(["SELL", "FERTILIZER", drain])
                action = dict(action, market=orders)

        if (step in (671, 695) or step >= 716) and isinstance(action, dict):
            orders = list(action.get("market") or [])
            planned = {p: 0 for p in _TL_PRODUCTS}
            for o in orders:
                if len(o) >= 3 and o[0] == "SELL" and o[1] in planned:
                    planned[o[1]] += int(o[2])

            unscheduled = []
            for p in _TL_PRODUCTS:
                avail = max(0, int(shed.get(p, 0)))
                extra = avail - planned.get(p, 0)
                if extra > 0:
                    unscheduled.append([p, extra])

            if unscheduled:
                changed = False
                for i in range(len(orders)):
                    if (not orders[i] or orders[i] == []) and unscheduled:
                        item = unscheduled[0]
                        sell_qty = min(item[1], 100)
                        orders[i] = ["SELL", item[0], sell_qty]
                        item[1] -= sell_qty
                        if item[1] <= 0:
                            unscheduled.pop(0)
                        changed = True
                while unscheduled and len(orders) < 10:
                    item = unscheduled[0]
                    sell_qty = min(item[1], 100)
                    orders.append(["SELL", item[0], sell_qty])
                    item[1] -= sell_qty
                    if item[1] <= 0:
                        unscheduled.pop(0)
                    changed = True
                if changed:
                    action = dict(action, market=orders)

    except Exception:
        pass
    return action

agent = _terminal_liquidation_agent
kaggle_submission_agent = agent


