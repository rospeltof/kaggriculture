"""Registered loop30 development: fixed initial wheat quantity on two parents."""
from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import tarfile
import time

from auditar_forecast_pareado_real import inspect_env
from construir_apertura12 import OUT as AGENTS, EVIDENCE as OUT
from sonda_fallo_forecast import run


def packed(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def main():
    assert os.environ.get('PYTHONHASHSEED') == '0'
    panel = json.loads((OUT / 'close_panel_manifest.json').read_text())
    manifest = json.loads((AGENTS / 'manifest.json').read_text())
    arms = dict(base=panel['controls']['base'], top3=panel['controls']['top3'], **manifest)
    rivals = {n: panel['pilot_pool'][n] for n in ('mirror_vq','public_v7')}
    for rival in rivals.values():
        assert hashlib.sha256(Path(rival['path']).read_bytes()).hexdigest() == rival['sha256']
    plan = dict(seeds=[1077000, 362118074], seats=[0, 1],
                expected_games=48, runtime_hash_seed='0', opponents=rivals, agents=arms,
                purpose='Opening BUY12/SELL7 preserves net wheat5. Two reactive opponents, exact noops, physical accounting, no reward selection.')
    target = OUT / 'opening12_smoke.json'; plan_path = OUT / 'opening12_smoke.plan.json'
    assert not target.exists() and not plan_path.exists()
    plan_path.write_text(json.dumps(plan, indent=2) + '\n')
    with tarfile.open(OUT / 'opening12_smoke.sources.tgz', 'x:gz') as archive:
        for name, spec in arms.items():
            archive.add(spec['path'], arcname=f'agents/{name}.py')
        for name, rival in rivals.items():
            archive.add(rival['path'], arcname='opponents/'+name+'.py')
        archive.add(__file__, arcname=Path(__file__).name)
    engine = importlib.import_module('kaggle_environments.envs.kaggriculture.kaggriculture')
    original_unit = engine._apply_unit_action; original_night = engine._end_of_day
    baseline = {}; results = []
    for rival_name, rival in rivals.items():
        for seed in plan['seeds']:
            for name, spec in arms.items():
                for seat in plan['seats']:
                    path = spec['path']; raw = Path(path).read_bytes()
                    assert hashlib.sha256(raw).hexdigest() == spec['sha256']
                    ns = {}; exec(compile(raw, path, 'exec'), ns)
                    entry = [v for v in ns.values() if callable(v)][-1]
                    elapsed = []; units = []; nights = []
                    accepted = Counter(); harvest = Counter()

                    def agent(obs, config=None):
                        start = time.perf_counter(); action = entry(obs, config)
                        elapsed.append(1000 * (time.perf_counter()-start))
                        return action

                    def unit(farm, private, actor, command, *args, **kwargs):
                        frame = sys._getframe(1)
                        watch = (frame.f_code is engine.interpreter.__code__ and frame.f_locals.get('i') == seat
                                 and command and command[0] in ('FEED', 'CARE', 'HARVEST', 'FERTILIZE', 'PLANT'))
                        if watch:
                            x, y = farm['farmer'] if actor == 0 else farm['hands'][actor-1]
                            tile = deepcopy(farm['tiles'][y][x]); before = dict(private['inventories'][actor])
                            seeds_before = dict(private['seeds'])
                        result = original_unit(farm, private, actor, command, *args, **kwargs)
                        if watch:
                            after = private['inventories'][actor]
                            delta = {k: after.get(k, 0)-before.get(k, 0) for k in set(before)|set(after)}
                            subject = (tile.get('animal') or tile.get('crop') or tile.get('kind')) if isinstance(tile, dict) else None
                            if command[0] == 'HARVEST':
                                gain = {k: v for k, v in delta.items() if v > 0}; harvest.update(gain); ok = bool(gain)
                            elif command[0] == 'FEED': ok = delta.get('WHEAT', 0) < 0
                            elif command[0] == 'FERTILIZE': ok = delta.get('FERTILIZER', 0) < 0
                            elif command[0] == 'PLANT': ok = seeds_before != private['seeds']
                            else:
                                new = farm['tiles'][y][x]
                                ok = isinstance(tile, dict) and isinstance(new, dict) and not tile.get('cared_today') and new.get('cared_today')
                            if ok: accepted[command[0]+':'+str(subject)] += 1
                            units.append(dict(step=frame.f_locals['step'], actor=actor, command=deepcopy(command),
                                              xy=[x,y], accepted=bool(ok), delta={k: v for k, v in delta.items() if v}))
                        return result

                    def night(state, env, day):
                        private = deepcopy(state[seat].observation.private); before = Counter(private['shed'])
                        for bag in private['inventories']: before.update(bag)
                        result = original_night(state, env, day)
                        nights.append(dict(step=day*24+23, loss=dict(before-Counter(state[seat].observation.private['shed']))))
                        return result

                    engine._apply_unit_action, engine._end_of_day = unit, night
                    try: env, ledger = run(agent, rival['path'], seed, seat)
                    finally: engine._apply_unit_action, engine._end_of_day = original_unit, original_night
                    actions = [[s.action for s in row] for row in env.steps[1:]]
                    rewards = [s.reward for s in env.steps[-1]]
                    shops = [row[0].observation['town'] for row in env.steps]
                    if name in ('base', 'top3'):
                        baseline[name, seed, seat] = dict(actions=deepcopy(actions), rewards=rewards, shops=shops)
                    parent = spec.get('behavior_reference', name)
                    reference = baseline[parent, seed, seat]
                    if name.startswith('open_noop'):
                        assert actions == reference['actions'] and rewards == reference['rewards']
                    reports = {k: deepcopy(ns.get(k, {})) for k in ('_OPN_REPORT','_VQ_REPORT','_V92_P_REPORT','_R127_REPORT')}
                    assert not any(v for d in reports.values() for k,v in d.items() if 'error' in k and isinstance(v,(int,float)))
                    result = dict(arm=name, opponent=rival_name, seed=seed, seat=seat, source_sha256=spec['sha256'],
                                  action_hashes=[hashlib.sha256(b'\n'.join(packed(a[p]) for a in actions)+b'\n').hexdigest() for p in (0,1)],
                                  max_turn_ms=max(elapsed), reports=reports, edits=deepcopy(ns.get('_OPN_EVENTS', [])), daily_min_cash=deepcopy(ns.get('_OPN_DAILY_MIN', {})),
                                  changed_own_turns=sum(a[seat] != b[seat] for a,b in zip(actions,reference['actions'])),
                                  changed_rival_turns=sum(a[1-seat] != b[1-seat] for a,b in zip(actions,reference['actions'])),
                                  same_shops=shops == reference['shops'], accepted=dict(accepted), harvested=dict(harvest),
                                  nights=nights, **inspect_env(env,ledger,seat))
                    for kind, data in [('ledger',ledger),('units',units)]:
                        (OUT / f'opening12_smoke.{rival_name}.{seed}.{name}.{seat}.{kind}.jsonl.gz').write_bytes(
                            gzip.compress(b'\n'.join(packed(r) for r in data)+b'\n',mtime=0))
                    results.append(result)
                    print(json.dumps({k:result[k] for k in ('arm','opponent','seed','seat','changed_own_turns','same_shops','max_turn_ms')}),flush=True)
    assert len(results) == 48
    target.write_text(json.dumps(dict(plan=plan,results=results),indent=2)+'\n')


if __name__ == '__main__':
    main()
